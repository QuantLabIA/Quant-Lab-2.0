# Roadmap de desarrollo — QuantLab AI Web

**Proyecto:** QuantLab AI 5.0 Beta Integrada  
**Versión actual:** 5.0.0 Beta 1 — Integración completa del núcleo  
**Última actualización:** 1 de agosto de 2026  
**Estado general:** BETA INTEGRADA Y VERIFICADA. Alpha 1.4, Alpha 1.5 y Alpha 1.6 están acumuladas en un único proyecto. Próximo paso: prueba real y diseño de usuarios/nube.

---

## Cómo utilizar este archivo

- `[x]` Terminado y comprobado.
- `[ ]` Pendiente.
- `EN CURSO` Versión que se está desarrollando.
- `POSTERGADO` Se realizará después de las dependencias indicadas.

**Regla del proyecto:** no avanzar de versión hasta completar funciones críticas, migraciones, pruebas, documentación y paquete instalable.

---

# 0. QuantLab AI 5.0 Beta — Integración completa

**Estado:** COMPLETADA Y VERIFICADA  
**Esquema:** 15  
**Suite:** 114 pruebas automatizadas

- [x] Un único ZIP reemplaza todas las fases descargables.
- [x] Mercado, portafolio, Analytics, dividendos, eventos, agente, alertas y memoria integrados.
- [x] `iniciar_windows.bat` inicia el proyecto completo.
- [x] `verificar_windows.bat` ejecuta diagnóstico y pruebas.
- [x] README y guía de instalación reescritos para instalación desde cero.
- [x] Datos, logs y backups de prueba excluidos del paquete.
- [x] Documentación histórica conservada dentro de `docs/`.
- [x] Auditoría de cursos incluida sin redistribuir los archivos originales.
- [x] Versión de producto actualizada a `5.0.0-beta.1-integrated`.

**Regla de releases desde esta versión:** cada entrega futura será completa. Para actualizar datos se usará `.qlbackup` o `data/quantlab.db`; nunca se mezclarán carpetas de código entre versiones.

---

# 1. Base consolidada

## Mercado y datos

- [x] Cotizaciones e históricos mediante `yfinance`.
- [x] Búsqueda por ticker o nombre.
- [x] Acciones, ETF, fondos, criptomonedas, divisas, índices y futuros.
- [x] Conversión FX actual e histórica.
- [x] Caché, reintentos y estados de calidad.
- [x] Precio manual de respaldo.
- [x] Alias para cambios de ticker.
- [x] Proveedor de mercado desacoplado para una API profesional futura.

## Portafolio

- [x] Múltiples portafolios aislados.
- [x] Compras y ventas fraccionarias.
- [x] Comisiones, costo promedio, P&L realizado y no realizado.
- [x] Depósitos, retiros, dividendos, intereses, impuestos y gastos.
- [x] Activos automáticos y manuales.
- [x] Portafolio y efectivo multimoneda.
- [x] Conversiones FX auditables.
- [x] XIRR y TWR educativo inicial.
- [x] Edición segura, vista previa y auditoría.
- [x] Borrado lógico y restauración.
- [x] Importación/exportación CSV.
- [x] Backup `.qlbackup` y restauración validada.

## Plataforma

- [x] Frontend HTML, CSS y JavaScript responsive.
- [x] Backend FastAPI y Python.
- [x] SQLite local.
- [x] API oficial `/api/v1`.
- [x] Migraciones idempotentes y en orden.
- [x] Errores seguros, request ID y logs estructurados.
- [x] Variables de entorno y CORS configurable.
- [x] Iniciador `iniciar_windows.bat`.
- [x] Indicadores de carga, filtros, ordenamiento y tema claro/oscuro.

---

# 2. Alpha 1.4 — Consolidación del núcleo

**Estado:** COMPLETADA Y VERIFICADA  
**Esquema final:** 8

## Fase 1 — Múltiples portafolios

- [x] Tabla `portfolios`.
- [x] `portfolio_id` en datos financieros.
- [x] Crear, seleccionar, renombrar, archivar y restaurar.
- [x] Moneda base y capital inicial independientes.
- [x] Preparación de `user_id` sin activar usuarios.

## Fase 2 — Edición segura

- [x] Editar operaciones y movimientos.
- [x] Recalcular eventos posteriores.
- [x] Vista previa del impacto.
- [x] Rechazar secuencias inválidas.
- [x] Eliminación lógica, restauración y auditoría.

## Fase 3 — Tesorería multimoneda

- [x] Caja separada por moneda.
- [x] Compras financiadas con la moneda real del activo.
- [x] Conversiones FX automáticas o manuales.
- [x] Comisiones y P&L FX.
- [x] Margen opcional y desactivado por defecto.

## Fase 4 — Portabilidad

- [x] CSV genérico con vista previa.
- [x] Errores parciales o modo estricto.
- [x] Detección de duplicados.
- [x] Exportaciones por conjunto de datos.
- [x] Backups con manifiesto y checksum.
- [x] Restauración atómica con backup previo.

## Fase 5 — Estabilidad de plataforma

- [x] API `/api/v1` y compatibilidad temporal heredada.
- [x] Capa `MarketDataProvider`.
- [x] Calidad y antigüedad de cotizaciones.
- [x] Fallback manual y alias de ticker.
- [x] Manejo global de errores.
- [x] Logs JSON, CORS y configuración por entorno.
- [x] Experiencia móvil, accesibilidad básica y temas.
- [x] Pruebas de cierre de Alpha 1.4.

---

# 3. Alpha 1.5 — Analytics y riesgo

**Estado:** COMPLETADA Y VERIFICADA  
**Esquema final:** 12  
**Dependencia:** Alpha 1.4 completa.  
**Objetivo:** medir rendimiento, riesgo, diversificación y eventos financieros con cálculos trazables antes de conectar el agente AI.

## Fase 1 — Rendimiento, benchmark y riesgo

**Estado:** COMPLETADA

### Rendimiento

- [x] Retorno TWR diario neutralizado por depósitos y retiros.
- [x] Rentabilidad diaria.
- [x] Rentabilidad del mes actual.
- [x] Rentabilidad del año actual.
- [x] Rentabilidad del período seleccionado.
- [x] Rentabilidad desde el inicio.
- [x] Períodos 1 mes, 3 meses, 6 meses, 1 año, 2 años, 5 años y máximo.
- [x] Rendimiento por posición.
- [x] Resultado realizado, no realizado y dividendos por posición.
- [x] Descomposición general del resultado.
- [x] Separar precio y efecto FX en posiciones abiertas; el realizado histórico permanece combinado y documentado.

### Benchmark

- [x] Configuración independiente por portafolio.
- [x] SPY, QQQ, `^MERV`, BTC-USD y símbolo personalizado.
- [x] Opción sin benchmark.
- [x] Comparación acumulada en base 100.
- [x] Diferencia de rendimiento.
- [x] Alineación de calendarios.
- [x] Conversión histórica a la moneda base.
- [x] Estados parciales cuando faltan datos.

### Riesgo

- [x] Volatilidad anualizada.
- [x] Drawdown máximo.
- [x] Drawdown actual.
- [x] Curva de drawdown.
- [x] Mejor y peor día.
- [x] Ratio de Sharpe educativo.
- [x] Tasa libre de riesgo configurable.
- [x] Concentración por activo.
- [x] Concentración por moneda.
- [x] Concentración por tipo de activo.
- [x] HHI y puntaje educativo de diversificación.
- [x] Concentración por sector e industria con cobertura parcial y fuente visible.
- [x] Correlaciones y covarianzas entre posiciones con históricos alineados.
- [x] Beta, tracking error, alpha e information ratio contra benchmark.
- [x] VaR/CVaR histórico educativo con metodología validada y documentada.

### Plataforma y validación

- [x] Tabla `portfolio_analytics_settings`.
- [x] Migración de esquema 9 con backup previo.
- [x] API `/api/v1/analytics`.
- [x] Pantalla Analytics responsive.
- [x] Gráficos SVG sin dependencia de Node en producción.
- [x] Resultados y metodología documentados.
- [x] Aviso de uso educativo.
- [x] Inventario de reutilización de cursos.

## Fase 2 — Dividendos y calendario

**Estado:** COMPLETADA

- [x] Dividendo bruto.
- [x] Retención impositiva.
- [x] Dividendo neto.
- [x] Moneda y FX del cobro.
- [x] Reinversión de dividendos con compra vinculada.
- [x] Eliminación y restauración sincronizada del dividendo y su compra vinculada.
- [x] Rendimiento por dividendos y yield sobre costo/valor.
- [x] Historial y calendario.
- [x] Próximas fechas estimadas claramente diferenciadas de hechos confirmados.
- [x] Evitar doble importación.
- [x] Reporte por activo y portafolio.
- [x] Exportación CSV específica.
- [x] Preferencias independientes por portafolio.
- [x] Migración de esquema 10 con backup previo.
- [x] Pruebas de bruto, retención, reinversión, importación y API.

## Fase 3 — Eventos corporativos

**Estado:** COMPLETADA

- [x] Split.
- [x] Reverse split.
- [x] Cambio de ticker formal dentro del ledger y alias de mercado.
- [x] Fusión por intercambio de acciones.
- [x] Spin-off con asignación porcentual de costo.
- [x] Dividendo en acciones.
- [x] Devolución de capital y exceso sobre costo.
- [x] Vista previa, corrección, auditoría, eliminación lógica y restauración.
- [x] Replay cronológico integrado al portafolio y a la curva patrimonial.
- [x] Verificar que cantidad, costo total y patrimonio no cambien incorrectamente.
- [x] Migración al esquema 11 con backup previo.
- [x] 85 pruebas automatizadas del release completo.

## Fase 4 — Analytics avanzado y visualización

**Estado:** COMPLETADA EN ESTE RELEASE

- [x] Concentración por sector e industria con cobertura parcial visible.
- [x] Comparador de dos a seis activos en moneda base.
- [x] Correlación, covarianza y matriz de diversificación.
- [x] Beta, tracking error, alpha, information ratio y captura de mercados.
- [x] Atribución precio/FX/dividendos por posición abierta; realizado histórico documentado como combinado.
- [x] Gráficos SVG con zoom temporal y tooltips.
- [x] Exportación CSV de métricas, posiciones, riesgo y alertas.
- [x] Resumen de riesgo estructurado para el futuro agente AI.

## Cierre de Alpha 1.5

- [x] Métricas verificadas con series controladas y casos de referencia internos.
- [x] TWR neutraliza aportes y retiros.
- [x] Benchmark alineado con la curva TWR y convertido a moneda base.
- [x] Eventos corporativos no alteran incorrectamente costo o patrimonio.
- [x] Dividendos brutos/netos y reinversiones son auditables.
- [x] Analytics avanzado responde correctamente con datos parciales.
- [x] Resultados explicados como métricas educativas, no asesoramiento.
- [x] Documentación y 92 pruebas completas de Alpha 1.5.

---

# 4. Reutilización de cursos y proyectos previos

**Registro detallado:** `docs/REUTILIZACION_CURSOS.md`

## Incorporado

- [x] `pandas` para series temporales y alineación.
- [x] `numpy` para estadística y cálculos vectorizados.
- [x] `yfinance` para históricos, benchmark y FX.
- [x] Arquitectura por servicios y modelos.
- [x] HTML/CSS/JavaScript y `fetch()` para la web.
- [x] Conceptos de disciplina, proceso y control del riesgo del curso de trader.

## Evaluado

- [x] Plotly del proyecto previo como referencia visual.
- [x] Código Flet: no se reutiliza en la interfaz, sólo se rescata lógica independiente.
- [x] Streamlit: descartado como frontend principal.

## Archivos originales auditados y pendientes

- [x] Curso de trading cuantitativo: métricas, optimización, indicadores y backtesting recuperados parcialmente.
- [x] Curso del profesor chileno: riesgo, VaR, portafolios, GARCH e indicadores.
- [x] Estrategias del profesor: pares, cointegración, PCA, clustering y modelos experimentales inventariados.
- [x] Paquete “por las dudas”: plantillas, históricos y estrategias inventariados.
- [ ] Redes neuronales: el último notebook del ZIP está dañado; se espera una copia íntegra.
- [ ] Desarrollo web: el RAR fue inventariado; se espera una nueva copia ZIP para auditoría línea por línea.
- [ ] Bot de Telegram y software cripto: revisar antes de una futura fase de alertas/paper trading.

**Regla:** no afirmar que un código fue reciclado hasta localizarlo, revisarlo, adaptarlo y probarlo.

---

# 5. Alpha 1.6 — Agente AI financiero

**Estado:** COMPLETADA — Fases 1, 2 y 3 cerradas y verificadas  
**Dependencia:** Alpha 1.5 completa y métricas confiables.

## Fase 1 — Herramientas y trazabilidad — COMPLETADA

### Herramientas internas

- [x] Consultar cotizaciones y calidad del dato.
- [x] Calcular indicadores técnicos.
- [x] Consultar posiciones, movimientos y eventos.
- [x] Consultar Analytics y riesgo.
- [x] Comparar activos y benchmark.
- [x] Registrar fuentes, fechas, tiempos y herramientas usadas.

### Capacidades entregadas

- [x] Análisis técnico explicado.
- [x] Comparación entre activos.
- [x] Análisis completo del portafolio.
- [x] Detección de concentración y riesgo.
- [x] Resumen de rendimiento.
- [x] Historial de análisis aislado por portafolio.
- [x] Planificador automático de intención.
- [x] Calidad completa, parcial o no disponible.

### Seguridad AI

- [x] Separar hechos, cálculos e interpretación.
- [x] No inventar precios, noticias o indicadores.
- [x] Mostrar datos faltantes y límites.
- [x] Evitar órdenes directas de compra o venta.
- [x] No permitir modificaciones financieras desde el agente.
- [x] Pruebas contra fallas, datos parciales e inconsistencias.

## Fase 2 — Fundamentos y conversación — COMPLETADA

- [x] Análisis fundamental básico con campos disponibles y fecha de fuente.
- [x] Preguntas de seguimiento dentro de una sesión.
- [x] Comparación fundamental entre empresas.
- [x] Explicación más flexible sin alterar los cálculos.
- [x] Resumen de tesis favorable, riesgos y datos faltantes.
- [x] Proveedor opcional de modelo de lenguaje detrás de una interfaz.
- [x] Respuesta determinística como fallback obligatorio.

## Fase 3 — Alertas educativas y memoria — COMPLETADA

- [x] Reglas de alerta por concentración, drawdown, volatilidad y precios.
- [x] Alertas revisables, sin ejecución automática.
- [x] Memoria de análisis y cambios desde la última consulta.
- [x] Registro de alertas atendidas o descartadas.
- [x] Resolución automática cuando la condición deja de cumplirse.
- [x] Snapshots estructurados independientes de la redacción generativa.
- [x] Cola interna preparada para notificaciones futuras.
- [x] Modelo de lenguaje conservado como opcional y desactivado por defecto.

### Criterios de cierre de Alpha 1.6

- [x] El agente consulta únicamente herramientas verificables.
- [x] Hechos, cálculos, interpretación y límites permanecen separados.
- [x] Fundamentos y comparaciones informan cobertura y datos faltantes.
- [x] La memoria compara métricas estructuradas, no texto libre.
- [x] Las alertas no modifican el portafolio ni envían órdenes.
- [x] La preparación de notificaciones no ejecuta tareas en segundo plano.
- [x] Migración al esquema 15 y backup previo comprobados.
- [x] Suite completa de 114 pruebas aprobada.

**Regla:** ningún modelo de lenguaje puede reemplazar fuentes, cálculos o validaciones del motor financiero.

---

# 6. Próxima etapa — Usuarios, nube y sincronización

**Estado:** PLANIFICADA — comenzar después de probar la Beta integrada con datos reales.

- [ ] PostgreSQL.
- [ ] Registro, inicio de sesión y recuperación de contraseña.
- [ ] Sesiones seguras.
- [ ] Aislamiento por `user_id`.
- [ ] Sincronización entre dispositivos.
- [ ] Backups automáticos del servidor.
- [ ] Despliegue permanente.
- [ ] Roles y permisos.
- [ ] Exportación/eliminación de cuenta.
- [ ] Proveedor profesional de datos en tiempo real.
- [ ] Planes comerciales sólo después de validar el producto.

---

# 7. Arquitectura objetivo

```text
Usuario
  │
  ├── Watchlists
  └── Portafolios
       ├── Ledger y efectivo multimoneda
       ├── Eventos corporativos
       ├── Dividendos
       ├── Analytics y riesgo
       └── Análisis AI

HTML / CSS / JavaScript
          │
          ▼
FastAPI /api/v1
          │
          ├── PortfolioService
          ├── AnalyticsService
          ├── MarketDataProvider
          ├── AIService futuro
          └── Migraciones y auditoría
          │
          ▼
SQLite local → PostgreSQL en la nube
```

---

# 8. Orden de trabajo acordado

1. [x] **Alpha 1.4:** consolidación y estabilidad.
2. [x] **Alpha 1.5:** analytics, benchmark, riesgo, dividendos y eventos.
3. [x] **Alpha 1.6:** agente AI verificable, fundamentos, alertas y memoria.
4. [x] **5.0 Beta:** integración completa en un único release.
5. [ ] **Siguiente ciclo:** usuarios, nube y sincronización.

**Siguiente tarea:** probar la Beta integrada desde cero, registrar incidencias reales y luego diseñar PostgreSQL, autenticación y sincronización sin romper el núcleo local.
