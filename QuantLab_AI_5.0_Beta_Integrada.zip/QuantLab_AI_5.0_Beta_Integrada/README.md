# QuantLab AI 5.0 Beta — Versión integrada

Esta es la **primera entrega acumulativa y completa** de QuantLab AI. No requiere ensamblar versiones anteriores: el paquete incluye en una sola carpeta todo el núcleo desarrollado desde Alpha 1.0 hasta Alpha 1.6 Fase 3.

## Inicio rápido en Windows

1. Instalá Python 3.11 o superior y marcá **Add Python to PATH**.
2. Descomprimí el ZIP completo.
3. Entrá en la carpeta `QuantLab_AI_5.0_Beta_Integrada`.
4. Hacé doble clic en `iniciar_windows.bat`.
5. La web se abrirá en `http://127.0.0.1:8000`.

La primera ejecución crea `.venv`, instala dependencias y genera una base nueva en `data/quantlab.db`.

> No copies código de fases anteriores dentro de esta carpeta. Esta versión ya las contiene todas.

## Verificación opcional

Después de la primera instalación podés ejecutar:

```text
verificar_windows.bat
```

Este archivo comprueba dependencias, compila el backend y ejecuta las 114 pruebas automatizadas incluidas.

## Módulos integrados

### Mercado y datos

- Cotizaciones e históricos con `yfinance`.
- Búsqueda por ticker o nombre.
- Acciones, ETF, fondos, criptomonedas, divisas, índices y futuros.
- Calidad y antigüedad del dato.
- Caché y reintentos.
- Precios manuales de respaldo.
- Alias para cambios de ticker.
- Proveedor de mercado desacoplado para una futura API en tiempo real.

### Portafolios

- Múltiples portafolios aislados.
- Compras, ventas y cantidades fraccionarias.
- Precio promedio, comisiones y P&L.
- Activos automáticos y manuales.
- Efectivo separado por moneda.
- Conversiones FX auditables.
- Depósitos, retiros, intereses, impuestos y gastos.
- Edición segura, vista previa, borrado lógico y restauración.
- Auditoría de cambios.

### Dividendos y eventos corporativos

- Dividendo bruto, retención y neto.
- Reinversión vinculada.
- Importación histórica de dividendos.
- Splits y reverse splits.
- Cambios de ticker.
- Fusiones, spin-offs y dividendos en acciones.
- Devoluciones de capital.

### Analytics y riesgo

- TWR y XIRR educativos.
- Rendimiento diario, mensual, anual y desde el inicio.
- Benchmark configurable.
- Volatilidad, Sharpe, Sortino, Calmar y Omega.
- Drawdown máximo y actual.
- VaR y CVaR históricos.
- Beta, alpha, tracking error e information ratio.
- Correlación, covarianza y contribución al riesgo.
- Concentración por activo, moneda, tipo, sector e industria.
- Comparador de hasta seis activos.

### Agente AI verificable

- Consultas sobre mercado, activos, portafolio, riesgo y fundamentales.
- Herramientas internas con fuente, fecha, calidad y duración.
- Comparación técnica y fundamental.
- Historial separado por portafolio.
- Preguntas de seguimiento.
- Alertas educativas.
- Memoria estructurada de cambios.
- Modelo de lenguaje opcional, desactivado por defecto.
- Sin compras, ventas ni modificación automática de inversiones.

### Datos y plataforma

- API estable `/api/v1`.
- Frontend HTML, CSS y JavaScript responsive.
- Backend FastAPI.
- SQLite con esquema 15 y migraciones automáticas.
- Importación y exportación CSV.
- Backups `.qlbackup` con checksum.
- Restauración validada.
- Logs estructurados y errores con request ID.
- Tema claro, oscuro o automático.

## Instalación desde PowerShell

```powershell
cd "C:\ruta\QuantLab_AI_5.0_Beta_Integrada"
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
python -m uvicorn backend.main:app --host 127.0.0.1 --port 8000
```

Después abrí `http://127.0.0.1:8000`.

## Linux, macOS o Codespaces

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
./run.sh
```

En Codespaces, abrí el puerto 8000 desde la pestaña **Ports**.

## Conservar datos de una versión anterior

La opción recomendada es generar un backup `.qlbackup` desde la versión anterior y restaurarlo desde la sección de portabilidad.

También podés copiar `data/quantlab.db` dentro de la carpeta `data` antes del primer inicio. QuantLab crea un backup previo y aplica las migraciones pendientes automáticamente.

Nunca reemplaces carpetas de código ni mezcles archivos entre releases.

## Archivos importantes

```text
iniciar_windows.bat       Inicio normal en Windows
verificar_windows.bat     Diagnóstico y pruebas
VERSION                   Versión exacta
ROADMAP.md                Estado y próximos pasos
CHANGELOG.md              Historial acumulado
LEEME_PRIMERO.txt         Instrucciones simples
frontend/                 Interfaz web
backend/                  API y motor financiero
tests/                    Pruebas automatizadas
docs/                     Documentación funcional y técnica
data/                     Base local, logs y backups
```

## Limitaciones actuales

- `yfinance` es adecuado para investigación y uso educativo, pero no es un feed profesional en tiempo real.
- Las alertas se evalúan manualmente; todavía no existe un proceso permanente en segundo plano.
- No hay usuarios ni sincronización online.
- SQLite guarda los datos localmente en la computadora donde se ejecuta.
- El modelo de lenguaje es opcional y permanece desactivado.
- Las métricas no constituyen asesoramiento financiero.

## Próxima etapa

Antes de incorporar usuarios se realizará una revisión de uso real de esta Beta integrada. El siguiente bloque planificado contempla PostgreSQL, autenticación, aislamiento por usuario, sincronización y despliegue permanente.

Consultá `ROADMAP.md` y `docs/INTEGRACION_COMPLETA.md` para el detalle.
