from fastapi import APIRouter

from backend.core.config import settings
from backend.core.database import SCHEMA_VERSION, get_connection

router = APIRouter(prefix="", tags=["system"])


@router.get("/health")
def health() -> dict:
    return {
        "status": "ok",
        "app": settings.app_name,
        "version": settings.version,
        "environment": settings.environment,
        "api_version": "v1",
        "schema_version": SCHEMA_VERSION,
    }


@router.get("/system/migrations")
def migrations_status() -> dict:
    with get_connection() as connection:
        rows = connection.execute(
            "SELECT version, name, applied_at FROM schema_migrations ORDER BY version"
        ).fetchall()
    return {
        "schema_version": SCHEMA_VERSION,
        "applied": [dict(row) for row in rows],
        "ordered": [int(row["version"]) for row in rows] == sorted(int(row["version"]) for row in rows),
    }


@router.get("/system/config")
def public_config() -> dict:
    return {
        "environment": settings.environment,
        "market_provider": settings.market_data_provider,
        "legacy_api_enabled": settings.legacy_api_enabled,
        "cors_origins_count": len(settings.cors_origins),
        "log_level": settings.log_level,
    }
