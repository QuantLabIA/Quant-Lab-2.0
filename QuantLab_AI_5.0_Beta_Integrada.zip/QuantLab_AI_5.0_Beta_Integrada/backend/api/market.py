from fastapi import APIRouter, HTTPException, Query, Response, status

from backend.models import ManualMarketPriceCreate, SymbolAliasCreate
from backend.services.manual_price_service import (
    delete_manual_price,
    delete_symbol_alias,
    get_symbol_alias,
    list_manual_prices,
    list_symbol_aliases,
    manual_quote,
    save_manual_price,
    save_symbol_alias,
)
from backend.services.market_service import (
    MarketDataError,
    find_market_asset,
    get_dividend_history,
    get_fx_rate,
    get_market_history,
    list_market_assets,
    market_provider_status,
    search_market_assets,
)

router = APIRouter(prefix="/market", tags=["market"])


@router.get("")
def market_list() -> list[dict]:
    try:
        return list_market_assets()
    except MarketDataError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@router.get("/provider/status")
def provider_status() -> dict:
    return market_provider_status()


@router.get("/search")
def market_search(q: str = Query(min_length=1, max_length=100), limit: int = Query(default=12, ge=1, le=25)) -> list[dict]:
    try:
        return search_market_assets(q, limit)
    except MarketDataError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@router.get("/fx")
def market_fx(from_currency: str, to_currency: str) -> dict:
    try:
        return get_fx_rate(from_currency, to_currency)
    except MarketDataError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.get("/manual-prices")
def manual_prices() -> list[dict]:
    return list_manual_prices()


@router.put("/manual-prices/{symbol}")
def upsert_manual_price(symbol: str, payload: ManualMarketPriceCreate) -> dict:
    try:
        return save_manual_price(
            symbol,
            payload.price,
            payload.currency,
            payload.name,
            payload.notes,
            payload.observed_at,
        )
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@router.delete("/manual-prices/{symbol}", status_code=status.HTTP_204_NO_CONTENT)
def remove_manual_price(symbol: str) -> Response:
    if not delete_manual_price(symbol):
        raise HTTPException(status_code=404, detail="No existe un precio manual para ese símbolo")
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.get("/aliases")
def symbol_aliases() -> list[dict]:
    return list_symbol_aliases()


@router.put("/aliases/{old_symbol}")
def upsert_symbol_alias(old_symbol: str, payload: SymbolAliasCreate) -> dict:
    try:
        return save_symbol_alias(old_symbol, payload.new_symbol, payload.notes)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@router.delete("/aliases/{old_symbol}", status_code=status.HTTP_204_NO_CONTENT)
def remove_symbol_alias(old_symbol: str) -> Response:
    if not delete_symbol_alias(old_symbol):
        raise HTTPException(status_code=404, detail="No existe un alias para ese símbolo")
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.get("/{symbol}/history")
def market_history(
    symbol: str,
    period: str = Query(default="1mo"),
    interval: str = Query(default="1d"),
) -> dict:
    try:
        return get_market_history(symbol, period=period, interval=interval)
    except MarketDataError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.get("/{symbol}/dividends")
def market_dividends(symbol: str, period: str = Query(default="5y")) -> dict:
    try:
        return get_dividend_history(symbol, period)
    except MarketDataError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.get("/{symbol}")
def market_detail(symbol: str, allow_manual_fallback: bool = Query(default=True)) -> dict:
    requested_symbol = symbol.strip().upper()
    alias = get_symbol_alias(requested_symbol)
    provider_symbol = alias["new_symbol"] if alias else requested_symbol
    provider_error: str | None = None
    try:
        asset = find_market_asset(provider_symbol)
    except MarketDataError as exc:
        asset = None
        provider_error = str(exc)

    if asset is not None:
        if alias:
            asset = dict(asset)
            asset["requested_symbol"] = requested_symbol
            asset["symbol_alias"] = provider_symbol
            asset.setdefault("warnings", []).append(
                f"{requested_symbol} fue reemplazado por {provider_symbol}."
            )
        return asset

    if allow_manual_fallback:
        fallback = manual_quote(requested_symbol) or manual_quote(provider_symbol)
        if fallback is not None:
            if alias:
                fallback["requested_symbol"] = requested_symbol
                fallback["symbol_alias"] = provider_symbol
                fallback["warnings"].append(
                    f"Se aplicó el alias {requested_symbol} → {provider_symbol}."
                )
            if provider_error:
                fallback["warnings"].append(f"Proveedor automático no disponible: {provider_error}")
            return fallback

    if provider_error:
        raise HTTPException(status_code=503, detail=provider_error)
    raise HTTPException(
        status_code=404,
        detail="Símbolo no encontrado o posiblemente deslistado. Podés definir un alias o guardar un precio manual.",
    )

