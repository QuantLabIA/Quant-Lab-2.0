from fastapi import APIRouter, HTTPException, Query

from backend.agents.history import archive_session, get_session, list_sessions
from backend.agents.alerts import (
    create_rule, disable_rule, evaluate_alerts, list_events, list_rules,
    notification_readiness, update_event_status, update_rule,
)
from backend.agents.memory import recent_changes
from backend.agents.settings import get_agent_settings, update_agent_settings
from backend.agents.service import capabilities, run_agent_query
from backend.models import (
    AIAnalysisRequest, AIAgentQuery, AIAgentSettingsUpdate, AIAlertEventAction,
    AIAlertRuleCreate, AIAlertRuleUpdate,
)
from backend.services.ai_service import analyze_asset
from backend.services.fundamental_service import analyze_fundamentals, compare_fundamentals
from backend.services.market_service import MarketDataError, get_fundamental_data
from backend.services.portfolio_service import PortfolioError, PortfolioValidationError

router = APIRouter(prefix="/ai", tags=["ai"])


def _http_error(exc: Exception) -> HTTPException:
    if isinstance(exc, PortfolioValidationError):
        return HTTPException(status_code=422, detail=str(exc))
    if isinstance(exc, (MarketDataError, PortfolioError, ValueError)):
        return HTTPException(status_code=503, detail=str(exc))
    return HTTPException(status_code=500, detail="No se pudo completar el análisis AI")


@router.post("/analyze")
def analyze(payload: AIAnalysisRequest) -> dict:
    try:
        return analyze_asset(payload)
    except (MarketDataError, ValueError) as exc:
        raise _http_error(exc) from exc



@router.get("/fundamentals/{symbol}")
def fundamentals(symbol: str) -> dict:
    try:
        return analyze_fundamentals(symbol, get_fundamental_data)
    except Exception as exc:
        raise _http_error(exc) from exc


@router.get("/fundamentals/compare/list")
def fundamentals_compare(symbols: str = Query(min_length=3, max_length=240)) -> dict:
    try:
        items = [item.strip().upper() for item in symbols.split(",") if item.strip()]
        return compare_fundamentals(items, get_fundamental_data)
    except Exception as exc:
        raise _http_error(exc) from exc


@router.get("/agent/settings")
def agent_settings(portfolio_id: int = Query(default=1, ge=1)) -> dict:
    return get_agent_settings(portfolio_id)


@router.put("/agent/settings")
def save_agent_settings(payload: AIAgentSettingsUpdate, portfolio_id: int = Query(default=1, ge=1)) -> dict:
    return update_agent_settings(
        portfolio_id,
        use_language_model=payload.use_language_model,
        response_style=payload.response_style,
    )

@router.get("/agent/capabilities")
def agent_capabilities() -> dict:
    return capabilities()


@router.post("/agent/query")
def agent_query(payload: AIAgentQuery) -> dict:
    try:
        return run_agent_query(payload)
    except Exception as exc:
        raise _http_error(exc) from exc


@router.get("/agent/sessions")
def agent_sessions(portfolio_id: int = Query(default=1, ge=1), limit: int = Query(default=20, ge=1, le=100)) -> list[dict]:
    return list_sessions(portfolio_id, limit)


@router.get("/agent/sessions/{session_id}")
def agent_session(session_id: int, portfolio_id: int = Query(default=1, ge=1)) -> dict:
    result = get_session(session_id, portfolio_id)
    if result is None:
        raise HTTPException(status_code=404, detail="Conversación AI no encontrada")
    return result


@router.delete("/agent/sessions/{session_id}")
def remove_agent_session(session_id: int, portfolio_id: int = Query(default=1, ge=1)) -> dict:
    if not archive_session(session_id, portfolio_id):
        raise HTTPException(status_code=404, detail="Conversación AI no encontrada")
    return {"status": "archived", "session_id": session_id}


@router.get("/alerts/rules")
def alert_rules(portfolio_id: int = Query(default=1, ge=1)) -> list[dict]:
    return list_rules(portfolio_id)


@router.post("/alerts/rules")
def add_alert_rule(payload: AIAlertRuleCreate, portfolio_id: int = Query(default=1, ge=1)) -> dict:
    return create_rule(portfolio_id, payload)


@router.put("/alerts/rules/{rule_id}")
def save_alert_rule(rule_id: int, payload: AIAlertRuleUpdate, portfolio_id: int = Query(default=1, ge=1)) -> dict:
    result = update_rule(portfolio_id, rule_id, payload)
    if result is None:
        raise HTTPException(status_code=404, detail="Regla de alerta no encontrada")
    return result


@router.delete("/alerts/rules/{rule_id}")
def remove_alert_rule(rule_id: int, portfolio_id: int = Query(default=1, ge=1)) -> dict:
    if not disable_rule(portfolio_id, rule_id):
        raise HTTPException(status_code=404, detail="Regla de alerta no encontrada")
    return {"status": "disabled", "rule_id": rule_id}


@router.post("/alerts/evaluate")
def run_alert_evaluation(portfolio_id: int = Query(default=1, ge=1), period: str = Query(default="1y")) -> dict:
    try:
        return evaluate_alerts(portfolio_id, period)
    except Exception as exc:
        raise _http_error(exc) from exc


@router.get("/alerts/events")
def alert_events(
    portfolio_id: int = Query(default=1, ge=1),
    status: str = Query(default="OPEN", pattern="^(OPEN|ACTIVE|ACKNOWLEDGED|DISMISSED|RESOLVED)$"),
    limit: int = Query(default=100, ge=1, le=500),
) -> list[dict]:
    return list_events(portfolio_id, status, limit)


@router.put("/alerts/events/{event_id}")
def save_alert_event_status(
    event_id: int, payload: AIAlertEventAction, portfolio_id: int = Query(default=1, ge=1)
) -> dict:
    result = update_event_status(portfolio_id, event_id, payload.status, payload.note)
    if result is None:
        raise HTTPException(status_code=404, detail="Alerta no encontrada o ya resuelta")
    return result


@router.get("/alerts/readiness")
def alert_notification_readiness(portfolio_id: int = Query(default=1, ge=1)) -> dict:
    return notification_readiness(portfolio_id)


@router.get("/memory/changes")
def agent_memory_changes(portfolio_id: int = Query(default=1, ge=1), limit: int = Query(default=50, ge=2, le=200)) -> list[dict]:
    return recent_changes(portfolio_id, limit)
