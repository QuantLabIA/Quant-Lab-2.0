from fastapi import APIRouter

from backend.services.market_service import (
    MarketDataError,
    find_market_asset,
    get_market_history,
    get_fx_history,
    get_fx_rate,
    list_market_assets,
)
from backend.services.portfolio_service import PortfolioError, get_equity_curve, get_portfolio_overview

router = APIRouter(prefix="/dashboard", tags=["dashboard"])


def _money(value: float, currency: str) -> str:
    return f"{currency} {value:,.2f}"


@router.get("")
def dashboard(portfolio_id: int = 1) -> dict:
    market_summary: list[dict] = []
    market_error: str | None = None
    try:
        quotes = list_market_assets()
        selected = [quote for quote in quotes if quote["symbol"] in {"SPY", "QQQ", "BTC-USD"}]
        market_summary = [
            {
                "symbol": quote["symbol"].replace("-USD", ""),
                "value": quote["price"],
                "currency": quote["currency"],
                "change_percent": quote["change_percent"],
                "last_updated": quote["last_updated"],
            }
            for quote in selected
        ]
    except MarketDataError as exc:
        market_error = str(exc)

    portfolio_error: str | None = None
    try:
        portfolio = get_portfolio_overview(find_market_asset, get_fx_rate, portfolio_id)
        summary = portfolio["summary"]
        curve = get_equity_curve("1mo", get_market_history, get_fx_history, portfolio_id)
        values = [point["equity"] for point in curve["points"]]
        currency = summary["currency"]
        total_pnl = float(summary["total_pnl"])
        total_return = float(summary["total_return_percent"])
        valuation_note = (
            "Cotización completa"
            if summary["valuation_status"] == "complete"
            else f"{summary['unpriced_assets']} sin precio"
        )
        metrics = [
            {
                "label": "Capital total",
                "value": _money(summary["total_equity"], currency),
                "variation": f"{total_return:+.2f}%",
                "positive": total_pnl >= 0,
            },
            {
                "label": "Ganancia / pérdida",
                "value": _money(total_pnl, currency),
                "variation": "Ajustado por aportes",
                "positive": total_pnl >= 0,
            },
            {
                "label": "Efectivo disponible",
                "value": _money(summary["cash_balance"], currency),
                "variation": f"{summary['holdings_count']} posiciones",
                "positive": summary["cash_balance"] >= 0,
            },
            {
                "label": "Valuación",
                "value": valuation_note,
                "variation": f"{summary['transactions_count']} operaciones",
                "positive": summary["valuation_status"] == "complete",
            },
        ]
    except (PortfolioError, MarketDataError) as exc:
        portfolio_error = str(exc)
        metrics = [
            {"label": "Capital total", "value": "Sin dato", "variation": "Error", "positive": False},
            {"label": "Ganancia / pérdida", "value": "Sin dato", "variation": "Error", "positive": False},
            {"label": "Efectivo disponible", "value": "Sin dato", "variation": "Error", "positive": False},
            {"label": "Valuación", "value": "Parcial", "variation": "Revisar", "positive": False},
        ]
        values = [0]

    return {
        "portfolio_id": portfolio_id,
        "metrics": metrics,
        "portfolio_curve": values,
        "portfolio_curve_label": "Evolución real según operaciones e históricos",
        "portfolio_is_demo": False,
        "portfolio_error": portfolio_error,
        "market_summary": market_summary,
        "market_error": market_error,
        "market_is_real": True,
    }
