from __future__ import annotations

from fastapi import APIRouter, HTTPException, Request, status
from fastapi.responses import FileResponse, Response

from backend.models import BackupCreateRequest, CsvImportRequest
from backend.services.backup_service import (
    BackupError,
    backup_path,
    create_backup,
    list_backups,
    restore_backup,
    validate_backup_bytes,
)
from backend.services.csv_service import (
    CsvImportError,
    commit_csv_import,
    export_portfolio_csv,
    generic_template_csv,
    list_import_batches,
    preview_csv_import,
)
from backend.services.market_service import (
    MarketDataError,
    find_market_asset,
    get_fx_rate,
)

router = APIRouter(prefix="/data", tags=["data-management"])


def _error(exc: Exception) -> HTTPException:
    if isinstance(exc, (CsvImportError, BackupError)):
        return HTTPException(status_code=422, detail=str(exc))
    if isinstance(exc, MarketDataError):
        return HTTPException(status_code=503, detail=str(exc))
    return HTTPException(status_code=500, detail="No se pudo completar la operación de datos")


@router.get("/csv/template")
def csv_template() -> Response:
    return Response(
        content=generic_template_csv(), media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": 'attachment; filename="QuantLab_plantilla_generica.csv"'},
    )


@router.post("/csv/preview")
def preview_import(payload: CsvImportRequest, portfolio_id: int = 1) -> dict:
    try:
        return preview_csv_import(
            payload.content, portfolio_id, find_market_asset, get_fx_rate,
            skip_duplicates=payload.skip_duplicates,
        )
    except (CsvImportError, MarketDataError) as exc:
        raise _error(exc) from exc


@router.post("/csv/import", status_code=status.HTTP_201_CREATED)
def import_csv(payload: CsvImportRequest, portfolio_id: int = 1) -> dict:
    try:
        return commit_csv_import(
            payload.content, payload.filename, portfolio_id, find_market_asset, get_fx_rate,
            import_valid_only=payload.import_valid_only,
            skip_duplicates=payload.skip_duplicates,
            adapter=payload.adapter,
        )
    except (CsvImportError, MarketDataError) as exc:
        raise _error(exc) from exc


@router.get("/csv/imports")
def import_history(portfolio_id: int = 1, limit: int = 50) -> list[dict]:
    try:
        return list_import_batches(portfolio_id, limit)
    except CsvImportError as exc:
        raise _error(exc) from exc


@router.get("/csv/export/{dataset}")
def export_csv(
    dataset: str, portfolio_id: int = 1, include_deleted: bool = False
) -> Response:
    try:
        content, filename = export_portfolio_csv(
            dataset, portfolio_id, find_market_asset, get_fx_rate,
            include_deleted=include_deleted,
        )
    except (CsvImportError, MarketDataError) as exc:
        raise _error(exc) from exc
    return Response(
        content=content, media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@router.get("/backups")
def backups() -> list[dict]:
    try:
        return list_backups()
    except BackupError as exc:
        raise _error(exc) from exc


@router.post("/backups", status_code=status.HTTP_201_CREATED)
def make_backup(payload: BackupCreateRequest) -> dict:
    try:
        return create_backup(payload.note)
    except BackupError as exc:
        raise _error(exc) from exc


@router.get("/backups/{filename}")
def download_backup(filename: str) -> FileResponse:
    try:
        path = backup_path(filename)
    except BackupError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    return FileResponse(path, filename=path.name, media_type="application/zip")


@router.post("/backups/validate")
async def validate_backup(request: Request, filename: str = "backup.qlbackup") -> dict:
    try:
        return validate_backup_bytes(await request.body(), filename)
    except BackupError as exc:
        raise _error(exc) from exc


@router.post("/backups/restore")
async def restore_database_backup(
    request: Request, filename: str = "backup.qlbackup", confirmation: str = ""
) -> dict:
    try:
        return restore_backup(await request.body(), filename, confirmation)
    except BackupError as exc:
        raise _error(exc) from exc
