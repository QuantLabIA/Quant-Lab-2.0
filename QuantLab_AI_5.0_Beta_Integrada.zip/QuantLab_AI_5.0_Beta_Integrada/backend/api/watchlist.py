from fastapi import APIRouter, HTTPException, status

from backend.models import WatchlistCreate, WatchlistItem
from backend.services.watchlist_service import create_item, delete_item, list_items

router = APIRouter(prefix="/watchlist", tags=["watchlist"])


@router.get("", response_model=list[WatchlistItem])
def get_watchlist() -> list[dict]:
    return list_items()


@router.post("", response_model=WatchlistItem, status_code=status.HTTP_201_CREATED)
def add_watchlist_item(payload: WatchlistCreate) -> dict:
    try:
        return create_item(payload)
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@router.delete("/{item_id}", status_code=status.HTTP_204_NO_CONTENT)
def remove_watchlist_item(item_id: int) -> None:
    if not delete_item(item_id):
        raise HTTPException(status_code=404, detail="Activo no encontrado")
