from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import Response

from backend.models import AnalyticsSettingsUpdate
from backend.services.analytics_service import (
    SUPPORTED_ANALYTICS_PERIODS,
    compare_assets,
    export_analytics_csv,
    get_analytics_overview,
    get_analytics_settings,
    update_analytics_settings,
)
from backend.services.market_service import (
    MarketDataError,
    find_market_asset,
    get_fx_history,
    get_fx_rate,
    get_market_history,
)
from backend.services.portfolio_service import PortfolioError, PortfolioValidationError


router = APIRouter(prefix="/analytics", tags=["analytics"])


def _http_error(exc: Exception) -> HTTPException:
    if isinstance(exc, PortfolioValidationError):
        return HTTPException(status_code=422, detail=str(exc))
    if isinstance(exc, MarketDataError):
        return HTTPException(status_code=503, detail=str(exc))
    if isinstance(exc, PortfolioError):
        return HTTPException(status_code=400, detail=str(exc))
    return HTTPException(status_code=500, detail="No se pudo calcular analytics")


@router.get("/settings")
def analytics_settings(portfolio_id: int = 1) -> dict:
    try:
        return get_analytics_settings(portfolio_id)
    except PortfolioError as exc:
        raise _http_error(exc) from exc


@router.put("/settings")
def save_analytics_settings(payload: AnalyticsSettingsUpdate, portfolio_id: int = 1) -> dict:
    try:
        return update_analytics_settings(payload, portfolio_id)
    except PortfolioError as exc:
        raise _http_error(exc) from exc


@router.get("/overview")
def analytics_overview(
    portfolio_id: int = 1,
    period: str = Query(default="1y"),
) -> dict:
    if period not in SUPPORTED_ANALYTICS_PERIODS:
        raise HTTPException(
            status_code=422,
            detail=f"Período no permitido. Usá: {', '.join(sorted(SUPPORTED_ANALYTICS_PERIODS))}",
        )
    try:
        return get_analytics_overview(
            period,
            get_market_history,
            get_fx_history,
            find_market_asset,
            get_fx_rate,
            portfolio_id,
        )
    except (PortfolioError, MarketDataError) as exc:
        raise _http_error(exc) from exc


@router.get("/compare")
def analytics_compare(
    symbols: str = Query(min_length=3, max_length=240),
    portfolio_id: int = 1,
    period: str = Query(default="1y"),
) -> dict:
    try:
        requested = [item.strip().upper() for item in symbols.split(",") if item.strip()]
        return compare_assets(
            requested, period, get_market_history, get_fx_history, portfolio_id
        )
    except (PortfolioError, MarketDataError) as exc:
        raise _http_error(exc) from exc


@router.get("/export.csv")
def analytics_export(
    portfolio_id: int = 1,
    period: str = Query(default="1y"),
) -> Response:
    try:
        data = get_analytics_overview(
            period,
            get_market_history,
            get_fx_history,
            find_market_asset,
            get_fx_rate,
            portfolio_id,
        )
        content = export_analytics_csv(data)
        filename = f"quantlab_analytics_portfolio_{portfolio_id}_{period}.csv"
        return Response(
            content=content.encode("utf-8-sig"),
            media_type="text/csv; charset=utf-8",
            headers={"Content-Disposition": f'attachment; filename="{filename}"'},
        )
    except (PortfolioError, MarketDataError) as exc:
        raise _http_error(exc) from exc
