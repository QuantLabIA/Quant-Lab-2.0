from fastapi import APIRouter, HTTPException, Response, status

from backend.models import (
    ManualAssetCreate,
    ManualAssetPriceUpdate,
    PortfolioCashMovementCreate,
    PortfolioCashMovementUpdate,
    PortfolioCreate,
    PortfolioFxConversionCreate,
    PortfolioFxConversionUpdate,
    PortfolioDividendCreate,
    PortfolioDividendImportOptions,
    PortfolioDividendSettingsUpdate,
    PortfolioCorporateActionCreate,
    PortfolioCorporateActionUpdate,
    PortfolioSettingsUpdate,
    PortfolioTransactionCreate,
    PortfolioTransactionUpdate,
)
from backend.services.market_service import (
    MarketDataError,
    find_market_asset,
    get_dividend_history,
    get_fx_history,
    get_fx_rate,
    get_market_history,
)
from backend.services.corporate_actions_service import (
    create_corporate_action,
    delete_corporate_action,
    get_corporate_action,
    list_corporate_actions,
    preview_corporate_action,
    preview_corporate_action_update,
    restore_corporate_action,
    update_corporate_action,
)
from backend.services.dividends_service import (
    create_dividend,
    dividend_summary,
    get_dividend_settings,
    import_dividends as import_advanced_dividends,
    list_dividends,
    update_dividend_settings,
)
from backend.services.portfolio_service import (
    PortfolioError,
    PortfolioValidationError,
    archive_portfolio,
    create_cash_movement,
    create_manual_asset,
    create_portfolio,
    create_fx_conversion,
    create_portfolio_transaction,
    delete_cash_movement,
    delete_fx_conversion,
    delete_portfolio_transaction,
    get_equity_curve,
    get_cash_movement,
    get_fx_conversion,
    get_portfolio_transaction,
    get_portfolio_overview,
    get_portfolio_settings,
    list_cash_movements,
    list_fx_conversions,
    list_portfolio_audit_log,
    list_portfolio_assets,
    list_portfolio_transactions,
    list_portfolios,
    restore_cash_movement,
    restore_fx_conversion,
    restore_portfolio,
    restore_portfolio_transaction,
    preview_cash_movement_update,
    preview_fx_conversion_create,
    preview_fx_conversion_update,
    preview_portfolio_transaction_update,
    update_cash_movement,
    update_fx_conversion,
    update_manual_asset_price,
    update_portfolio_transaction,
    update_portfolio_settings,
)

router = APIRouter(tags=["portfolio"])


def _http_error(exc: Exception) -> HTTPException:
    if isinstance(exc, PortfolioValidationError):
        return HTTPException(status_code=422, detail=str(exc))
    if isinstance(exc, MarketDataError):
        return HTTPException(status_code=503, detail=str(exc))
    return HTTPException(status_code=500, detail=str(exc))


# Administración de portafolios. Se mantiene separada del futuro sistema de usuarios.
@router.get("/portfolios")
def portfolios(include_archived: bool = False) -> list[dict]:
    return list_portfolios(include_archived=include_archived)


@router.post("/portfolios", status_code=status.HTTP_201_CREATED)
def add_portfolio(payload: PortfolioCreate) -> dict:
    try:
        return create_portfolio(payload)
    except PortfolioError as exc:
        raise _http_error(exc) from exc


@router.get("/portfolios/{portfolio_id}")
def portfolio_detail(portfolio_id: int) -> dict:
    try:
        return get_portfolio_settings(portfolio_id, include_archived=True)
    except PortfolioError as exc:
        raise _http_error(exc) from exc


@router.put("/portfolios/{portfolio_id}")
def save_portfolio(portfolio_id: int, payload: PortfolioSettingsUpdate) -> dict:
    try:
        return update_portfolio_settings(payload, portfolio_id)
    except PortfolioError as exc:
        raise _http_error(exc) from exc


@router.delete("/portfolios/{portfolio_id}")
def remove_portfolio(portfolio_id: int) -> dict:
    try:
        return archive_portfolio(portfolio_id)
    except PortfolioError as exc:
        raise _http_error(exc) from exc


@router.post("/portfolios/{portfolio_id}/restore")
def restore_archived_portfolio(portfolio_id: int) -> dict:
    try:
        return restore_portfolio(portfolio_id)
    except PortfolioError as exc:
        raise _http_error(exc) from exc


# Endpoints financieros conservan /api/portfolio para compatibilidad.
@router.get("/portfolio")
def portfolio_overview(portfolio_id: int = 1) -> dict:
    try:
        return get_portfolio_overview(find_market_asset, get_fx_rate, portfolio_id)
    except (PortfolioError, MarketDataError) as exc:
        raise _http_error(exc) from exc


@router.get("/portfolio/settings")
def portfolio_settings(portfolio_id: int = 1) -> dict:
    try:
        return get_portfolio_settings(portfolio_id)
    except PortfolioError as exc:
        raise _http_error(exc) from exc


@router.put("/portfolio/settings")
def save_portfolio_settings(payload: PortfolioSettingsUpdate, portfolio_id: int = 1) -> dict:
    try:
        return update_portfolio_settings(payload, portfolio_id)
    except PortfolioError as exc:
        raise _http_error(exc) from exc


@router.get("/portfolio/assets")
def portfolio_assets(portfolio_id: int = 1) -> list[dict]:
    try:
        return list_portfolio_assets(portfolio_id)
    except PortfolioError as exc:
        raise _http_error(exc) from exc


@router.post("/portfolio/assets/manual", status_code=status.HTTP_201_CREATED)
def add_manual_asset(payload: ManualAssetCreate, portfolio_id: int = 1) -> dict:
    try:
        return create_manual_asset(payload, portfolio_id)
    except PortfolioError as exc:
        raise _http_error(exc) from exc


@router.put("/portfolio/assets/{symbol}/price")
def save_manual_asset_price(
    symbol: str,
    payload: ManualAssetPriceUpdate,
    portfolio_id: int = 1,
) -> dict:
    try:
        return update_manual_asset_price(symbol.upper(), payload, portfolio_id)
    except PortfolioError as exc:
        raise _http_error(exc) from exc


@router.get("/portfolio/transactions")
def portfolio_transactions(portfolio_id: int = 1, include_deleted: bool = False) -> list[dict]:
    try:
        return list_portfolio_transactions(
            portfolio_id=portfolio_id, include_deleted=include_deleted
        )
    except PortfolioError as exc:
        raise _http_error(exc) from exc


@router.get("/portfolio/transactions/{transaction_id}")
def portfolio_transaction_detail(
    transaction_id: int, portfolio_id: int = 1, include_deleted: bool = False
) -> dict:
    try:
        return get_portfolio_transaction(
            transaction_id, portfolio_id, include_deleted=include_deleted
        )
    except PortfolioError as exc:
        raise _http_error(exc) from exc


@router.post("/portfolio/transactions", status_code=status.HTTP_201_CREATED)
def add_portfolio_transaction(payload: PortfolioTransactionCreate, portfolio_id: int = 1) -> dict:
    try:
        return create_portfolio_transaction(
            payload,
            find_market_asset,
            get_fx_rate,
            portfolio_id,
        )
    except (PortfolioError, MarketDataError) as exc:
        raise _http_error(exc) from exc


@router.post("/portfolio/transactions/{transaction_id}/preview")
def preview_transaction_change(
    transaction_id: int, payload: PortfolioTransactionUpdate, portfolio_id: int = 1
) -> dict:
    try:
        return preview_portfolio_transaction_update(
            transaction_id, payload, find_market_asset, get_fx_rate, portfolio_id
        )
    except (PortfolioError, MarketDataError) as exc:
        raise _http_error(exc) from exc


@router.put("/portfolio/transactions/{transaction_id}")
def save_transaction_change(
    transaction_id: int, payload: PortfolioTransactionUpdate, portfolio_id: int = 1
) -> dict:
    try:
        return update_portfolio_transaction(
            transaction_id, payload, find_market_asset, get_fx_rate, portfolio_id
        )
    except (PortfolioError, MarketDataError) as exc:
        raise _http_error(exc) from exc


@router.delete("/portfolio/transactions/{transaction_id}", status_code=status.HTTP_204_NO_CONTENT)
def remove_portfolio_transaction(
    transaction_id: int, portfolio_id: int = 1,
    reason: str = "Eliminación solicitada por el usuario",
) -> Response:
    try:
        delete_portfolio_transaction(transaction_id, portfolio_id, reason)
    except PortfolioError as exc:
        raise _http_error(exc) from exc
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.post("/portfolio/transactions/{transaction_id}/restore")
def restore_deleted_transaction(
    transaction_id: int, portfolio_id: int = 1,
    reason: str = "Restauración solicitada por el usuario",
) -> dict:
    try:
        return restore_portfolio_transaction(transaction_id, portfolio_id, reason)
    except PortfolioError as exc:
        raise _http_error(exc) from exc


@router.get("/portfolio/cash-movements")
def portfolio_cash_movements(portfolio_id: int = 1, include_deleted: bool = False) -> list[dict]:
    try:
        return list_cash_movements(
            portfolio_id=portfolio_id, include_deleted=include_deleted
        )
    except PortfolioError as exc:
        raise _http_error(exc) from exc


@router.get("/portfolio/cash-movements/{movement_id}")
def cash_movement_detail(
    movement_id: int, portfolio_id: int = 1, include_deleted: bool = False
) -> dict:
    try:
        return get_cash_movement(movement_id, portfolio_id, include_deleted=include_deleted)
    except PortfolioError as exc:
        raise _http_error(exc) from exc


@router.post("/portfolio/cash-movements", status_code=status.HTTP_201_CREATED)
def add_cash_movement(payload: PortfolioCashMovementCreate, portfolio_id: int = 1) -> dict:
    try:
        return create_cash_movement(payload, get_fx_rate, portfolio_id)
    except (PortfolioError, MarketDataError) as exc:
        raise _http_error(exc) from exc


@router.post("/portfolio/cash-movements/{movement_id}/preview")
def preview_cash_change(
    movement_id: int, payload: PortfolioCashMovementUpdate, portfolio_id: int = 1
) -> dict:
    try:
        return preview_cash_movement_update(movement_id, payload, get_fx_rate, portfolio_id)
    except (PortfolioError, MarketDataError) as exc:
        raise _http_error(exc) from exc


@router.put("/portfolio/cash-movements/{movement_id}")
def save_cash_change(
    movement_id: int, payload: PortfolioCashMovementUpdate, portfolio_id: int = 1
) -> dict:
    try:
        return update_cash_movement(movement_id, payload, get_fx_rate, portfolio_id)
    except (PortfolioError, MarketDataError) as exc:
        raise _http_error(exc) from exc


@router.get("/portfolio/fx-conversions")
def portfolio_fx_conversions(portfolio_id: int = 1, include_deleted: bool = False) -> list[dict]:
    try:
        return list_fx_conversions(
            portfolio_id=portfolio_id, include_deleted=include_deleted
        )
    except PortfolioError as exc:
        raise _http_error(exc) from exc


@router.get("/portfolio/fx-conversions/{conversion_id}")
def fx_conversion_detail(
    conversion_id: int, portfolio_id: int = 1, include_deleted: bool = False
) -> dict:
    try:
        return get_fx_conversion(
            conversion_id, portfolio_id, include_deleted=include_deleted
        )
    except PortfolioError as exc:
        raise _http_error(exc) from exc


@router.post("/portfolio/fx-conversions/preview")
def preview_new_fx_conversion(payload: PortfolioFxConversionCreate, portfolio_id: int = 1) -> dict:
    try:
        return preview_fx_conversion_create(payload, get_fx_rate, portfolio_id)
    except (PortfolioError, MarketDataError) as exc:
        raise _http_error(exc) from exc


@router.post("/portfolio/fx-conversions", status_code=status.HTTP_201_CREATED)
def add_fx_conversion(payload: PortfolioFxConversionCreate, portfolio_id: int = 1) -> dict:
    try:
        return create_fx_conversion(payload, get_fx_rate, portfolio_id)
    except (PortfolioError, MarketDataError) as exc:
        raise _http_error(exc) from exc


@router.post("/portfolio/fx-conversions/{conversion_id}/preview")
def preview_fx_change(
    conversion_id: int, payload: PortfolioFxConversionUpdate, portfolio_id: int = 1
) -> dict:
    try:
        return preview_fx_conversion_update(
            conversion_id, payload, get_fx_rate, portfolio_id
        )
    except (PortfolioError, MarketDataError) as exc:
        raise _http_error(exc) from exc


@router.put("/portfolio/fx-conversions/{conversion_id}")
def save_fx_change(
    conversion_id: int, payload: PortfolioFxConversionUpdate, portfolio_id: int = 1
) -> dict:
    try:
        return update_fx_conversion(conversion_id, payload, get_fx_rate, portfolio_id)
    except (PortfolioError, MarketDataError) as exc:
        raise _http_error(exc) from exc


@router.delete(
    "/portfolio/fx-conversions/{conversion_id}",
    status_code=status.HTTP_204_NO_CONTENT,
)
def remove_fx_conversion(
    conversion_id: int,
    portfolio_id: int = 1,
    reason: str = "Eliminación solicitada por el usuario",
) -> Response:
    try:
        delete_fx_conversion(conversion_id, portfolio_id, reason)
    except PortfolioError as exc:
        raise _http_error(exc) from exc
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.post("/portfolio/fx-conversions/{conversion_id}/restore")
def restore_deleted_fx_conversion(
    conversion_id: int,
    portfolio_id: int = 1,
    reason: str = "Restauración solicitada por el usuario",
) -> dict:
    try:
        return restore_fx_conversion(conversion_id, portfolio_id, reason)
    except PortfolioError as exc:
        raise _http_error(exc) from exc


@router.get("/portfolio/corporate-actions")
def portfolio_corporate_actions(
    portfolio_id: int = 1, include_deleted: bool = False
) -> list[dict]:
    try:
        return list_corporate_actions(portfolio_id, include_deleted=include_deleted)
    except PortfolioError as exc:
        raise _http_error(exc) from exc


@router.get("/portfolio/corporate-actions/{action_id}")
def corporate_action_detail(
    action_id: int, portfolio_id: int = 1, include_deleted: bool = False
) -> dict:
    try:
        return get_corporate_action(action_id, portfolio_id, include_deleted=include_deleted)
    except PortfolioError as exc:
        raise _http_error(exc) from exc


@router.post("/portfolio/corporate-actions/preview")
def preview_new_corporate_action(
    payload: PortfolioCorporateActionCreate, portfolio_id: int = 1
) -> dict:
    try:
        return preview_corporate_action(payload, find_market_asset, get_fx_rate, portfolio_id)
    except (PortfolioError, MarketDataError) as exc:
        raise _http_error(exc) from exc


@router.post("/portfolio/corporate-actions", status_code=status.HTTP_201_CREATED)
def add_corporate_action(
    payload: PortfolioCorporateActionCreate, portfolio_id: int = 1
) -> dict:
    try:
        return create_corporate_action(payload, find_market_asset, get_fx_rate, portfolio_id)
    except (PortfolioError, MarketDataError) as exc:
        raise _http_error(exc) from exc


@router.post("/portfolio/corporate-actions/{action_id}/preview")
def preview_corporate_action_change(
    action_id: int, payload: PortfolioCorporateActionUpdate, portfolio_id: int = 1
) -> dict:
    try:
        return preview_corporate_action_update(
            action_id, payload, find_market_asset, get_fx_rate, portfolio_id
        )
    except (PortfolioError, MarketDataError) as exc:
        raise _http_error(exc) from exc


@router.put("/portfolio/corporate-actions/{action_id}")
def save_corporate_action_change(
    action_id: int, payload: PortfolioCorporateActionUpdate, portfolio_id: int = 1
) -> dict:
    try:
        return update_corporate_action(
            action_id, payload, find_market_asset, get_fx_rate, portfolio_id
        )
    except (PortfolioError, MarketDataError) as exc:
        raise _http_error(exc) from exc


@router.delete(
    "/portfolio/corporate-actions/{action_id}",
    status_code=status.HTTP_204_NO_CONTENT,
)
def remove_corporate_action(
    action_id: int,
    portfolio_id: int = 1,
    reason: str = "Eliminación solicitada por el usuario",
) -> Response:
    try:
        delete_corporate_action(action_id, portfolio_id, reason)
    except PortfolioError as exc:
        raise _http_error(exc) from exc
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.post("/portfolio/corporate-actions/{action_id}/restore")
def restore_deleted_corporate_action(
    action_id: int,
    portfolio_id: int = 1,
    reason: str = "Restauración solicitada por el usuario",
) -> dict:
    try:
        return restore_corporate_action(action_id, portfolio_id, reason)
    except PortfolioError as exc:
        raise _http_error(exc) from exc


@router.get("/portfolio/dividends")
def portfolio_dividends(portfolio_id: int = 1, include_deleted: bool = False) -> list[dict]:
    try:
        return list_dividends(portfolio_id, include_deleted=include_deleted)
    except PortfolioError as exc:
        raise _http_error(exc) from exc


@router.post("/portfolio/dividends", status_code=status.HTTP_201_CREATED)
def add_portfolio_dividend(payload: PortfolioDividendCreate, portfolio_id: int = 1) -> dict:
    try:
        return create_dividend(payload, get_fx_rate, portfolio_id)
    except (PortfolioError, MarketDataError) as exc:
        raise _http_error(exc) from exc


@router.get("/portfolio/dividends/settings")
def portfolio_dividend_settings(portfolio_id: int = 1) -> dict:
    try:
        return get_dividend_settings(portfolio_id)
    except PortfolioError as exc:
        raise _http_error(exc) from exc


@router.put("/portfolio/dividends/settings")
def save_portfolio_dividend_settings(
    payload: PortfolioDividendSettingsUpdate, portfolio_id: int = 1
) -> dict:
    try:
        return update_dividend_settings(payload, portfolio_id)
    except PortfolioError as exc:
        raise _http_error(exc) from exc


@router.get("/portfolio/dividends/summary")
def portfolio_dividend_summary(portfolio_id: int = 1) -> dict:
    try:
        return dividend_summary(find_market_asset, get_fx_rate, portfolio_id)
    except (PortfolioError, MarketDataError) as exc:
        raise _http_error(exc) from exc


@router.post("/portfolio/dividends/import/{symbol}")
def import_asset_dividends(
    symbol: str,
    period: str = "5y",
    portfolio_id: int = 1,
    options: PortfolioDividendImportOptions | None = None,
) -> dict:
    if period not in {"1y", "2y", "5y", "max"}:
        raise HTTPException(status_code=422, detail="Período no permitido")
    try:
        return import_advanced_dividends(
            symbol.upper(),
            period,
            options or PortfolioDividendImportOptions(),
            get_dividend_history,
            get_market_history,
            get_fx_rate,
            portfolio_id,
        )
    except (PortfolioError, MarketDataError) as exc:
        raise _http_error(exc) from exc


@router.delete("/portfolio/cash-movements/{movement_id}", status_code=status.HTTP_204_NO_CONTENT)
def remove_cash_movement(
    movement_id: int, portfolio_id: int = 1,
    reason: str = "Eliminación solicitada por el usuario",
) -> Response:
    try:
        delete_cash_movement(movement_id, portfolio_id, reason)
    except PortfolioError as exc:
        raise _http_error(exc) from exc
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.post("/portfolio/cash-movements/{movement_id}/restore")
def restore_deleted_cash_movement(
    movement_id: int, portfolio_id: int = 1,
    reason: str = "Restauración solicitada por el usuario",
) -> dict:
    try:
        return restore_cash_movement(movement_id, portfolio_id, reason)
    except PortfolioError as exc:
        raise _http_error(exc) from exc


@router.get("/portfolio/audit-log")
def portfolio_audit_log(
    portfolio_id: int = 1, limit: int = 100, entity_type: str | None = None
) -> list[dict]:
    try:
        return list_portfolio_audit_log(
            portfolio_id, limit=limit, entity_type=entity_type
        )
    except PortfolioError as exc:
        raise _http_error(exc) from exc


@router.get("/portfolio/equity-curve")
def portfolio_equity_curve(period: str = "1mo", portfolio_id: int = 1) -> dict:
    if period not in {"1mo", "3mo", "6mo", "1y", "2y", "5y", "max"}:
        raise HTTPException(status_code=422, detail="Período no permitido")
    try:
        return get_equity_curve(period, get_market_history, get_fx_history, portfolio_id)
    except (PortfolioError, MarketDataError) as exc:
        raise _http_error(exc) from exc
