from __future__ import annotations

from functools import lru_cache

from backend.core.config import settings
from backend.llm.base import LanguageModelProvider
from backend.llm.openai_responses import OpenAIResponsesProvider


@lru_cache(maxsize=1)
def get_language_model_provider() -> LanguageModelProvider | None:
    name = settings.llm_provider.strip().lower()
    if name in {"", "none", "disabled", "deterministic"}:
        return None
    if name in {"openai", "openai_responses", "responses"}:
        return OpenAIResponsesProvider()
    return None


def language_model_status() -> dict:
    provider = get_language_model_provider()
    if provider is None:
        return {"provider": "none", "configured": False, "model": None}
    return provider.status()
