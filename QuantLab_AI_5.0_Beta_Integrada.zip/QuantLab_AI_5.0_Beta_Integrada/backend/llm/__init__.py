"""Proveedores opcionales de redacción natural para el agente AI."""
