from __future__ import annotations

from typing import Protocol


class LanguageModelError(RuntimeError):
    """Falla uniforme de un proveedor de lenguaje opcional."""


class LanguageModelProvider(Protocol):
    name: str

    def is_available(self) -> bool: ...
    def rewrite(self, *, question: str, deterministic_answer: str, evidence_json: str, response_style: str = "claro") -> str: ...
    def status(self) -> dict: ...
