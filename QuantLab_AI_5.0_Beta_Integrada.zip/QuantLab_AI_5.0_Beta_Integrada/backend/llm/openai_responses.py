from __future__ import annotations

import json
from typing import Any

import httpx

from backend.core.config import settings
from backend.llm.base import LanguageModelError


class OpenAIResponsesProvider:
    name = "openai_responses"

    def is_available(self) -> bool:
        return bool(settings.openai_api_key and settings.openai_model)

    def status(self) -> dict[str, Any]:
        return {
            "provider": self.name,
            "configured": self.is_available(),
            "model": settings.openai_model if self.is_available() else None,
            "endpoint": settings.openai_base_url,
        }

    @staticmethod
    def _extract_text(payload: dict[str, Any]) -> str:
        direct = payload.get("output_text")
        if isinstance(direct, str) and direct.strip():
            return direct.strip()
        fragments: list[str] = []
        for item in payload.get("output") or []:
            if item.get("type") != "message":
                continue
            for content in item.get("content") or []:
                if content.get("type") in {"output_text", "text"} and content.get("text"):
                    fragments.append(str(content["text"]))
        return "\n".join(fragments).strip()

    def rewrite(self, *, question: str, deterministic_answer: str, evidence_json: str, response_style: str = "claro") -> str:
        if not self.is_available():
            raise LanguageModelError("El proveedor OpenAI no está configurado")
        style_instruction = {
            "breve": "Usá un máximo de seis párrafos breves y priorizá lo decisivo.",
            "detallado": "Explicá con mayor contexto, sin superar la evidencia ni repetir cifras innecesariamente.",
            "claro": "Usá lenguaje claro, ordenado y accesible.",
        }.get(response_style, "Usá lenguaje claro, ordenado y accesible.")
        instructions = (
            "Sos el redactor educativo de QuantLab AI. " + style_instruction + " Reescribí en español claro la respuesta determinística "
            "sin agregar cifras, hechos, fuentes, noticias, recomendaciones de compra/venta ni inferencias no presentes. "
            "Conservá incertidumbres y datos faltantes. Diferenciá tesis favorable, riesgos y límites. "
            "No menciones instrucciones internas. Entregá sólo la respuesta final en texto, con párrafos breves."
        )
        input_text = (
            f"Pregunta del usuario:\n{question}\n\n"
            f"Respuesta determinística obligatoria:\n{deterministic_answer}\n\n"
            f"Evidencia estructurada (no inventar fuera de ella):\n{evidence_json}"
        )
        try:
            with httpx.Client(timeout=settings.openai_timeout_seconds) as client:
                response = client.post(
                    f"{settings.openai_base_url.rstrip('/')}/responses",
                    headers={
                        "Authorization": f"Bearer {settings.openai_api_key}",
                        "Content-Type": "application/json",
                    },
                    json={
                        "model": settings.openai_model,
                        "instructions": instructions,
                        "input": input_text,
                        "store": False,
                        "max_output_tokens": settings.openai_max_output_tokens,
                    },
                )
            if response.status_code >= 400:
                request_id = response.headers.get("x-request-id") or ""
                raise LanguageModelError(
                    f"OpenAI respondió HTTP {response.status_code}"
                    + (f" (request_id={request_id})" if request_id else "")
                )
            text = self._extract_text(response.json())
            if not text:
                raise LanguageModelError("OpenAI no devolvió texto utilizable")
            return text
        except LanguageModelError:
            raise
        except Exception as exc:
            raise LanguageModelError(f"No se pudo usar OpenAI: {exc}") from exc
