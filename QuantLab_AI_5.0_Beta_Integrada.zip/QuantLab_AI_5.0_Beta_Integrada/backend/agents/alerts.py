from __future__ import annotations

from datetime import datetime, timezone
import json
from typing import Any

from backend.agents.tools import execute_tool
from backend.core.database import get_connection
from backend.models import AIAlertRuleCreate, AIAlertRuleUpdate


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def ensure_default_rules(portfolio_id: int) -> None:
    defaults = (
        ("Concentración por activo", "CONCENTRATION", "", 30.0, "HIGH", 24),
        ("Drawdown actual", "DRAWDOWN", "", 15.0, "HIGH", 24),
        ("Volatilidad anualizada", "VOLATILITY", "", 35.0, "MEDIUM", 24),
    )
    with get_connection() as connection:
        for name, rule_type, symbol, threshold, severity, cooldown in defaults:
            connection.execute(
                """
                INSERT INTO ai_alert_rules
                    (portfolio_id, name, rule_type, symbol, threshold, severity,
                     cooldown_hours, is_enabled, created_at, updated_at)
                SELECT ?, ?, ?, ?, ?, ?, ?, 1, ?, ?
                WHERE NOT EXISTS (
                    SELECT 1 FROM ai_alert_rules
                    WHERE portfolio_id = ? AND rule_type = ? AND symbol = ?
                )
                """,
                (
                    portfolio_id, name, rule_type, symbol, threshold, severity, cooldown,
                    _now(), _now(), portfolio_id, rule_type, symbol,
                ),
            )


def _serialize_rule(row: Any) -> dict[str, Any]:
    item = dict(row)
    item["is_enabled"] = bool(item["is_enabled"])
    return item


def list_rules(portfolio_id: int) -> list[dict[str, Any]]:
    ensure_default_rules(portfolio_id)
    with get_connection() as connection:
        rows = connection.execute(
            """
            SELECT id, portfolio_id, name, rule_type, symbol, threshold, severity,
                   cooldown_hours, is_enabled, last_evaluated_at, created_at, updated_at
            FROM ai_alert_rules
            WHERE portfolio_id = ?
            ORDER BY is_enabled DESC, id
            """,
            (portfolio_id,),
        ).fetchall()
    return [_serialize_rule(row) for row in rows]


def create_rule(portfolio_id: int, payload: AIAlertRuleCreate) -> dict[str, Any]:
    with get_connection() as connection:
        cursor = connection.execute(
            """
            INSERT INTO ai_alert_rules
                (portfolio_id, name, rule_type, symbol, threshold, severity,
                 cooldown_hours, is_enabled, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                portfolio_id, payload.name, payload.rule_type, payload.symbol,
                payload.threshold, payload.severity, payload.cooldown_hours,
                int(payload.is_enabled), _now(), _now(),
            ),
        )
        rule_id = int(cursor.lastrowid)
        row = connection.execute("SELECT * FROM ai_alert_rules WHERE id = ?", (rule_id,)).fetchone()
    return _serialize_rule(row)


def update_rule(portfolio_id: int, rule_id: int, payload: AIAlertRuleUpdate) -> dict[str, Any] | None:
    with get_connection() as connection:
        cursor = connection.execute(
            """
            UPDATE ai_alert_rules
            SET name = ?, rule_type = ?, symbol = ?, threshold = ?, severity = ?,
                cooldown_hours = ?, is_enabled = ?, updated_at = ?
            WHERE id = ? AND portfolio_id = ?
            """,
            (
                payload.name, payload.rule_type, payload.symbol, payload.threshold,
                payload.severity, payload.cooldown_hours, int(payload.is_enabled),
                _now(), rule_id, portfolio_id,
            ),
        )
        if cursor.rowcount == 0:
            return None
        row = connection.execute("SELECT * FROM ai_alert_rules WHERE id = ?", (rule_id,)).fetchone()
    return _serialize_rule(row)


def disable_rule(portfolio_id: int, rule_id: int) -> bool:
    with get_connection() as connection:
        cursor = connection.execute(
            "UPDATE ai_alert_rules SET is_enabled = 0, updated_at = ? WHERE id = ? AND portfolio_id = ?",
            (_now(), rule_id, portfolio_id),
        )
    return cursor.rowcount > 0


def _rule_observation(rule: dict[str, Any], analytics: dict[str, Any] | None, quotes: dict[str, dict[str, Any]]) -> tuple[float | None, dict[str, Any]]:
    rule_type = rule["rule_type"]
    if rule_type == "CONCENTRATION":
        concentration = (analytics or {}).get("concentration") or {}
        rows = concentration.get("by_asset") or []
        leader = rows[0] if rows else {}
        return float(concentration.get("largest_position_percent") or 0.0), {
            "largest_position": leader.get("key") or "",
            "largest_position_label": leader.get("label") or "",
        }
    if rule_type == "DRAWDOWN":
        risk = (analytics or {}).get("risk") or {}
        return abs(float(risk.get("current_drawdown_percent") or 0.0)), {}
    if rule_type == "VOLATILITY":
        risk = (analytics or {}).get("risk") or {}
        return float(risk.get("annualized_volatility_percent") or 0.0), {}
    quote = quotes.get(rule.get("symbol") or "") or {}
    price = quote.get("price")
    return (float(price) if price is not None else None), {
        "currency": quote.get("currency"),
        "source": quote.get("source"),
        "last_updated": quote.get("last_updated"),
    }


def _is_triggered(rule_type: str, observed: float, threshold: float) -> bool:
    if rule_type == "PRICE_BELOW":
        return observed <= threshold
    return observed >= threshold


def _event_copy(rule: dict[str, Any], observed: float, context: dict[str, Any]) -> tuple[str, str]:
    threshold = float(rule["threshold"])
    symbol = rule.get("symbol") or ""
    if rule["rule_type"] == "CONCENTRATION":
        asset = context.get("largest_position") or "la mayor posición"
        return (
            "Concentración elevada",
            f"{asset} representa {observed:.2f}% del portafolio, por encima del umbral de {threshold:.2f}%.",
        )
    if rule["rule_type"] == "DRAWDOWN":
        return ("Drawdown relevante", f"El drawdown actual es {observed:.2f}%, con un umbral de {threshold:.2f}%.")
    if rule["rule_type"] == "VOLATILITY":
        return ("Volatilidad elevada", f"La volatilidad anualizada es {observed:.2f}%, por encima de {threshold:.2f}%.")
    direction = "superó" if rule["rule_type"] == "PRICE_ABOVE" else "cayó por debajo de"
    return (f"Alerta de precio · {symbol}", f"{symbol} {direction} {threshold:.4f}; última referencia {observed:.4f}.")


def _upsert_triggered_event(connection, rule: dict[str, Any], observed: float, context: dict[str, Any]) -> tuple[dict[str, Any], bool]:
    event_key = f"rule:{rule['id']}:{rule.get('symbol') or 'portfolio'}"
    existing = connection.execute(
        """
        SELECT * FROM ai_alert_events
        WHERE event_key = ? AND status IN ('ACTIVE', 'ACKNOWLEDGED', 'DISMISSED')
        ORDER BY id DESC LIMIT 1
        """,
        (event_key,),
    ).fetchone()
    title, message = _event_copy(rule, observed, context)
    now = _now()
    created = existing is None
    if existing is None:
        cursor = connection.execute(
            """
            INSERT INTO ai_alert_events
                (portfolio_id, rule_id, event_key, rule_type, symbol, title, message,
                 severity, status, observed_value, threshold, context_json,
                 triggered_at, last_seen_at, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'ACTIVE', ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                rule["portfolio_id"], rule["id"], event_key, rule["rule_type"],
                rule.get("symbol") or "", title, message, rule["severity"], observed,
                rule["threshold"], json.dumps(context, ensure_ascii=False), now, now, now, now,
            ),
        )
        event_id = int(cursor.lastrowid)
        connection.execute(
            """
            INSERT INTO ai_notification_outbox
                (portfolio_id, alert_event_id, channel, status, payload_json, created_at)
            VALUES (?, ?, 'IN_APP', 'PENDING', ?, ?)
            """,
            (rule["portfolio_id"], event_id, json.dumps({"title": title, "message": message}, ensure_ascii=False), now),
        )
    else:
        event_id = int(existing["id"])
        connection.execute(
            """
            UPDATE ai_alert_events
            SET title = ?, message = ?, severity = ?, observed_value = ?, threshold = ?,
                context_json = ?, last_seen_at = ?, updated_at = ?
            WHERE id = ?
            """,
            (title, message, rule["severity"], observed, rule["threshold"], json.dumps(context, ensure_ascii=False), now, now, event_id),
        )
    row = connection.execute("SELECT * FROM ai_alert_events WHERE id = ?", (event_id,)).fetchone()
    return _serialize_event(row), created


def _resolve_event(connection, rule: dict[str, Any]) -> int:
    event_key = f"rule:{rule['id']}:{rule.get('symbol') or 'portfolio'}"
    cursor = connection.execute(
        """
        UPDATE ai_alert_events
        SET status = 'RESOLVED', resolved_at = ?, updated_at = ?
        WHERE event_key = ? AND status IN ('ACTIVE', 'ACKNOWLEDGED', 'DISMISSED')
        """,
        (_now(), _now(), event_key),
    )
    return cursor.rowcount


def _serialize_event(row: Any) -> dict[str, Any]:
    item = dict(row)
    try:
        item["context"] = json.loads(item.pop("context_json") or "{}")
    except json.JSONDecodeError:
        item["context"] = {}
    return item


def evaluate_alerts(portfolio_id: int, period: str = "1y") -> dict[str, Any]:
    rules = [rule for rule in list_rules(portfolio_id) if rule["is_enabled"]]
    needs_analytics = any(rule["rule_type"] in {"CONCENTRATION", "DRAWDOWN", "VOLATILITY"} for rule in rules)
    analytics_run = execute_tool("portfolio_analytics", {"portfolio_id": portfolio_id, "period": period}) if needs_analytics else None
    analytics = analytics_run.get("result") if analytics_run and analytics_run.get("status") == "success" else None
    quotes: dict[str, dict[str, Any]] = {}
    errors: list[str] = []
    if analytics_run and analytics_run.get("status") != "success":
        errors.append(f"Analytics: {analytics_run.get('error') or 'no disponible'}")
    for symbol in sorted({rule["symbol"] for rule in rules if rule.get("symbol")}):
        run = execute_tool("market_quote", {"symbol": symbol})
        if run["status"] == "success":
            quotes[symbol] = run["result"]
        else:
            errors.append(f"{symbol}: {run.get('error') or 'cotización no disponible'}")

    triggered: list[dict[str, Any]] = []
    new_events = 0
    resolved = 0
    with get_connection() as connection:
        for rule in rules:
            observed, context = _rule_observation(rule, analytics, quotes)
            connection.execute(
                "UPDATE ai_alert_rules SET last_evaluated_at = ?, updated_at = updated_at WHERE id = ?",
                (_now(), rule["id"]),
            )
            if observed is None:
                continue
            if _is_triggered(rule["rule_type"], observed, float(rule["threshold"])):
                event, created = _upsert_triggered_event(connection, rule, observed, context)
                triggered.append(event)
                new_events += int(created)
            else:
                resolved += _resolve_event(connection, rule)
    return {
        "portfolio_id": portfolio_id,
        "period": period,
        "evaluated_rules": len(rules),
        "triggered": triggered,
        "new_events": new_events,
        "resolved_events": resolved,
        "errors": errors,
        "is_partial": bool(errors),
        "generated_at": _now(),
        "safety": {"automatic_trading": False, "educational_only": True, "notification_delivery_enabled": False},
    }


def list_events(portfolio_id: int, status: str = "OPEN", limit: int = 100) -> list[dict[str, Any]]:
    where = "status IN ('ACTIVE', 'ACKNOWLEDGED', 'DISMISSED')" if status == "OPEN" else "status = ?"
    params: list[Any] = [portfolio_id]
    if status != "OPEN":
        params.append(status)
    params.append(max(1, min(limit, 500)))
    with get_connection() as connection:
        rows = connection.execute(
            f"""
            SELECT * FROM ai_alert_events
            WHERE portfolio_id = ? AND {where}
            ORDER BY CASE severity WHEN 'CRITICAL' THEN 4 WHEN 'HIGH' THEN 3 WHEN 'MEDIUM' THEN 2 ELSE 1 END DESC,
                     last_seen_at DESC, id DESC
            LIMIT ?
            """,
            tuple(params),
        ).fetchall()
    return [_serialize_event(row) for row in rows]


def update_event_status(portfolio_id: int, event_id: int, status: str, note: str = "") -> dict[str, Any] | None:
    now = _now()
    timestamp_column = {"ACKNOWLEDGED": "acknowledged_at", "DISMISSED": "dismissed_at"}.get(status)
    with get_connection() as connection:
        if timestamp_column:
            cursor = connection.execute(
                f"""
                UPDATE ai_alert_events
                SET status = ?, {timestamp_column} = ?, user_note = ?, updated_at = ?
                WHERE id = ? AND portfolio_id = ? AND status <> 'RESOLVED'
                """,
                (status, now, note, now, event_id, portfolio_id),
            )
        else:
            cursor = connection.execute(
                """
                UPDATE ai_alert_events
                SET status = 'ACTIVE', acknowledged_at = NULL, dismissed_at = NULL,
                    user_note = ?, updated_at = ?
                WHERE id = ? AND portfolio_id = ? AND status <> 'RESOLVED'
                """,
                (note, now, event_id, portfolio_id),
            )
        if cursor.rowcount == 0:
            return None
        row = connection.execute("SELECT * FROM ai_alert_events WHERE id = ?", (event_id,)).fetchone()
    return _serialize_event(row)


def notification_readiness(portfolio_id: int) -> dict[str, Any]:
    with get_connection() as connection:
        pending = connection.execute(
            "SELECT COUNT(*) FROM ai_notification_outbox WHERE portfolio_id = ? AND status = 'PENDING'",
            (portfolio_id,),
        ).fetchone()[0]
    return {
        "portfolio_id": portfolio_id,
        "pending_in_app_events": int(pending),
        "delivery_enabled": False,
        "available_channel": "IN_APP",
        "future_channels": ["EMAIL", "PUSH", "TELEGRAM"],
        "note": "La cola está preparada, pero esta versión no envía notificaciones externas ni ejecuta operaciones.",
    }
