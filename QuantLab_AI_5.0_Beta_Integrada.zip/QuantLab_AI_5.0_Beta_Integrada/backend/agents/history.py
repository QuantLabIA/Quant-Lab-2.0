from __future__ import annotations

from datetime import datetime, timezone
import json
from typing import Any

from backend.core.database import get_connection


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def create_session(portfolio_id: int, title: str, risk_profile: str) -> int:
    with get_connection() as connection:
        cursor = connection.execute(
            """
            INSERT INTO ai_analysis_sessions (portfolio_id, title, risk_profile, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?)
            """,
            (portfolio_id, title[:120], risk_profile, _now(), _now()),
        )
        return int(cursor.lastrowid)


def session_exists(session_id: int, portfolio_id: int) -> bool:
    with get_connection() as connection:
        row = connection.execute(
            "SELECT 1 FROM ai_analysis_sessions WHERE id = ? AND portfolio_id = ? AND is_archived = 0",
            (session_id, portfolio_id),
        ).fetchone()
    return row is not None


def add_message(session_id: int, role: str, content: str, payload: dict[str, Any] | None = None) -> int:
    with get_connection() as connection:
        cursor = connection.execute(
            """
            INSERT INTO ai_analysis_messages (session_id, role, content, payload_json, created_at)
            VALUES (?, ?, ?, ?, ?)
            """,
            (session_id, role, content, json.dumps(payload or {}, ensure_ascii=False), _now()),
        )
        connection.execute(
            "UPDATE ai_analysis_sessions SET updated_at = ? WHERE id = ?",
            (_now(), session_id),
        )
        return int(cursor.lastrowid)


def add_tool_runs(message_id: int, tool_runs: list[dict[str, Any]]) -> None:
    with get_connection() as connection:
        for run in tool_runs:
            result = run.get("result") or {}
            source = str(result.get("source") or (result.get("data") or {}).get("source") or "")
            observed_at = str(result.get("last_updated") or (result.get("data") or {}).get("last_updated") or "")
            connection.execute(
                """
                INSERT INTO ai_tool_runs
                    (message_id, tool_name, input_json, status, source, observed_at,
                     duration_ms, error, output_summary_json, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    message_id,
                    run.get("name"),
                    json.dumps(run.get("arguments") or {}, ensure_ascii=False),
                    run.get("status"),
                    source,
                    observed_at,
                    run.get("duration_ms") or 0,
                    run.get("error") or "",
                    json.dumps(_compact_tool_result(result), ensure_ascii=False),
                    _now(),
                ),
            )


def _compact_tool_result(result: dict[str, Any]) -> dict[str, Any]:
    if not result:
        return {}
    keys = (
        "symbol", "name", "summary", "source", "last_updated", "is_partial", "errors",
        "portfolio_id", "period", "base_currency", "methodology",
    )
    compact = {key: result.get(key) for key in keys if key in result}
    if "summary" in result and isinstance(result["summary"], dict):
        compact["summary"] = result["summary"]
    if "risk_summary" in result:
        compact["risk_summary"] = result["risk_summary"]
    return compact


def list_sessions(portfolio_id: int, limit: int = 20) -> list[dict[str, Any]]:
    with get_connection() as connection:
        rows = connection.execute(
            """
            SELECT s.id, s.portfolio_id, s.title, s.risk_profile, s.created_at, s.updated_at,
                   COUNT(m.id) AS messages_count
            FROM ai_analysis_sessions s
            LEFT JOIN ai_analysis_messages m ON m.session_id = s.id
            WHERE s.portfolio_id = ? AND s.is_archived = 0
            GROUP BY s.id
            ORDER BY s.updated_at DESC, s.id DESC
            LIMIT ?
            """,
            (portfolio_id, max(1, min(limit, 100))),
        ).fetchall()
    return [dict(row) for row in rows]


def get_session(session_id: int, portfolio_id: int) -> dict[str, Any] | None:
    with get_connection() as connection:
        session = connection.execute(
            """
            SELECT id, portfolio_id, title, risk_profile, last_intent, context_symbols_json, created_at, updated_at
            FROM ai_analysis_sessions
            WHERE id = ? AND portfolio_id = ? AND is_archived = 0
            """,
            (session_id, portfolio_id),
        ).fetchone()
        if session is None:
            return None
        messages = connection.execute(
            """
            SELECT id, role, content, payload_json, created_at
            FROM ai_analysis_messages
            WHERE session_id = ?
            ORDER BY id
            """,
            (session_id,),
        ).fetchall()
    parsed_messages = []
    for row in messages:
        item = dict(row)
        try:
            item["payload"] = json.loads(item.pop("payload_json") or "{}")
        except json.JSONDecodeError:
            item["payload"] = {}
        parsed_messages.append(item)
    session_data = dict(session)
    try:
        session_data["context_symbols"] = json.loads(session_data.pop("context_symbols_json") or "[]")
    except json.JSONDecodeError:
        session_data["context_symbols"] = []
    return {**session_data, "messages": parsed_messages}


def archive_session(session_id: int, portfolio_id: int) -> bool:
    with get_connection() as connection:
        cursor = connection.execute(
            """
            UPDATE ai_analysis_sessions
            SET is_archived = 1, updated_at = ?
            WHERE id = ? AND portfolio_id = ? AND is_archived = 0
            """,
            (_now(), session_id, portfolio_id),
        )
        return cursor.rowcount > 0


def update_session_context(session_id: int, intent: str, symbols: list[str]) -> None:
    with get_connection() as connection:
        connection.execute(
            """
            UPDATE ai_analysis_sessions
            SET last_intent = ?, context_symbols_json = ?, updated_at = ?
            WHERE id = ?
            """,
            (intent, json.dumps(symbols, ensure_ascii=False), _now(), session_id),
        )


def get_session_context(session_id: int, portfolio_id: int) -> dict[str, Any] | None:
    with get_connection() as connection:
        row = connection.execute(
            """
            SELECT last_intent, context_symbols_json
            FROM ai_analysis_sessions
            WHERE id = ? AND portfolio_id = ? AND is_archived = 0
            """,
            (session_id, portfolio_id),
        ).fetchone()
    if row is None:
        return None
    try:
        symbols = json.loads(row["context_symbols_json"] or "[]")
    except json.JSONDecodeError:
        symbols = []
    return {"last_intent": row["last_intent"] or "", "symbols": symbols}
