"""Agente financiero verificable de QuantLab AI."""
