from __future__ import annotations

from datetime import datetime, timezone

from backend.core.database import get_connection


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def get_agent_settings(portfolio_id: int) -> dict:
    with get_connection() as connection:
        connection.execute(
            """
            INSERT OR IGNORE INTO ai_agent_settings
                (portfolio_id, use_language_model, response_style, created_at, updated_at)
            VALUES (?, 0, 'claro', ?, ?)
            """,
            (portfolio_id, _now(), _now()),
        )
        row = connection.execute(
            """
            SELECT portfolio_id, use_language_model, response_style, created_at, updated_at
            FROM ai_agent_settings WHERE portfolio_id = ?
            """,
            (portfolio_id,),
        ).fetchone()
    result = dict(row)
    result["use_language_model"] = bool(result["use_language_model"])
    return result


def update_agent_settings(portfolio_id: int, *, use_language_model: bool, response_style: str) -> dict:
    with get_connection() as connection:
        connection.execute(
            """
            INSERT INTO ai_agent_settings
                (portfolio_id, use_language_model, response_style, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?)
            ON CONFLICT(portfolio_id) DO UPDATE SET
                use_language_model = excluded.use_language_model,
                response_style = excluded.response_style,
                updated_at = excluded.updated_at
            """,
            (portfolio_id, int(use_language_model), response_style, _now(), _now()),
        )
    return get_agent_settings(portfolio_id)
