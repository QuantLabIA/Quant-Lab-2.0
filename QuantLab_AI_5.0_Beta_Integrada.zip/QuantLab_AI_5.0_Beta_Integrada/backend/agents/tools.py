from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import time
from typing import Any, Callable

from backend.models import AIAnalysisRequest
from backend.services.ai_service import analyze_asset
from backend.services.analytics_service import compare_assets, get_analytics_overview
from backend.services.corporate_actions_service import list_corporate_actions
from backend.services.market_service import (
    find_market_asset,
    get_fundamental_data,
    get_fx_history,
    get_fx_rate,
    get_market_history,
)
from backend.services.fundamental_service import analyze_fundamentals, compare_fundamentals
from backend.services.portfolio_service import (
    get_portfolio_overview,
    list_cash_movements,
    list_fx_conversions,
    list_portfolio_transactions,
)


@dataclass(frozen=True)
class AgentTool:
    name: str
    description: str
    runner: Callable[[dict[str, Any]], dict[str, Any]]


def _market_quote(arguments: dict[str, Any]) -> dict[str, Any]:
    symbol = str(arguments["symbol"]).upper()
    quote = find_market_asset(symbol)
    if quote is None:
        raise ValueError(f"No se encontró el símbolo {symbol}")
    return quote


def _technical_analysis(arguments: dict[str, Any]) -> dict[str, Any]:
    return analyze_asset(
        AIAnalysisRequest(
            symbol=str(arguments["symbol"]).upper(),
            risk_profile=str(arguments.get("risk_profile") or "moderado"),
        )
    )



def _fundamental_analysis(arguments: dict[str, Any]) -> dict[str, Any]:
    return analyze_fundamentals(str(arguments["symbol"]).upper(), get_fundamental_data)


def _fundamental_comparison(arguments: dict[str, Any]) -> dict[str, Any]:
    symbols = [str(item).upper() for item in arguments.get("symbols") or []]
    return compare_fundamentals(symbols, get_fundamental_data)

def _portfolio_snapshot(arguments: dict[str, Any]) -> dict[str, Any]:
    return get_portfolio_overview(
        find_market_asset,
        get_fx_rate,
        int(arguments.get("portfolio_id") or 1),
    )


def _portfolio_analytics(arguments: dict[str, Any]) -> dict[str, Any]:
    return get_analytics_overview(
        str(arguments.get("period") or "1y"),
        get_market_history,
        get_fx_history,
        find_market_asset,
        get_fx_rate,
        int(arguments.get("portfolio_id") or 1),
    )


def _portfolio_activity(arguments: dict[str, Any]) -> dict[str, Any]:
    portfolio_id = int(arguments.get("portfolio_id") or 1)
    limit = max(1, min(50, int(arguments.get("limit") or 12)))
    transactions = list_portfolio_transactions(portfolio_id=portfolio_id, include_deleted=False)
    movements = list_cash_movements(portfolio_id=portfolio_id, include_deleted=False)
    conversions = list_fx_conversions(portfolio_id=portfolio_id, include_deleted=False)
    actions = list_corporate_actions(portfolio_id=portfolio_id, include_deleted=False)
    return {
        "portfolio_id": portfolio_id,
        "transactions": transactions[:limit],
        "cash_movements": movements[:limit],
        "fx_conversions": conversions[:limit],
        "corporate_actions": actions[:limit],
        "counts": {
            "transactions": len(transactions),
            "cash_movements": len(movements),
            "fx_conversions": len(conversions),
            "corporate_actions": len(actions),
        },
        "source": "SQLite local de QuantLab AI",
        "last_updated": datetime.now(timezone.utc).isoformat(),
    }


def _asset_comparison(arguments: dict[str, Any]) -> dict[str, Any]:
    symbols = [str(item).upper() for item in arguments.get("symbols") or []]
    return compare_assets(
        symbols,
        str(arguments.get("period") or "1y"),
        get_market_history,
        get_fx_history,
        int(arguments.get("portfolio_id") or 1),
    )


TOOLS: dict[str, AgentTool] = {
    "market_quote": AgentTool(
        "market_quote",
        "Consulta la última referencia, moneda, mercado, fuente y estado de un activo.",
        _market_quote,
    ),
    "technical_analysis": AgentTool(
        "technical_analysis",
        "Calcula tendencia, SMA 20/50, RSI y volatilidad con históricos del activo.",
        _technical_analysis,
    ),
    "fundamental_analysis": AgentTool(
        "fundamental_analysis",
        "Consulta estados financieros, múltiplos, crecimiento, rentabilidad, deuda y flujo de caja.",
        _fundamental_analysis,
    ),
    "fundamental_comparison": AgentTool(
        "fundamental_comparison",
        "Compara de dos a seis empresas por calidad, crecimiento, fortaleza financiera y valuación.",
        _fundamental_comparison,
    ),
    "portfolio_snapshot": AgentTool(
        "portfolio_snapshot",
        "Consulta patrimonio, efectivo, posiciones, P&L y valuación del portafolio.",
        _portfolio_snapshot,
    ),
    "portfolio_analytics": AgentTool(
        "portfolio_analytics",
        "Calcula rendimiento, benchmark, drawdown, riesgo de cola, correlación y concentración.",
        _portfolio_analytics,
    ),
    "portfolio_activity": AgentTool(
        "portfolio_activity",
        "Consulta operaciones, movimientos, conversiones FX y eventos corporativos registrados.",
        _portfolio_activity,
    ),
    "asset_comparison": AgentTool(
        "asset_comparison",
        "Compara de dos a seis activos en moneda base con retorno, volatilidad y riesgo.",
        _asset_comparison,
    ),
}


def tool_catalog() -> list[dict[str, str]]:
    return [{"name": item.name, "description": item.description} for item in TOOLS.values()]


def execute_tool(name: str, arguments: dict[str, Any]) -> dict[str, Any]:
    tool = TOOLS.get(name)
    if tool is None:
        raise ValueError(f"Herramienta desconocida: {name}")
    started = time.perf_counter()
    try:
        result = tool.runner(arguments)
        return {
            "name": name,
            "arguments": arguments,
            "status": "success",
            "duration_ms": round((time.perf_counter() - started) * 1000, 2),
            "result": result,
            "error": None,
        }
    except Exception as exc:
        return {
            "name": name,
            "arguments": arguments,
            "status": "error",
            "duration_ms": round((time.perf_counter() - started) * 1000, 2),
            "result": None,
            "error": str(exc),
        }
