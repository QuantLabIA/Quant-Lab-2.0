from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import math
from typing import Any

from backend.core.database import get_connection


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _number(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if math.isfinite(result) else None


def _snapshot_for_run(run: dict[str, Any]) -> tuple[str, str, str, dict[str, Any]] | None:
    if run.get("status") != "success" or not run.get("result"):
        return None
    name = str(run["name"])
    result = run["result"]
    args = run.get("arguments") or {}
    symbol = str(args.get("symbol") or result.get("symbol") or "").upper()
    if name == "market_quote":
        payload = {key: result.get(key) for key in ("price", "change_percent", "currency", "market_state", "quote_status", "last_updated")}
        return f"market_quote:{symbol}", name, symbol, payload
    if name == "technical_analysis":
        indicators = result.get("indicators") or {}
        payload = {key: indicators.get(key) for key in ("price", "change_percent", "rsi14", "annualized_volatility_percent", "trend", "risk_level")}
        return f"technical_analysis:{symbol}", name, symbol, payload
    if name == "fundamental_analysis":
        metrics = result.get("metrics") or {}
        scores = result.get("scores") or {}
        payload = {
            "overall_score": scores.get("overall"),
            "quality_score": scores.get("quality"),
            "growth_score": scores.get("growth"),
            "financial_strength_score": scores.get("financial_strength"),
            "valuation_score": scores.get("valuation"),
            "revenue_growth_percent": metrics.get("revenue_growth_percent"),
            "earnings_growth_percent": metrics.get("earnings_growth_percent"),
            "profit_margin_percent": metrics.get("profit_margin_percent"),
            "trailing_pe": metrics.get("trailing_pe"),
            "coverage_status": (result.get("coverage") or {}).get("status"),
        }
        return f"fundamental_analysis:{symbol}", name, symbol, payload
    if name == "portfolio_snapshot":
        summary = result.get("summary") or {}
        holdings = result.get("holdings") or []
        largest = max(holdings, key=lambda item: float(item.get("market_value") or 0.0), default={})
        payload = {
            "total_equity": summary.get("total_equity"),
            "investment_profit": summary.get("investment_profit"),
            "return_percent": summary.get("return_percent") if summary.get("return_percent") is not None else summary.get("total_return_percent"),
            "realized_pnl": summary.get("realized_pnl"),
            "unrealized_pnl": summary.get("unrealized_pnl"),
            "positions_count": len(holdings),
            "largest_symbol": largest.get("symbol"),
            "largest_value": largest.get("market_value"),
            "valuation_status": summary.get("valuation_status"),
        }
        return "portfolio_snapshot", name, "", payload
    if name == "portfolio_analytics":
        risk = result.get("risk") or {}
        performance = result.get("performance") or {}
        returns = performance.get("period_returns") or {}
        concentration = result.get("concentration") or {}
        benchmark = result.get("benchmark") or {}
        period = str(result.get("period") or args.get("period") or "1y")
        payload = {
            "selected_period_percent": returns.get("selected_period_percent"),
            "since_inception_percent": returns.get("since_inception_percent"),
            "annualized_volatility_percent": risk.get("annualized_volatility_percent"),
            "current_drawdown_percent": risk.get("current_drawdown_percent"),
            "max_drawdown_percent": risk.get("max_drawdown_percent"),
            "var_95_percent": risk.get("var_95_percent"),
            "largest_position_percent": concentration.get("largest_position_percent"),
            "benchmark_return_percent": benchmark.get("benchmark_return_percent"),
            "outperformance_percent": benchmark.get("outperformance_percent"),
            "is_partial": result.get("is_partial"),
        }
        return f"portfolio_analytics:{period}", name, "", payload
    return None


LABELS = {
    "price": "precio",
    "change_percent": "variación diaria",
    "rsi14": "RSI",
    "annualized_volatility_percent": "volatilidad anualizada",
    "trend": "tendencia",
    "risk_level": "nivel de riesgo",
    "overall_score": "puntaje fundamental",
    "revenue_growth_percent": "crecimiento de ingresos",
    "earnings_growth_percent": "crecimiento de beneficios",
    "profit_margin_percent": "margen neto",
    "trailing_pe": "P/E",
    "total_equity": "patrimonio",
    "investment_profit": "ganancia de inversión",
    "return_percent": "retorno",
    "positions_count": "cantidad de posiciones",
    "largest_symbol": "mayor posición",
    "selected_period_percent": "rendimiento del período",
    "current_drawdown_percent": "drawdown actual",
    "max_drawdown_percent": "drawdown máximo",
    "var_95_percent": "VaR 95",
    "largest_position_percent": "concentración máxima",
    "outperformance_percent": "diferencia contra benchmark",
    "coverage_status": "cobertura fundamental",
    "valuation_status": "estado de valuación",
}


def _material_change(key: str, old: Any, new: Any) -> bool:
    if old is None or new is None:
        return old != new
    old_num, new_num = _number(old), _number(new)
    if old_num is not None and new_num is not None:
        absolute = abs(new_num - old_num)
        if key in {"price", "total_equity", "investment_profit", "largest_value"}:
            baseline = max(abs(old_num), 1.0)
            return absolute / baseline >= 0.005
        if key == "positions_count":
            return absolute >= 1
        return absolute >= 0.5
    return old != new


def _format_change(key: str, old: Any, new: Any, symbol: str) -> dict[str, Any]:
    label = LABELS.get(key, key.replace("_", " "))
    old_num, new_num = _number(old), _number(new)
    prefix = f"{symbol}: " if symbol else ""
    if old_num is not None and new_num is not None:
        delta = new_num - old_num
        direction = "subió" if delta > 0 else "bajó"
        text = f"{prefix}{label} {direction} de {old_num:.2f} a {new_num:.2f} ({delta:+.2f})."
        return {"metric": key, "label": label, "previous": old_num, "current": new_num, "delta": delta, "text": text}
    return {"metric": key, "label": label, "previous": old, "current": new, "delta": None, "text": f"{prefix}{label} cambió de {old or 'sin dato'} a {new or 'sin dato'}."}


def preview_changes(portfolio_id: int, tool_runs: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    changes: list[dict[str, Any]] = []
    snapshots: list[dict[str, Any]] = []
    with get_connection() as connection:
        for run in tool_runs:
            snapshot = _snapshot_for_run(run)
            if snapshot is None:
                continue
            key, snapshot_type, symbol, payload = snapshot
            previous_row = connection.execute(
                """
                SELECT payload_json, created_at FROM ai_analysis_snapshots
                WHERE portfolio_id = ? AND snapshot_key = ?
                ORDER BY id DESC LIMIT 1
                """,
                (portfolio_id, key),
            ).fetchone()
            previous = {}
            previous_at = None
            if previous_row:
                previous_at = previous_row["created_at"]
                try:
                    previous = json.loads(previous_row["payload_json"] or "{}")
                except json.JSONDecodeError:
                    previous = {}
            if previous:
                for metric, current in payload.items():
                    old = previous.get(metric)
                    if _material_change(metric, old, current):
                        item = _format_change(metric, old, current, symbol)
                        item.update({"snapshot_key": key, "snapshot_type": snapshot_type, "previous_at": previous_at})
                        changes.append(item)
            canonical = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
            snapshots.append({
                "snapshot_key": key,
                "snapshot_type": snapshot_type,
                "symbol": symbol,
                "payload": payload,
                "fingerprint": hashlib.sha256(canonical.encode("utf-8")).hexdigest(),
            })
    return changes[:20], snapshots


def store_snapshots(portfolio_id: int, session_id: int | None, message_id: int | None, snapshots: list[dict[str, Any]]) -> int:
    stored = 0
    with get_connection() as connection:
        for item in snapshots:
            previous = connection.execute(
                """
                SELECT fingerprint FROM ai_analysis_snapshots
                WHERE portfolio_id = ? AND snapshot_key = ?
                ORDER BY id DESC LIMIT 1
                """,
                (portfolio_id, item["snapshot_key"]),
            ).fetchone()
            if previous and previous["fingerprint"] == item["fingerprint"]:
                continue
            connection.execute(
                """
                INSERT INTO ai_analysis_snapshots
                    (portfolio_id, session_id, message_id, snapshot_key, snapshot_type,
                     symbol, payload_json, fingerprint, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    portfolio_id, session_id, message_id, item["snapshot_key"], item["snapshot_type"],
                    item["symbol"], json.dumps(item["payload"], ensure_ascii=False), item["fingerprint"], _now(),
                ),
            )
            stored += 1
    return stored


def recent_changes(portfolio_id: int, limit: int = 50) -> list[dict[str, Any]]:
    with get_connection() as connection:
        rows = connection.execute(
            """
            SELECT id, session_id, message_id, snapshot_key, snapshot_type, symbol,
                   payload_json, created_at
            FROM ai_analysis_snapshots
            WHERE portfolio_id = ?
            ORDER BY id DESC LIMIT ?
            """,
            (portfolio_id, max(2, min(limit, 200))),
        ).fetchall()
    grouped: dict[str, list[dict[str, Any]]] = {}
    for row in rows:
        item = dict(row)
        try:
            item["payload"] = json.loads(item.pop("payload_json") or "{}")
        except json.JSONDecodeError:
            item["payload"] = {}
        grouped.setdefault(item["snapshot_key"], []).append(item)
    result: list[dict[str, Any]] = []
    for key, items in grouped.items():
        if len(items) < 2:
            continue
        current, previous = items[0], items[1]
        changes = []
        for metric, value in current["payload"].items():
            old = previous["payload"].get(metric)
            if _material_change(metric, old, value):
                changes.append(_format_change(metric, old, value, current.get("symbol") or ""))
        if changes:
            result.append({
                "snapshot_key": key,
                "snapshot_type": current["snapshot_type"],
                "symbol": current["symbol"],
                "previous_at": previous["created_at"],
                "current_at": current["created_at"],
                "changes": changes,
            })
    return result
