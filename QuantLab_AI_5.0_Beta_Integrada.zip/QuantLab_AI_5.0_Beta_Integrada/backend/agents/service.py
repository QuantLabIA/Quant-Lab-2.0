from __future__ import annotations

from datetime import datetime, timezone
import json
from typing import Any

from backend.agents.memory import preview_changes, store_snapshots
from backend.agents.history import (
    add_message,
    add_tool_runs,
    create_session,
    get_session_context,
    session_exists,
    update_session_context,
)
from backend.agents.planner import plan_query
from backend.agents.settings import get_agent_settings
from backend.agents.tools import execute_tool, tool_catalog
from backend.llm.base import LanguageModelError
from backend.llm.registry import get_language_model_provider, language_model_status
from backend.models import AIAgentQuery


def _number(value: Any, digits: int = 2) -> str:
    try:
        return f"{float(value):,.{digits}f}".replace(",", "X").replace(".", ",").replace("X", ".")
    except (TypeError, ValueError):
        return "sin dato"


def _source_from_run(run: dict[str, Any], source_id: str) -> dict[str, Any]:
    result = run.get("result") or {}
    data = result.get("data") or {}
    errors = result.get("errors") or []
    return {
        "id": source_id,
        "tool": run.get("name"),
        "source": result.get("source") or data.get("source") or "Cálculo interno de QuantLab AI",
        "observed_at": result.get("last_updated") or data.get("last_updated") or datetime.now(timezone.utc).isoformat(),
        "status": run.get("status"),
        "is_delayed": bool(result.get("is_delayed") or data.get("is_delayed")),
        "is_partial": bool(result.get("is_partial") or errors),
        "errors": errors or ([run.get("error")] if run.get("error") else []),
    }


def _asset_sections(run_map: dict[str, dict[str, Any]], source_ids: dict[str, str]) -> list[dict[str, Any]]:
    quote = (run_map.get("market_quote") or {}).get("result") or {}
    analysis = (run_map.get("technical_analysis") or {}).get("result") or {}
    indicators = analysis.get("indicators") or {}
    symbol = analysis.get("symbol") or quote.get("symbol") or "Activo"
    facts: list[dict] = []
    calculations: list[dict] = []
    interpretation: list[dict] = []
    risks: list[dict] = []
    if quote:
        facts.append({
            "text": f"{symbol} cotiza en {_number(quote.get('price'), 4)} {quote.get('currency') or ''} y la última variación disponible es {_number(quote.get('change_percent'))}%.",
            "source_ids": [source_ids.get("market_quote")],
        })
    if indicators:
        calculations.extend([
            {"text": f"SMA 20: {_number(indicators.get('sma20'), 4)}; SMA 50: {_number(indicators.get('sma50'), 4)}.", "source_ids": [source_ids.get("technical_analysis")]},
            {"text": f"RSI 14: {_number(indicators.get('rsi14'))}; volatilidad anualizada: {_number(indicators.get('annualized_volatility_percent'))}%.", "source_ids": [source_ids.get("technical_analysis")]},
        ])
        interpretation.append({
            "text": analysis.get("summary") or f"La tendencia calculada es {indicators.get('trend') or 'indeterminada'}.",
            "source_ids": [source_ids.get("technical_analysis")],
        })
        risks.append({
            "text": analysis.get("risk_note") or f"Nivel de riesgo cuantitativo: {indicators.get('risk_level') or 'sin clasificar'}.",
            "source_ids": [source_ids.get("technical_analysis")],
        })
    return [
        {"key": "facts", "title": "Hechos observados", "items": facts},
        {"key": "calculations", "title": "Cálculos técnicos", "items": calculations},
        {"key": "interpretation", "title": "Interpretación educativa", "items": interpretation},
        {"key": "risks", "title": "Riesgos y cautelas", "items": risks},
    ]


def _fundamental_sections(run_map: dict[str, dict[str, Any]], source_ids: dict[str, str]) -> list[dict[str, Any]]:
    quote = (run_map.get("market_quote") or {}).get("result") or {}
    fundamental = (run_map.get("fundamental_analysis") or {}).get("result") or {}
    metrics = fundamental.get("metrics") or {}
    scores = fundamental.get("scores") or {}
    assessment = fundamental.get("assessment") or {}
    coverage = fundamental.get("coverage") or {}
    symbol = fundamental.get("symbol") or quote.get("symbol") or "Activo"
    currency = fundamental.get("currency") or quote.get("currency") or ""
    facts: list[dict] = []
    calculations: list[dict] = []
    thesis: list[dict] = []
    risks: list[dict] = []
    missing: list[dict] = []

    if quote:
        facts.append({
            "text": f"{symbol} tiene una última referencia de {_number(quote.get('price'), 4)} {quote.get('currency') or ''}.",
            "source_ids": [source_ids.get("market_quote")],
        })
    if fundamental:
        facts.append({
            "text": f"Empresa/activo: {fundamental.get('name') or symbol}; sector: {fundamental.get('sector') or 'sin dato'}; industria: {fundamental.get('industry') or 'sin dato'}; moneda financiera: {currency or 'sin dato'}.",
            "source_ids": [source_ids.get("fundamental_analysis")],
        })
        calculations.extend([
            {"text": f"Ingresos: {_number(metrics.get('revenue'))} {currency}; crecimiento: {_number(metrics.get('revenue_growth_percent'))}%.", "source_ids": [source_ids.get("fundamental_analysis")]},
            {"text": f"Beneficio neto: {_number(metrics.get('net_income'))} {currency}; margen neto: {_number(metrics.get('profit_margin_percent'))}%.", "source_ids": [source_ids.get("fundamental_analysis")]},
            {"text": f"Flujo de caja libre: {_number(metrics.get('free_cash_flow'))} {currency}; deuda/patrimonio: {_number(metrics.get('debt_to_equity'))}.", "source_ids": [source_ids.get("fundamental_analysis")]},
            {"text": f"P/E histórico: {_number(metrics.get('trailing_pe'))}; P/E futuro: {_number(metrics.get('forward_pe'))}; precio/valor libro: {_number(metrics.get('price_to_book'))}.", "source_ids": [source_ids.get("fundamental_analysis")]},
            {"text": f"Puntaje educativo general: {_number(scores.get('overall'), 1)}/100; calidad {_number(scores.get('quality'), 1)}, crecimiento {_number(scores.get('growth'), 1)}, fortaleza {_number(scores.get('financial_strength'), 1)} y valuación {_number(scores.get('valuation'), 1)}.", "source_ids": [source_ids.get("fundamental_analysis")]},
        ])
        thesis.extend({"text": text, "source_ids": [source_ids.get("fundamental_analysis")]} for text in assessment.get("favorable") or [])
        risks.extend({"text": text, "source_ids": [source_ids.get("fundamental_analysis")]} for text in assessment.get("risks") or [])
        missing.extend({"text": f"No se recibió {text}.", "source_ids": [source_ids.get("fundamental_analysis")]} for text in assessment.get("missing") or [])
        if coverage.get("status") != "complete":
            missing.append({
                "text": f"Cobertura fundamental parcial: {_number(coverage.get('coverage_percent'), 1)}% de los campos previstos.",
                "source_ids": [source_ids.get("fundamental_analysis")],
            })
    return [
        {"key": "facts", "title": "Hechos fundamentales", "items": facts},
        {"key": "calculations", "title": "Métricas y cálculos", "items": calculations},
        {"key": "thesis", "title": "Factores favorables", "items": thesis},
        {"key": "risks", "title": "Riesgos fundamentales", "items": risks},
        {"key": "missing", "title": "Datos faltantes", "items": missing},
    ]


def _portfolio_sections(run_map: dict[str, dict[str, Any]], source_ids: dict[str, str]) -> list[dict[str, Any]]:
    portfolio = (run_map.get("portfolio_snapshot") or {}).get("result") or {}
    analytics = (run_map.get("portfolio_analytics") or {}).get("result") or {}
    activity = (run_map.get("portfolio_activity") or {}).get("result") or {}
    summary = portfolio.get("summary") or {}
    performance = analytics.get("performance") or {}
    advanced = analytics.get("advanced_risk") or {}
    risk_summary = analytics.get("risk_summary") or {}
    benchmark = analytics.get("benchmark_relationship") or {}
    currency = summary.get("currency") or analytics.get("currency") or ""

    facts: list[dict] = []
    calculations: list[dict] = []
    interpretation: list[dict] = []
    risks: list[dict] = []
    if summary:
        facts.extend([
            {"text": f"Patrimonio total: {_number(summary.get('total_equity'))} {currency}; efectivo: {_number(summary.get('cash_balance'))} {currency}.", "source_ids": [source_ids.get("portfolio_snapshot")]},
            {"text": f"Posiciones abiertas: {summary.get('holdings_count', 0)}; monedas: {summary.get('currencies_count', 0)}; valuación: {summary.get('valuation_status', 'sin dato')}.", "source_ids": [source_ids.get("portfolio_snapshot")]},
        ])
        calculations.append({
            "text": f"Resultado de inversión ajustado por aportes: {_number(summary.get('investment_profit'))} {currency}, equivalente a {_number(summary.get('total_return_percent'))}%.",
            "source_ids": [source_ids.get("portfolio_snapshot")],
        })
    if performance:
        periods = performance.get("period_returns") or {}
        calculations.extend([
            {"text": f"Rendimiento del período: {_number(periods.get('selected_period_percent'))}%; volatilidad anualizada: {_number(performance.get('annualized_volatility_percent'))}%.", "source_ids": [source_ids.get("portfolio_analytics")]},
            {"text": f"Drawdown máximo: {_number(performance.get('max_drawdown_percent'))}%; Sharpe: {_number(performance.get('sharpe_ratio'))}; Sortino: {_number(advanced.get('sortino_ratio'))}.", "source_ids": [source_ids.get("portfolio_analytics")]},
        ])
    if risk_summary:
        interpretation.append({
            "text": f"Lectura general: {risk_summary.get('headline', 'sin clasificación')} (puntaje {risk_summary.get('score', '—')}/100).",
            "source_ids": [source_ids.get("portfolio_analytics")],
        })
        for flag in (risk_summary.get("flags") or [])[:6]:
            risks.append({"text": f"{flag.get('title')}: {flag.get('detail')}", "source_ids": [source_ids.get("portfolio_analytics")]})
    if benchmark.get("beta") is not None:
        interpretation.append({
            "text": f"Relación con benchmark: beta {_number(benchmark.get('beta'))}, correlación {_number(benchmark.get('correlation'))} y tracking error {_number(benchmark.get('tracking_error_percent'))}%.",
            "source_ids": [source_ids.get("portfolio_analytics")],
        })
    if activity:
        counts = activity.get("counts") or {}
        facts.append({
            "text": f"Historial activo: {counts.get('transactions', 0)} operaciones, {counts.get('cash_movements', 0)} movimientos, {counts.get('fx_conversions', 0)} conversiones y {counts.get('corporate_actions', 0)} eventos corporativos.",
            "source_ids": [source_ids.get("portfolio_activity")],
        })
    return [
        {"key": "facts", "title": "Hechos del portafolio", "items": facts},
        {"key": "calculations", "title": "Cálculos y rendimiento", "items": calculations},
        {"key": "interpretation", "title": "Interpretación educativa", "items": interpretation},
        {"key": "risks", "title": "Riesgos detectados", "items": risks},
    ]


def _comparison_sections(run_map: dict[str, dict[str, Any]], source_ids: dict[str, str]) -> list[dict[str, Any]]:
    result = (run_map.get("asset_comparison") or {}).get("result") or {}
    fundamental = (run_map.get("fundamental_comparison") or {}).get("result") or {}
    assets = result.get("assets") or []
    fundamental_assets = fundamental.get("assets") or []
    facts: list[dict] = []
    calculations: list[dict] = []
    interpretation: list[dict] = []
    risks: list[dict] = []
    if assets:
        for asset in assets:
            calculations.append({
                "text": f"{asset.get('symbol')}: retorno {_number(asset.get('return_percent'))}%, volatilidad {_number(asset.get('annualized_volatility_percent'))}% y drawdown {_number(asset.get('max_drawdown_percent'))}%.",
                "source_ids": [source_ids.get("asset_comparison")],
            })
        best_return = max(assets, key=lambda item: float(item.get("return_percent") or -10**9))
        lowest_vol = min(assets, key=lambda item: float(item.get("annualized_volatility_percent") or 10**9))
        interpretation.extend([
            {"text": f"En el período seleccionado, {best_return.get('symbol')} tuvo el mayor rendimiento histórico del grupo.", "source_ids": [source_ids.get("asset_comparison")]},
            {"text": f"{lowest_vol.get('symbol')} presentó la menor volatilidad anualizada del grupo.", "source_ids": [source_ids.get("asset_comparison")]},
        ])
        facts.append({"text": f"Se compararon {len(assets)} activos convertidos a {result.get('base_currency') or 'la moneda base'}.", "source_ids": [source_ids.get("asset_comparison")]})
    if fundamental_assets:
        for asset in fundamental_assets:
            metrics = asset.get("metrics") or {}
            scores = asset.get("scores") or {}
            calculations.append({
                "text": f"{asset.get('symbol')}: puntaje fundamental {_number(scores.get('overall'), 1)}/100, crecimiento de ingresos {_number(metrics.get('revenue_growth_percent'))}%, margen neto {_number(metrics.get('profit_margin_percent'))}% y P/E {_number(metrics.get('trailing_pe'))}.",
                "source_ids": [source_ids.get("fundamental_comparison")],
            })
        leaders = fundamental.get("leaders") or {}
        if leaders.get("overall_score"):
            interpretation.append({
                "text": f"{leaders['overall_score'].get('symbol')} obtuvo el mayor puntaje fundamental educativo del grupo ({_number(leaders['overall_score'].get('value'), 1)}/100).",
                "source_ids": [source_ids.get("fundamental_comparison")],
            })
        for error in fundamental.get("errors") or []:
            risks.append({"text": f"{error.get('symbol')}: {error.get('error')}", "source_ids": [source_ids.get("fundamental_comparison")]})
    risks.append({"text": "Un mejor resultado histórico o puntaje fundamental no implica superioridad futura ni una recomendación de compra.", "source_ids": []})
    return [
        {"key": "facts", "title": "Alcance de la comparación", "items": facts},
        {"key": "calculations", "title": "Resultados comparables", "items": calculations},
        {"key": "interpretation", "title": "Lectura educativa", "items": interpretation},
        {"key": "risks", "title": "Riesgos y límites", "items": risks},
    ]


def _answer_text(sections: list[dict[str, Any]]) -> str:
    paragraphs: list[str] = []
    for section in sections:
        items = section.get("items") or []
        if items:
            paragraphs.append(f"{section['title']}: " + " ".join(str(item.get("text") or "") for item in items))
    return "\n\n".join(paragraphs)


def _contextual_payload(payload: AIAgentQuery) -> AIAgentQuery:
    if payload.session_id is None or payload.symbols:
        return payload
    context = get_session_context(payload.session_id, payload.portfolio_id)
    if not context or not context.get("symbols"):
        return payload
    text = payload.message.lower()
    explicit_portfolio = any(term in text for term in ("portafolio", "cartera", "mis inversiones"))
    if explicit_portfolio:
        return payload
    updates: dict[str, Any] = {"symbols": context["symbols"]}
    if payload.scope == "auto":
        previous_intent = context.get("last_intent")
        if previous_intent in {"fundamental", "fundamental_compare"}:
            updates["scope"] = "fundamental" if len(context["symbols"]) == 1 else "compare"
        elif previous_intent == "compare":
            updates["scope"] = "compare"
        elif previous_intent == "asset":
            updates["scope"] = "asset"
    return payload.model_copy(update=updates)


def _maybe_rewrite(payload: AIAgentQuery, deterministic_answer: str, sections: list[dict], sources: list[dict]) -> tuple[str, dict[str, Any]]:
    saved_settings = get_agent_settings(payload.portfolio_id)
    enabled = saved_settings["use_language_model"] if payload.use_language_model is None else payload.use_language_model
    provider = get_language_model_provider()
    status = language_model_status()
    status.update({"requested": bool(enabled), "used": False, "fallback": False, "error": None})
    if not enabled or provider is None or not provider.is_available():
        return deterministic_answer, status
    evidence = json.dumps({"sections": sections, "sources": sources}, ensure_ascii=False, separators=(",", ":"))
    try:
        answer = provider.rewrite(question=payload.message, deterministic_answer=deterministic_answer, evidence_json=evidence, response_style=saved_settings.get("response_style") or "claro")
        status["used"] = True
        return answer, status
    except LanguageModelError as exc:
        status["fallback"] = True
        status["error"] = str(exc)
        return deterministic_answer, status


def run_agent_query(payload: AIAgentQuery) -> dict[str, Any]:
    payload = _contextual_payload(payload)
    plan = plan_query(payload)
    title = payload.message.strip().replace("\n", " ")[:80]
    session_id = payload.session_id
    if session_id is None or not session_exists(session_id, payload.portfolio_id):
        session_id = create_session(payload.portfolio_id, title, payload.risk_profile)
    add_message(session_id, "user", payload.message, {"symbols": plan.get("symbols"), "intent": plan.get("intent")})

    tool_runs = [execute_tool(item["name"], item["arguments"]) for item in plan.get("tools") or []]
    run_map = {run["name"]: run for run in tool_runs}
    source_ids: dict[str, str] = {}
    sources: list[dict[str, Any]] = []
    for index, run in enumerate(tool_runs, start=1):
        source_id = f"S{index}"
        source_ids[run["name"]] = source_id
        sources.append(_source_from_run(run, source_id))

    memory_changes, pending_snapshots = preview_changes(payload.portfolio_id, tool_runs)

    intent = plan.get("intent")
    if plan.get("missing"):
        sections = [{"key": "limitations", "title": "Información necesaria", "items": [{"text": item, "source_ids": []} for item in plan["missing"]]}]
    elif intent == "asset":
        sections = _asset_sections(run_map, source_ids)
    elif intent == "fundamental":
        sections = _fundamental_sections(run_map, source_ids)
    elif intent in {"compare", "fundamental_compare"}:
        sections = _comparison_sections(run_map, source_ids)
    else:
        sections = _portfolio_sections(run_map, source_ids)

    if memory_changes:
        sections.append({
            "key": "changes",
            "title": "Qué cambió desde el análisis anterior",
            "items": [{"text": item["text"], "source_ids": []} for item in memory_changes],
        })

    failed = [run for run in tool_runs if run["status"] != "success"]
    partial_sources = [source for source in sources if source["is_partial"] or source["status"] != "success"]
    limitations: list[str] = []
    if failed:
        limitations.extend(f"{run['name']}: {run.get('error') or 'no disponible'}" for run in failed)
    if partial_sources:
        limitations.append("Algunas fuentes o cálculos fueron parciales; revisá la trazabilidad antes de tomar decisiones.")
    limitations.append("La respuesta es educativa y no constituye una orden ni recomendación personalizada de compra o venta.")
    sections.append({"key": "limitations", "title": "Límites y seguridad", "items": [{"text": item, "source_ids": []} for item in limitations]})

    successful = sum(run["status"] == "success" for run in tool_runs)
    quality = "unavailable" if tool_runs and successful == 0 else "partial" if failed or partial_sources else "complete"
    deterministic_answer = _answer_text(sections)
    answer, llm = _maybe_rewrite(payload, deterministic_answer, sections, sources)
    update_session_context(session_id, str(intent or ""), plan.get("symbols") or [])
    response = {
        "session_id": session_id,
        "agent_version": "grounded-agent-3",
        "mode": "grounded_optional_llm" if llm.get("used") else "deterministic_grounded",
        "intent": intent,
        "question": payload.message,
        "answer": answer,
        "deterministic_answer": deterministic_answer,
        "sections": sections,
        "sources": sources,
        "tools_used": [{key: run.get(key) for key in ("name", "arguments", "status", "duration_ms", "error")} for run in tool_runs],
        "data_quality": quality,
        "missing_information": plan.get("missing") or [],
        "conversation_context": {"symbols": plan.get("symbols") or [], "follow_up_resolved": payload.session_id is not None},
        "change_memory": {
            "has_previous_snapshot": bool(memory_changes),
            "changes": memory_changes,
            "snapshots_prepared": len(pending_snapshots),
        },
        "language_model": llm,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "safety": {
            "facts_calculations_interpretation_separated": True,
            "can_modify_portfolio": False,
            "direct_trade_orders": False,
            "educational_only": True,
            "llm_cannot_add_evidence": True,
        },
        "disclaimer": "QuantLab AI explica datos y cálculos disponibles. No reemplaza asesoramiento profesional ni garantiza resultados futuros.",
    }
    assistant_message_id = add_message(session_id, "assistant", response["answer"], response)
    add_tool_runs(assistant_message_id, tool_runs)
    response["change_memory"]["snapshots_stored"] = store_snapshots(
        payload.portfolio_id, session_id, assistant_message_id, pending_snapshots
    )
    return response


def capabilities() -> dict[str, Any]:
    return {
        "agent_version": "grounded-agent-3",
        "mode": "grounded_with_optional_language_model",
        "tools": tool_catalog(),
        "supported_scopes": ["auto", "asset", "fundamental", "portfolio", "risk", "performance", "compare"],
        "periods": ["1mo", "3mo", "6mo", "1y", "2y", "5y", "max"],
        "language_model": language_model_status(),
        "guardrails": [
            "No inventa precios, estados financieros ni indicadores.",
            "No modifica portafolios ni envía órdenes.",
            "Separa hechos, cálculos, interpretación, tesis, riesgos y datos faltantes.",
            "El proveedor de lenguaje permanece opcional y desactivado por defecto; nunca reemplaza evidencia.",
            "Compara análisis con snapshots anteriores y señala sólo cambios materiales.",
            "Las alertas son educativas y no ejecutan operaciones.",
            "Registra herramientas, fuentes y fecha de observación.",
        ],
    }
