from __future__ import annotations

import re
from typing import Any

from backend.models import AIAgentQuery


_SYMBOL_TOKEN = re.compile(r"(?<![A-Z0-9])([A-Z^][A-Z0-9.\-=_^]{0,14})(?![A-Z0-9])")
_STOP_TOKENS = {
    "AI", "ARS", "USD", "EUR", "CON", "DEL", "LOS", "LAS", "POR", "QUE", "PARA",
    "COMO", "RIESGO", "TWR", "XIRR", "RSI", "SMA", "VAR", "CVAR", "FX", "ETF",
}


def extract_symbols(message: str, explicit: list[str]) -> list[str]:
    symbols: list[str] = []
    for symbol in explicit:
        normalized = symbol.strip().upper()
        if normalized and normalized not in symbols:
            symbols.append(normalized)
    for raw_token in _SYMBOL_TOKEN.findall(message):
        token = raw_token.upper()
        if token in _STOP_TOKENS or len(token) < 2:
            continue
        if token not in symbols:
            symbols.append(token)
    return symbols[:6]


def plan_query(payload: AIAgentQuery) -> dict[str, Any]:
    text = payload.message.lower()
    symbols = extract_symbols(payload.message, payload.symbols)
    scope = payload.scope
    asks_compare = any(term in text for term in ("compar", " versus ", " vs ", "diferencia entre"))
    asks_portfolio = any(term in text for term in ("portafolio", "cartera", "mis inversiones", "mi inversión"))
    asks_risk = any(term in text for term in (
        "riesgo", "drawdown", "var", "cvar", "sortino", "sharpe", "correlación", "correlacion",
        "volatilidad", "concentración", "concentracion", "diversificación", "diversificacion",
    ))
    asks_performance = any(term in text for term in (
        "rendimiento", "rentabilidad", "ganancia", "pérdida", "perdida", "benchmark", "resultado",
    ))
    asks_fundamental = any(term in text for term in (
        "fundamental", "balance", "ingresos", "ventas", "beneficio", "ganancias", "margen",
        "deuda", "flujo de caja", "cash flow", "pe ", "p/e", "valuación", "valuacion",
        "empresa sólida", "empresa solida", "estado financiero", "roe", "roa", "ebitda",
    ))
    asks_activity = any(term in text for term in (
        "operaciones", "movimientos", "compras", "ventas", "depósitos", "depositos", "dividendos",
        "eventos", "conversiones", "historial",
    ))

    if scope == "compare" or asks_compare or len(symbols) >= 2:
        if len(symbols) < 2:
            return {"intent": "compare", "symbols": symbols, "tools": [], "missing": ["Indicá al menos dos símbolos para comparar."]}
        tools = [{
            "name": "asset_comparison",
            "arguments": {"symbols": symbols, "period": payload.period, "portfolio_id": payload.portfolio_id},
        }]
        if asks_fundamental or scope == "fundamental":
            tools.append({"name": "fundamental_comparison", "arguments": {"symbols": symbols}})
        return {
            "intent": "fundamental_compare" if asks_fundamental or scope == "fundamental" else "compare",
            "symbols": symbols,
            "tools": tools,
            "missing": [],
        }

    if scope in {"asset", "fundamental"} or (symbols and not asks_portfolio):
        symbol = symbols[0]
        tools = [{"name": "market_quote", "arguments": {"symbol": symbol}}]
        if scope != "fundamental" and not asks_fundamental:
            tools.append({"name": "technical_analysis", "arguments": {"symbol": symbol, "risk_profile": payload.risk_profile}})
        if asks_fundamental or scope == "fundamental":
            tools.append({"name": "fundamental_analysis", "arguments": {"symbol": symbol}})
        return {
            "intent": "fundamental" if asks_fundamental or scope == "fundamental" else "asset",
            "symbols": [symbol],
            "tools": tools,
            "missing": [],
        }

    tools = [{"name": "portfolio_snapshot", "arguments": {"portfolio_id": payload.portfolio_id}}]
    if scope in {"risk", "performance"} or asks_risk or asks_performance or not asks_activity:
        tools.append({
            "name": "portfolio_analytics",
            "arguments": {"portfolio_id": payload.portfolio_id, "period": payload.period},
        })
    if asks_activity or payload.include_activity:
        tools.append({
            "name": "portfolio_activity",
            "arguments": {"portfolio_id": payload.portfolio_id, "limit": 12},
        })
    return {
        "intent": "portfolio_risk" if asks_risk or scope == "risk" else "portfolio_performance" if asks_performance or scope == "performance" else "portfolio",
        "symbols": symbols,
        "tools": tools,
        "missing": [],
    }
