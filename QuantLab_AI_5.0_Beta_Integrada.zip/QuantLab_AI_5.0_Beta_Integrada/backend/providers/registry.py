from __future__ import annotations

from functools import lru_cache

from backend.core.config import settings
from backend.providers.base import MarketDataProvider
from backend.providers.yahoo_finance import YahooFinanceProvider


@lru_cache(maxsize=1)
def get_market_provider() -> MarketDataProvider:
    provider_name = settings.market_data_provider.strip().lower()
    if provider_name in {"yfinance", "yahoo", "yahoo_finance"}:
        return YahooFinanceProvider()
    raise RuntimeError(f"Proveedor de mercado no configurado: {settings.market_data_provider}")
