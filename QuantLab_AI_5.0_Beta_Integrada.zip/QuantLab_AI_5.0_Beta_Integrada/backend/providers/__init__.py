"""Proveedores de datos externos de QuantLab AI."""

from backend.providers.registry import get_market_provider

__all__ = ["get_market_provider"]
