from __future__ import annotations

import math
import re
import threading
import time
from dataclasses import dataclass
from datetime import date, datetime, timedelta, timezone
from typing import Any

import pandas as pd

from backend.core.config import settings
from backend.providers.base import MarketDataError


@dataclass(frozen=True)
class FeaturedAsset:
    symbol: str
    name: str
    market: str


FEATURED_ASSETS: tuple[FeaturedAsset, ...] = (
    FeaturedAsset("AAPL", "Apple Inc.", "NASDAQ"),
    FeaturedAsset("MSFT", "Microsoft Corp.", "NASDAQ"),
    FeaturedAsset("NVDA", "NVIDIA Corp.", "NASDAQ"),
    FeaturedAsset("TSLA", "Tesla Inc.", "NASDAQ"),
    FeaturedAsset("SPY", "SPDR S&P 500 ETF Trust", "NYSE Arca"),
    FeaturedAsset("QQQ", "Invesco QQQ Trust", "NASDAQ"),
    FeaturedAsset("BTC-USD", "Bitcoin USD", "Crypto"),
)

ALLOWED_PERIODS = {"1d", "5d", "1mo", "3mo", "6mo", "1y", "2y", "5y", "max"}
ALLOWED_INTERVALS = {"1m", "2m", "5m", "15m", "30m", "60m", "90m", "1h", "1d", "5d", "1wk", "1mo"}
ASSET_TYPE_MAP = {
    "EQUITY": "EQUITY",
    "ETF": "ETF",
    "MUTUALFUND": "FUND",
    "INDEX": "INDEX",
    "CRYPTOCURRENCY": "CRYPTO",
    "CURRENCY": "FOREX",
    "FUTURE": "FUTURE",
    "OPTION": "OPTION",
    "BOND": "BOND",
}
MINOR_CURRENCY_UNITS = {
    "GBP": ("GBP", 1.0),
    "GBPENCE": ("GBP", 0.01),
    "GBX": ("GBP", 0.01),
    "GBP": ("GBP", 1.0),
    "ILA": ("ILS", 0.01),
    "ZAC": ("ZAR", 0.01),
}


def _get_yfinance():
    try:
        import yfinance as yf
    except ImportError as exc:
        raise MarketDataError(
            "Falta instalar yfinance. Ejecutá: pip install -r requirements.txt"
        ) from exc
    return yf


def _retry_call(operation, label: str):
    last_error: Exception | None = None
    for attempt in range(1, settings.market_retry_attempts + 1):
        try:
            return operation()
        except Exception as exc:
            last_error = exc
            if attempt < settings.market_retry_attempts:
                time.sleep(settings.market_retry_backoff_seconds * attempt)
    raise MarketDataError(
        f"No se pudo consultar {label} después de {settings.market_retry_attempts} intento(s): {last_error}"
    ) from last_error


def _quality_metadata(quote: dict, *, price_kind: str | None = None) -> dict:
    state = str(quote.get("market_state") or "unknown").strip().lower()
    normalized_state = {
        "regular": "open",
        "open": "open",
        "pre": "pre_market",
        "premarket": "pre_market",
        "post": "after_hours",
        "postmarket": "after_hours",
        "closed": "closed",
    }.get(state, state if state in {"open", "closed", "pre_market", "after_hours", "manual"} else "unknown")
    quote["market_state"] = normalized_state

    try:
        updated = datetime.fromisoformat(str(quote.get("last_updated", "")).replace("Z", "+00:00"))
        if updated.tzinfo is None:
            updated = updated.replace(tzinfo=timezone.utc)
        age_seconds = max(0, int((datetime.now(timezone.utc) - updated.astimezone(timezone.utc)).total_seconds()))
    except Exception:
        age_seconds = None

    if quote.get("pricing_mode") == "MANUAL":
        data_status = "manual"
        label = "Precio manual"
    elif age_seconds is not None and age_seconds > 72 * 3600:
        data_status = "stale"
        label = "Último cierre disponible"
    elif quote.get("is_delayed", True):
        data_status = "delayed"
        label = "Dato demorado"
    else:
        data_status = "updated"
        label = "Dato actualizado"

    if price_kind is None:
        if normalized_state in {"open", "pre_market", "after_hours"}:
            price_kind = "intraday"
        else:
            price_kind = "last_close"

    quote["price_kind"] = price_kind
    quote["data_status"] = data_status
    quote["status_label"] = label
    quote["data_age_seconds"] = age_seconds
    quote["warnings"] = []
    if normalized_state == "closed":
        quote["warnings"].append("El mercado figura cerrado; se muestra la última referencia disponible.")
    if data_status == "stale":
        quote["warnings"].append("La cotización tiene más de 72 horas; verificá el símbolo o el estado del mercado.")
    return quote


class TTLCache:
    def __init__(self) -> None:
        self._values: dict[str, tuple[float, Any]] = {}
        self._lock = threading.Lock()

    def get(self, key: str) -> Any | None:
        now = time.monotonic()
        with self._lock:
            item = self._values.get(key)
            if item is None:
                return None
            expires_at, value = item
            if expires_at <= now:
                self._values.pop(key, None)
                return None
            return value

    def set(self, key: str, value: Any, ttl_seconds: int) -> None:
        with self._lock:
            self._values[key] = (time.monotonic() + ttl_seconds, value)


_CACHE = TTLCache()
_SYMBOL_PATTERN = re.compile(r"^[A-Z0-9.\-=_^/:]+$")


def _normalize_symbol(symbol: str) -> str:
    normalized = symbol.strip().upper()
    if not normalized or len(normalized) > 40:
        raise MarketDataError("El símbolo está vacío o es demasiado largo")
    if not _SYMBOL_PATTERN.fullmatch(normalized):
        raise MarketDataError("El símbolo contiene caracteres no permitidos")
    return normalized


def _normalize_currency(raw: Any) -> tuple[str, float]:
    if raw is None:
        return "USD", 1.0
    text = str(raw).strip()
    compact = text.upper().replace(" ", "")
    if text == "GBp" or compact in {"GBPENCE", "GBX"}:
        return "GBP", 0.01
    if text == "ILA" or compact == "ILA":
        return "ILS", 0.01
    if text == "ZAc" or compact == "ZAC":
        return "ZAR", 0.01
    if len(compact) == 3 and compact.isalpha():
        return compact, 1.0
    return compact[:3] if len(compact) >= 3 else "USD", 1.0


def _asset_type(quote_type: Any) -> str:
    return ASSET_TYPE_MAP.get(str(quote_type or "").upper(), "OTHER")


def _safe_number(value: Any) -> float | None:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if math.isfinite(number) else None


def _iso_timestamp(value: Any | None = None) -> str:
    if value is None:
        return datetime.now(timezone.utc).isoformat()
    try:
        timestamp = pd.Timestamp(value)
        if timestamp.tzinfo is None:
            timestamp = timestamp.tz_localize("UTC")
        else:
            timestamp = timestamp.tz_convert("UTC")
        return timestamp.isoformat()
    except Exception:
        return datetime.now(timezone.utc).isoformat()


def _fast_info_value(fast_info: Any, key: str) -> Any:
    try:
        return fast_info[key]
    except Exception:
        return getattr(fast_info, key, None)


def _quote_from_history(
    symbol: str,
    history: pd.DataFrame,
    *,
    name: str | None = None,
    market: str | None = None,
    currency: str | None = None,
    quote_type: str | None = None,
    provider_timestamp: Any | None = None,
    price_scale: float = 1.0,
) -> dict:
    if history.empty or "Close" not in history.columns:
        raise MarketDataError(f"No se encontraron cotizaciones para {symbol}")

    closes = history["Close"].dropna()
    if closes.empty:
        raise MarketDataError(f"No se encontraron precios válidos para {symbol}")

    price = float(closes.iloc[-1]) * price_scale
    previous = (float(closes.iloc[-2]) if len(closes) > 1 else float(closes.iloc[-1])) * price_scale
    change = price - previous
    change_percent = (change / previous * 100) if previous else 0.0

    return _quality_metadata({
        "symbol": symbol,
        "name": name or symbol,
        "price": round(price, 8),
        "previous_close": round(previous, 8),
        "change": round(change, 8),
        "change_percent": round(change_percent, 4),
        "market": market or "Mercado",
        "exchange": market or "Mercado",
        "currency": currency or "USD",
        "quote_type": str(quote_type or "OTHER").upper(),
        "asset_type": _asset_type(quote_type),
        "sector": None,
        "industry": None,
        "market_state": "unknown",
        "last_updated": _iso_timestamp(provider_timestamp or closes.index[-1]),
        "source": "Yahoo Finance vía yfinance",
        "is_delayed": True,
        "pricing_mode": "AUTO",
    }, price_kind="last_close")


def _download_featured() -> list[dict]:
    symbols = [asset.symbol for asset in FEATURED_ASSETS]
    yf = _get_yfinance()
    try:
        frame = _retry_call(lambda: yf.download(
            tickers=symbols,
            period="5d",
            interval="1d",
            group_by="ticker",
            auto_adjust=False,
            progress=False,
            threads=True,
            timeout=15,
        ), "activos destacados")
    except Exception as exc:
        raise MarketDataError(f"No se pudo consultar el proveedor de mercado: {exc}") from exc

    if frame.empty:
        raise MarketDataError("El proveedor no devolvió datos de mercado")

    results: list[dict] = []
    for asset in FEATURED_ASSETS:
        try:
            history = frame[asset.symbol].dropna(how="all") if isinstance(frame.columns, pd.MultiIndex) else frame.dropna(how="all")
            results.append(
                _quote_from_history(asset.symbol, history, name=asset.name, market=asset.market)
            )
        except (KeyError, MarketDataError):
            continue

    if not results:
        raise MarketDataError("No se pudieron procesar los activos destacados")
    return results


def list_market_assets() -> list[dict]:
    cache_key = "market:featured"
    cached = _CACHE.get(cache_key)
    if cached is not None:
        return cached
    results = _download_featured()
    _CACHE.set(cache_key, results, ttl_seconds=60)
    return results


def search_market_assets(query: str, limit: int = 12) -> list[dict]:
    text = query.strip()
    if len(text) < 1:
        return []
    limit = max(1, min(int(limit), 25))
    cache_key = f"market:search:{text.lower()}:{limit}"
    cached = _CACHE.get(cache_key)
    if cached is not None:
        return cached

    yf = _get_yfinance()
    try:
        search = _retry_call(lambda: yf.Search(
            text,
            max_results=limit,
            news_count=0,
            lists_count=0,
            include_cb=False,
            include_nav_links=False,
            include_research=False,
            enable_fuzzy_query=True,
            recommended=0,
            timeout=15,
            raise_errors=True,
        ), f"búsqueda de {text}")
        raw_quotes = list(search.quotes or [])
    except Exception as exc:
        raise MarketDataError(f"No se pudo buscar activos: {exc}") from exc

    results: list[dict] = []
    seen: set[str] = set()
    for item in raw_quotes:
        symbol = str(item.get("symbol") or "").upper().strip()
        if not symbol or symbol in seen:
            continue
        try:
            _normalize_symbol(symbol)
        except MarketDataError:
            continue
        seen.add(symbol)
        quote_type = str(item.get("quoteType") or item.get("typeDisp") or "OTHER").upper()
        currency, _ = _normalize_currency(item.get("currency"))
        results.append(
            {
                "symbol": symbol,
                "name": item.get("shortname") or item.get("longname") or item.get("name") or symbol,
                "asset_type": _asset_type(quote_type),
                "quote_type": quote_type,
                "exchange": item.get("exchDisp") or item.get("exchange") or "Mercado",
                "currency": currency,
                "pricing_mode": "AUTO",
            }
        )
        if len(results) >= limit:
            break

    _CACHE.set(cache_key, results, ttl_seconds=300)
    return results


def find_market_asset(symbol: str) -> dict | None:
    normalized = _normalize_symbol(symbol)
    cache_key = f"market:quote:{normalized}"
    cached = _CACHE.get(cache_key)
    if cached is not None:
        return cached

    yf = _get_yfinance()
    try:
        ticker = yf.Ticker(normalized)
        history = _retry_call(lambda: ticker.history(period="5d", interval="1d", auto_adjust=False, repair=True), normalized)
        if history.empty:
            return None

        featured = next((item for item in FEATURED_ASSETS if item.symbol == normalized), None)
        name = featured.name if featured else normalized
        market = featured.market if featured else "Mercado"
        currency = "USD"
        price_scale = 1.0
        market_state = "unknown"
        quote_type = "OTHER"
        sector: str | None = None
        industry: str | None = None
        current_price: float | None = None
        previous_close: float | None = None

        try:
            fast_info = ticker.fast_info
            current_price = _safe_number(_fast_info_value(fast_info, "last_price"))
            previous_close = _safe_number(_fast_info_value(fast_info, "previous_close"))
            currency, price_scale = _normalize_currency(_fast_info_value(fast_info, "currency"))
            market = _fast_info_value(fast_info, "exchange") or market
        except Exception:
            pass

        try:
            info = ticker.get_info()
            name = info.get("shortName") or info.get("longName") or name
            market = info.get("fullExchangeName") or info.get("exchange") or market
            raw_currency = info.get("currency")
            if raw_currency:
                currency, price_scale = _normalize_currency(raw_currency)
            market_state = info.get("marketState") or market_state
            quote_type = info.get("quoteType") or quote_type
            sector = info.get("sector") or info.get("category") or sector
            industry = info.get("industry") or info.get("industryDisp") or industry
        except Exception:
            pass

        quote = _quote_from_history(
            normalized,
            history,
            name=name,
            market=market,
            currency=currency,
            quote_type=quote_type,
            price_scale=price_scale,
        )

        if current_price is not None and current_price > 0:
            current_price *= price_scale
            previous = (previous_close * price_scale if previous_close else quote["previous_close"])
            change = current_price - previous
            quote.update(
                price=round(current_price, 8),
                previous_close=round(previous, 8),
                change=round(change, 8),
                change_percent=round((change / previous * 100) if previous else 0.0, 4),
                last_updated=datetime.now(timezone.utc).isoformat(),
            )
        quote["market_state"] = market_state
        quote["exchange"] = market
        quote["quote_type"] = str(quote_type).upper()
        quote["asset_type"] = _asset_type(quote_type)
        quote["sector"] = str(sector).strip() if sector else None
        quote["industry"] = str(industry).strip() if industry else None
        _quality_metadata(quote, price_kind="intraday" if current_price is not None else "last_close")

        _CACHE.set(cache_key, quote, ttl_seconds=45)
        return quote
    except MarketDataError:
        raise
    except Exception as exc:
        raise MarketDataError(f"No se pudo consultar {normalized}: {exc}") from exc


def get_market_history(symbol: str, period: str = "1mo", interval: str = "1d") -> dict:
    normalized = _normalize_symbol(symbol)
    if period not in ALLOWED_PERIODS:
        raise MarketDataError(f"Período no permitido. Usá: {', '.join(sorted(ALLOWED_PERIODS))}")
    if interval not in ALLOWED_INTERVALS:
        raise MarketDataError(f"Intervalo no permitido. Usá: {', '.join(sorted(ALLOWED_INTERVALS))}")

    cache_key = f"market:history:{normalized}:{period}:{interval}"
    cached = _CACHE.get(cache_key)
    if cached is not None:
        return cached

    yf = _get_yfinance()
    try:
        ticker = yf.Ticker(normalized)
        history = _retry_call(lambda: ticker.history(period=period, interval=interval, auto_adjust=False, repair=True), f"histórico de {normalized}")
        price_scale = 1.0
        currency = "USD"
        try:
            currency, price_scale = _normalize_currency(_fast_info_value(ticker.fast_info, "currency"))
        except Exception:
            pass
    except Exception as exc:
        raise MarketDataError(f"No se pudo descargar el histórico de {normalized}: {exc}") from exc

    if history.empty:
        raise MarketDataError(f"No hay histórico disponible para {normalized}")

    candles: list[dict] = []
    for index, row in history.iterrows():
        close = _safe_number(row.get("Close"))
        if close is None:
            continue
        candles.append(
            {
                "date": _iso_timestamp(index),
                "open": (_safe_number(row.get("Open")) or 0) * price_scale,
                "high": (_safe_number(row.get("High")) or 0) * price_scale,
                "low": (_safe_number(row.get("Low")) or 0) * price_scale,
                "close": close * price_scale,
                "volume": int(_safe_number(row.get("Volume")) or 0),
            }
        )

    if not candles:
        raise MarketDataError(f"El histórico de {normalized} no contiene precios válidos")

    result = {
        "symbol": normalized,
        "period": period,
        "interval": interval,
        "currency": currency,
        "candles": candles,
        "source": "Yahoo Finance vía yfinance",
        "is_delayed": True,
        "data_status": "delayed",
        "status_label": "Histórico demorado",
        "last_updated": datetime.now(timezone.utc).isoformat(),
    }
    _CACHE.set(cache_key, result, ttl_seconds=180)
    return result


def _load_fx_series(from_currency: str, to_currency: str, *, period: str | None = None, target_date: date | None = None) -> tuple[pd.Series, bool, str]:
    source = from_currency.upper()
    target = to_currency.upper()
    if source == target:
        index = pd.DatetimeIndex([pd.Timestamp.now(tz="UTC")])
        return pd.Series([1.0], index=index), False, f"{source}{target}"

    yf = _get_yfinance()
    candidates = [(f"{source}{target}=X", False), (f"{target}{source}=X", True)]
    errors: list[str] = []
    for symbol, inverse in candidates:
        try:
            ticker = yf.Ticker(symbol)
            if target_date is not None:
                start = target_date - timedelta(days=10)
                end = target_date + timedelta(days=2)
                frame = ticker.history(start=start.isoformat(), end=end.isoformat(), interval="1d", auto_adjust=False, repair=True)
            else:
                frame = ticker.history(period=period or "5d", interval="1d", auto_adjust=False, repair=True)
            closes = frame.get("Close", pd.Series(dtype=float)).dropna()
            if closes.empty:
                continue
            values = 1.0 / closes if inverse else closes
            return values.astype(float), inverse, symbol
        except Exception as exc:
            errors.append(f"{symbol}: {exc}")
    raise MarketDataError(
        f"No se encontró conversión {source}/{target}" + (f" ({'; '.join(errors)})" if errors else "")
    )


def get_fx_rate(from_currency: str, to_currency: str, occurred_at: datetime | date | None = None) -> dict:
    source = from_currency.strip().upper()
    target = to_currency.strip().upper()
    if source == target:
        return {
            "from_currency": source,
            "to_currency": target,
            "rate": 1.0,
            "symbol": f"{source}{target}",
            "last_updated": datetime.now(timezone.utc).isoformat(),
            "source": "Identidad monetaria",
        }

    target_date: date | None = None
    if isinstance(occurred_at, datetime):
        target_date = occurred_at.astimezone(timezone.utc).date() if occurred_at.tzinfo else occurred_at.date()
    elif isinstance(occurred_at, date):
        target_date = occurred_at

    cache_key = f"market:fx:{source}:{target}:{target_date or 'current'}"
    cached = _CACHE.get(cache_key)
    if cached is not None:
        return cached

    try:
        series, _, symbol = _load_fx_series(source, target, target_date=target_date)
    except MarketDataError:
        if source != "USD" and target != "USD":
            first = get_fx_rate(source, "USD", occurred_at)
            second = get_fx_rate("USD", target, occurred_at)
            result = {
                "from_currency": source,
                "to_currency": target,
                "rate": round(float(first["rate"]) * float(second["rate"]), 10),
                "symbol": f"{first['symbol']} × {second['symbol']}",
                "last_updated": max(str(first["last_updated"]), str(second["last_updated"])),
                "source": "Yahoo Finance vía yfinance (cruce USD)",
            }
            _CACHE.set(cache_key, result, ttl_seconds=3600 if target_date else 120)
            return result
        raise

    if target_date is not None:
        eligible = series[series.index.date <= target_date]
        value = float((eligible if not eligible.empty else series).iloc[-1])
        timestamp = (eligible if not eligible.empty else series).index[-1]
    else:
        value = float(series.iloc[-1])
        timestamp = series.index[-1]
    result = {
        "from_currency": source,
        "to_currency": target,
        "rate": round(value, 10),
        "symbol": symbol,
        "last_updated": _iso_timestamp(timestamp),
        "source": "Yahoo Finance vía yfinance",
    }
    _CACHE.set(cache_key, result, ttl_seconds=3600 if target_date else 120)
    return result


def get_fx_history(from_currency: str, to_currency: str, period: str = "1y") -> dict:
    source = from_currency.strip().upper()
    target = to_currency.strip().upper()
    if period not in ALLOWED_PERIODS:
        raise MarketDataError("Período FX no permitido")
    if source == target:
        now = datetime.now(timezone.utc)
        return {
            "from_currency": source,
            "to_currency": target,
            "period": period,
            "candles": [{"date": now.isoformat(), "close": 1.0}],
            "source": "Identidad monetaria",
        }
    cache_key = f"market:fx-history:{source}:{target}:{period}"
    cached = _CACHE.get(cache_key)
    if cached is not None:
        return cached

    try:
        series, _, symbol = _load_fx_series(source, target, period=period)
    except MarketDataError:
        if source != "USD" and target != "USD":
            first = get_fx_history(source, "USD", period)
            second = get_fx_history("USD", target, period)
            first_map = {str(item["date"])[:10]: float(item["close"]) for item in first["candles"]}
            second_map = {str(item["date"])[:10]: float(item["close"]) for item in second["candles"]}
            common = sorted(set(first_map) & set(second_map))
            result = {
                "from_currency": source,
                "to_currency": target,
                "period": period,
                "candles": [{"date": day, "close": first_map[day] * second_map[day]} for day in common],
                "source": "Yahoo Finance vía yfinance (cruce USD)",
            }
            _CACHE.set(cache_key, result, ttl_seconds=600)
            return result
        raise

    result = {
        "from_currency": source,
        "to_currency": target,
        "period": period,
        "symbol": symbol,
        "candles": [{"date": _iso_timestamp(index), "close": float(value)} for index, value in series.items()],
        "source": "Yahoo Finance vía yfinance",
    }
    _CACHE.set(cache_key, result, ttl_seconds=600)
    return result


def get_dividend_history(symbol: str, period: str = "5y") -> dict:
    normalized = _normalize_symbol(symbol)
    if period not in ALLOWED_PERIODS:
        raise MarketDataError("Período no permitido")
    yf = _get_yfinance()
    try:
        series = yf.Ticker(normalized).get_dividends(period=period)
    except Exception as exc:
        raise MarketDataError(f"No se pudieron consultar dividendos de {normalized}: {exc}") from exc
    events = [
        {"date": _iso_timestamp(index), "amount_per_unit": float(value)}
        for index, value in series.dropna().items()
        if float(value) > 0
    ]
    return {
        "symbol": normalized,
        "period": period,
        "events": events,
        "source": "Yahoo Finance vía yfinance",
    }



def _statement_value(frame: pd.DataFrame, labels: tuple[str, ...], column_index: int = 0) -> float | None:
    if frame is None or getattr(frame, "empty", True):
        return None
    for label in labels:
        if label not in frame.index:
            continue
        try:
            values = frame.loc[label]
            if hasattr(values, "dropna"):
                values = values.dropna()
            if len(values) <= column_index:
                continue
            return _safe_number(values.iloc[column_index])
        except Exception:
            continue
    return None


def _statement_snapshot(frame: pd.DataFrame, mapping: dict[str, tuple[str, ...]]) -> dict[str, dict[str, float | None]]:
    result: dict[str, dict[str, float | None]] = {}
    for key, labels in mapping.items():
        current = _statement_value(frame, labels, 0)
        previous = _statement_value(frame, labels, 1)
        growth = None
        if current is not None and previous not in (None, 0):
            growth = (current / previous - 1) * 100
        result[key] = {
            "current": current,
            "previous": previous,
            "growth_percent": round(growth, 4) if growth is not None else None,
        }
    return result


def get_fundamental_data(symbol: str) -> dict:
    normalized = _normalize_symbol(symbol)
    cache_key = f"market:fundamentals:{normalized}"
    cached = _CACHE.get(cache_key)
    if cached is not None:
        return cached

    yf = _get_yfinance()
    try:
        ticker = yf.Ticker(normalized)
        info = _retry_call(lambda: ticker.get_info(), f"fundamentales de {normalized}") or {}
        try:
            income = ticker.get_income_stmt(freq="yearly")
        except Exception:
            income = getattr(ticker, "income_stmt", pd.DataFrame())
        try:
            balance = ticker.get_balance_sheet(freq="yearly")
        except Exception:
            balance = getattr(ticker, "balance_sheet", pd.DataFrame())
        try:
            cashflow = ticker.get_cashflow(freq="yearly")
        except Exception:
            cashflow = getattr(ticker, "cashflow", pd.DataFrame())
    except Exception as exc:
        raise MarketDataError(f"No se pudieron consultar fundamentales de {normalized}: {exc}") from exc

    currency, scale = _normalize_currency(info.get("financialCurrency") or info.get("currency"))
    statement_mapping = {
        "revenue": ("Total Revenue", "Operating Revenue"),
        "net_income": ("Net Income", "Net Income Common Stockholders"),
        "operating_income": ("Operating Income",),
        "ebitda": ("Normalized EBITDA", "EBITDA"),
    }
    balance_mapping = {
        "total_assets": ("Total Assets",),
        "total_debt": ("Total Debt",),
        "stockholders_equity": ("Stockholders Equity", "Common Stock Equity"),
        "cash": ("Cash Cash Equivalents And Short Term Investments", "Cash And Cash Equivalents"),
    }
    cashflow_mapping = {
        "operating_cash_flow": ("Operating Cash Flow", "Total Cash From Operating Activities"),
        "free_cash_flow": ("Free Cash Flow",),
        "capital_expenditure": ("Capital Expenditure", "Capital Expenditures"),
    }
    statements = {
        "income_statement": _statement_snapshot(income, statement_mapping),
        "balance_sheet": _statement_snapshot(balance, balance_mapping),
        "cash_flow": _statement_snapshot(cashflow, cashflow_mapping),
    }

    revenue = _safe_number(info.get("totalRevenue")) or statements["income_statement"]["revenue"]["current"]
    net_income = _safe_number(info.get("netIncomeToCommon")) or statements["income_statement"]["net_income"]["current"]
    total_debt = _safe_number(info.get("totalDebt")) or statements["balance_sheet"]["total_debt"]["current"]
    equity = statements["balance_sheet"]["stockholders_equity"]["current"]
    free_cash_flow = _safe_number(info.get("freeCashflow")) or statements["cash_flow"]["free_cash_flow"]["current"]
    operating_cash_flow = _safe_number(info.get("operatingCashflow")) or statements["cash_flow"]["operating_cash_flow"]["current"]

    metrics = {
        "market_cap": _safe_number(info.get("marketCap")),
        "enterprise_value": _safe_number(info.get("enterpriseValue")),
        "trailing_pe": _safe_number(info.get("trailingPE")),
        "forward_pe": _safe_number(info.get("forwardPE")),
        "price_to_book": _safe_number(info.get("priceToBook")),
        "price_to_sales": _safe_number(info.get("priceToSalesTrailing12Months")),
        "enterprise_to_ebitda": _safe_number(info.get("enterpriseToEbitda")),
        "dividend_yield_percent": (_safe_number(info.get("dividendYield")) * 100 if _safe_number(info.get("dividendYield")) is not None else None),
        "payout_ratio_percent": (_safe_number(info.get("payoutRatio")) * 100 if _safe_number(info.get("payoutRatio")) is not None else None),
        "profit_margin_percent": (_safe_number(info.get("profitMargins")) * 100 if _safe_number(info.get("profitMargins")) is not None else ((net_income / revenue * 100) if net_income is not None and revenue else None)),
        "operating_margin_percent": (_safe_number(info.get("operatingMargins")) * 100 if _safe_number(info.get("operatingMargins")) is not None else None),
        "gross_margin_percent": (_safe_number(info.get("grossMargins")) * 100 if _safe_number(info.get("grossMargins")) is not None else None),
        "return_on_equity_percent": (_safe_number(info.get("returnOnEquity")) * 100 if _safe_number(info.get("returnOnEquity")) is not None else None),
        "return_on_assets_percent": (_safe_number(info.get("returnOnAssets")) * 100 if _safe_number(info.get("returnOnAssets")) is not None else None),
        "revenue_growth_percent": (_safe_number(info.get("revenueGrowth")) * 100 if _safe_number(info.get("revenueGrowth")) is not None else statements["income_statement"]["revenue"]["growth_percent"]),
        "earnings_growth_percent": (_safe_number(info.get("earningsGrowth")) * 100 if _safe_number(info.get("earningsGrowth")) is not None else statements["income_statement"]["net_income"]["growth_percent"]),
        "debt_to_equity": _safe_number(info.get("debtToEquity")) or ((total_debt / equity * 100) if total_debt is not None and equity else None),
        "current_ratio": _safe_number(info.get("currentRatio")),
        "quick_ratio": _safe_number(info.get("quickRatio")),
        "free_cash_flow": free_cash_flow,
        "operating_cash_flow": operating_cash_flow,
        "total_cash": _safe_number(info.get("totalCash")) or statements["balance_sheet"]["cash"]["current"],
        "total_debt": total_debt,
        "revenue": revenue,
        "net_income": net_income,
        "ebitda": _safe_number(info.get("ebitda")) or statements["income_statement"]["ebitda"]["current"],
        "trailing_eps": _safe_number(info.get("trailingEps")),
        "forward_eps": _safe_number(info.get("forwardEps")),
        "book_value_per_share": _safe_number(info.get("bookValue")),
        "target_mean_price": _safe_number(info.get("targetMeanPrice")),
        "number_of_analyst_opinions": _safe_number(info.get("numberOfAnalystOpinions")),
    }
    total_fields = len(metrics)
    available_fields = sum(value is not None for value in metrics.values())
    result = {
        "symbol": normalized,
        "name": info.get("longName") or info.get("shortName") or normalized,
        "quote_type": str(info.get("quoteType") or "OTHER").upper(),
        "asset_type": _asset_type(info.get("quoteType")),
        "currency": currency,
        "currency_scale": scale,
        "exchange": info.get("fullExchangeName") or info.get("exchange") or "",
        "sector": info.get("sector") or info.get("category"),
        "industry": info.get("industry") or info.get("industryDisp"),
        "country": info.get("country"),
        "website": info.get("website"),
        "business_summary": str(info.get("longBusinessSummary") or "")[:1600],
        "recommendation_key": info.get("recommendationKey"),
        "metrics": metrics,
        "statements": statements,
        "coverage": {"available_fields": available_fields, "total_fields": total_fields},
        "source": "Yahoo Finance vía yfinance",
        "last_updated": datetime.now(timezone.utc).isoformat(),
        "is_delayed": True,
        "is_partial": available_fields < total_fields,
        "errors": [],
    }
    _CACHE.set(cache_key, result, ttl_seconds=900)
    return result

def market_provider_status() -> dict:
    return {
        "provider": "yfinance",
        "source": "Yahoo Finance vía yfinance",
        "mode": "real_delayed",
        "cache_seconds": 60,
        "retry_attempts": settings.market_retry_attempts,
        "supports_manual_fallback": True,
        "quality_states": ["updated", "delayed", "stale", "manual", "unavailable"],
        "asset_universe": ["EQUITY", "ETF", "FUND", "CRYPTO", "FOREX", "INDEX", "FUTURE", "OPTION", "BOND", "OTHER"],
        "notice": "Datos reales para uso educativo; pueden tener demora y no equivalen a una cotización bursátil licenciada en tiempo real.",
    }


class YahooFinanceProvider:
    """Adaptador del proveedor actual al contrato común de mercado."""

    name = "yfinance"

    def list_assets(self) -> list[dict]:
        return list_market_assets()

    def search_assets(self, query: str, limit: int = 12) -> list[dict]:
        return search_market_assets(query, limit)

    def get_quote(self, symbol: str) -> dict | None:
        return find_market_asset(symbol)

    def get_history(self, symbol: str, period: str = "1mo", interval: str = "1d") -> dict:
        return get_market_history(symbol, period, interval)

    def get_fx_rate(self, from_currency: str, to_currency: str, occurred_at=None) -> dict:
        return get_fx_rate(from_currency, to_currency, occurred_at)

    def get_fx_history(self, from_currency: str, to_currency: str, period: str = "1y") -> dict:
        return get_fx_history(from_currency, to_currency, period)

    def get_dividends(self, symbol: str, period: str = "5y") -> dict:
        return get_dividend_history(symbol, period)

    def get_fundamentals(self, symbol: str) -> dict:
        return get_fundamental_data(symbol)

    def status(self) -> dict:
        return market_provider_status()
