from contextlib import asynccontextmanager

from fastapi import APIRouter, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from backend.api import ai, analytics, dashboard, data_management, market, portfolio, system, watchlist
from backend.core.config import FRONTEND_DIR, settings
from backend.core.database import initialize_database
from backend.core.errors import RequestContextMiddleware, install_exception_handlers
from backend.core.logging import configure_logging

configure_logging()


@asynccontextmanager
async def lifespan(_: FastAPI):
    initialize_database()
    yield


app = FastAPI(
    title=settings.app_name,
    version=settings.version,
    description="API educativa, financiera y modular para QuantLab AI.",
    lifespan=lifespan,
)

app.add_middleware(RequestContextMiddleware)
app.add_middleware(
    CORSMiddleware,
    allow_origins=list(settings.cors_origins),
    allow_credentials=settings.cors_allow_credentials,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["Content-Type", "X-Request-ID"],
    expose_headers=["X-Request-ID"],
)
install_exception_handlers(app)

api_router = APIRouter()
for module_router in (
    system.router,
    dashboard.router,
    analytics.router,
    market.router,
    watchlist.router,
    portfolio.router,
    data_management.router,
    ai.router,
):
    api_router.include_router(module_router)

# API estable y documentada.
app.include_router(api_router, prefix="/api/v1")
# Alias temporal para el frontend y enlaces de versiones anteriores.
if settings.legacy_api_enabled:
    app.include_router(api_router, prefix="/api", include_in_schema=False)

app.mount(
    "/assets",
    StaticFiles(directory=FRONTEND_DIR / "assets"),
    name="assets",
)


@app.get("/", include_in_schema=False)
def frontend() -> FileResponse:
    return FileResponse(FRONTEND_DIR / "index.html")


@app.get("/{path:path}", include_in_schema=False)
def frontend_fallback(path: str) -> FileResponse:
    if path.startswith("api/"):
        raise HTTPException(status_code=404, detail="Endpoint no encontrado")
    return FileResponse(FRONTEND_DIR / "index.html")
