"""Backend package for QuantLab AI."""
