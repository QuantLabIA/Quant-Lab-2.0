import shutil
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterator

from backend.core.config import DATABASE_PATH, DATA_DIR
from backend.core.migrations import run_migrations


SCHEMA_VERSION = 15


def _table_exists(connection: sqlite3.Connection, table: str) -> bool:
    row = connection.execute(
        "SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = ?",
        (table,),
    ).fetchone()
    return row is not None


def _columns(connection: sqlite3.Connection, table: str) -> set[str]:
    if not _table_exists(connection, table):
        return set()
    return {str(row[1]) for row in connection.execute(f"PRAGMA table_info({table})").fetchall()}


def _ensure_column(connection: sqlite3.Connection, table: str, definition: str) -> None:
    name = definition.split()[0]
    if name not in _columns(connection, table):
        connection.execute(f"ALTER TABLE {table} ADD COLUMN {definition}")


def _create_portfolio_assets_table(connection: sqlite3.Connection) -> None:
    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS portfolio_assets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            portfolio_id INTEGER NOT NULL,
            symbol TEXT NOT NULL,
            name TEXT NOT NULL,
            asset_type TEXT NOT NULL DEFAULT 'OTHER',
            currency TEXT NOT NULL,
            exchange TEXT NOT NULL DEFAULT '',
            pricing_mode TEXT NOT NULL DEFAULT 'AUTO' CHECK (pricing_mode IN ('AUTO', 'MANUAL')),
            manual_price REAL,
            provider_symbol TEXT,
            sector TEXT NOT NULL DEFAULT '',
            industry TEXT NOT NULL DEFAULT '',
            metadata_source TEXT NOT NULL DEFAULT '',
            metadata_updated_at TEXT,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            UNIQUE (portfolio_id, symbol),
            FOREIGN KEY (portfolio_id) REFERENCES portfolios(id) ON DELETE CASCADE
        )
        """
    )


def _migrate_portfolio_assets(connection: sqlite3.Connection, default_portfolio_id: int) -> None:
    if not _table_exists(connection, "portfolio_assets"):
        _create_portfolio_assets_table(connection)
        return

    columns = _columns(connection, "portfolio_assets")
    if "portfolio_id" in columns:
        connection.execute(
            "UPDATE portfolio_assets SET portfolio_id = ? WHERE portfolio_id IS NULL OR portfolio_id <= 0",
            (default_portfolio_id,),
        )
        return

    legacy_table = "portfolio_assets_alpha13_legacy"
    connection.execute(f"DROP TABLE IF EXISTS {legacy_table}")
    connection.execute(f"ALTER TABLE portfolio_assets RENAME TO {legacy_table}")
    _create_portfolio_assets_table(connection)
    connection.execute(
        f"""
        INSERT INTO portfolio_assets
            (portfolio_id, symbol, name, asset_type, currency, exchange, pricing_mode,
             manual_price, provider_symbol, created_at, updated_at)
        SELECT ?, symbol, name, asset_type, currency, exchange, pricing_mode,
               manual_price, provider_symbol, created_at, updated_at
        FROM {legacy_table}
        """,
        (default_portfolio_id,),
    )
    connection.execute(f"DROP TABLE {legacy_table}")


def _backup_before_alpha14_migration() -> Path | None:
    if not DATABASE_PATH.exists():
        return None
    try:
        with sqlite3.connect(DATABASE_PATH) as connection:
            if _table_exists(connection, "portfolios"):
                return None
    except sqlite3.DatabaseError:
        return None

    backup_dir = DATA_DIR / "backups"
    backup_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    backup_path = backup_dir / f"quantlab_pre_alpha14_{stamp}.db"
    shutil.copy2(DATABASE_PATH, backup_path)
    return backup_path


def _backup_before_alpha14_phase2_migration() -> Path | None:
    if not DATABASE_PATH.exists():
        return None
    try:
        with sqlite3.connect(DATABASE_PATH) as connection:
            if not _table_exists(connection, "portfolios"):
                return None
            if _table_exists(connection, "schema_migrations"):
                applied = connection.execute(
                    "SELECT 1 FROM schema_migrations WHERE version = 5"
                ).fetchone()
                if applied is not None:
                    return None
    except sqlite3.DatabaseError:
        return None

    backup_dir = DATA_DIR / "backups"
    backup_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    backup_path = backup_dir / f"quantlab_pre_alpha14_phase2_{stamp}.db"
    shutil.copy2(DATABASE_PATH, backup_path)
    return backup_path


def _backup_before_alpha14_phase3_migration() -> Path | None:
    if not DATABASE_PATH.exists():
        return None
    try:
        with sqlite3.connect(DATABASE_PATH) as connection:
            if not _table_exists(connection, "portfolios"):
                return None
            if _table_exists(connection, "schema_migrations"):
                applied = connection.execute(
                    "SELECT 1 FROM schema_migrations WHERE version = 6"
                ).fetchone()
                if applied is not None:
                    return None
    except sqlite3.DatabaseError:
        return None

    backup_dir = DATA_DIR / "backups"
    backup_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    backup_path = backup_dir / f"quantlab_pre_alpha14_phase3_{stamp}.db"
    shutil.copy2(DATABASE_PATH, backup_path)
    return backup_path




def _backup_before_alpha14_phase4_migration() -> Path | None:
    if not DATABASE_PATH.exists():
        return None
    try:
        with sqlite3.connect(DATABASE_PATH) as connection:
            if not _table_exists(connection, "portfolios"):
                return None
            if _table_exists(connection, "schema_migrations"):
                applied = connection.execute(
                    "SELECT 1 FROM schema_migrations WHERE version = 7"
                ).fetchone()
                if applied is not None:
                    return None
    except sqlite3.DatabaseError:
        return None

    backup_dir = DATA_DIR / "backups"
    backup_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    backup_path = backup_dir / f"quantlab_pre_alpha14_phase4_{stamp}.db"
    shutil.copy2(DATABASE_PATH, backup_path)
    return backup_path


def _backup_before_alpha14_phase5_migration() -> Path | None:
    if not DATABASE_PATH.exists():
        return None
    try:
        with sqlite3.connect(DATABASE_PATH) as connection:
            if not _table_exists(connection, "portfolios"):
                return None
            if _table_exists(connection, "schema_migrations"):
                applied = connection.execute(
                    "SELECT 1 FROM schema_migrations WHERE version = 8"
                ).fetchone()
                if applied is not None:
                    return None
    except sqlite3.DatabaseError:
        return None

    backup_dir = DATA_DIR / "backups"
    backup_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    backup_path = backup_dir / f"quantlab_pre_alpha14_phase5_{stamp}.db"
    shutil.copy2(DATABASE_PATH, backup_path)
    return backup_path


def _backup_before_alpha15_phase1_migration() -> Path | None:
    if not DATABASE_PATH.exists():
        return None
    try:
        with sqlite3.connect(DATABASE_PATH) as connection:
            if not _table_exists(connection, "portfolios"):
                return None
            if _table_exists(connection, "schema_migrations"):
                applied = connection.execute(
                    "SELECT 1 FROM schema_migrations WHERE version = 9"
                ).fetchone()
                if applied is not None:
                    return None
    except sqlite3.DatabaseError:
        return None

    backup_dir = DATA_DIR / "backups"
    backup_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    backup_path = backup_dir / f"quantlab_pre_alpha15_phase1_{stamp}.db"
    shutil.copy2(DATABASE_PATH, backup_path)
    return backup_path




def _backup_before_alpha15_phase2_migration() -> Path | None:
    if not DATABASE_PATH.exists():
        return None
    try:
        with sqlite3.connect(DATABASE_PATH) as connection:
            if not _table_exists(connection, "portfolios"):
                return None
            if _table_exists(connection, "schema_migrations"):
                applied = connection.execute(
                    "SELECT 1 FROM schema_migrations WHERE version = 10"
                ).fetchone()
                if applied is not None:
                    return None
    except sqlite3.DatabaseError:
        return None

    backup_dir = DATA_DIR / "backups"
    backup_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    backup_path = backup_dir / f"quantlab_pre_alpha15_phase2_{stamp}.db"
    shutil.copy2(DATABASE_PATH, backup_path)
    return backup_path



def _backup_before_alpha15_phase3_migration() -> Path | None:
    if not DATABASE_PATH.exists():
        return None
    try:
        with sqlite3.connect(DATABASE_PATH) as connection:
            if not _table_exists(connection, "portfolios"):
                return None
            if _table_exists(connection, "schema_migrations"):
                applied = connection.execute(
                    "SELECT 1 FROM schema_migrations WHERE version = 11"
                ).fetchone()
                if applied is not None:
                    return None
    except sqlite3.DatabaseError:
        return None

    backup_dir = DATA_DIR / "backups"
    backup_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    backup_path = backup_dir / f"quantlab_pre_alpha15_phase3_{stamp}.db"
    shutil.copy2(DATABASE_PATH, backup_path)
    return backup_path


def _backup_before_alpha15_phase4_migration() -> Path | None:
    if not DATABASE_PATH.exists():
        return None
    try:
        with sqlite3.connect(DATABASE_PATH) as connection:
            if not _table_exists(connection, "portfolios"):
                return None
            if _table_exists(connection, "schema_migrations"):
                applied = connection.execute(
                    "SELECT 1 FROM schema_migrations WHERE version = 12"
                ).fetchone()
                if applied is not None:
                    return None
    except sqlite3.DatabaseError:
        return None

    backup_dir = DATA_DIR / "backups"
    backup_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    backup_path = backup_dir / f"quantlab_pre_alpha15_phase4_{stamp}.db"
    shutil.copy2(DATABASE_PATH, backup_path)
    return backup_path


def _backup_before_alpha16_phase1_migration() -> Path | None:
    if not DATABASE_PATH.exists():
        return None
    try:
        with sqlite3.connect(DATABASE_PATH) as connection:
            if not _table_exists(connection, "portfolios"):
                return None
            if _table_exists(connection, "schema_migrations"):
                applied = connection.execute(
                    "SELECT 1 FROM schema_migrations WHERE version = 13"
                ).fetchone()
                if applied is not None:
                    return None
    except sqlite3.DatabaseError:
        return None

    backup_dir = DATA_DIR / "backups"
    backup_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    backup_path = backup_dir / f"quantlab_pre_alpha16_phase1_{stamp}.db"
    shutil.copy2(DATABASE_PATH, backup_path)
    return backup_path

def _backup_before_alpha16_phase2_migration() -> Path | None:
    if not DATABASE_PATH.exists():
        return None
    try:
        with sqlite3.connect(DATABASE_PATH) as connection:
            if not _table_exists(connection, "portfolios"):
                return None
            if _table_exists(connection, "schema_migrations"):
                applied = connection.execute(
                    "SELECT 1 FROM schema_migrations WHERE version = 14"
                ).fetchone()
                if applied is not None:
                    return None
    except sqlite3.DatabaseError:
        return None
    backup_dir = DATA_DIR / "backups"
    backup_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    backup_path = backup_dir / f"quantlab_pre_alpha16_phase2_{stamp}.db"
    shutil.copy2(DATABASE_PATH, backup_path)
    return backup_path


def _backup_before_alpha16_phase3_migration() -> Path | None:
    if not DATABASE_PATH.exists():
        return None
    try:
        with sqlite3.connect(DATABASE_PATH) as connection:
            if not _table_exists(connection, "portfolios"):
                return None
            if _table_exists(connection, "schema_migrations"):
                applied = connection.execute(
                    "SELECT 1 FROM schema_migrations WHERE version = 15"
                ).fetchone()
                if applied is not None:
                    return None
    except sqlite3.DatabaseError:
        return None
    backup_dir = DATA_DIR / "backups"
    backup_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    backup_path = backup_dir / f"quantlab_pre_alpha16_phase3_{stamp}.db"
    shutil.copy2(DATABASE_PATH, backup_path)
    return backup_path


def initialize_database() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    _backup_before_alpha14_migration()
    _backup_before_alpha14_phase2_migration()
    _backup_before_alpha14_phase3_migration()
    _backup_before_alpha14_phase4_migration()
    _backup_before_alpha14_phase5_migration()
    _backup_before_alpha15_phase1_migration()
    _backup_before_alpha15_phase2_migration()
    _backup_before_alpha15_phase3_migration()
    _backup_before_alpha15_phase4_migration()
    _backup_before_alpha16_phase1_migration()
    _backup_before_alpha16_phase2_migration()
    _backup_before_alpha16_phase3_migration()

    with sqlite3.connect(DATABASE_PATH) as connection:
        connection.execute("PRAGMA foreign_keys = ON")
        connection.execute("PRAGMA journal_mode = WAL")

        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS schema_migrations (
                version INTEGER PRIMARY KEY,
                name TEXT NOT NULL,
                applied_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS watchlist (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                symbol TEXT NOT NULL UNIQUE,
                name TEXT NOT NULL,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
            """
        )

        # Tabla heredada conservada para migrar bases Alpha 1.2/1.3.
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS portfolio_settings (
                id INTEGER PRIMARY KEY CHECK (id = 1),
                name TEXT NOT NULL DEFAULT 'Portafolio principal',
                base_currency TEXT NOT NULL DEFAULT 'USD',
                initial_cash REAL NOT NULL DEFAULT 10000 CHECK (initial_cash >= 0),
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        connection.execute(
            """
            INSERT OR IGNORE INTO portfolio_settings (id, name, base_currency, initial_cash)
            VALUES (1, 'Portafolio principal', 'USD', 10000)
            """
        )

        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS portfolios (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                name TEXT NOT NULL,
                base_currency TEXT NOT NULL DEFAULT 'USD',
                initial_cash REAL NOT NULL DEFAULT 10000 CHECK (initial_cash >= 0),
                allow_margin INTEGER NOT NULL DEFAULT 0 CHECK (allow_margin IN (0, 1)),
                is_archived INTEGER NOT NULL DEFAULT 0 CHECK (is_archived IN (0, 1)),
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        _ensure_column(connection, "portfolios", "allow_margin INTEGER NOT NULL DEFAULT 0")
        connection.execute(
            "UPDATE portfolios SET allow_margin = COALESCE(allow_margin, 0)"
        )
        portfolio_count = int(connection.execute("SELECT COUNT(*) FROM portfolios").fetchone()[0])
        if portfolio_count == 0:
            legacy = connection.execute(
                """
                SELECT name, base_currency, initial_cash, created_at, updated_at
                FROM portfolio_settings WHERE id = 1
                """
            ).fetchone()
            if legacy is None:
                connection.execute(
                    """
                    INSERT INTO portfolios (id, name, base_currency, initial_cash)
                    VALUES (1, 'Portafolio principal', 'USD', 10000)
                    """
                )
            else:
                connection.execute(
                    """
                    INSERT INTO portfolios
                        (id, name, base_currency, initial_cash, created_at, updated_at)
                    VALUES (1, ?, ?, ?, ?, ?)
                    """,
                    tuple(legacy),
                )

        default_portfolio_id = int(
            connection.execute("SELECT id FROM portfolios ORDER BY id LIMIT 1").fetchone()[0]
        )

        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS portfolio_transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                portfolio_id INTEGER NOT NULL DEFAULT 1,
                symbol TEXT NOT NULL,
                transaction_type TEXT NOT NULL CHECK (transaction_type IN ('BUY', 'SELL')),
                quantity REAL NOT NULL CHECK (quantity > 0),
                price REAL NOT NULL CHECK (price > 0),
                fees REAL NOT NULL DEFAULT 0 CHECK (fees >= 0),
                occurred_at TEXT NOT NULL,
                notes TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (portfolio_id) REFERENCES portfolios(id) ON DELETE CASCADE
            )
            """
        )
        _ensure_column(connection, "portfolio_transactions", "portfolio_id INTEGER")
        _ensure_column(connection, "portfolio_transactions", "asset_name TEXT NOT NULL DEFAULT ''")
        _ensure_column(connection, "portfolio_transactions", "asset_type TEXT NOT NULL DEFAULT 'EQUITY'")
        _ensure_column(connection, "portfolio_transactions", "asset_currency TEXT NOT NULL DEFAULT 'USD'")
        _ensure_column(connection, "portfolio_transactions", "exchange TEXT NOT NULL DEFAULT ''")
        _ensure_column(connection, "portfolio_transactions", "pricing_mode TEXT NOT NULL DEFAULT 'AUTO'")
        _ensure_column(connection, "portfolio_transactions", "fx_rate_to_base REAL NOT NULL DEFAULT 1")
        _ensure_column(connection, "portfolio_transactions", "is_deleted INTEGER NOT NULL DEFAULT 0")
        _ensure_column(connection, "portfolio_transactions", "deleted_at TEXT")
        _ensure_column(connection, "portfolio_transactions", "deleted_reason TEXT NOT NULL DEFAULT ''")
        _ensure_column(connection, "portfolio_transactions", "updated_at TEXT")
        _ensure_column(connection, "portfolio_transactions", "revision INTEGER NOT NULL DEFAULT 1")
        _ensure_column(connection, "portfolio_transactions", "import_fingerprint TEXT")
        _ensure_column(connection, "portfolio_transactions", "import_batch_id INTEGER")
        _ensure_column(connection, "portfolio_transactions", "import_row_number INTEGER")
        connection.execute(
            """
            UPDATE portfolio_transactions
            SET is_deleted = COALESCE(is_deleted, 0),
                revision = CASE WHEN revision IS NULL OR revision < 1 THEN 1 ELSE revision END,
                updated_at = COALESCE(updated_at, created_at, CURRENT_TIMESTAMP)
            """
        )
        connection.execute(
            "UPDATE portfolio_transactions SET portfolio_id = ? WHERE portfolio_id IS NULL OR portfolio_id <= 0",
            (default_portfolio_id,),
        )

        base_currency_row = connection.execute(
            "SELECT base_currency FROM portfolios WHERE id = ?",
            (default_portfolio_id,),
        ).fetchone()
        base_currency = str(base_currency_row[0] if base_currency_row else "USD")
        connection.execute(
            """
            UPDATE portfolio_transactions
            SET asset_name = CASE WHEN asset_name = '' THEN symbol ELSE asset_name END,
                fx_rate_to_base = CASE WHEN fx_rate_to_base <= 0 THEN 1 ELSE fx_rate_to_base END
            WHERE portfolio_id = ?
            """,
            (default_portfolio_id,),
        )
        if base_currency != "USD":
            connection.execute(
                """
                UPDATE portfolio_transactions
                SET asset_currency = ?
                WHERE portfolio_id = ? AND asset_currency = 'USD'
                """,
                (base_currency, default_portfolio_id),
            )

        _migrate_portfolio_assets(connection, default_portfolio_id)
        _ensure_column(connection, "portfolio_assets", "sector TEXT NOT NULL DEFAULT ''")
        _ensure_column(connection, "portfolio_assets", "industry TEXT NOT NULL DEFAULT ''")
        _ensure_column(connection, "portfolio_assets", "metadata_source TEXT NOT NULL DEFAULT ''")
        _ensure_column(connection, "portfolio_assets", "metadata_updated_at TEXT")
        connection.execute(
            """
            INSERT OR IGNORE INTO portfolio_assets
                (portfolio_id, symbol, name, asset_type, currency, exchange, pricing_mode, provider_symbol)
            SELECT DISTINCT portfolio_id, symbol,
                   CASE WHEN asset_name = '' THEN symbol ELSE asset_name END,
                   asset_type, asset_currency, exchange, pricing_mode,
                   CASE WHEN pricing_mode = 'AUTO' THEN symbol ELSE NULL END
            FROM portfolio_transactions
            """
        )

        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS portfolio_cash_movements (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                portfolio_id INTEGER NOT NULL DEFAULT 1,
                movement_type TEXT NOT NULL CHECK (
                    movement_type IN ('DEPOSIT', 'WITHDRAWAL', 'DIVIDEND', 'INTEREST', 'TAX', 'FEE')
                ),
                amount REAL NOT NULL CHECK (amount > 0),
                currency TEXT NOT NULL,
                fx_rate_to_base REAL NOT NULL CHECK (fx_rate_to_base > 0),
                symbol TEXT,
                occurred_at TEXT NOT NULL,
                notes TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (portfolio_id) REFERENCES portfolios(id) ON DELETE CASCADE
            )
            """
        )
        _ensure_column(connection, "portfolio_cash_movements", "portfolio_id INTEGER")
        _ensure_column(connection, "portfolio_cash_movements", "is_deleted INTEGER NOT NULL DEFAULT 0")
        _ensure_column(connection, "portfolio_cash_movements", "deleted_at TEXT")
        _ensure_column(connection, "portfolio_cash_movements", "deleted_reason TEXT NOT NULL DEFAULT ''")
        _ensure_column(connection, "portfolio_cash_movements", "updated_at TEXT")
        _ensure_column(connection, "portfolio_cash_movements", "revision INTEGER NOT NULL DEFAULT 1")
        _ensure_column(connection, "portfolio_cash_movements", "import_fingerprint TEXT")
        _ensure_column(connection, "portfolio_cash_movements", "import_batch_id INTEGER")
        _ensure_column(connection, "portfolio_cash_movements", "import_row_number INTEGER")
        connection.execute(
            """
            UPDATE portfolio_cash_movements
            SET is_deleted = COALESCE(is_deleted, 0),
                revision = CASE WHEN revision IS NULL OR revision < 1 THEN 1 ELSE revision END,
                updated_at = COALESCE(updated_at, created_at, CURRENT_TIMESTAMP)
            """
        )
        connection.execute(
            "UPDATE portfolio_cash_movements SET portfolio_id = ? WHERE portfolio_id IS NULL OR portfolio_id <= 0",
            (default_portfolio_id,),
        )


        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS portfolio_fx_conversions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                portfolio_id INTEGER NOT NULL,
                from_currency TEXT NOT NULL,
                to_currency TEXT NOT NULL,
                from_amount REAL NOT NULL CHECK (from_amount > 0),
                to_amount REAL NOT NULL CHECK (to_amount > 0),
                exchange_rate REAL NOT NULL CHECK (exchange_rate > 0),
                pricing_mode TEXT NOT NULL DEFAULT 'AUTO' CHECK (pricing_mode IN ('AUTO', 'MANUAL')),
                fee_amount REAL NOT NULL DEFAULT 0 CHECK (fee_amount >= 0),
                fee_currency TEXT,
                from_fx_rate_to_base REAL NOT NULL CHECK (from_fx_rate_to_base > 0),
                to_fx_rate_to_base REAL NOT NULL CHECK (to_fx_rate_to_base > 0),
                realized_fx_pnl_base REAL NOT NULL DEFAULT 0,
                occurred_at TEXT NOT NULL,
                notes TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                revision INTEGER NOT NULL DEFAULT 1,
                is_deleted INTEGER NOT NULL DEFAULT 0 CHECK (is_deleted IN (0, 1)),
                deleted_at TEXT,
                deleted_reason TEXT NOT NULL DEFAULT '',
                CHECK (from_currency <> to_currency),
                FOREIGN KEY (portfolio_id) REFERENCES portfolios(id) ON DELETE CASCADE
            )
            """
        )

        _ensure_column(connection, "portfolio_fx_conversions", "import_fingerprint TEXT")
        _ensure_column(connection, "portfolio_fx_conversions", "import_batch_id INTEGER")
        _ensure_column(connection, "portfolio_fx_conversions", "import_row_number INTEGER")

        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS portfolio_audit_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                portfolio_id INTEGER NOT NULL,
                entity_type TEXT NOT NULL,
                entity_id INTEGER NOT NULL,
                action TEXT NOT NULL,
                before_json TEXT,
                after_json TEXT,
                reason TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (portfolio_id) REFERENCES portfolios(id) ON DELETE CASCADE
            )
            """
        )

        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS portfolio_activity_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                portfolio_id INTEGER NOT NULL,
                action TEXT NOT NULL,
                entity_type TEXT NOT NULL DEFAULT 'portfolio',
                entity_id TEXT,
                details TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (portfolio_id) REFERENCES portfolios(id) ON DELETE CASCADE
            )
            """
        )


        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS portfolio_import_batches (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                portfolio_id INTEGER NOT NULL,
                filename TEXT NOT NULL,
                adapter TEXT NOT NULL DEFAULT 'generic',
                file_sha256 TEXT NOT NULL,
                status TEXT NOT NULL,
                total_rows INTEGER NOT NULL DEFAULT 0,
                accepted_rows INTEGER NOT NULL DEFAULT 0,
                rejected_rows INTEGER NOT NULL DEFAULT 0,
                duplicate_rows INTEGER NOT NULL DEFAULT 0,
                report_json TEXT,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                committed_at TEXT,
                FOREIGN KEY (portfolio_id) REFERENCES portfolios(id) ON DELETE CASCADE
            )
            """
        )
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS backup_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                filename TEXT NOT NULL,
                backup_type TEXT NOT NULL DEFAULT 'manual',
                schema_version INTEGER NOT NULL,
                size_bytes INTEGER NOT NULL,
                checksum_sha256 TEXT NOT NULL,
                note TEXT NOT NULL DEFAULT '',
                action TEXT NOT NULL DEFAULT 'CREATE',
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
            """
        )

        connection.execute(
            "CREATE INDEX IF NOT EXISTS idx_portfolios_archived ON portfolios(is_archived, id)"
        )
        connection.execute(
            """
            CREATE INDEX IF NOT EXISTS idx_portfolio_transactions_portfolio_date
            ON portfolio_transactions(portfolio_id, occurred_at, id)
            """
        )
        connection.execute(
            """
            CREATE INDEX IF NOT EXISTS idx_portfolio_transactions_portfolio_symbol
            ON portfolio_transactions(portfolio_id, symbol)
            """
        )
        connection.execute(
            """
            CREATE INDEX IF NOT EXISTS idx_portfolio_transactions_active
            ON portfolio_transactions(portfolio_id, is_deleted, occurred_at, id)
            """
        )
        connection.execute(
            """
            CREATE INDEX IF NOT EXISTS idx_portfolio_cash_portfolio_date
            ON portfolio_cash_movements(portfolio_id, occurred_at, id)
            """
        )
        connection.execute(
            """
            CREATE INDEX IF NOT EXISTS idx_portfolio_cash_active
            ON portfolio_cash_movements(portfolio_id, is_deleted, occurred_at, id)
            """
        )
        connection.execute(
            """
            CREATE INDEX IF NOT EXISTS idx_portfolio_fx_active
            ON portfolio_fx_conversions(portfolio_id, is_deleted, occurred_at, id)
            """
        )
        connection.execute(
            """
            CREATE INDEX IF NOT EXISTS idx_portfolio_audit_entity
            ON portfolio_audit_log(portfolio_id, entity_type, entity_id, id DESC)
            """
        )
        connection.execute(
            """
            CREATE UNIQUE INDEX IF NOT EXISTS idx_portfolio_assets_portfolio_symbol
            ON portfolio_assets(portfolio_id, symbol)
            """
        )

        connection.execute(
            """
            CREATE INDEX IF NOT EXISTS idx_import_batches_portfolio
            ON portfolio_import_batches(portfolio_id, id DESC)
            """
        )
        connection.execute(
            """
            CREATE INDEX IF NOT EXISTS idx_backup_history_created
            ON backup_history(created_at DESC, id DESC)
            """
        )

        run_migrations(connection)
        connection.commit()


@contextmanager
def get_connection() -> Iterator[sqlite3.Connection]:
    connection = sqlite3.connect(DATABASE_PATH)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    try:
        yield connection
        connection.commit()
    finally:
        connection.close()
