from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from typing import Callable


@dataclass(frozen=True)
class Migration:
    version: int
    name: str
    apply: Callable[[sqlite3.Connection], None]


def _noop(_: sqlite3.Connection) -> None:
    return None


def _phase5(connection: sqlite3.Connection) -> None:
    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS market_manual_prices (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            symbol TEXT NOT NULL UNIQUE,
            price REAL NOT NULL CHECK (price > 0),
            currency TEXT NOT NULL,
            name TEXT NOT NULL DEFAULT '',
            notes TEXT NOT NULL DEFAULT '',
            observed_at TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
        """
    )
    connection.execute(
        "CREATE INDEX IF NOT EXISTS idx_market_manual_prices_symbol ON market_manual_prices(symbol)"
    )
    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS market_symbol_aliases (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            old_symbol TEXT NOT NULL UNIQUE,
            new_symbol TEXT NOT NULL,
            notes TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
        """
    )
    connection.execute(
        "CREATE INDEX IF NOT EXISTS idx_market_symbol_aliases_old ON market_symbol_aliases(old_symbol)"
    )


def _alpha15_phase1(connection: sqlite3.Connection) -> None:
    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS portfolio_analytics_settings (
            portfolio_id INTEGER PRIMARY KEY,
            benchmark_symbol TEXT NOT NULL DEFAULT 'SPY',
            benchmark_name TEXT NOT NULL DEFAULT 'S&P 500 (SPY)',
            risk_free_rate_percent REAL NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (portfolio_id) REFERENCES portfolios(id) ON DELETE CASCADE
        )
        """
    )
    connection.execute(
        """
        INSERT OR IGNORE INTO portfolio_analytics_settings
            (portfolio_id, benchmark_symbol, benchmark_name, risk_free_rate_percent)
        SELECT id, 'SPY', 'S&P 500 (SPY)', 0 FROM portfolios
        """
    )
    connection.execute(
        "CREATE INDEX IF NOT EXISTS idx_portfolio_analytics_benchmark "
        "ON portfolio_analytics_settings(benchmark_symbol)"
    )


def _alpha15_phase2(connection: sqlite3.Connection) -> None:
    existing = {str(row[1]) for row in connection.execute("PRAGMA table_info(portfolio_cash_movements)")}
    columns = {
        "gross_amount": "REAL",
        "withholding_tax": "REAL NOT NULL DEFAULT 0",
        "withholding_percent": "REAL NOT NULL DEFAULT 0",
        "dividend_per_share": "REAL",
        "shares_held": "REAL",
        "dividend_source": "TEXT NOT NULL DEFAULT 'MANUAL'",
        "reinvested": "INTEGER NOT NULL DEFAULT 0",
        "reinvest_transaction_id": "INTEGER",
        "ex_dividend_date": "TEXT",
    }
    for name, definition in columns.items():
        if name not in existing:
            connection.execute(f"ALTER TABLE portfolio_cash_movements ADD COLUMN {name} {definition}")
    connection.execute(
        """
        UPDATE portfolio_cash_movements
        SET gross_amount = COALESCE(gross_amount, amount),
            withholding_tax = COALESCE(withholding_tax, 0),
            withholding_percent = CASE
                WHEN COALESCE(gross_amount, amount) > 0
                THEN COALESCE(withholding_tax, 0) / COALESCE(gross_amount, amount) * 100
                ELSE 0 END,
            dividend_source = COALESCE(NULLIF(dividend_source, ''), 'MANUAL'),
            reinvested = COALESCE(reinvested, 0)
        """
    )
    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS portfolio_dividend_settings (
            portfolio_id INTEGER PRIMARY KEY,
            default_withholding_percent REAL NOT NULL DEFAULT 0
                CHECK (default_withholding_percent >= 0 AND default_withholding_percent <= 100),
            default_reinvest INTEGER NOT NULL DEFAULT 0 CHECK (default_reinvest IN (0, 1)),
            forecast_months INTEGER NOT NULL DEFAULT 12 CHECK (forecast_months BETWEEN 1 AND 36),
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (portfolio_id) REFERENCES portfolios(id) ON DELETE CASCADE
        )
        """
    )
    connection.execute(
        """
        INSERT OR IGNORE INTO portfolio_dividend_settings
            (portfolio_id, default_withholding_percent, default_reinvest, forecast_months)
        SELECT id, 0, 0, 12 FROM portfolios
        """
    )
    connection.execute(
        "CREATE INDEX IF NOT EXISTS idx_cash_dividend_symbol_date "
        "ON portfolio_cash_movements(portfolio_id, movement_type, symbol, occurred_at)"
    )
    connection.execute(
        "CREATE INDEX IF NOT EXISTS idx_cash_reinvest_transaction "
        "ON portfolio_cash_movements(reinvest_transaction_id)"
    )


def _alpha15_phase3(connection: sqlite3.Connection) -> None:
    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS portfolio_corporate_actions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            portfolio_id INTEGER NOT NULL,
            action_type TEXT NOT NULL CHECK (action_type IN (
                'SPLIT', 'REVERSE_SPLIT', 'TICKER_CHANGE', 'MERGER',
                'SPINOFF', 'STOCK_DIVIDEND', 'RETURN_OF_CAPITAL'
            )),
            symbol TEXT NOT NULL,
            target_symbol TEXT,
            quantity_ratio REAL NOT NULL DEFAULT 1 CHECK (quantity_ratio > 0),
            cost_allocation_percent REAL NOT NULL DEFAULT 0
                CHECK (cost_allocation_percent >= 0 AND cost_allocation_percent <= 100),
            cash_amount REAL NOT NULL DEFAULT 0 CHECK (cash_amount >= 0),
            cash_currency TEXT,
            fx_rate_to_base REAL,
            target_name TEXT NOT NULL DEFAULT '',
            target_asset_type TEXT NOT NULL DEFAULT 'EQUITY',
            target_currency TEXT,
            target_exchange TEXT NOT NULL DEFAULT '',
            occurred_at TEXT NOT NULL,
            notes TEXT NOT NULL DEFAULT '',
            source TEXT NOT NULL DEFAULT 'MANUAL',
            import_fingerprint TEXT,
            import_batch_id INTEGER,
            import_row_number INTEGER,
            is_deleted INTEGER NOT NULL DEFAULT 0 CHECK (is_deleted IN (0, 1)),
            deleted_at TEXT,
            deleted_reason TEXT NOT NULL DEFAULT '',
            revision INTEGER NOT NULL DEFAULT 1,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (portfolio_id) REFERENCES portfolios(id) ON DELETE CASCADE
        )
        """
    )
    existing = {str(row[1]) for row in connection.execute("PRAGMA table_info(portfolio_corporate_actions)")}
    import_columns = {
        "import_fingerprint": "TEXT",
        "import_batch_id": "INTEGER",
        "import_row_number": "INTEGER",
    }
    for name, definition in import_columns.items():
        if name not in existing:
            connection.execute(
                f"ALTER TABLE portfolio_corporate_actions ADD COLUMN {name} {definition}"
            )

    connection.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_corporate_actions_portfolio_date
        ON portfolio_corporate_actions(portfolio_id, is_deleted, occurred_at, id)
        """
    )
    connection.execute(
        """
        CREATE INDEX IF NOT EXISTS idx_corporate_actions_symbols
        ON portfolio_corporate_actions(portfolio_id, symbol, target_symbol)
        """
    )


def _alpha15_phase4(connection: sqlite3.Connection) -> None:
    existing = {str(row[1]) for row in connection.execute("PRAGMA table_info(portfolio_assets)")}
    columns = {
        "sector": "TEXT NOT NULL DEFAULT ''",
        "industry": "TEXT NOT NULL DEFAULT ''",
        "metadata_source": "TEXT NOT NULL DEFAULT ''",
        "metadata_updated_at": "TEXT",
    }
    for name, definition in columns.items():
        if name not in existing:
            connection.execute(f"ALTER TABLE portfolio_assets ADD COLUMN {name} {definition}")
    connection.execute(
        "CREATE INDEX IF NOT EXISTS idx_portfolio_assets_sector "
        "ON portfolio_assets(portfolio_id, sector)"
    )



def _alpha16_phase1(connection: sqlite3.Connection) -> None:
    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS ai_analysis_sessions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            portfolio_id INTEGER NOT NULL,
            title TEXT NOT NULL,
            risk_profile TEXT NOT NULL DEFAULT 'moderado',
            is_archived INTEGER NOT NULL DEFAULT 0 CHECK (is_archived IN (0, 1)),
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (portfolio_id) REFERENCES portfolios(id) ON DELETE CASCADE
        )
        """
    )
    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS ai_analysis_messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id INTEGER NOT NULL,
            role TEXT NOT NULL CHECK (role IN ('user', 'assistant', 'system')),
            content TEXT NOT NULL,
            payload_json TEXT NOT NULL DEFAULT '{}',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (session_id) REFERENCES ai_analysis_sessions(id) ON DELETE CASCADE
        )
        """
    )
    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS ai_tool_runs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            message_id INTEGER NOT NULL,
            tool_name TEXT NOT NULL,
            input_json TEXT NOT NULL DEFAULT '{}',
            status TEXT NOT NULL CHECK (status IN ('success', 'error')),
            source TEXT NOT NULL DEFAULT '',
            observed_at TEXT NOT NULL DEFAULT '',
            duration_ms REAL NOT NULL DEFAULT 0,
            error TEXT NOT NULL DEFAULT '',
            output_summary_json TEXT NOT NULL DEFAULT '{}',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (message_id) REFERENCES ai_analysis_messages(id) ON DELETE CASCADE
        )
        """
    )
    connection.execute(
        "CREATE INDEX IF NOT EXISTS idx_ai_sessions_portfolio_updated "
        "ON ai_analysis_sessions(portfolio_id, is_archived, updated_at DESC)"
    )
    connection.execute(
        "CREATE INDEX IF NOT EXISTS idx_ai_messages_session ON ai_analysis_messages(session_id, id)"
    )
    connection.execute(
        "CREATE INDEX IF NOT EXISTS idx_ai_tool_runs_message ON ai_tool_runs(message_id, id)"
    )



def _alpha16_phase2(connection: sqlite3.Connection) -> None:
    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS ai_agent_settings (
            portfolio_id INTEGER PRIMARY KEY,
            use_language_model INTEGER NOT NULL DEFAULT 1 CHECK (use_language_model IN (0, 1)),
            response_style TEXT NOT NULL DEFAULT 'claro'
                CHECK (response_style IN ('claro', 'breve', 'detallado')),
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (portfolio_id) REFERENCES portfolios(id) ON DELETE CASCADE
        )
        """
    )
    connection.execute(
        """
        INSERT OR IGNORE INTO ai_agent_settings
            (portfolio_id, use_language_model, response_style)
        SELECT id, 1, 'claro' FROM portfolios
        """
    )
    existing = {str(row[1]) for row in connection.execute("PRAGMA table_info(ai_analysis_sessions)")}
    if "last_intent" not in existing:
        connection.execute("ALTER TABLE ai_analysis_sessions ADD COLUMN last_intent TEXT NOT NULL DEFAULT ''")
    if "context_symbols_json" not in existing:
        connection.execute("ALTER TABLE ai_analysis_sessions ADD COLUMN context_symbols_json TEXT NOT NULL DEFAULT '[]'")


def _alpha16_phase3(connection: sqlite3.Connection) -> None:
    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS ai_alert_rules (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            portfolio_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            rule_type TEXT NOT NULL CHECK (rule_type IN (
                'CONCENTRATION', 'DRAWDOWN', 'VOLATILITY', 'PRICE_ABOVE', 'PRICE_BELOW'
            )),
            symbol TEXT NOT NULL DEFAULT '',
            threshold REAL NOT NULL,
            severity TEXT NOT NULL DEFAULT 'MEDIUM'
                CHECK (severity IN ('LOW', 'MEDIUM', 'HIGH', 'CRITICAL')),
            cooldown_hours INTEGER NOT NULL DEFAULT 24 CHECK (cooldown_hours BETWEEN 1 AND 8760),
            is_enabled INTEGER NOT NULL DEFAULT 1 CHECK (is_enabled IN (0, 1)),
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            last_evaluated_at TEXT,
            FOREIGN KEY (portfolio_id) REFERENCES portfolios(id) ON DELETE CASCADE
        )
        """
    )
    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS ai_alert_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            portfolio_id INTEGER NOT NULL,
            rule_id INTEGER NOT NULL,
            event_key TEXT NOT NULL,
            rule_type TEXT NOT NULL,
            symbol TEXT NOT NULL DEFAULT '',
            title TEXT NOT NULL,
            message TEXT NOT NULL,
            severity TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'ACTIVE'
                CHECK (status IN ('ACTIVE', 'ACKNOWLEDGED', 'DISMISSED', 'RESOLVED')),
            observed_value REAL,
            threshold REAL,
            context_json TEXT NOT NULL DEFAULT '{}',
            triggered_at TEXT NOT NULL,
            last_seen_at TEXT NOT NULL,
            acknowledged_at TEXT,
            dismissed_at TEXT,
            resolved_at TEXT,
            user_note TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (portfolio_id) REFERENCES portfolios(id) ON DELETE CASCADE,
            FOREIGN KEY (rule_id) REFERENCES ai_alert_rules(id) ON DELETE CASCADE
        )
        """
    )
    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS ai_analysis_snapshots (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            portfolio_id INTEGER NOT NULL,
            session_id INTEGER,
            message_id INTEGER,
            snapshot_key TEXT NOT NULL,
            snapshot_type TEXT NOT NULL,
            symbol TEXT NOT NULL DEFAULT '',
            payload_json TEXT NOT NULL DEFAULT '{}',
            fingerprint TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (portfolio_id) REFERENCES portfolios(id) ON DELETE CASCADE,
            FOREIGN KEY (session_id) REFERENCES ai_analysis_sessions(id) ON DELETE SET NULL,
            FOREIGN KEY (message_id) REFERENCES ai_analysis_messages(id) ON DELETE SET NULL
        )
        """
    )
    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS ai_notification_outbox (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            portfolio_id INTEGER NOT NULL,
            alert_event_id INTEGER NOT NULL,
            channel TEXT NOT NULL DEFAULT 'IN_APP',
            status TEXT NOT NULL DEFAULT 'PENDING'
                CHECK (status IN ('PENDING', 'SENT', 'SKIPPED', 'FAILED')),
            payload_json TEXT NOT NULL DEFAULT '{}',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            processed_at TEXT,
            FOREIGN KEY (portfolio_id) REFERENCES portfolios(id) ON DELETE CASCADE,
            FOREIGN KEY (alert_event_id) REFERENCES ai_alert_events(id) ON DELETE CASCADE
        )
        """
    )
    connection.execute(
        """
        INSERT INTO ai_alert_rules
            (portfolio_id, name, rule_type, threshold, severity, cooldown_hours, is_enabled)
        SELECT p.id, 'Concentración por activo', 'CONCENTRATION', 30, 'HIGH', 24, 1
        FROM portfolios p
        WHERE NOT EXISTS (
            SELECT 1 FROM ai_alert_rules r
            WHERE r.portfolio_id = p.id AND r.rule_type = 'CONCENTRATION' AND r.symbol = ''
        )
        """
    )
    connection.execute(
        """
        INSERT INTO ai_alert_rules
            (portfolio_id, name, rule_type, threshold, severity, cooldown_hours, is_enabled)
        SELECT p.id, 'Drawdown actual', 'DRAWDOWN', 15, 'HIGH', 24, 1
        FROM portfolios p
        WHERE NOT EXISTS (
            SELECT 1 FROM ai_alert_rules r
            WHERE r.portfolio_id = p.id AND r.rule_type = 'DRAWDOWN' AND r.symbol = ''
        )
        """
    )
    connection.execute(
        """
        INSERT INTO ai_alert_rules
            (portfolio_id, name, rule_type, threshold, severity, cooldown_hours, is_enabled)
        SELECT p.id, 'Volatilidad anualizada', 'VOLATILITY', 35, 'MEDIUM', 24, 1
        FROM portfolios p
        WHERE NOT EXISTS (
            SELECT 1 FROM ai_alert_rules r
            WHERE r.portfolio_id = p.id AND r.rule_type = 'VOLATILITY' AND r.symbol = ''
        )
        """
    )
    connection.execute(
        "CREATE INDEX IF NOT EXISTS idx_ai_alert_rules_portfolio ON ai_alert_rules(portfolio_id, is_enabled, id)"
    )
    connection.execute(
        "CREATE INDEX IF NOT EXISTS idx_ai_alert_events_portfolio_status ON ai_alert_events(portfolio_id, status, last_seen_at DESC)"
    )
    connection.execute(
        "CREATE INDEX IF NOT EXISTS idx_ai_alert_events_key ON ai_alert_events(event_key, status, id DESC)"
    )
    connection.execute(
        "CREATE INDEX IF NOT EXISTS idx_ai_snapshots_key ON ai_analysis_snapshots(portfolio_id, snapshot_key, id DESC)"
    )
    connection.execute(
        "CREATE INDEX IF NOT EXISTS idx_ai_outbox_status ON ai_notification_outbox(status, id)"
    )
    # El modelo de lenguaje queda disponible pero se desactiva una sola vez al migrar.
    phase3_already_applied = connection.execute(
        "SELECT 1 FROM schema_migrations WHERE version = 15"
    ).fetchone()
    if phase3_already_applied is None:
        connection.execute("UPDATE ai_agent_settings SET use_language_model = 0")


MIGRATIONS: tuple[Migration, ...] = (
    Migration(1, "Base local, watchlist y portafolio inicial", _noop),
    Migration(2, "Portafolio real y movimientos", _noop),
    Migration(3, "Multiactivo, multimoneda y rendimiento", _noop),
    Migration(4, "Alpha 1.4 fase 1: múltiples portafolios", _noop),
    Migration(5, "Alpha 1.4 fase 2: edición segura y auditoría", _noop),
    Migration(6, "Alpha 1.4 fase 3: efectivo multimoneda y conversiones FX", _noop),
    Migration(7, "Alpha 1.4 fase 4: CSV, backups y portabilidad", _noop),
    Migration(8, "Alpha 1.4 fase 5: plataforma, calidad de mercado y fallback manual", _phase5),
    Migration(9, "Alpha 1.5 fase 1: analytics, benchmark y riesgo", _alpha15_phase1),
    Migration(10, "Alpha 1.5 fase 2: dividendos, retenciones y atribución", _alpha15_phase2),
    Migration(11, "Alpha 1.5 fase 3: eventos corporativos y continuidad de costo", _alpha15_phase3),
    Migration(12, "Alpha 1.5 fase 4: analytics avanzado, sector y riesgo multiactivo", _alpha15_phase4),
    Migration(13, "Alpha 1.6 fase 1: agente AI verificable, herramientas y trazabilidad", _alpha16_phase1),
    Migration(14, "Alpha 1.6 fase 2: fundamentales, contexto conversacional y LLM opcional", _alpha16_phase2),
    Migration(15, "Alpha 1.6 fase 3: alertas educativas, memoria de cambios y outbox", _alpha16_phase3),
)


def run_migrations(connection: sqlite3.Connection) -> list[int]:
    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS schema_migrations (
            version INTEGER PRIMARY KEY,
            name TEXT NOT NULL,
            applied_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
        """
    )
    applied = {int(row[0]) for row in connection.execute("SELECT version FROM schema_migrations")}
    executed: list[int] = []
    for migration in sorted(MIGRATIONS, key=lambda item: item.version):
        # Las migraciones son idempotentes: asegurar el esquema actual también repara
        # una instalación incompleta sin volver a registrar la versión.
        migration.apply(connection)
        if migration.version in applied:
            continue
        connection.execute(
            "INSERT INTO schema_migrations (version, name) VALUES (?, ?)",
            (migration.version, migration.name),
        )
        executed.append(migration.version)
    return executed
