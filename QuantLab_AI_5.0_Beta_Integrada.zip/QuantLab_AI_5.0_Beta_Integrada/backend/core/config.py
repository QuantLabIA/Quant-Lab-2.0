import os
from dataclasses import dataclass
from pathlib import Path


BASE_DIR = Path(__file__).resolve().parents[2]
FRONTEND_DIR = BASE_DIR / "frontend"
DATA_DIR = BASE_DIR / "data"
DATABASE_PATH = DATA_DIR / "quantlab.db"
LOG_DIR = DATA_DIR / "logs"


def _load_local_env() -> None:
    """Carga un .env local sin reemplazar variables ya definidas por el sistema."""
    path = BASE_DIR / ".env"
    if not path.exists():
        return
    try:
        for raw_line in path.read_text(encoding="utf-8").splitlines():
            line = raw_line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            key = key.strip()
            value = value.strip().strip('"').strip("'")
            if key:
                os.environ.setdefault(key, value)
    except OSError:
        return


_load_local_env()


def _env_int(name: str, default: int, minimum: int = 1) -> int:
    try:
        return max(minimum, int(os.getenv(name, str(default))))
    except ValueError:
        return default


def _env_float(name: str, default: float, minimum: float = 0.0) -> float:
    try:
        return max(minimum, float(os.getenv(name, str(default))))
    except ValueError:
        return default


def _env_bool(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "si", "sí", "on"}


def _env_list(name: str, default: tuple[str, ...]) -> tuple[str, ...]:
    raw = os.getenv(name)
    if raw is None:
        return default
    values = tuple(item.strip() for item in raw.split(",") if item.strip())
    return values or default


@dataclass(frozen=True)
class Settings:
    app_name: str = os.getenv("QUANTLAB_APP_NAME", "QuantLab AI")
    version: str = "5.0.0-beta.1-integrated"
    environment: str = os.getenv("QUANTLAB_ENV", "development")
    market_data_provider: str = os.getenv("QUANTLAB_MARKET_PROVIDER", "yfinance")
    market_retry_attempts: int = _env_int("QUANTLAB_MARKET_RETRY_ATTEMPTS", 2)
    market_retry_backoff_seconds: float = _env_float("QUANTLAB_MARKET_RETRY_BACKOFF_SECONDS", 0.35)
    max_csv_bytes: int = _env_int("QUANTLAB_MAX_CSV_BYTES", 5 * 1024 * 1024)
    max_csv_rows: int = _env_int("QUANTLAB_MAX_CSV_ROWS", 10000)
    max_backup_bytes: int = _env_int("QUANTLAB_MAX_BACKUP_BYTES", 100 * 1024 * 1024)
    cors_origins: tuple[str, ...] = _env_list(
        "QUANTLAB_CORS_ORIGINS",
        ("http://127.0.0.1:8000", "http://localhost:8000"),
    )
    cors_allow_credentials: bool = _env_bool("QUANTLAB_CORS_ALLOW_CREDENTIALS", False)
    legacy_api_enabled: bool = _env_bool("QUANTLAB_LEGACY_API_ENABLED", True)
    log_level: str = os.getenv("QUANTLAB_LOG_LEVEL", "INFO").upper()
    log_json: bool = _env_bool("QUANTLAB_LOG_JSON", True)
    expose_error_details: bool = _env_bool("QUANTLAB_EXPOSE_ERROR_DETAILS", False)
    llm_provider: str = os.getenv("QUANTLAB_LLM_PROVIDER", "none")
    openai_api_key: str = os.getenv("OPENAI_API_KEY", "")
    openai_model: str = os.getenv("QUANTLAB_OPENAI_MODEL", "gpt-5.6")
    openai_base_url: str = os.getenv("QUANTLAB_OPENAI_BASE_URL", "https://api.openai.com/v1")
    openai_timeout_seconds: float = _env_float("QUANTLAB_OPENAI_TIMEOUT_SECONDS", 45.0, 1.0)
    openai_max_output_tokens: int = _env_int("QUANTLAB_OPENAI_MAX_OUTPUT_TOKENS", 900, 100)


settings = Settings()
