from __future__ import annotations

import logging
import uuid
from time import perf_counter

from fastapi import FastAPI, HTTPException, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware

from backend.core.config import settings

logger = logging.getLogger("quantlab.api")


def _request_id(request: Request) -> str:
    return str(getattr(request.state, "request_id", "") or uuid.uuid4().hex[:16])


def error_payload(detail: str, code: str, request_id: str, fields=None) -> dict:
    payload = {
        "detail": detail,
        "error": {
            "code": code,
            "request_id": request_id,
        },
    }
    if fields:
        payload["error"]["fields"] = fields
    return payload


class RequestContextMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        request_id = request.headers.get("X-Request-ID", "").strip()[:64] or uuid.uuid4().hex[:16]
        request.state.request_id = request_id
        started = perf_counter()
        try:
            response = await call_next(request)
        except Exception:
            duration_ms = round((perf_counter() - started) * 1000, 2)
            logger.exception(
                "Unhandled request error",
                extra={
                    "request_id": request_id,
                    "method": request.method,
                    "path": request.url.path,
                    "duration_ms": duration_ms,
                    "error_code": "internal_error",
                },
            )
            raise
        duration_ms = round((perf_counter() - started) * 1000, 2)
        response.headers["X-Request-ID"] = request_id
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Referrer-Policy"] = "same-origin"
        response.headers["X-Frame-Options"] = "SAMEORIGIN"
        logger.info(
            "Request completed",
            extra={
                "request_id": request_id,
                "method": request.method,
                "path": request.url.path,
                "status_code": response.status_code,
                "duration_ms": duration_ms,
            },
        )
        return response


def install_exception_handlers(app: FastAPI) -> None:
    @app.exception_handler(HTTPException)
    async def http_exception_handler(request: Request, exc: HTTPException):
        detail = exc.detail if isinstance(exc.detail, str) else "La solicitud no pudo completarse"
        return JSONResponse(
            status_code=exc.status_code,
            content=error_payload(detail, f"http_{exc.status_code}", _request_id(request)),
            headers=exc.headers,
        )

    @app.exception_handler(RequestValidationError)
    async def validation_exception_handler(request: Request, exc: RequestValidationError):
        fields = []
        for item in exc.errors():
            location = ".".join(str(part) for part in item.get("loc", []) if part not in {"body", "query", "path"})
            fields.append({"field": location or "request", "message": item.get("msg", "Valor inválido")})
        return JSONResponse(
            status_code=422,
            content=error_payload("Hay datos inválidos en la solicitud", "validation_error", _request_id(request), fields),
        )

    @app.exception_handler(Exception)
    async def unhandled_exception_handler(request: Request, exc: Exception):
        request_id = _request_id(request)
        detail = str(exc) if settings.expose_error_details else "Ocurrió un error interno. Usá el identificador para diagnosticarlo."
        logger.exception("Unhandled application exception", extra={"request_id": request_id, "error_code": "internal_error"})
        return JSONResponse(
            status_code=500,
            content=error_payload(detail, "internal_error", request_id),
        )
