from datetime import datetime, timezone
from typing import Literal
import re

from pydantic import BaseModel, Field, field_validator, model_validator


_SYMBOL_PATTERN = re.compile(r"^[A-Z0-9.\-=_^/:]+$")


def normalize_symbol(value: str) -> str:
    normalized = value.strip().upper()
    if not normalized or len(normalized) > 40:
        raise ValueError("El símbolo está vacío o es demasiado largo")
    if not _SYMBOL_PATTERN.fullmatch(normalized):
        raise ValueError("El símbolo contiene caracteres no permitidos")
    return normalized


def normalize_currency(value: str) -> str:
    normalized = value.strip().upper()
    if not re.fullmatch(r"[A-Z]{3}", normalized):
        raise ValueError("La moneda debe tener un código ISO de 3 letras")
    return normalized


class WatchlistCreate(BaseModel):
    symbol: str = Field(min_length=1, max_length=40)
    name: str = Field(min_length=1, max_length=100)

    @field_validator("symbol")
    @classmethod
    def normalize_watchlist_symbol(cls, value: str) -> str:
        return normalize_symbol(value)

    @field_validator("name")
    @classmethod
    def normalize_name(cls, value: str) -> str:
        return value.strip()


class WatchlistItem(BaseModel):
    id: int
    symbol: str
    name: str
    created_at: str


class SymbolAliasCreate(BaseModel):
    new_symbol: str = Field(min_length=1, max_length=40)
    notes: str = Field(default="", max_length=240)

    @field_validator("new_symbol")
    @classmethod
    def normalize_alias_symbol(cls, value: str) -> str:
        return normalize_symbol(value)

    @field_validator("notes")
    @classmethod
    def normalize_alias_notes(cls, value: str) -> str:
        return value.strip()


class ManualMarketPriceCreate(BaseModel):
    price: float = Field(gt=0, le=1_000_000_000_000)
    currency: str = Field(default="USD")
    name: str = Field(default="", max_length=120)
    notes: str = Field(default="", max_length=240)
    observed_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    @field_validator("currency")
    @classmethod
    def normalize_manual_currency(cls, value: str) -> str:
        return normalize_currency(value)

    @field_validator("name", "notes")
    @classmethod
    def normalize_manual_text(cls, value: str) -> str:
        return value.strip()

    @field_validator("observed_at")
    @classmethod
    def normalize_manual_date(cls, value: datetime) -> datetime:
        if value.tzinfo is None:
            return value.replace(tzinfo=timezone.utc)
        return value.astimezone(timezone.utc)


class AIAnalysisRequest(BaseModel):
    symbol: str = Field(min_length=1, max_length=40)
    risk_profile: str = Field(default="moderado", pattern="^(conservador|moderado|agresivo)$")

    @field_validator("symbol")
    @classmethod
    def normalize_ai_symbol(cls, value: str) -> str:
        return normalize_symbol(value)




class PortfolioCreate(BaseModel):
    name: str = Field(min_length=1, max_length=80)
    base_currency: str = Field(default="USD")
    initial_cash: float = Field(default=10000, ge=0, le=1_000_000_000_000)
    allow_margin: bool = False

    @field_validator("name")
    @classmethod
    def normalize_portfolio_name(cls, value: str) -> str:
        return value.strip()

    @field_validator("base_currency")
    @classmethod
    def normalize_base_currency(cls, value: str) -> str:
        return normalize_currency(value)


class PortfolioSettingsUpdate(BaseModel):
    name: str = Field(min_length=1, max_length=80)
    base_currency: str = Field(default="USD")
    initial_cash: float = Field(ge=0, le=1_000_000_000_000)
    allow_margin: bool = False

    @field_validator("name")
    @classmethod
    def normalize_portfolio_name(cls, value: str) -> str:
        return value.strip()

    @field_validator("base_currency")
    @classmethod
    def normalize_base_currency(cls, value: str) -> str:
        return normalize_currency(value)


class PortfolioTransactionCreate(BaseModel):
    symbol: str = Field(min_length=1, max_length=40)
    transaction_type: Literal["BUY", "SELL"]
    quantity: float = Field(gt=0, le=1_000_000_000)
    price: float = Field(gt=0, le=1_000_000_000_000)
    fees: float = Field(default=0, ge=0, le=1_000_000_000)
    occurred_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    notes: str = Field(default="", max_length=240)
    pricing_mode: Literal["AUTO", "MANUAL"] = "AUTO"
    asset_name: str | None = Field(default=None, max_length=120)
    asset_type: str | None = Field(default=None, max_length=40)
    asset_currency: str | None = None
    exchange: str | None = Field(default=None, max_length=80)
    fx_rate_to_base: float | None = Field(default=None, gt=0, le=1_000_000)

    @field_validator("symbol")
    @classmethod
    def normalize_portfolio_symbol(cls, value: str) -> str:
        return normalize_symbol(value)

    @field_validator("transaction_type", "pricing_mode", mode="before")
    @classmethod
    def normalize_upper(cls, value: str) -> str:
        return str(value).strip().upper()

    @field_validator("occurred_at")
    @classmethod
    def normalize_occurred_at(cls, value: datetime) -> datetime:
        if value.tzinfo is None:
            return value.replace(tzinfo=timezone.utc)
        return value.astimezone(timezone.utc)

    @field_validator("notes")
    @classmethod
    def normalize_notes(cls, value: str) -> str:
        return value.strip()

    @field_validator("asset_name", "asset_type", "exchange")
    @classmethod
    def normalize_optional_text(cls, value: str | None) -> str | None:
        if value is None:
            return None
        stripped = value.strip()
        return stripped or None

    @field_validator("asset_currency")
    @classmethod
    def normalize_asset_currency(cls, value: str | None) -> str | None:
        return normalize_currency(value) if value else None

    @model_validator(mode="after")
    def validate_manual_asset(self):
        if self.pricing_mode == "MANUAL" and not self.asset_currency:
            raise ValueError("Los activos manuales requieren indicar la moneda")
        return self


class PortfolioTransactionUpdate(BaseModel):
    symbol: str = Field(min_length=1, max_length=40)
    transaction_type: Literal["BUY", "SELL"]
    quantity: float = Field(gt=0, le=1_000_000_000)
    price: float = Field(gt=0, le=1_000_000_000_000)
    fees: float = Field(default=0, ge=0, le=1_000_000_000)
    occurred_at: datetime
    notes: str = Field(default="", max_length=240)
    pricing_mode: Literal["AUTO", "MANUAL"] = "AUTO"
    asset_name: str | None = Field(default=None, max_length=120)
    asset_type: str | None = Field(default=None, max_length=40)
    asset_currency: str | None = None
    exchange: str | None = Field(default=None, max_length=80)
    fx_rate_to_base: float | None = Field(default=None, gt=0, le=1_000_000)
    reason: str = Field(default="Corrección de operación", max_length=240)

    @field_validator("symbol")
    @classmethod
    def normalize_update_symbol(cls, value: str) -> str:
        return normalize_symbol(value)

    @field_validator("transaction_type", "pricing_mode", mode="before")
    @classmethod
    def normalize_transaction_type(cls, value: str) -> str:
        return str(value).strip().upper()

    @field_validator("occurred_at")
    @classmethod
    def normalize_update_date(cls, value: datetime) -> datetime:
        if value.tzinfo is None:
            return value.replace(tzinfo=timezone.utc)
        return value.astimezone(timezone.utc)

    @field_validator("notes", "reason")
    @classmethod
    def normalize_update_text(cls, value: str) -> str:
        return value.strip()

    @field_validator("asset_name", "asset_type", "exchange")
    @classmethod
    def normalize_update_optional_text(cls, value: str | None) -> str | None:
        if value is None:
            return None
        stripped = value.strip()
        return stripped or None

    @field_validator("asset_currency")
    @classmethod
    def normalize_update_asset_currency(cls, value: str | None) -> str | None:
        return normalize_currency(value) if value else None

    @model_validator(mode="after")
    def validate_update_manual_asset(self):
        if self.pricing_mode == "MANUAL" and not self.asset_currency:
            raise ValueError("Los activos manuales requieren indicar la moneda")
        return self


class PortfolioCashMovementCreate(BaseModel):
    movement_type: Literal["DEPOSIT", "WITHDRAWAL", "DIVIDEND", "INTEREST", "TAX", "FEE"]
    amount: float = Field(gt=0, le=1_000_000_000_000)
    currency: str = "USD"
    symbol: str | None = Field(default=None, max_length=40)
    occurred_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    notes: str = Field(default="", max_length=240)
    fx_rate_to_base: float | None = Field(default=None, gt=0, le=1_000_000)

    @field_validator("movement_type", mode="before")
    @classmethod
    def normalize_movement_type(cls, value: str) -> str:
        return str(value).strip().upper()

    @field_validator("currency")
    @classmethod
    def normalize_movement_currency(cls, value: str) -> str:
        return normalize_currency(value)

    @field_validator("symbol")
    @classmethod
    def normalize_optional_symbol(cls, value: str | None) -> str | None:
        return normalize_symbol(value) if value else None

    @field_validator("occurred_at")
    @classmethod
    def normalize_movement_date(cls, value: datetime) -> datetime:
        if value.tzinfo is None:
            return value.replace(tzinfo=timezone.utc)
        return value.astimezone(timezone.utc)

    @field_validator("notes")
    @classmethod
    def normalize_movement_notes(cls, value: str) -> str:
        return value.strip()


class PortfolioCashMovementUpdate(BaseModel):
    movement_type: Literal["DEPOSIT", "WITHDRAWAL", "DIVIDEND", "INTEREST", "TAX", "FEE"]
    amount: float = Field(gt=0, le=1_000_000_000_000)
    currency: str = "USD"
    symbol: str | None = Field(default=None, max_length=40)
    occurred_at: datetime
    notes: str = Field(default="", max_length=240)
    fx_rate_to_base: float | None = Field(default=None, gt=0, le=1_000_000)
    reason: str = Field(default="Corrección de movimiento", max_length=240)

    @field_validator("movement_type", mode="before")
    @classmethod
    def normalize_update_movement_type(cls, value: str) -> str:
        return str(value).strip().upper()

    @field_validator("currency")
    @classmethod
    def normalize_update_currency(cls, value: str) -> str:
        return normalize_currency(value)

    @field_validator("symbol")
    @classmethod
    def normalize_update_symbol(cls, value: str | None) -> str | None:
        return normalize_symbol(value) if value else None

    @field_validator("occurred_at")
    @classmethod
    def normalize_update_movement_date(cls, value: datetime) -> datetime:
        if value.tzinfo is None:
            return value.replace(tzinfo=timezone.utc)
        return value.astimezone(timezone.utc)

    @field_validator("notes", "reason")
    @classmethod
    def normalize_update_movement_text(cls, value: str) -> str:
        return value.strip()


class PortfolioDividendCreate(BaseModel):
    symbol: str = Field(min_length=1, max_length=40)
    gross_amount: float = Field(gt=0, le=1_000_000_000_000)
    currency: str = "USD"
    withholding_tax: float | None = Field(default=None, ge=0, le=1_000_000_000_000)
    withholding_percent: float | None = Field(default=None, ge=0, le=100)
    dividend_per_share: float | None = Field(default=None, gt=0, le=1_000_000_000)
    shares_held: float | None = Field(default=None, gt=0, le=1_000_000_000_000)
    occurred_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    ex_dividend_date: datetime | None = None
    notes: str = Field(default="", max_length=240)
    fx_rate_to_base: float | None = Field(default=None, gt=0, le=1_000_000)
    source: Literal["MANUAL", "YFINANCE", "IMPORT"] = "MANUAL"
    reinvest: bool = False
    reinvest_price: float | None = Field(default=None, gt=0, le=1_000_000_000)
    reinvest_fees: float = Field(default=0, ge=0, le=1_000_000_000)

    @field_validator("symbol")
    @classmethod
    def normalize_dividend_symbol(cls, value: str) -> str:
        return normalize_symbol(value)

    @field_validator("currency")
    @classmethod
    def normalize_dividend_currency(cls, value: str) -> str:
        return normalize_currency(value)

    @field_validator("occurred_at", "ex_dividend_date")
    @classmethod
    def normalize_dividend_date(cls, value: datetime | None) -> datetime | None:
        if value is None:
            return None
        if value.tzinfo is None:
            return value.replace(tzinfo=timezone.utc)
        return value.astimezone(timezone.utc)

    @field_validator("notes")
    @classmethod
    def normalize_dividend_notes(cls, value: str) -> str:
        return value.strip()

    @model_validator(mode="after")
    def validate_dividend(self):
        if self.withholding_tax is not None and self.withholding_percent is not None:
            expected = self.gross_amount * self.withholding_percent / 100.0
            tolerance = max(0.01, self.gross_amount * 0.0001)
            if abs(self.withholding_tax - expected) > tolerance:
                raise ValueError("La retención y el porcentaje no coinciden con el dividendo bruto")
        tax = self.withholding_tax
        if tax is None:
            tax = self.gross_amount * float(self.withholding_percent or 0) / 100.0
        if tax - self.gross_amount > 1e-9:
            raise ValueError("La retención no puede superar el dividendo bruto")
        if self.reinvest and self.reinvest_price is None:
            raise ValueError("La reinversión requiere indicar el precio de compra")
        if self.reinvest and self.reinvest_fees >= self.gross_amount - tax:
            raise ValueError("Las comisiones de reinversión deben ser menores al dividendo neto")
        return self


class PortfolioDividendImportOptions(BaseModel):
    withholding_percent: float = Field(default=0, ge=0, le=100)
    reinvest: bool = False
    reinvest_fees: float = Field(default=0, ge=0, le=1_000_000_000)
    price_strategy: Literal["HISTORICAL_CLOSE", "NONE"] = "HISTORICAL_CLOSE"


class PortfolioDividendSettingsUpdate(BaseModel):
    default_withholding_percent: float = Field(default=0, ge=0, le=100)
    default_reinvest: bool = False
    forecast_months: int = Field(default=12, ge=1, le=36)


class PortfolioCorporateActionCreate(BaseModel):
    action_type: Literal[
        "SPLIT", "REVERSE_SPLIT", "TICKER_CHANGE", "MERGER",
        "SPINOFF", "STOCK_DIVIDEND", "RETURN_OF_CAPITAL"
    ]
    symbol: str = Field(min_length=1, max_length=40)
    target_symbol: str | None = Field(default=None, max_length=40)
    quantity_ratio: float = Field(default=1.0, gt=0, le=1_000_000)
    cost_allocation_percent: float = Field(default=0, ge=0, le=100)
    cash_amount: float = Field(default=0, ge=0, le=1_000_000_000_000)
    cash_currency: str | None = None
    fx_rate_to_base: float | None = Field(default=None, gt=0, le=1_000_000)
    target_name: str = Field(default="", max_length=120)
    target_asset_type: str = Field(default="EQUITY", max_length=40)
    target_currency: str | None = None
    target_exchange: str = Field(default="", max_length=80)
    occurred_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    notes: str = Field(default="", max_length=240)
    source: Literal["MANUAL", "YFINANCE", "IMPORT"] = "MANUAL"

    @field_validator("symbol")
    @classmethod
    def normalize_action_symbol(cls, value: str) -> str:
        return normalize_symbol(value)

    @field_validator("target_symbol")
    @classmethod
    def normalize_action_target_symbol(cls, value: str | None) -> str | None:
        return normalize_symbol(value) if value else None

    @field_validator("cash_currency", "target_currency")
    @classmethod
    def normalize_action_currency(cls, value: str | None) -> str | None:
        return normalize_currency(value) if value else None

    @field_validator("occurred_at")
    @classmethod
    def normalize_action_date(cls, value: datetime) -> datetime:
        if value.tzinfo is None:
            return value.replace(tzinfo=timezone.utc)
        return value.astimezone(timezone.utc)

    @field_validator("target_name", "target_asset_type", "target_exchange", "notes")
    @classmethod
    def normalize_action_text(cls, value: str) -> str:
        return value.strip()

    @model_validator(mode="after")
    def validate_action(self):
        target_required = {"TICKER_CHANGE", "MERGER", "SPINOFF"}
        if self.action_type in target_required and not self.target_symbol:
            raise ValueError("Este evento requiere indicar el símbolo de destino")
        if self.action_type in {"TICKER_CHANGE", "MERGER"} and self.target_symbol == self.symbol:
            raise ValueError("El símbolo de destino debe ser diferente")
        if self.action_type == "SPINOFF" and not (0 < self.cost_allocation_percent < 100):
            raise ValueError("El spin-off requiere asignar entre 0 y 100% del costo al nuevo activo")
        if self.action_type != "SPINOFF" and self.cost_allocation_percent not in {0, 0.0}:
            raise ValueError("La asignación de costo sólo corresponde a un spin-off")
        if self.action_type == "RETURN_OF_CAPITAL" and self.cash_amount <= 0:
            raise ValueError("La devolución de capital requiere un importe positivo")
        if self.action_type != "RETURN_OF_CAPITAL" and self.cash_amount > 0:
            raise ValueError("El importe en efectivo sólo corresponde a una devolución de capital")
        if self.action_type == "STOCK_DIVIDEND" and self.quantity_ratio >= 10:
            raise ValueError("En dividendo en acciones, quantity_ratio representa acciones nuevas por acción existente")
        return self


class PortfolioCorporateActionUpdate(PortfolioCorporateActionCreate):
    reason: str = Field(default="Corrección de evento corporativo", max_length=240)

    @field_validator("reason")
    @classmethod
    def normalize_action_reason(cls, value: str) -> str:
        return value.strip()


class PortfolioFxConversionCreate(BaseModel):
    from_currency: str
    to_currency: str
    from_amount: float = Field(gt=0, le=1_000_000_000_000)
    exchange_rate: float | None = Field(default=None, gt=0, le=1_000_000_000)
    pricing_mode: Literal["AUTO", "MANUAL"] = "AUTO"
    fee_amount: float = Field(default=0, ge=0, le=1_000_000_000)
    fee_currency: str | None = None
    occurred_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    notes: str = Field(default="", max_length=240)
    from_fx_rate_to_base: float | None = Field(default=None, gt=0, le=1_000_000)
    to_fx_rate_to_base: float | None = Field(default=None, gt=0, le=1_000_000)

    @field_validator("from_currency", "to_currency")
    @classmethod
    def normalize_conversion_currency(cls, value: str) -> str:
        return normalize_currency(value)

    @field_validator("fee_currency")
    @classmethod
    def normalize_fee_currency(cls, value: str | None) -> str | None:
        return normalize_currency(value) if value else None

    @field_validator("pricing_mode", mode="before")
    @classmethod
    def normalize_conversion_mode(cls, value: str) -> str:
        return str(value).strip().upper()

    @field_validator("occurred_at")
    @classmethod
    def normalize_conversion_date(cls, value: datetime) -> datetime:
        if value.tzinfo is None:
            return value.replace(tzinfo=timezone.utc)
        return value.astimezone(timezone.utc)

    @field_validator("notes")
    @classmethod
    def normalize_conversion_notes(cls, value: str) -> str:
        return value.strip()

    @model_validator(mode="after")
    def validate_conversion(self):
        if self.from_currency == self.to_currency:
            raise ValueError("Las monedas de origen y destino deben ser diferentes")
        if self.pricing_mode == "MANUAL" and self.exchange_rate is None:
            raise ValueError("La conversión manual requiere indicar el tipo de cambio")
        if self.fee_amount > 0:
            if not self.fee_currency:
                self.fee_currency = self.from_currency
            if self.fee_currency not in {self.from_currency, self.to_currency}:
                raise ValueError("La comisión debe cobrarse en la moneda de origen o destino")
        return self


class PortfolioFxConversionUpdate(PortfolioFxConversionCreate):
    reason: str = Field(default="Corrección de conversión FX", max_length=240)

    @field_validator("reason")
    @classmethod
    def normalize_conversion_reason(cls, value: str) -> str:
        return value.strip()


class ManualAssetCreate(BaseModel):
    symbol: str = Field(min_length=1, max_length=40)
    name: str = Field(min_length=1, max_length=120)
    asset_type: str = Field(default="OTHER", min_length=1, max_length=40)
    currency: str = "USD"
    exchange: str = Field(default="Manual", max_length=80)
    sector: str = Field(default="", max_length=120)
    industry: str = Field(default="", max_length=160)
    current_price: float = Field(gt=0, le=1_000_000_000_000)

    @field_validator("symbol")
    @classmethod
    def normalize_manual_symbol(cls, value: str) -> str:
        return normalize_symbol(value)

    @field_validator("name", "asset_type", "exchange", "sector", "industry")
    @classmethod
    def normalize_manual_text(cls, value: str) -> str:
        return value.strip()

    @field_validator("currency")
    @classmethod
    def normalize_manual_currency(cls, value: str) -> str:
        return normalize_currency(value)


class ManualAssetPriceUpdate(BaseModel):
    current_price: float = Field(gt=0, le=1_000_000_000_000)


class CsvImportRequest(BaseModel):
    content: str = Field(min_length=1)
    filename: str = Field(default="import.csv", min_length=1, max_length=240)
    import_valid_only: bool = True
    skip_duplicates: bool = True
    adapter: str = Field(default="generic", min_length=1, max_length=40)

    @field_validator("filename", "adapter")
    @classmethod
    def normalize_import_text(cls, value: str) -> str:
        return value.strip()


class BackupCreateRequest(BaseModel):
    note: str = Field(default="", max_length=240)

    @field_validator("note")
    @classmethod
    def normalize_backup_note(cls, value: str) -> str:
        return value.strip()


class AnalyticsSettingsUpdate(BaseModel):
    benchmark_symbol: str = Field(default="SPY", min_length=1, max_length=40)
    benchmark_name: str = Field(default="S&P 500 (SPY)", max_length=120)
    risk_free_rate_percent: float = Field(default=0.0, ge=-20.0, le=100.0)

    @field_validator("benchmark_symbol")
    @classmethod
    def normalize_benchmark_symbol(cls, value: str) -> str:
        normalized = value.strip().upper()
        if normalized == "NONE":
            return normalized
        return normalize_symbol(normalized)

    @field_validator("benchmark_name")
    @classmethod
    def normalize_benchmark_name(cls, value: str) -> str:
        return value.strip()


class AIAgentQuery(BaseModel):
    message: str = Field(min_length=3, max_length=1200)
    portfolio_id: int = Field(default=1, ge=1)
    risk_profile: Literal["conservador", "moderado", "agresivo"] = "moderado"
    period: Literal["1mo", "3mo", "6mo", "1y", "2y", "5y", "max"] = "1y"
    scope: Literal["auto", "asset", "fundamental", "portfolio", "risk", "performance", "compare"] = "auto"
    symbols: list[str] = Field(default_factory=list, max_length=6)
    session_id: int | None = Field(default=None, ge=1)
    include_activity: bool = False
    use_language_model: bool | None = None

    @field_validator("message")
    @classmethod
    def normalize_agent_message(cls, value: str) -> str:
        normalized = " ".join(value.strip().split())
        if not normalized:
            raise ValueError("La consulta del agente está vacía")
        return normalized

    @field_validator("symbols")
    @classmethod
    def normalize_agent_symbols(cls, value: list[str]) -> list[str]:
        normalized: list[str] = []
        for symbol in value:
            item = normalize_symbol(symbol)
            if item not in normalized:
                normalized.append(item)
        return normalized


class AIAgentSettingsUpdate(BaseModel):
    use_language_model: bool = False
    response_style: Literal["claro", "breve", "detallado"] = "claro"

class AIAlertRuleCreate(BaseModel):
    name: str = Field(min_length=3, max_length=120)
    rule_type: Literal["CONCENTRATION", "DRAWDOWN", "VOLATILITY", "PRICE_ABOVE", "PRICE_BELOW"]
    symbol: str = Field(default="", max_length=40)
    threshold: float = Field(gt=0)
    severity: Literal["LOW", "MEDIUM", "HIGH", "CRITICAL"] = "MEDIUM"
    cooldown_hours: int = Field(default=24, ge=1, le=8760)
    is_enabled: bool = True

    @field_validator("name")
    @classmethod
    def normalize_alert_name(cls, value: str) -> str:
        return " ".join(value.strip().split())

    @field_validator("symbol")
    @classmethod
    def normalize_alert_symbol(cls, value: str) -> str:
        return normalize_symbol(value) if value.strip() else ""

    @model_validator(mode="after")
    def validate_price_symbol(self):
        if self.rule_type in {"PRICE_ABOVE", "PRICE_BELOW"} and not self.symbol:
            raise ValueError("Las alertas de precio requieren un símbolo")
        if self.rule_type not in {"PRICE_ABOVE", "PRICE_BELOW"} and self.symbol:
            raise ValueError("Esta regla se aplica al portafolio y no debe incluir símbolo")
        return self


class AIAlertRuleUpdate(AIAlertRuleCreate):
    pass


class AIAlertEventAction(BaseModel):
    status: Literal["ACKNOWLEDGED", "DISMISSED", "ACTIVE"]
    note: str = Field(default="", max_length=240)

    @field_validator("note")
    @classmethod
    def normalize_alert_note(cls, value: str) -> str:
        return " ".join(value.strip().split())
