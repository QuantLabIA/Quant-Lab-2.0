from __future__ import annotations

import math

import pandas as pd

from backend.models import AIAnalysisRequest
from backend.services.market_service import find_market_asset, get_market_history


def _calculate_rsi(closes: pd.Series, period: int = 14) -> float | None:
    if len(closes) <= period:
        return None
    delta = closes.diff()
    gains = delta.clip(lower=0).rolling(period).mean()
    losses = (-delta.clip(upper=0)).rolling(period).mean()
    last_loss = losses.iloc[-1]
    if pd.isna(last_loss):
        return None
    if last_loss == 0:
        return 100.0
    relative_strength = gains.iloc[-1] / last_loss
    return float(100 - (100 / (1 + relative_strength)))


def analyze_asset(payload: AIAnalysisRequest) -> dict:
    quote = find_market_asset(payload.symbol)
    if quote is None:
        raise ValueError(f"No se encontró el símbolo {payload.symbol}")

    history_payload = get_market_history(payload.symbol, period="6mo", interval="1d")
    closes = pd.Series([candle["close"] for candle in history_payload["candles"]], dtype="float64")
    returns = closes.pct_change().dropna()

    sma20 = float(closes.tail(20).mean()) if len(closes) >= 20 else float(closes.mean())
    sma50 = float(closes.tail(50).mean()) if len(closes) >= 50 else float(closes.mean())
    rsi = _calculate_rsi(closes)
    volatility = float(returns.std() * math.sqrt(252) * 100) if not returns.empty else 0.0
    price = float(quote["price"])

    if price > sma20 > sma50:
        trend = "alcista"
        trend_explanation = "el precio está por encima de sus medias de 20 y 50 ruedas"
    elif price < sma20 < sma50:
        trend = "bajista"
        trend_explanation = "el precio está por debajo de sus medias de 20 y 50 ruedas"
    else:
        trend = "mixta o lateral"
        trend_explanation = "las medias móviles todavía no muestran una dirección alineada"

    if rsi is None:
        momentum = "sin datos suficientes para RSI"
    elif rsi >= 70:
        momentum = "RSI en zona alta; podría existir sobrecompra"
    elif rsi <= 30:
        momentum = "RSI en zona baja; podría existir sobreventa"
    else:
        momentum = "RSI en zona neutral"

    if volatility >= 45:
        risk_level = "alto"
    elif volatility >= 25:
        risk_level = "moderado"
    else:
        risk_level = "bajo"

    profile_guidance = {
        "conservador": "priorizar tamaño de posición pequeño, diversificación y una señal más confirmada",
        "moderado": "combinar la tendencia con niveles de entrada, salida e invalidación",
        "agresivo": "mantener límites de pérdida definidos aunque tolere oscilaciones mayores",
    }[payload.risk_profile]

    return {
        "symbol": quote["symbol"],
        "name": quote["name"],
        "summary": (
            f"{quote['symbol']} presenta una lectura {trend}: {trend_explanation}. "
            f"La variación de la última referencia es {quote['change_percent']:+.2f}% y el {momentum.lower()}."
        ),
        "risk_note": (
            f"La volatilidad anualizada estimada es {volatility:.1f}%, compatible con un riesgo {risk_level}. "
            f"Para un perfil {payload.risk_profile}, conviene {profile_guidance}."
        ),
        "indicators": {
            "price": round(price, 4),
            "change_percent": round(float(quote["change_percent"]), 4),
            "sma20": round(sma20, 4),
            "sma50": round(sma50, 4),
            "rsi14": round(rsi, 2) if rsi is not None else None,
            "annualized_volatility_percent": round(volatility, 2),
            "trend": trend,
            "risk_level": risk_level,
        },
        "data": {
            "source": quote["source"],
            "last_updated": quote["last_updated"],
            "is_delayed": quote["is_delayed"],
        },
        "confidence": "análisis cuantitativo explicable",
        "disclaimer": "Contenido educativo; no constituye recomendación de compra o venta.",
    }
