from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import math
from typing import Any, Callable


FundamentalGetter = Callable[[str], dict[str, Any]]


def _number(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if math.isfinite(result) else None


def _percent(value: Any) -> float | None:
    # El contrato del servicio expresa todos los ratios porcentuales en puntos porcentuales.
    return _number(value)


def _bounded_score(value: float | None, low: float, high: float, *, reverse: bool = False) -> float | None:
    if value is None or high <= low:
        return None
    clipped = max(low, min(high, value))
    score = (clipped - low) / (high - low) * 100
    return 100 - score if reverse else score


def _average(values: list[float | None]) -> float | None:
    valid = [value for value in values if value is not None and math.isfinite(value)]
    return sum(valid) / len(valid) if valid else None


def _score_fundamentals(metrics: dict[str, Any]) -> dict[str, Any]:
    profit_margin = _percent(metrics.get("profit_margin_percent"))
    roe = _percent(metrics.get("return_on_equity_percent"))
    roa = _percent(metrics.get("return_on_assets_percent"))
    revenue_growth = _percent(metrics.get("revenue_growth_percent"))
    earnings_growth = _percent(metrics.get("earnings_growth_percent"))
    debt_to_equity = _number(metrics.get("debt_to_equity"))
    current_ratio = _number(metrics.get("current_ratio"))
    free_cash_flow = _number(metrics.get("free_cash_flow"))
    operating_cash_flow = _number(metrics.get("operating_cash_flow"))
    trailing_pe = _number(metrics.get("trailing_pe"))
    price_to_book = _number(metrics.get("price_to_book"))
    price_to_sales = _number(metrics.get("price_to_sales"))

    quality = _average([
        _bounded_score(profit_margin, -10, 30),
        _bounded_score(roe, -10, 35),
        _bounded_score(roa, -5, 20),
        80.0 if free_cash_flow is not None and free_cash_flow > 0 else 25.0 if free_cash_flow is not None else None,
    ])
    growth = _average([
        _bounded_score(revenue_growth, -20, 30),
        _bounded_score(earnings_growth, -30, 40),
    ])
    financial_strength = _average([
        _bounded_score(debt_to_equity, 0, 250, reverse=True),
        _bounded_score(current_ratio, 0.5, 2.5),
        80.0 if operating_cash_flow is not None and operating_cash_flow > 0 else 25.0 if operating_cash_flow is not None else None,
    ])
    valuation = _average([
        _bounded_score(trailing_pe, 8, 45, reverse=True),
        _bounded_score(price_to_book, 1, 12, reverse=True),
        _bounded_score(price_to_sales, 1, 15, reverse=True),
    ])
    overall = _average([quality, growth, financial_strength, valuation])

    return {
        "overall": round(overall, 1) if overall is not None else None,
        "quality": round(quality, 1) if quality is not None else None,
        "growth": round(growth, 1) if growth is not None else None,
        "financial_strength": round(financial_strength, 1) if financial_strength is not None else None,
        "valuation": round(valuation, 1) if valuation is not None else None,
        "methodology": "Puntaje educativo normalizado; no es recomendación ni valuación intrínseca.",
    }


def _assessment(metrics: dict[str, Any], scores: dict[str, Any]) -> dict[str, list[str]]:
    favorable: list[str] = []
    risks: list[str] = []
    missing: list[str] = []

    revenue_growth = _percent(metrics.get("revenue_growth_percent"))
    earnings_growth = _percent(metrics.get("earnings_growth_percent"))
    profit_margin = _percent(metrics.get("profit_margin_percent"))
    free_cash_flow = _number(metrics.get("free_cash_flow"))
    debt_to_equity = _number(metrics.get("debt_to_equity"))
    current_ratio = _number(metrics.get("current_ratio"))
    trailing_pe = _number(metrics.get("trailing_pe"))

    if revenue_growth is None:
        missing.append("crecimiento de ingresos")
    elif revenue_growth > 8:
        favorable.append(f"Los ingresos muestran crecimiento interanual aproximado de {revenue_growth:.1f}%.")
    elif revenue_growth < 0:
        risks.append(f"Los ingresos presentan contracción aproximada de {abs(revenue_growth):.1f}%.")

    if earnings_growth is None:
        missing.append("crecimiento de beneficios")
    elif earnings_growth > 10:
        favorable.append(f"Los beneficios muestran crecimiento aproximado de {earnings_growth:.1f}%.")
    elif earnings_growth < 0:
        risks.append(f"Los beneficios presentan una variación negativa aproximada de {abs(earnings_growth):.1f}%.")

    if profit_margin is None:
        missing.append("margen neto")
    elif profit_margin > 15:
        favorable.append(f"El margen neto informado es elevado ({profit_margin:.1f}%).")
    elif profit_margin < 3:
        risks.append(f"El margen neto informado es reducido ({profit_margin:.1f}%).")

    if free_cash_flow is None:
        missing.append("flujo de caja libre")
    elif free_cash_flow > 0:
        favorable.append("El flujo de caja libre informado es positivo.")
    else:
        risks.append("El flujo de caja libre informado es negativo.")

    if debt_to_equity is None:
        missing.append("deuda sobre patrimonio")
    elif debt_to_equity > 200:
        risks.append(f"La relación deuda/patrimonio es elevada ({debt_to_equity:.1f}).")
    elif debt_to_equity < 80:
        favorable.append(f"La relación deuda/patrimonio es moderada ({debt_to_equity:.1f}).")

    if current_ratio is None:
        missing.append("liquidez corriente")
    elif current_ratio < 1:
        risks.append(f"La liquidez corriente es inferior a 1 ({current_ratio:.2f}).")

    if trailing_pe is None:
        missing.append("P/E histórico")
    elif trailing_pe > 45:
        risks.append(f"El múltiplo P/E histórico es exigente ({trailing_pe:.1f}).")

    if scores.get("overall") is not None and scores["overall"] >= 70:
        favorable.append("El puntaje fundamental educativo agregado es sólido dentro de la metodología de QuantLab.")
    elif scores.get("overall") is not None and scores["overall"] < 40:
        risks.append("El puntaje fundamental educativo agregado es débil dentro de la metodología de QuantLab.")

    return {"favorable": favorable[:8], "risks": risks[:8], "missing": missing[:12]}


def analyze_fundamentals(symbol: str, getter: FundamentalGetter) -> dict[str, Any]:
    normalized = symbol.strip().upper()
    raw = getter(normalized)
    metrics = dict(raw.get("metrics") or {})
    scores = _score_fundamentals(metrics)
    assessment = _assessment(metrics, scores)
    coverage = raw.get("coverage") or {}
    available = int(coverage.get("available_fields") or sum(value is not None for value in metrics.values()))
    total = int(coverage.get("total_fields") or max(1, len(metrics)))
    coverage_percent = round(available / total * 100, 1) if total else 0.0
    return {
        **raw,
        "symbol": normalized,
        "scores": scores,
        "assessment": assessment,
        "coverage": {
            **coverage,
            "available_fields": available,
            "total_fields": total,
            "coverage_percent": coverage_percent,
            "status": "complete" if coverage_percent >= 75 else "partial" if coverage_percent > 0 else "unavailable",
        },
        "methodology": {
            "scope": "Fundamentales declarados por el proveedor y cálculos derivados simples.",
            "limitations": [
                "Las definiciones contables pueden variar entre empresas, mercados y proveedores.",
                "Los múltiplos no sustituyen una valuación por flujos descontados ni análisis cualitativo.",
                "La ausencia de un dato se informa; QuantLab no lo estima silenciosamente.",
            ],
        },
        "last_updated": raw.get("last_updated") or datetime.now(timezone.utc).isoformat(),
    }


def compare_fundamentals(symbols: list[str], getter: FundamentalGetter) -> dict[str, Any]:
    normalized: list[str] = []
    for symbol in symbols:
        item = symbol.strip().upper()
        if item and item not in normalized:
            normalized.append(item)
    if len(normalized) < 2:
        raise ValueError("Indicá al menos dos símbolos para comparar fundamentales")
    if len(normalized) > 6:
        raise ValueError("Se pueden comparar hasta seis símbolos")

    assets: list[dict[str, Any]] = []
    errors: list[dict[str, str]] = []
    for symbol in normalized:
        try:
            assets.append(analyze_fundamentals(symbol, getter))
        except Exception as exc:
            errors.append({"symbol": symbol, "error": str(exc)})
    if not assets:
        raise ValueError("No se pudieron obtener fundamentales de los símbolos solicitados")

    def leader(metric: str, *, lowest: bool = False) -> dict[str, Any] | None:
        valid = [asset for asset in assets if _number((asset.get("metrics") or {}).get(metric)) is not None]
        if not valid:
            return None
        key = lambda asset: float((asset.get("metrics") or {}).get(metric))
        chosen = min(valid, key=key) if lowest else max(valid, key=key)
        return {"symbol": chosen["symbol"], "value": (chosen.get("metrics") or {}).get(metric)}

    valid_scores = [asset for asset in assets if _number((asset.get("scores") or {}).get("overall")) is not None]
    best_score = max(valid_scores, key=lambda asset: float(asset["scores"]["overall"])) if valid_scores else None
    return {
        "symbols": normalized,
        "assets": assets,
        "leaders": {
            "overall_score": {"symbol": best_score["symbol"], "value": best_score["scores"]["overall"]} if best_score else None,
            "revenue_growth": leader("revenue_growth_percent"),
            "profit_margin": leader("profit_margin_percent"),
            "lower_trailing_pe": leader("trailing_pe", lowest=True),
            "lower_debt_to_equity": leader("debt_to_equity", lowest=True),
        },
        "errors": errors,
        "is_partial": bool(errors) or any((asset.get("coverage") or {}).get("status") != "complete" for asset in assets),
        "source": "Yahoo Finance vía yfinance; procesamiento interno de QuantLab AI",
        "last_updated": datetime.now(timezone.utc).isoformat(),
    }
