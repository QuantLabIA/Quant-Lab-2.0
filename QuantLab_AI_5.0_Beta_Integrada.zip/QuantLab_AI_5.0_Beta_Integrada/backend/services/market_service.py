from __future__ import annotations

from datetime import date, datetime

from backend.providers.base import MarketDataError
from backend.providers.registry import get_market_provider
from backend.providers.yahoo_finance import (
    ALLOWED_INTERVALS,
    ALLOWED_PERIODS,
    FEATURED_ASSETS,
)


def list_market_assets() -> list[dict]:
    return get_market_provider().list_assets()


def search_market_assets(query: str, limit: int = 12) -> list[dict]:
    return get_market_provider().search_assets(query, limit)


def find_market_asset(symbol: str) -> dict | None:
    return get_market_provider().get_quote(symbol)


def get_market_history(symbol: str, period: str = "1mo", interval: str = "1d") -> dict:
    return get_market_provider().get_history(symbol, period, interval)


def get_fx_rate(from_currency: str, to_currency: str, occurred_at: datetime | date | None = None) -> dict:
    return get_market_provider().get_fx_rate(from_currency, to_currency, occurred_at)


def get_fx_history(from_currency: str, to_currency: str, period: str = "1y") -> dict:
    return get_market_provider().get_fx_history(from_currency, to_currency, period)


def get_dividend_history(symbol: str, period: str = "5y") -> dict:
    return get_market_provider().get_dividends(symbol, period)


def get_fundamental_data(symbol: str) -> dict:
    return get_market_provider().get_fundamentals(symbol)


def market_provider_status() -> dict:
    return get_market_provider().status()
