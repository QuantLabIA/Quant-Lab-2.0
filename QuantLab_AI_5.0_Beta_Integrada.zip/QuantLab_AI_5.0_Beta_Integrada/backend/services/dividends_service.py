from __future__ import annotations

from collections import defaultdict
from collections.abc import Callable
from datetime import date, datetime, timedelta, timezone
import math
import statistics
from typing import Any

from backend.core.database import get_connection
from backend.models import (
    PortfolioDividendCreate,
    PortfolioDividendImportOptions,
    PortfolioDividendSettingsUpdate,
)
from backend.services.portfolio_service import (
    EPSILON,
    PortfolioValidationError,
    _active_corporate_actions,
    _calculate_for_portfolio,
    _load_fx_rate,
    _parse_datetime,
    _serialize_cash_movement,
    _serialize_transaction,
    _write_audit,
    get_portfolio_asset,
    get_portfolio_overview,
    get_portfolio_settings,
    list_cash_movements,
    list_fx_conversions,
    list_portfolio_transactions,
)


def _round(value: float | int | None, digits: int = 6) -> float | None:
    if value is None:
        return None
    number = float(value)
    return round(number, digits) if math.isfinite(number) else None


def _dividend_columns() -> str:
    return """
        id, portfolio_id, movement_type, amount, currency, fx_rate_to_base,
        symbol, occurred_at, notes, created_at, updated_at, revision,
        is_deleted, deleted_at, deleted_reason,
        gross_amount, withholding_tax, withholding_percent,
        dividend_per_share, shares_held, dividend_source, reinvested,
        reinvest_transaction_id, ex_dividend_date
    """


def _serialize_dividend(row: Any) -> dict:
    item = _serialize_cash_movement(row)
    gross = float(item.get("gross_amount") if item.get("gross_amount") is not None else item["amount"])
    tax = float(item.get("withholding_tax") or 0.0)
    item["gross_amount"] = _round(gross)
    item["withholding_tax"] = _round(tax)
    item["net_amount"] = _round(item["amount"])
    item["withholding_percent"] = _round(
        float(item.get("withholding_percent") or (tax / gross * 100.0 if gross > EPSILON else 0.0))
    )
    item["dividend_per_share"] = _round(item.get("dividend_per_share"))
    item["shares_held"] = _round(item.get("shares_held"))
    item["dividend_source"] = str(item.get("dividend_source") or "MANUAL")
    item["reinvested"] = bool(item.get("reinvested", 0))
    item["reinvest_transaction_id"] = (
        int(item["reinvest_transaction_id"]) if item.get("reinvest_transaction_id") else None
    )
    item["gross_amount_base"] = _round(gross * item["fx_rate_to_base"])
    item["withholding_tax_base"] = _round(tax * item["fx_rate_to_base"])
    item["net_amount_base"] = _round(item["amount"] * item["fx_rate_to_base"])
    return item


def list_dividends(portfolio_id: int = 1, *, include_deleted: bool = False) -> list[dict]:
    get_portfolio_settings(portfolio_id)
    deleted_clause = "" if include_deleted else " AND is_deleted = 0"
    with get_connection() as connection:
        rows = connection.execute(
            f"""
            SELECT {_dividend_columns()}
            FROM portfolio_cash_movements
            WHERE portfolio_id = ? AND movement_type = 'DIVIDEND'{deleted_clause}
            ORDER BY occurred_at DESC, id DESC
            """,
            (portfolio_id,),
        ).fetchall()
    return [_serialize_dividend(row) for row in rows]


def get_dividend_settings(portfolio_id: int = 1) -> dict:
    get_portfolio_settings(portfolio_id)
    with get_connection() as connection:
        connection.execute(
            """
            INSERT OR IGNORE INTO portfolio_dividend_settings
                (portfolio_id, default_withholding_percent, default_reinvest, forecast_months)
            VALUES (?, 0, 0, 12)
            """,
            (portfolio_id,),
        )
        row = connection.execute(
            """
            SELECT portfolio_id, default_withholding_percent, default_reinvest,
                   forecast_months, created_at, updated_at
            FROM portfolio_dividend_settings WHERE portfolio_id = ?
            """,
            (portfolio_id,),
        ).fetchone()
    if row is None:
        raise PortfolioValidationError("No se pudo cargar la configuración de dividendos")
    item = dict(row)
    item["default_withholding_percent"] = float(item["default_withholding_percent"])
    item["default_reinvest"] = bool(item["default_reinvest"])
    item["forecast_months"] = int(item["forecast_months"])
    return item


def update_dividend_settings(payload: PortfolioDividendSettingsUpdate, portfolio_id: int = 1) -> dict:
    get_portfolio_settings(portfolio_id)
    with get_connection() as connection:
        connection.execute(
            """
            INSERT INTO portfolio_dividend_settings
                (portfolio_id, default_withholding_percent, default_reinvest, forecast_months, updated_at)
            VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
            ON CONFLICT(portfolio_id) DO UPDATE SET
                default_withholding_percent = excluded.default_withholding_percent,
                default_reinvest = excluded.default_reinvest,
                forecast_months = excluded.forecast_months,
                updated_at = CURRENT_TIMESTAMP
            """,
            (
                portfolio_id,
                payload.default_withholding_percent,
                int(payload.default_reinvest),
                payload.forecast_months,
            ),
        )
    return get_dividend_settings(portfolio_id)


def historical_quantity(symbol: str, occurred_at: datetime, portfolio_id: int = 1) -> float:
    """Reconstruct holdings at a date, including corporate actions.

    This prevents splits, ticker changes, mergers, spin-offs and stock dividends
    from producing an incorrect share count when a historical dividend is loaded.
    """
    cutoff = _parse_datetime(occurred_at)
    settings = get_portfolio_settings(portfolio_id)
    transactions = [
        item for item in list_portfolio_transactions(ascending=True, portfolio_id=portfolio_id)
        if _parse_datetime(item["occurred_at"]) <= cutoff
    ]
    movements = [
        item for item in list_cash_movements(ascending=True, portfolio_id=portfolio_id)
        if _parse_datetime(item["occurred_at"]) <= cutoff
    ]
    conversions = [
        item for item in list_fx_conversions(ascending=True, portfolio_id=portfolio_id)
        if _parse_datetime(item["occurred_at"]) <= cutoff
    ]
    actions = [
        item for item in _active_corporate_actions(portfolio_id)
        if _parse_datetime(item["occurred_at"]) <= cutoff
    ]
    ledger = _calculate_for_portfolio(
        settings, transactions, movements, conversions, actions
    )
    state = ledger["states"].get(symbol.upper()) or {}
    return max(float(state.get("quantity") or 0.0), 0.0)


def _tax_values(payload: PortfolioDividendCreate) -> tuple[float, float, float]:
    gross = float(payload.gross_amount)
    if payload.withholding_tax is not None:
        tax = float(payload.withholding_tax)
    else:
        tax = gross * float(payload.withholding_percent or 0.0) / 100.0
    tax = min(max(tax, 0.0), gross)
    net = gross - tax
    percent = tax / gross * 100.0 if gross > EPSILON else 0.0
    return gross, tax, net if net > EPSILON else 0.0


def create_dividend(
    payload: PortfolioDividendCreate,
    fx_loader: Callable[[str, str, datetime | date | None], dict] | None = None,
    portfolio_id: int = 1,
) -> dict:
    settings = get_portfolio_settings(portfolio_id)
    if payload.occurred_at > datetime.now(timezone.utc).replace(microsecond=0):
        raise PortfolioValidationError("La fecha del dividendo no puede estar en el futuro")
    asset = get_portfolio_asset(payload.symbol, portfolio_id)
    if asset is None:
        raise PortfolioValidationError("Primero registrá una operación del activo en este portafolio")
    if str(asset["currency"]).upper() != payload.currency:
        raise PortfolioValidationError(
            f"El activo {payload.symbol} está registrado en {asset['currency']}; el dividendo usa {payload.currency}."
        )

    gross, tax, net = _tax_values(payload)
    if net <= EPSILON:
        raise PortfolioValidationError("El dividendo neto debe ser mayor que cero")
    shares = float(payload.shares_held or historical_quantity(payload.symbol, payload.occurred_at, portfolio_id))
    if shares <= EPSILON:
        raise PortfolioValidationError("No había tenencia del activo en la fecha del dividendo")
    per_share = float(payload.dividend_per_share or (gross / shares))
    fx_rate = _load_fx_rate(
        payload.currency,
        settings["base_currency"],
        payload.occurred_at,
        payload.fx_rate_to_base,
        fx_loader,
    )

    transactions = list_portfolio_transactions(ascending=True, portfolio_id=portfolio_id)
    movements = list_cash_movements(ascending=True, portfolio_id=portfolio_id)
    conversions = list_fx_conversions(ascending=True, portfolio_id=portfolio_id)
    proposed_dividend = {
        "id": max((int(item["id"]) for item in movements), default=0) + 1,
        "portfolio_id": portfolio_id,
        "movement_type": "DIVIDEND",
        "amount": net,
        "currency": payload.currency,
        "fx_rate_to_base": fx_rate,
        "symbol": payload.symbol,
        "occurred_at": payload.occurred_at.isoformat(),
        "notes": payload.notes,
    }
    proposed_transactions = list(transactions)
    reinvest_quantity = 0.0
    if payload.reinvest:
        assert payload.reinvest_price is not None
        if payload.reinvest_fees >= net:
            raise PortfolioValidationError("Las comisiones de reinversión consumen todo el dividendo neto")
        reinvest_quantity = (net - float(payload.reinvest_fees)) / float(payload.reinvest_price)
        proposed_transactions.append(
            {
                "id": max((int(item["id"]) for item in transactions), default=0) + 1,
                "portfolio_id": portfolio_id,
                "symbol": payload.symbol,
                "transaction_type": "BUY",
                "quantity": reinvest_quantity,
                "price": float(payload.reinvest_price),
                "fees": float(payload.reinvest_fees),
                "asset_name": asset["name"],
                "asset_type": asset["asset_type"],
                "asset_currency": asset["currency"],
                "exchange": asset["exchange"],
                "pricing_mode": asset["pricing_mode"],
                "fx_rate_to_base": fx_rate,
                "occurred_at": payload.occurred_at.isoformat(),
                "notes": f"Reinversión de dividendo · {payload.notes}".strip(" ·"),
            }
        )

    _calculate_for_portfolio(
        settings,
        proposed_transactions,
        [*movements, proposed_dividend],
        conversions,
    )

    with get_connection() as connection:
        cursor = connection.execute(
            """
            INSERT INTO portfolio_cash_movements
                (portfolio_id, movement_type, amount, currency, fx_rate_to_base, symbol,
                 occurred_at, notes, gross_amount, withholding_tax, withholding_percent,
                 dividend_per_share, shares_held, dividend_source, reinvested,
                 ex_dividend_date, updated_at, revision, is_deleted)
            VALUES (?, 'DIVIDEND', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, 1, 0)
            """,
            (
                portfolio_id,
                net,
                payload.currency,
                fx_rate,
                payload.symbol,
                payload.occurred_at.isoformat(),
                payload.notes,
                gross,
                tax,
                tax / gross * 100.0 if gross > EPSILON else 0.0,
                per_share,
                shares,
                payload.source,
                int(payload.reinvest),
                payload.ex_dividend_date.isoformat() if payload.ex_dividend_date else None,
            ),
        )
        movement_id = int(cursor.lastrowid)
        reinvest_transaction_id = None
        if payload.reinvest:
            reinvest = proposed_transactions[-1]
            tx_cursor = connection.execute(
                """
                INSERT INTO portfolio_transactions
                    (portfolio_id, symbol, transaction_type, quantity, price, fees,
                     asset_name, asset_type, asset_currency, exchange, pricing_mode,
                     fx_rate_to_base, occurred_at, notes, updated_at, revision, is_deleted)
                VALUES (?, ?, 'BUY', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, 1, 0)
                """,
                (
                    portfolio_id,
                    payload.symbol,
                    reinvest_quantity,
                    payload.reinvest_price,
                    payload.reinvest_fees,
                    asset["name"],
                    asset["asset_type"],
                    asset["currency"],
                    asset["exchange"],
                    asset["pricing_mode"],
                    fx_rate,
                    payload.occurred_at.isoformat(),
                    reinvest["notes"],
                ),
            )
            reinvest_transaction_id = int(tx_cursor.lastrowid)
            connection.execute(
                "UPDATE portfolio_cash_movements SET reinvest_transaction_id = ? WHERE id = ?",
                (reinvest_transaction_id, movement_id),
            )
            tx_row = connection.execute(
                """
                SELECT id, portfolio_id, symbol, transaction_type, quantity, price, fees,
                       asset_name, asset_type, asset_currency, exchange, pricing_mode,
                       fx_rate_to_base, occurred_at, notes, created_at, updated_at,
                       revision, is_deleted, deleted_at, deleted_reason
                FROM portfolio_transactions WHERE id = ?
                """,
                (reinvest_transaction_id,),
            ).fetchone()
            _write_audit(
                connection,
                portfolio_id,
                "transaction",
                reinvest_transaction_id,
                "CREATE",
                after=_serialize_transaction(tx_row),
                reason="Reinversión automática de dividendo",
            )

        row = connection.execute(
            f"SELECT {_dividend_columns()} FROM portfolio_cash_movements WHERE id = ?",
            (movement_id,),
        ).fetchone()
        created = _serialize_dividend(row)
        _write_audit(
            connection,
            portfolio_id,
            "cash_movement",
            movement_id,
            "CREATE",
            after=created,
            reason="Dividendo avanzado registrado",
        )
    created["reinvest_transaction_id"] = reinvest_transaction_id
    created["reinvest_quantity"] = _round(reinvest_quantity)
    return created


def _historical_close(history: dict, event_date: date) -> float | None:
    candidates: list[tuple[int, float]] = []
    for candle in history.get("candles", []):
        try:
            day = _parse_datetime(str(candle["date"])).date()
            price = float(candle["close"])
        except (KeyError, TypeError, ValueError):
            continue
        distance = abs((day - event_date).days)
        if distance <= 7 and price > 0:
            candidates.append((distance, price))
    return min(candidates, default=(0, None), key=lambda item: item[0])[1]


def import_dividends(
    symbol: str,
    period: str,
    options: PortfolioDividendImportOptions,
    dividend_loader: Callable[[str, str], dict],
    history_loader: Callable[[str, str, str], dict] | None,
    fx_loader: Callable[[str, str, datetime | date | None], dict] | None,
    portfolio_id: int = 1,
) -> dict:
    asset = get_portfolio_asset(symbol, portfolio_id)
    if asset is None:
        raise PortfolioValidationError("Primero registrá una operación del activo")
    if asset["pricing_mode"] != "AUTO":
        raise PortfolioValidationError("La importación automática requiere un activo de mercado")
    try:
        source = dividend_loader(symbol, period)
    except Exception as exc:
        raise PortfolioValidationError(f"No se pudieron consultar dividendos: {exc}") from exc

    events = sorted(source.get("events", []), key=lambda item: str(item.get("date") or ""))
    existing_notes = {
        str(item.get("notes") or "")
        for item in list_dividends(portfolio_id)
        if item.get("symbol") == symbol
    }
    history = None
    if options.reinvest and history_loader is not None:
        try:
            history = history_loader(symbol, period, "1d")
        except Exception:
            history = None

    imported: list[dict] = []
    skipped = 0
    errors: list[dict] = []
    for event in events:
        event_at = _parse_datetime(str(event["date"]))
        marker = f"AUTO_DIVIDEND:{symbol}:{event_at.date().isoformat()}"
        if any(marker in note for note in existing_notes):
            skipped += 1
            continue
        shares = historical_quantity(symbol, event_at, portfolio_id)
        per_share = float(event.get("amount_per_unit") or 0.0)
        gross = shares * per_share
        if shares <= EPSILON or gross <= EPSILON:
            skipped += 1
            continue
        reinvest_price = _historical_close(history or {}, event_at.date()) if options.reinvest else None
        if options.reinvest and reinvest_price is None:
            errors.append({"date": event_at.date().isoformat(), "error": "Sin cierre histórico para reinvertir"})
            skipped += 1
            continue
        try:
            imported.append(
                create_dividend(
                    PortfolioDividendCreate(
                        symbol=symbol,
                        gross_amount=gross,
                        currency=asset["currency"],
                        withholding_percent=options.withholding_percent,
                        dividend_per_share=per_share,
                        shares_held=shares,
                        occurred_at=event_at,
                        ex_dividend_date=event_at,
                        notes=f"Importado desde yfinance · {per_share:.8g} por unidad · {marker}",
                        source="YFINANCE",
                        reinvest=options.reinvest,
                        reinvest_price=reinvest_price,
                        reinvest_fees=options.reinvest_fees,
                    ),
                    fx_loader,
                    portfolio_id,
                )
            )
            existing_notes.add(marker)
        except Exception as exc:
            errors.append({"date": event_at.date().isoformat(), "error": str(exc)})

    return {
        "portfolio_id": portfolio_id,
        "symbol": symbol,
        "period": period,
        "imported_count": len(imported),
        "skipped_count": skipped,
        "error_count": len(errors),
        "errors": errors,
        "movements": imported,
        "withholding_percent": options.withholding_percent,
        "reinvested": options.reinvest,
        "source": source.get("source") or "Yahoo Finance vía yfinance",
    }


def _forecast_events(dividends: list[dict], months: int) -> list[dict]:
    today = datetime.now(timezone.utc).date()
    horizon = today + timedelta(days=int(months * 30.4375))
    grouped: dict[str, list[dict]] = defaultdict(list)
    for item in dividends:
        if item.get("symbol"):
            grouped[str(item["symbol"])].append(item)
    forecasts: list[dict] = []
    for symbol, rows in grouped.items():
        ordered = sorted(rows, key=lambda item: str(item["occurred_at"]))
        dates = [_parse_datetime(item["occurred_at"]).date() for item in ordered]
        intervals = [(dates[i] - dates[i - 1]).days for i in range(1, len(dates)) if (dates[i] - dates[i - 1]).days > 14]
        interval = int(statistics.median(intervals[-8:])) if intervals else 365
        interval = min(max(interval, 30), 370)
        recent = ordered[-min(len(ordered), 4):]
        per_share_values = [float(item.get("dividend_per_share") or 0.0) for item in recent if float(item.get("dividend_per_share") or 0.0) > 0]
        gross_values = [float(item.get("gross_amount") or 0.0) for item in recent]
        estimate_per_share = statistics.mean(per_share_values) if per_share_values else None
        estimate_gross = statistics.mean(gross_values) if gross_values else 0.0
        next_date = dates[-1] + timedelta(days=interval)
        count = 0
        while next_date <= horizon and count < 24:
            if next_date >= today:
                forecasts.append({
                    "symbol": symbol,
                    "date": next_date.isoformat(),
                    "estimated_gross_amount": _round(estimate_gross),
                    "estimated_dividend_per_share": _round(estimate_per_share),
                    "currency": ordered[-1]["currency"],
                    "confidence": "medium" if len(dates) >= 4 else "low",
                    "basis": f"Frecuencia histórica aproximada de {interval} días",
                    "is_estimate": True,
                })
            next_date += timedelta(days=interval)
            count += 1
    return sorted(forecasts, key=lambda item: (item["date"], item["symbol"]))


def dividend_summary(
    quote_loader: Callable[[str], dict | None] | None,
    fx_loader: Callable[[str, str, datetime | date | None], dict] | None,
    portfolio_id: int = 1,
) -> dict:
    settings = get_dividend_settings(portfolio_id)
    dividends = list_dividends(portfolio_id)
    overview = get_portfolio_overview(quote_loader, fx_loader, portfolio_id)
    today = datetime.now(timezone.utc).date()
    trailing_start = today - timedelta(days=365)

    by_symbol: dict[str, dict[str, Any]] = {}
    monthly: dict[str, dict[str, float]] = defaultdict(lambda: {"gross": 0.0, "tax": 0.0, "net": 0.0})
    totals = {"gross": 0.0, "tax": 0.0, "net": 0.0, "trailing_12m_net": 0.0, "reinvested_net": 0.0}
    for item in dividends:
        gross_base = float(item["gross_amount_base"] or 0.0)
        tax_base = float(item["withholding_tax_base"] or 0.0)
        net_base = float(item["net_amount_base"] or 0.0)
        totals["gross"] += gross_base
        totals["tax"] += tax_base
        totals["net"] += net_base
        occurred = _parse_datetime(item["occurred_at"]).date()
        if occurred >= trailing_start:
            totals["trailing_12m_net"] += net_base
        if item["reinvested"]:
            totals["reinvested_net"] += net_base
        month = occurred.strftime("%Y-%m")
        monthly[month]["gross"] += gross_base
        monthly[month]["tax"] += tax_base
        monthly[month]["net"] += net_base
        symbol = str(item.get("symbol") or "SIN-ACTIVO")
        row = by_symbol.setdefault(symbol, {
            "symbol": symbol,
            "currency": item["currency"],
            "gross": 0.0,
            "tax": 0.0,
            "net": 0.0,
            "events": 0,
            "reinvested_events": 0,
        })
        row["gross"] += gross_base
        row["tax"] += tax_base
        row["net"] += net_base
        row["events"] += 1
        row["reinvested_events"] += int(item["reinvested"])

    holdings = {str(item["symbol"]): item for item in overview.get("holdings", [])}
    symbol_rows = []
    for symbol, row in by_symbol.items():
        holding = holdings.get(symbol, {})
        cost_basis = float(holding.get("cost_basis") or 0.0)
        market_value = float(holding.get("market_value") or 0.0)
        row.update({
            "gross": _round(row["gross"]),
            "tax": _round(row["tax"]),
            "net": _round(row["net"]),
            "yield_on_cost_percent": _round(row["net"] / cost_basis * 100.0) if cost_basis > EPSILON else None,
            "yield_on_market_value_percent": _round(row["net"] / market_value * 100.0) if market_value > EPSILON else None,
        })
        symbol_rows.append(row)

    forecasts = _forecast_events(dividends, settings["forecast_months"])
    return {
        "portfolio_id": portfolio_id,
        "currency": overview["settings"]["base_currency"],
        "settings": settings,
        "totals": {key: _round(value) for key, value in totals.items()},
        "effective_withholding_percent": _round(totals["tax"] / totals["gross"] * 100.0) if totals["gross"] > EPSILON else 0.0,
        "events_count": len(dividends),
        "by_symbol": sorted(symbol_rows, key=lambda item: float(item["net"] or 0.0), reverse=True),
        "monthly": [
            {"month": month, **{key: _round(value) for key, value in values.items()}}
            for month, values in sorted(monthly.items())
        ],
        "history": dividends,
        "forecast": forecasts,
        "forecast_disclaimer": "Las fechas e importes futuros son estimaciones basadas únicamente en el historial registrado; no son anuncios confirmados.",
        "last_updated": datetime.now(timezone.utc).isoformat(),
    }


def asset_price_fx_attribution(overview: dict, portfolio_id: int = 1) -> dict:
    transactions = list_portfolio_transactions(ascending=True, portfolio_id=portfolio_id)
    holding_by_symbol = {str(item["symbol"]): item for item in overview.get("holdings", [])}
    states: dict[str, dict[str, float]] = defaultdict(lambda: {"quantity": 0.0, "local_cost": 0.0, "base_cost": 0.0})
    for tx in transactions:
        symbol = str(tx["symbol"])
        state = states[symbol]
        quantity = float(tx["quantity"])
        price = float(tx["price"])
        fees = float(tx.get("fees") or 0.0)
        fx = float(tx.get("fx_rate_to_base") or 1.0)
        if tx["transaction_type"] == "BUY":
            local = quantity * price + fees
            state["quantity"] += quantity
            state["local_cost"] += local
            state["base_cost"] += local * fx
        elif state["quantity"] > EPSILON:
            ratio = min(quantity / state["quantity"], 1.0)
            state["quantity"] -= quantity
            state["local_cost"] *= 1.0 - ratio
            state["base_cost"] *= 1.0 - ratio

    rows = []
    totals = {"price_effect": 0.0, "fx_effect": 0.0, "open_unrealized": 0.0}
    for symbol, holding in holding_by_symbol.items():
        state = states.get(symbol, {})
        quantity = float(holding.get("quantity") or 0.0)
        local_cost = float(state.get("local_cost") or 0.0)
        base_cost = float(holding.get("cost_basis") or state.get("base_cost") or 0.0)
        current_price = float(holding.get("current_price") or 0.0)
        current_fx = float(holding.get("current_fx_rate_to_base") or holding.get("fx_rate_to_base") or 1.0)
        current_local_value = quantity * current_price
        average_acquisition_fx = base_cost / local_cost if local_cost > EPSILON else current_fx
        price_effect = (current_local_value - local_cost) * average_acquisition_fx
        fx_effect = current_local_value * (current_fx - average_acquisition_fx)
        unrealized = float(holding.get("unrealized_pnl") or 0.0)
        reconciliation = unrealized - price_effect - fx_effect
        totals["price_effect"] += price_effect
        totals["fx_effect"] += fx_effect + reconciliation
        totals["open_unrealized"] += unrealized
        rows.append({
            "symbol": symbol,
            "currency": holding.get("currency"),
            "price_effect_base": _round(price_effect),
            "fx_effect_base": _round(fx_effect + reconciliation),
            "unrealized_pnl_base": _round(unrealized),
            "average_acquisition_fx": _round(average_acquisition_fx),
            "current_fx": _round(current_fx),
            "method": "Costo local remanente × FX promedio de adquisición; diferencia reconciliada contra P&L no realizado",
        })
    return {
        "totals": {key: _round(value) for key, value in totals.items()},
        "positions": sorted(rows, key=lambda item: abs(float(item["unrealized_pnl_base"] or 0.0)), reverse=True),
        "scope": "Posiciones abiertas; el resultado realizado histórico continúa informado de forma combinada.",
    }
