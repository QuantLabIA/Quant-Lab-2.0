import sqlite3

from backend.core.database import get_connection
from backend.models import WatchlistCreate


def list_items() -> list[dict]:
    with get_connection() as connection:
        rows = connection.execute(
            "SELECT id, symbol, name, created_at FROM watchlist ORDER BY created_at DESC"
        ).fetchall()
    return [dict(row) for row in rows]


def create_item(payload: WatchlistCreate) -> dict:
    try:
        with get_connection() as connection:
            cursor = connection.execute(
                "INSERT INTO watchlist (symbol, name) VALUES (?, ?)",
                (payload.symbol, payload.name),
            )
            row = connection.execute(
                "SELECT id, symbol, name, created_at FROM watchlist WHERE id = ?",
                (cursor.lastrowid,),
            ).fetchone()
    except sqlite3.IntegrityError as exc:
        raise ValueError("El activo ya está en la watchlist") from exc
    return dict(row)


def delete_item(item_id: int) -> bool:
    with get_connection() as connection:
        cursor = connection.execute("DELETE FROM watchlist WHERE id = ?", (item_id,))
    return cursor.rowcount > 0
