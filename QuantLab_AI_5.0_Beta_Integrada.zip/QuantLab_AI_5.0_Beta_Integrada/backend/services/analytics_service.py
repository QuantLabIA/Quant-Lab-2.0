from __future__ import annotations

from collections import defaultdict
from collections.abc import Callable
from datetime import date, datetime, timedelta, timezone
import math
from typing import Any

import numpy as np
import pandas as pd

from backend.core.database import get_connection
from backend.models import AnalyticsSettingsUpdate
from backend.services.dividends_service import asset_price_fx_attribution, list_dividends
from backend.services.advanced_analytics_service import (
    aggregate_sector_industry,
    analytics_csv_report,
    build_asset_return_matrix,
    build_risk_summary,
    calculate_benchmark_relationship,
    calculate_covariance_risk,
    calculate_downside_and_tail_risk,
    compare_assets as compare_market_assets,
)
from backend.services.portfolio_service import (
    EPSILON,
    PortfolioValidationError,
    get_equity_curve,
    get_portfolio_overview,
    get_portfolio_settings,
)


SUPPORTED_ANALYTICS_PERIODS = {"1mo", "3mo", "6mo", "1y", "2y", "5y", "max"}
DEFAULT_BENCHMARK_SYMBOL = "SPY"
DEFAULT_BENCHMARK_NAME = "S&P 500 (SPY)"
TRADING_DAYS = 252
PERIOD_DAYS = {
    "1mo": 31,
    "3mo": 92,
    "6mo": 183,
    "1y": 366,
    "2y": 731,
    "5y": 1827,
}


def _round(value: float | int | None, digits: int = 6) -> float | None:
    if value is None:
        return None
    number = float(value)
    if not math.isfinite(number):
        return None
    return round(number, digits)


def _as_utc_date(value: Any) -> date:
    parsed = pd.Timestamp(value)
    if parsed.tzinfo is None:
        parsed = parsed.tz_localize("UTC")
    else:
        parsed = parsed.tz_convert("UTC")
    return parsed.date()


def _prepare_curve(points: list[dict]) -> pd.DataFrame:
    if not points:
        return pd.DataFrame(columns=["equity", "external_flow", "daily_return", "wealth_index", "drawdown"])

    frame = pd.DataFrame(points).copy()
    if "date" not in frame or "equity" not in frame:
        raise PortfolioValidationError("La curva patrimonial no contiene fecha y patrimonio")

    frame["date"] = pd.to_datetime(frame["date"], utc=True, errors="coerce").dt.normalize()
    frame["equity"] = pd.to_numeric(frame["equity"], errors="coerce")
    frame["external_flow"] = pd.to_numeric(frame.get("external_flow", 0.0), errors="coerce").fillna(0.0)
    frame = frame.dropna(subset=["date", "equity"]).sort_values("date")
    if frame.empty:
        return pd.DataFrame(columns=["equity", "external_flow", "daily_return", "wealth_index", "drawdown"])

    # Si dos eventos caen el mismo día, se conserva la última valuación y se suman los flujos externos.
    frame = frame.groupby("date", as_index=False).agg({"equity": "last", "external_flow": "sum"})
    frame = frame.set_index("date")

    previous_equity = frame["equity"].shift(1)
    daily_return = (frame["equity"] - frame["external_flow"]) / previous_equity - 1.0
    daily_return = daily_return.where(previous_equity > EPSILON)
    if not daily_return.empty:
        daily_return.iloc[0] = 0.0
    frame["daily_return"] = daily_return.replace([np.inf, -np.inf], np.nan).fillna(0.0)
    frame["wealth_index"] = (1.0 + frame["daily_return"]).cumprod()
    running_peak = frame["wealth_index"].cummax()
    frame["drawdown"] = frame["wealth_index"] / running_peak - 1.0
    return frame


def _linked_return(returns: pd.Series) -> float:
    if returns.empty:
        return 0.0
    return float((1.0 + returns.fillna(0.0)).prod() - 1.0)


def _return_since(frame: pd.DataFrame, start: date) -> float:
    if frame.empty:
        return 0.0
    mask = frame.index.date >= start
    return _linked_return(frame.loc[mask, "daily_return"])


def _filter_curve_points(points: list[dict], period: str) -> list[dict]:
    """Limit analytics to the requested horizon without changing the ledger.

    ``get_equity_curve`` intentionally includes old event dates so the ledger can be
    reconstructed correctly. Analytics, however, must begin at the selected horizon.
    The first retained observation becomes the neutral base (return 0) and subsequent
    cash flows remain available for TWR adjustment.
    """
    if period == "max" or not points:
        return points
    days = PERIOD_DAYS.get(period)
    if days is None:
        return points
    cutoff = datetime.now(timezone.utc).date() - timedelta(days=days)
    filtered = [point for point in points if _as_utc_date(point.get("date")) >= cutoff]
    if filtered:
        return filtered
    return [points[-1]]


def calculate_performance_metrics(points: list[dict], risk_free_rate_percent: float = 0.0) -> dict:
    frame = _prepare_curve(points)
    if frame.empty:
        return {
            "period_returns": {},
            "annualized_return_percent": 0.0,
            "annualized_volatility_percent": 0.0,
            "sharpe_ratio": None,
            "max_drawdown_percent": 0.0,
            "current_drawdown_percent": 0.0,
            "best_day_percent": None,
            "worst_day_percent": None,
            "observations": 0,
            "start_date": None,
            "end_date": None,
            "series": [],
        }

    last_date = frame.index[-1].date()
    first_date = frame.index[0].date()
    daily = frame["daily_return"].iloc[1:]
    total_return = _linked_return(frame["daily_return"])
    elapsed_days = max((last_date - first_date).days, 1)
    annualized_return = (
        (1.0 + total_return) ** (365.0 / elapsed_days) - 1.0
        if total_return > -1.0 and len(frame) > 1
        else 0.0
    )

    daily_std = float(daily.std(ddof=1)) if len(daily) >= 2 else 0.0
    annualized_volatility = daily_std * math.sqrt(TRADING_DAYS)
    risk_free_daily = (1.0 + float(risk_free_rate_percent) / 100.0) ** (1.0 / TRADING_DAYS) - 1.0
    sharpe = None
    if daily_std > EPSILON and len(daily) >= 2:
        sharpe = float((daily.mean() - risk_free_daily) / daily_std * math.sqrt(TRADING_DAYS))

    period_returns = {
        "daily_percent": _round(float(frame["daily_return"].iloc[-1]) * 100),
        "month_to_date_percent": _round(_return_since(frame, last_date.replace(day=1)) * 100),
        "year_to_date_percent": _round(_return_since(frame, date(last_date.year, 1, 1)) * 100),
        "trailing_30d_percent": _round(_return_since(frame, last_date - timedelta(days=30)) * 100),
        "trailing_90d_percent": _round(_return_since(frame, last_date - timedelta(days=90)) * 100),
        "trailing_180d_percent": _round(_return_since(frame, last_date - timedelta(days=180)) * 100),
        "trailing_1y_percent": _round(_return_since(frame, last_date - timedelta(days=365)) * 100),
        "since_inception_percent": _round(total_return * 100),
    }

    series = [
        {
            "date": index.date().isoformat(),
            "equity": _round(row["equity"]),
            "external_flow": _round(row["external_flow"]),
            "daily_return_percent": _round(row["daily_return"] * 100),
            "cumulative_return_percent": _round((row["wealth_index"] - 1.0) * 100),
            "wealth_index": _round(row["wealth_index"] * 100),
            "drawdown_percent": _round(row["drawdown"] * 100),
        }
        for index, row in frame.iterrows()
    ]

    return {
        "period_returns": period_returns,
        "annualized_return_percent": _round(annualized_return * 100),
        "annualized_volatility_percent": _round(annualized_volatility * 100),
        "sharpe_ratio": _round(sharpe),
        "max_drawdown_percent": _round(float(frame["drawdown"].min()) * 100),
        "current_drawdown_percent": _round(float(frame["drawdown"].iloc[-1]) * 100),
        "best_day_percent": _round(float(daily.max()) * 100) if not daily.empty else None,
        "worst_day_percent": _round(float(daily.min()) * 100) if not daily.empty else None,
        "observations": int(len(frame)),
        "start_date": first_date.isoformat(),
        "end_date": last_date.isoformat(),
        "series": series,
        "methodology": {
            "return": "TWR diario enlazado y neutralizado por depósitos/retiros",
            "volatility": "Desvío estándar de retornos diarios × raíz de 252",
            "sharpe": "Exceso de retorno diario sobre tasa libre de riesgo / volatilidad diaria × raíz de 252",
            "drawdown": "Caída porcentual desde el máximo acumulado de la curva TWR",
        },
    }


def get_analytics_settings(portfolio_id: int = 1) -> dict:
    get_portfolio_settings(portfolio_id)
    with get_connection() as connection:
        connection.execute(
            """
            INSERT OR IGNORE INTO portfolio_analytics_settings
                (portfolio_id, benchmark_symbol, benchmark_name, risk_free_rate_percent)
            VALUES (?, ?, ?, 0)
            """,
            (portfolio_id, DEFAULT_BENCHMARK_SYMBOL, DEFAULT_BENCHMARK_NAME),
        )
        row = connection.execute(
            """
            SELECT portfolio_id, benchmark_symbol, benchmark_name, risk_free_rate_percent,
                   created_at, updated_at
            FROM portfolio_analytics_settings WHERE portfolio_id = ?
            """,
            (portfolio_id,),
        ).fetchone()
    if row is None:
        raise PortfolioValidationError("No se pudo cargar la configuración de analytics")
    item = dict(row)
    item["risk_free_rate_percent"] = float(item["risk_free_rate_percent"])
    return item


def update_analytics_settings(payload: AnalyticsSettingsUpdate, portfolio_id: int = 1) -> dict:
    get_portfolio_settings(portfolio_id)
    with get_connection() as connection:
        connection.execute(
            """
            INSERT INTO portfolio_analytics_settings
                (portfolio_id, benchmark_symbol, benchmark_name, risk_free_rate_percent, updated_at)
            VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
            ON CONFLICT(portfolio_id) DO UPDATE SET
                benchmark_symbol = excluded.benchmark_symbol,
                benchmark_name = excluded.benchmark_name,
                risk_free_rate_percent = excluded.risk_free_rate_percent,
                updated_at = CURRENT_TIMESTAMP
            """,
            (
                portfolio_id,
                payload.benchmark_symbol,
                payload.benchmark_name or payload.benchmark_symbol,
                payload.risk_free_rate_percent,
            ),
        )
    return get_analytics_settings(portfolio_id)


def _history_price_series(history: dict) -> pd.Series:
    rows = []
    for candle in history.get("candles", []):
        try:
            rows.append((_as_utc_date(candle["date"]), float(candle["close"])))
        except (KeyError, TypeError, ValueError):
            continue
    if not rows:
        return pd.Series(dtype=float)
    series = pd.Series({pd.Timestamp(day, tz="UTC"): value for day, value in rows}, dtype=float)
    return series.sort_index()[~series.index.duplicated(keep="last")]


def _benchmark_comparison(
    portfolio_series: list[dict],
    benchmark_symbol: str,
    period: str,
    base_currency: str,
    history_loader: Callable[[str, str, str], dict],
    fx_history_loader: Callable[[str, str, str], dict] | None,
) -> dict:
    result = {
        "enabled": benchmark_symbol not in {"", "NONE"},
        "symbol": benchmark_symbol,
        "name": benchmark_symbol,
        "currency": None,
        "portfolio_return_percent": None,
        "benchmark_return_percent": None,
        "excess_return_percent": None,
        "points": [],
        "is_partial": False,
        "errors": [],
        "source": None,
    }
    if not result["enabled"] or not portfolio_series:
        return result

    try:
        history = history_loader(benchmark_symbol, period, "1d")
        benchmark = _history_price_series(history)
        if benchmark.empty:
            raise PortfolioValidationError("El benchmark no devolvió precios")
        result["currency"] = str(history.get("currency") or base_currency).upper()
        result["source"] = history.get("source")

        if result["currency"] != base_currency:
            if fx_history_loader is None:
                raise PortfolioValidationError(
                    f"No hay histórico FX para convertir {result['currency']} a {base_currency}"
                )
            fx_history = fx_history_loader(result["currency"], base_currency, period)
            fx = _history_price_series(fx_history)
            if fx.empty:
                raise PortfolioValidationError("El histórico FX del benchmark está vacío")
            combined_index = benchmark.index.union(fx.index).sort_values()
            benchmark = benchmark.reindex(combined_index).ffill()
            fx = fx.reindex(combined_index).ffill()
            benchmark = (benchmark * fx).dropna()

        portfolio_frame = pd.DataFrame(portfolio_series)
        portfolio_frame["date"] = pd.to_datetime(portfolio_frame["date"], utc=True).dt.normalize()
        portfolio_frame = portfolio_frame.set_index("date").sort_index()
        portfolio_index = pd.to_numeric(portfolio_frame["wealth_index"], errors="coerce")

        all_index = portfolio_index.index.union(benchmark.index).sort_values()
        portfolio_aligned = portfolio_index.reindex(all_index).ffill()
        benchmark_aligned = benchmark.reindex(all_index).ffill()
        aligned = pd.DataFrame({"portfolio": portfolio_aligned, "benchmark": benchmark_aligned}).dropna()
        if len(aligned) < 2:
            raise PortfolioValidationError("No hay fechas suficientes en común con el benchmark")

        portfolio_normalized = aligned["portfolio"] / aligned["portfolio"].iloc[0] * 100.0
        benchmark_normalized = aligned["benchmark"] / aligned["benchmark"].iloc[0] * 100.0
        result["portfolio_return_percent"] = _round(portfolio_normalized.iloc[-1] - 100.0)
        result["benchmark_return_percent"] = _round(benchmark_normalized.iloc[-1] - 100.0)
        result["excess_return_percent"] = _round(
            float(result["portfolio_return_percent"] or 0.0)
            - float(result["benchmark_return_percent"] or 0.0)
        )
        result["points"] = [
            {
                "date": index.date().isoformat(),
                "portfolio_index": _round(portfolio_normalized.loc[index]),
                "benchmark_index": _round(benchmark_normalized.loc[index]),
                "difference": _round(portfolio_normalized.loc[index] - benchmark_normalized.loc[index]),
            }
            for index in aligned.index
        ]
    except Exception as exc:
        result["is_partial"] = True
        result["errors"].append(str(exc))
    return result


def _aggregate_concentration(overview: dict) -> dict:
    summary = overview["summary"]
    total_equity = float(summary.get("total_equity") or 0.0)
    denominator = total_equity if total_equity > EPSILON else 1.0

    by_asset = []
    for holding in overview.get("holdings", []):
        value = float(holding.get("market_value") or 0.0)
        by_asset.append({
            "key": holding["symbol"],
            "label": holding.get("name") or holding["symbol"],
            "value": _round(value),
            "percent": _round(value / denominator * 100.0),
        })
    for cash in overview.get("cash_balances", []):
        value = float(cash.get("base_value") or 0.0)
        if abs(value) <= EPSILON:
            continue
        by_asset.append({
            "key": f"CASH:{cash['currency']}",
            "label": f"Efectivo {cash['currency']}",
            "value": _round(value),
            "percent": _round(value / denominator * 100.0),
        })
    by_asset.sort(key=lambda item: float(item["value"] or 0.0), reverse=True)

    currency_values: dict[str, float] = defaultdict(float)
    type_values: dict[str, float] = defaultdict(float)
    for holding in overview.get("holdings", []):
        value = float(holding.get("market_value") or 0.0)
        currency_values[str(holding.get("currency") or summary["currency"])] += value
        type_values[str(holding.get("asset_type") or "OTHER")] += value
    for cash in overview.get("cash_balances", []):
        currency_values[str(cash["currency"])] += float(cash.get("base_value") or 0.0)
        type_values["CASH"] += float(cash.get("base_value") or 0.0)

    def rows(values: dict[str, float]) -> list[dict]:
        return [
            {"key": key, "label": key, "value": _round(value), "percent": _round(value / denominator * 100.0)}
            for key, value in sorted(values.items(), key=lambda item: item[1], reverse=True)
            if abs(value) > EPSILON
        ]

    positive_weights = [max(float(item.get("percent") or 0.0), 0.0) / 100.0 for item in by_asset]
    hhi = sum(weight * weight for weight in positive_weights)
    count = len(positive_weights)
    diversification = 100.0 if count <= 1 and not positive_weights else 0.0
    if count > 1:
        diversification = max(0.0, min(100.0, (1.0 - hhi) / (1.0 - 1.0 / count) * 100.0))

    return {
        "by_asset": by_asset,
        "by_currency": rows(currency_values),
        "by_asset_type": rows(type_values),
        "largest_position_percent": _round(max((float(item.get("percent") or 0.0) for item in by_asset), default=0.0)),
        "hhi": _round(hhi),
        "diversification_score": _round(diversification),
    }


def _position_performance(
    overview: dict,
    attribution: dict | None = None,
    dividend_rows: list[dict] | None = None,
) -> list[dict]:
    dividend_by_symbol: dict[str, float] = defaultdict(float)
    if dividend_rows is not None:
        for movement in dividend_rows:
            if movement.get("symbol"):
                dividend_by_symbol[str(movement["symbol"])] += float(movement.get("net_amount_base") or movement.get("cash_effect") or 0.0)
    else:
        for movement in overview.get("cash_movements", []):
            if movement.get("movement_type") == "DIVIDEND" and movement.get("symbol"):
                dividend_by_symbol[str(movement["symbol"])] += float(movement.get("cash_effect") or 0.0)

    attribution_by_symbol = {
        str(item.get("symbol")): item for item in (attribution or {}).get("positions", [])
    }
    rows = []
    for holding in overview.get("holdings", []):
        symbol = str(holding["symbol"])
        realized = float(holding.get("realized_pnl") or 0.0)
        unrealized = float(holding.get("unrealized_pnl") or 0.0)
        dividends = dividend_by_symbol.get(symbol, 0.0)
        total_pnl = realized + unrealized + dividends
        cost_basis = float(holding.get("cost_basis") or 0.0)
        effects = attribution_by_symbol.get(symbol, {})
        price_effect = float(effects.get("price_effect_base") or 0.0)
        fx_effect = float(effects.get("fx_effect_base") or 0.0)
        rows.append({
            "symbol": symbol,
            "name": holding.get("name") or symbol,
            "asset_type": holding.get("asset_type") or "OTHER",
            "currency": holding.get("currency"),
            "quantity": _round(holding.get("quantity")),
            "cost_basis": _round(cost_basis),
            "market_value": _round(holding.get("market_value")),
            "realized_pnl": _round(realized),
            "unrealized_pnl": _round(unrealized),
            "dividends": _round(dividends),
            "price_effect": _round(price_effect),
            "fx_effect": _round(fx_effect),
            "realized_trading_pnl_combined": _round(realized),
            "attributable_open_and_income": _round(price_effect + fx_effect + dividends),
            "total_pnl": _round(total_pnl),
            "total_return_percent": _round(total_pnl / cost_basis * 100.0) if cost_basis > EPSILON else None,
            "valuation_source": holding.get("valuation_source"),
        })
    return sorted(rows, key=lambda item: float(item.get("market_value") or 0.0), reverse=True)


def get_analytics_overview(
    period: str,
    history_loader: Callable[[str, str, str], dict],
    fx_history_loader: Callable[[str, str, str], dict] | None,
    quote_loader: Callable[[str], dict | None] | None,
    fx_loader: Callable[[str, str, datetime | date | None], dict] | None,
    portfolio_id: int = 1,
) -> dict:
    if period not in SUPPORTED_ANALYTICS_PERIODS:
        raise PortfolioValidationError(
            f"Período de analytics no permitido. Usá: {', '.join(sorted(SUPPORTED_ANALYTICS_PERIODS))}"
        )

    settings = get_analytics_settings(portfolio_id)
    overview = get_portfolio_overview(quote_loader, fx_loader, portfolio_id)
    curve = get_equity_curve(period, history_loader, fx_history_loader, portfolio_id)
    selected_points = _filter_curve_points(curve.get("points", []), period)
    performance = calculate_performance_metrics(selected_points, settings["risk_free_rate_percent"])
    selected_period_return = performance["period_returns"].get("since_inception_percent", 0.0)
    performance["period_returns"]["selected_period_percent"] = selected_period_return

    lifetime_curve = curve
    lifetime_performance = performance
    if period != "max":
        lifetime_curve = get_equity_curve("max", history_loader, fx_history_loader, portfolio_id)
        lifetime_performance = calculate_performance_metrics(
            lifetime_curve.get("points", []),
            settings["risk_free_rate_percent"],
        )
    performance["period_returns"]["since_inception_percent"] = (
        lifetime_performance["period_returns"].get("since_inception_percent", 0.0)
    )
    performance["lifetime_start_date"] = lifetime_performance.get("start_date")
    benchmark = _benchmark_comparison(
        performance["series"],
        settings["benchmark_symbol"],
        period,
        overview["settings"]["base_currency"],
        history_loader,
        fx_history_loader,
    )
    concentration = _aggregate_concentration(overview)

    summary = overview["summary"]
    attribution = asset_price_fx_attribution(overview, portfolio_id)
    dividend_rows = list_dividends(portfolio_id)
    positions = _position_performance(overview, attribution, dividend_rows)
    dividend_gross = sum(float(item.get("gross_amount_base") or 0.0) for item in dividend_rows)
    dividend_tax = sum(float(item.get("withholding_tax_base") or 0.0) for item in dividend_rows)
    open_price = float(attribution["totals"].get("price_effect") or 0.0)
    open_fx = float(attribution["totals"].get("fx_effect") or 0.0)
    realized_combined = float(summary.get("realized_pnl") or 0.0)

    performance_frame = _prepare_curve(selected_points)
    advanced_risk = calculate_downside_and_tail_risk(
        performance_frame["daily_return"].iloc[1:] if not performance_frame.empty else pd.Series(dtype=float),
        annualized_return_percent=performance.get("annualized_return_percent"),
        risk_free_rate_percent=settings["risk_free_rate_percent"],
        max_drawdown_percent=performance.get("max_drawdown_percent"),
    )
    matrix_data = build_asset_return_matrix(
        overview.get("holdings", []),
        period,
        overview["settings"]["base_currency"],
        history_loader,
        fx_history_loader,
    )
    covariance_risk = calculate_covariance_risk(matrix_data["returns"], matrix_data["weights"])
    benchmark_relationship = calculate_benchmark_relationship(
        performance["series"], benchmark.get("points", []), settings["risk_free_rate_percent"]
    )
    sector_industry = aggregate_sector_industry(
        overview.get("holdings", []), float(summary.get("total_equity") or 0.0)
    )

    decomposition = {
        # Clave heredada conservada para clientes anteriores.
        "asset_price_and_trading_pnl": _round(realized_combined + open_price + open_fx),
        "open_asset_price_pnl": _round(open_price),
        "open_asset_fx_pnl": _round(open_fx),
        "realized_trading_pnl_combined": _round(realized_combined),
        "dividends_gross": _round(dividend_gross),
        "dividend_withholding": _round(-dividend_tax),
        "dividends": _round(summary.get("dividends")),
        "interest": _round(summary.get("interest")),
        "cash_and_realized_fx_pnl": _round(
            float(summary.get("realized_fx_pnl") or 0.0)
            + float(summary.get("unrealized_cash_fx_pnl") or 0.0)
        ),
        "taxes_and_fees": _round(-(
            float(summary.get("taxes") or 0.0)
            + float(summary.get("other_fees") or 0.0)
            + float(summary.get("fx_fees") or 0.0)
        )),
        "total_investment_profit": _round(summary.get("investment_profit")),
        "asset_attribution": attribution,
        "note": "Las posiciones abiertas separan efecto precio y efecto FX. El P&L realizado histórico sigue combinado porque cada venta puede incluir precio, moneda y comisiones.",
    }

    advanced_is_partial = bool(matrix_data.get("is_partial") or sector_industry.get("is_partial"))
    risk_summary = build_risk_summary(
        performance=performance,
        concentration=concentration,
        advanced_risk=advanced_risk,
        covariance_risk=covariance_risk,
        benchmark_relationship=benchmark_relationship,
        sector_industry=sector_industry,
        is_partial=advanced_is_partial,
    )

    return {
        "portfolio_id": portfolio_id,
        "period": period,
        "currency": overview["settings"]["base_currency"],
        "settings": settings,
        "performance": performance,
        "benchmark": benchmark,
        "risk": {
            "annualized_volatility_percent": performance["annualized_volatility_percent"],
            "sharpe_ratio": performance["sharpe_ratio"],
            "sortino_ratio": advanced_risk.get("sortino_ratio"),
            "max_drawdown_percent": performance["max_drawdown_percent"],
            "current_drawdown_percent": performance["current_drawdown_percent"],
            "best_day_percent": performance["best_day_percent"],
            "worst_day_percent": performance["worst_day_percent"],
            "var_95_percent": (advanced_risk.get("var") or {}).get("95"),
            "cvar_95_percent": (advanced_risk.get("cvar") or {}).get("95"),
            "risk_free_rate_percent": settings["risk_free_rate_percent"],
            "educational_only": True,
        },
        "advanced_risk": advanced_risk,
        "benchmark_relationship": benchmark_relationship,
        "covariance_risk": covariance_risk,
        "sector_industry": sector_industry,
        "risk_summary": risk_summary,
        "concentration": {**concentration, **sector_industry},
        "positions": positions,
        "decomposition": decomposition,
        "valuation_status": summary.get("valuation_status"),
        "is_partial": bool(
            curve.get("is_partial")
            or lifetime_curve.get("is_partial")
            or benchmark.get("is_partial")
            or matrix_data.get("is_partial")
            or sector_industry.get("is_partial")
            or summary.get("valuation_status") == "partial"
        ),
        "errors": list(dict.fromkeys(
            list(curve.get("errors", []))
            + list(lifetime_curve.get("errors", []))
            + list(benchmark.get("errors", []))
            + list(matrix_data.get("errors", []))
        )),
        "source": "SQLite + motor TWR/riesgo con pandas y numpy + proveedor de mercado configurado",
        "last_updated": datetime.now(timezone.utc).isoformat(),
        "disclaimer": "Métricas educativas basadas en datos históricos. No constituyen asesoramiento financiero ni garantizan resultados futuros.",
    }


def compare_assets(
    symbols: list[str],
    period: str,
    history_loader: Callable[[str, str, str], dict],
    fx_history_loader: Callable[[str, str, str], dict] | None,
    portfolio_id: int = 1,
) -> dict:
    if period not in SUPPORTED_ANALYTICS_PERIODS:
        raise PortfolioValidationError("Período de comparación no permitido")
    settings = get_portfolio_settings(portfolio_id)
    return compare_market_assets(
        symbols, period, settings["base_currency"], history_loader, fx_history_loader
    )


def export_analytics_csv(data: dict) -> str:
    return analytics_csv_report(data)
