from __future__ import annotations

from datetime import datetime, timezone

from backend.core.database import get_connection
from backend.services.market_service import MarketDataError


def _symbol(value: str) -> str:
    normalized = value.strip().upper()
    if not normalized or len(normalized) > 40:
        raise ValueError("Símbolo manual inválido")
    return normalized


def list_manual_prices() -> list[dict]:
    with get_connection() as connection:
        rows = connection.execute(
            "SELECT symbol, price, currency, name, notes, observed_at, updated_at FROM market_manual_prices ORDER BY symbol"
        ).fetchall()
    return [dict(row) for row in rows]


def get_manual_price(symbol: str) -> dict | None:
    with get_connection() as connection:
        row = connection.execute(
            "SELECT symbol, price, currency, name, notes, observed_at, updated_at FROM market_manual_prices WHERE symbol = ?",
            (_symbol(symbol),),
        ).fetchone()
    return dict(row) if row else None


def save_manual_price(symbol: str, price: float, currency: str, name: str = "", notes: str = "", observed_at: datetime | None = None) -> dict:
    normalized = _symbol(symbol)
    if price <= 0:
        raise ValueError("El precio manual debe ser mayor que cero")
    currency = currency.strip().upper()
    if len(currency) != 3 or not currency.isalpha():
        raise ValueError("La moneda debe tener tres letras")
    observed = observed_at or datetime.now(timezone.utc)
    if observed.tzinfo is None:
        observed = observed.replace(tzinfo=timezone.utc)
    observed_iso = observed.astimezone(timezone.utc).isoformat()
    with get_connection() as connection:
        connection.execute(
            """
            INSERT INTO market_manual_prices (symbol, price, currency, name, notes, observed_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
            ON CONFLICT(symbol) DO UPDATE SET
                price = excluded.price,
                currency = excluded.currency,
                name = excluded.name,
                notes = excluded.notes,
                observed_at = excluded.observed_at,
                updated_at = CURRENT_TIMESTAMP
            """,
            (normalized, float(price), currency, name.strip(), notes.strip(), observed_iso),
        )
    return get_manual_price(normalized) or {}


def delete_manual_price(symbol: str) -> bool:
    with get_connection() as connection:
        cursor = connection.execute("DELETE FROM market_manual_prices WHERE symbol = ?", (_symbol(symbol),))
    return cursor.rowcount > 0


def manual_quote(symbol: str) -> dict | None:
    row = get_manual_price(symbol)
    if not row:
        return None
    observed = row["observed_at"]
    return {
        "symbol": row["symbol"],
        "name": row["name"] or row["symbol"],
        "price": float(row["price"]),
        "previous_close": float(row["price"]),
        "change": 0.0,
        "change_percent": 0.0,
        "market": "Precio manual",
        "exchange": "Manual",
        "currency": row["currency"],
        "quote_type": "MANUAL",
        "asset_type": "OTHER",
        "market_state": "manual",
        "last_updated": observed,
        "source": "Precio manual guardado por el usuario",
        "is_delayed": False,
        "pricing_mode": "MANUAL",
        "price_kind": "manual",
        "data_status": "manual",
        "status_label": "Respaldo manual",
        "data_age_seconds": None,
        "warnings": ["Este valor no fue obtenido automáticamente del mercado."],
    }


def list_symbol_aliases() -> list[dict]:
    with get_connection() as connection:
        rows = connection.execute(
            "SELECT old_symbol, new_symbol, notes, updated_at FROM market_symbol_aliases ORDER BY old_symbol"
        ).fetchall()
    return [dict(row) for row in rows]


def get_symbol_alias(symbol: str) -> dict | None:
    with get_connection() as connection:
        row = connection.execute(
            "SELECT old_symbol, new_symbol, notes, updated_at FROM market_symbol_aliases WHERE old_symbol = ?",
            (_symbol(symbol),),
        ).fetchone()
    return dict(row) if row else None


def save_symbol_alias(old_symbol: str, new_symbol: str, notes: str = "") -> dict:
    old_normalized = _symbol(old_symbol)
    new_normalized = _symbol(new_symbol)
    if old_normalized == new_normalized:
        raise ValueError("El símbolo anterior y el nuevo no pueden ser iguales")
    with get_connection() as connection:
        connection.execute(
            """
            INSERT INTO market_symbol_aliases (old_symbol, new_symbol, notes, updated_at)
            VALUES (?, ?, ?, CURRENT_TIMESTAMP)
            ON CONFLICT(old_symbol) DO UPDATE SET
                new_symbol = excluded.new_symbol,
                notes = excluded.notes,
                updated_at = CURRENT_TIMESTAMP
            """,
            (old_normalized, new_normalized, notes.strip()),
        )
    return get_symbol_alias(old_normalized) or {}


def delete_symbol_alias(old_symbol: str) -> bool:
    with get_connection() as connection:
        cursor = connection.execute(
            "DELETE FROM market_symbol_aliases WHERE old_symbol = ?", (_symbol(old_symbol),)
        )
    return cursor.rowcount > 0
