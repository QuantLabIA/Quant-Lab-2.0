from __future__ import annotations

from collections import defaultdict
from collections.abc import Callable, Iterable
from datetime import date, datetime, timezone
import csv
import io
import math
from typing import Any

import numpy as np
import pandas as pd

from backend.services.portfolio_service import EPSILON, PortfolioValidationError

TRADING_DAYS = 252
SUPPORTED_CONFIDENCE_LEVELS = (0.95, 0.99)


def _round(value: float | int | None, digits: int = 6) -> float | None:
    if value is None:
        return None
    number = float(value)
    if not math.isfinite(number):
        return None
    return round(number, digits)


def _utc_index(value: Any) -> pd.Timestamp:
    parsed = pd.Timestamp(value)
    if parsed.tzinfo is None:
        return parsed.tz_localize("UTC").normalize()
    return parsed.tz_convert("UTC").normalize()


def history_close_series(history: dict) -> pd.Series:
    rows: list[tuple[pd.Timestamp, float]] = []
    for candle in history.get("candles", []):
        try:
            close = float(candle["close"])
            if not math.isfinite(close) or close <= 0:
                continue
            rows.append((_utc_index(candle["date"]), close))
        except (KeyError, TypeError, ValueError):
            continue
    if not rows:
        return pd.Series(dtype=float)
    series = pd.Series({index: close for index, close in rows}, dtype=float)
    return series.sort_index()[~series.index.duplicated(keep="last")]


def _convert_price_series_to_base(
    prices: pd.Series,
    asset_currency: str,
    base_currency: str,
    period: str,
    fx_history_loader: Callable[[str, str, str], dict] | None,
) -> tuple[pd.Series, str | None]:
    source = str(asset_currency or base_currency).upper()
    target = str(base_currency).upper()
    if source == target:
        return prices, None
    if fx_history_loader is None:
        return pd.Series(dtype=float), f"Falta histórico FX {source}/{target}"
    try:
        fx_history = fx_history_loader(source, target, period)
        fx = history_close_series(fx_history)
        if fx.empty:
            return pd.Series(dtype=float), f"Histórico FX vacío para {source}/{target}"
        index = prices.index.union(fx.index).sort_values()
        converted = prices.reindex(index).ffill() * fx.reindex(index).ffill()
        return converted.dropna(), None
    except Exception as exc:
        return pd.Series(dtype=float), f"No se pudo convertir {source}/{target}: {exc}"


def build_asset_return_matrix(
    holdings: list[dict],
    period: str,
    base_currency: str,
    history_loader: Callable[[str, str, str], dict],
    fx_history_loader: Callable[[str, str, str], dict] | None,
    *,
    max_assets: int = 20,
) -> dict:
    """Construye precios/retornos comparables en moneda base.

    Los activos manuales o sin histórico se omiten, pero el resultado conserva el
    detalle de errores para que Analytics pueda operar en modo parcial.
    """
    errors: list[str] = []
    series_map: dict[str, pd.Series] = {}
    metadata: dict[str, dict] = {}

    ordered = sorted(
        holdings,
        key=lambda item: abs(float(item.get("market_value") or 0.0)),
        reverse=True,
    )[:max_assets]

    for holding in ordered:
        symbol = str(holding.get("symbol") or "").upper()
        if not symbol:
            continue
        if str(holding.get("pricing_mode") or "AUTO").upper() == "MANUAL":
            errors.append(f"{symbol}: activo manual sin histórico automático")
            continue
        try:
            history = history_loader(symbol, period, "1d")
            prices = history_close_series(history)
            if len(prices) < 3:
                raise PortfolioValidationError("histórico insuficiente")
            currency = str(history.get("currency") or holding.get("currency") or base_currency).upper()
            converted, fx_error = _convert_price_series_to_base(
                prices, currency, base_currency, period, fx_history_loader
            )
            if fx_error:
                errors.append(f"{symbol}: {fx_error}")
            if len(converted) < 3:
                raise PortfolioValidationError("histórico convertido insuficiente")
            series_map[symbol] = converted
            metadata[symbol] = {
                "name": holding.get("name") or symbol,
                "currency": currency,
                "base_currency": base_currency,
                "market_value": float(holding.get("market_value") or 0.0),
                "asset_type": holding.get("asset_type") or "OTHER",
                "sector": holding.get("sector") or "Sin clasificar",
                "industry": holding.get("industry") or "Sin clasificar",
                "source": history.get("source"),
            }
        except Exception as exc:
            errors.append(f"{symbol}: {exc}")

    if not series_map:
        return {
            "prices": pd.DataFrame(),
            "returns": pd.DataFrame(),
            "metadata": metadata,
            "weights": pd.Series(dtype=float),
            "errors": errors,
            "is_partial": bool(errors),
        }

    prices = pd.concat(series_map, axis=1).sort_index().ffill()
    prices = prices.dropna(how="all")
    returns = prices.pct_change(fill_method=None).replace([np.inf, -np.inf], np.nan)
    valid_columns = [column for column in returns.columns if returns[column].count() >= 2]
    prices = prices[valid_columns]
    returns = returns[valid_columns].dropna(how="all")

    raw_weights = pd.Series(
        {symbol: max(float(metadata[symbol]["market_value"]), 0.0) for symbol in valid_columns},
        dtype=float,
    )
    total = float(raw_weights.sum())
    weights = raw_weights / total if total > EPSILON else pd.Series(
        np.repeat(1.0 / len(valid_columns), len(valid_columns)),
        index=valid_columns,
        dtype=float,
    )
    return {
        "prices": prices,
        "returns": returns,
        "metadata": metadata,
        "weights": weights,
        "errors": errors,
        "is_partial": bool(errors) or len(valid_columns) < len(ordered),
    }


def calculate_downside_and_tail_risk(
    daily_returns: pd.Series,
    *,
    annualized_return_percent: float | None,
    risk_free_rate_percent: float = 0.0,
    max_drawdown_percent: float | None = None,
) -> dict:
    clean = pd.to_numeric(daily_returns, errors="coerce").dropna()
    clean = clean[np.isfinite(clean)]
    if clean.empty:
        return {
            "sortino_ratio": None,
            "downside_deviation_percent": None,
            "calmar_ratio": None,
            "omega_ratio": None,
            "var": {},
            "cvar": {},
            "observations": 0,
        }

    target_daily = (1.0 + float(risk_free_rate_percent) / 100.0) ** (1.0 / TRADING_DAYS) - 1.0
    excess = clean - target_daily
    downside = np.minimum(excess.to_numpy(dtype=float), 0.0)
    downside_daily = float(np.sqrt(np.mean(np.square(downside)))) if len(downside) else 0.0
    downside_annual = downside_daily * math.sqrt(TRADING_DAYS)
    annualized_return = float(annualized_return_percent or 0.0) / 100.0
    sortino = (
        (annualized_return - float(risk_free_rate_percent) / 100.0) / downside_annual
        if downside_annual > EPSILON else None
    )
    max_dd = abs(float(max_drawdown_percent or 0.0) / 100.0)
    calmar = annualized_return / max_dd if max_dd > EPSILON else None

    positive_excess = float(excess[excess > 0].sum())
    negative_excess = abs(float(excess[excess < 0].sum()))
    omega = positive_excess / negative_excess if negative_excess > EPSILON else None

    var: dict[str, float | None] = {}
    cvar: dict[str, float | None] = {}
    for level in SUPPORTED_CONFIDENCE_LEVELS:
        tail_probability = 1.0 - level
        threshold = float(clean.quantile(tail_probability, interpolation="linear"))
        tail = clean[clean <= threshold]
        key = str(int(level * 100))
        var[key] = _round(max(-threshold * 100.0, 0.0))
        cvar[key] = _round(max(-float(tail.mean()) * 100.0, 0.0)) if not tail.empty else None

    return {
        "sortino_ratio": _round(sortino),
        "downside_deviation_percent": _round(downside_annual * 100.0),
        "calmar_ratio": _round(calmar),
        "omega_ratio": _round(omega),
        "var": var,
        "cvar": cvar,
        "observations": int(len(clean)),
        "methodology": {
            "sortino": "Exceso de retorno anual sobre desviación bajista anualizada",
            "var": "Percentil histórico de pérdidas diarias; no supone normalidad",
            "cvar": "Pérdida diaria promedio en observaciones peores que el VaR",
            "calmar": "Retorno anualizado dividido por drawdown máximo absoluto",
            "omega": "Suma de excesos positivos / suma absoluta de excesos negativos",
        },
    }


def calculate_covariance_risk(return_matrix: pd.DataFrame, weights: pd.Series) -> dict:
    if return_matrix.empty or len(return_matrix.columns) < 1:
        return {
            "symbols": [],
            "correlation_matrix": [],
            "covariance_matrix_annualized": [],
            "risk_contributions": [],
            "portfolio_volatility_percent": None,
            "average_correlation": None,
            "observations": 0,
        }

    columns = [column for column in return_matrix.columns if return_matrix[column].count() >= 2]
    matrix = return_matrix[columns].dropna(how="all")
    if not columns or matrix.empty:
        return {
            "symbols": [],
            "correlation_matrix": [],
            "covariance_matrix_annualized": [],
            "risk_contributions": [],
            "portfolio_volatility_percent": None,
            "average_correlation": None,
            "observations": 0,
        }

    corr = matrix.corr(min_periods=2).fillna(0.0)
    covariance = matrix.cov(min_periods=2).fillna(0.0) * TRADING_DAYS
    aligned_weights = weights.reindex(columns).fillna(0.0).astype(float)
    if abs(float(aligned_weights.sum())) <= EPSILON:
        aligned_weights[:] = 1.0 / len(columns)
    else:
        aligned_weights /= float(aligned_weights.sum())

    w = aligned_weights.to_numpy(dtype=float)
    cov_values = covariance.to_numpy(dtype=float)
    variance = float(w.T @ cov_values @ w)
    volatility = math.sqrt(max(variance, 0.0))
    marginal = cov_values @ w / volatility if volatility > EPSILON else np.zeros_like(w)
    component = w * marginal
    contributions = component / volatility * 100.0 if volatility > EPSILON else np.zeros_like(w)

    off_diagonal: list[float] = []
    if len(columns) > 1:
        for i in range(len(columns)):
            for j in range(i + 1, len(columns)):
                off_diagonal.append(float(corr.iloc[i, j]))

    correlation_rows = [
        {
            "symbol": row,
            "values": {column: _round(corr.loc[row, column], 5) for column in columns},
        }
        for row in columns
    ]
    covariance_rows = [
        {
            "symbol": row,
            "values": {column: _round(covariance.loc[row, column], 8) for column in columns},
        }
        for row in columns
    ]
    risk_rows = []
    for index, symbol in enumerate(columns):
        own_vol = float(matrix[symbol].std(ddof=1) * math.sqrt(TRADING_DAYS)) if matrix[symbol].count() >= 2 else 0.0
        risk_rows.append({
            "symbol": symbol,
            "weight_percent": _round(aligned_weights[symbol] * 100.0),
            "asset_volatility_percent": _round(own_vol * 100.0),
            "marginal_risk_percent": _round(marginal[index] * 100.0),
            "component_risk_percent_points": _round(component[index] * 100.0),
            "risk_contribution_percent": _round(contributions[index]),
        })
    risk_rows.sort(key=lambda item: abs(float(item.get("risk_contribution_percent") or 0.0)), reverse=True)

    return {
        "symbols": columns,
        "correlation_matrix": correlation_rows,
        "covariance_matrix_annualized": covariance_rows,
        "risk_contributions": risk_rows,
        "portfolio_volatility_percent": _round(volatility * 100.0),
        "average_correlation": _round(float(np.mean(off_diagonal)), 5) if off_diagonal else None,
        "observations": int(matrix.dropna(how="all").shape[0]),
        "methodology": {
            "correlation": "Correlación de Pearson sobre retornos diarios en moneda base",
            "covariance": "Covarianza diaria anualizada por 252",
            "risk_contribution": "Peso × riesgo marginal / volatilidad total",
        },
    }


def calculate_benchmark_relationship(
    portfolio_series: list[dict],
    benchmark_points: list[dict],
    risk_free_rate_percent: float = 0.0,
) -> dict:
    if not portfolio_series or not benchmark_points:
        return {
            "beta": None,
            "correlation": None,
            "tracking_error_percent": None,
            "information_ratio": None,
            "alpha_annualized_percent": None,
            "up_capture_percent": None,
            "down_capture_percent": None,
            "observations": 0,
        }

    portfolio = pd.Series(
        {
            _utc_index(item["date"]): float(item["wealth_index"])
            for item in portfolio_series
            if item.get("wealth_index") is not None
        },
        dtype=float,
    ).sort_index()
    benchmark = pd.Series(
        {
            _utc_index(item["date"]): float(item["benchmark_index"])
            for item in benchmark_points
            if item.get("benchmark_index") is not None
        },
        dtype=float,
    ).sort_index()
    index = portfolio.index.union(benchmark.index).sort_values()
    aligned = pd.DataFrame({
        "portfolio": portfolio.reindex(index).ffill(),
        "benchmark": benchmark.reindex(index).ffill(),
    }).dropna()
    returns = aligned.pct_change(fill_method=None).dropna()
    if len(returns) < 2:
        return {
            "beta": None,
            "correlation": None,
            "tracking_error_percent": None,
            "information_ratio": None,
            "alpha_annualized_percent": None,
            "up_capture_percent": None,
            "down_capture_percent": None,
            "observations": int(len(returns)),
        }

    p = returns["portfolio"]
    b = returns["benchmark"]
    benchmark_variance = float(b.var(ddof=1))
    beta = float(p.cov(b) / benchmark_variance) if benchmark_variance > EPSILON else None
    correlation = float(p.corr(b)) if len(returns) >= 2 else None
    active = p - b
    tracking_daily = float(active.std(ddof=1))
    tracking_error = tracking_daily * math.sqrt(TRADING_DAYS)
    information = float(active.mean() / tracking_daily * math.sqrt(TRADING_DAYS)) if tracking_daily > EPSILON else None
    risk_free_daily = (1 + risk_free_rate_percent / 100.0) ** (1 / TRADING_DAYS) - 1
    alpha = (
        float(((p - risk_free_daily) - float(beta) * (b - risk_free_daily)).mean() * TRADING_DAYS)
        if beta is not None else None
    )

    up = b > 0
    down = b < 0
    up_capture = (
        float(p[up].mean() / b[up].mean() * 100.0)
        if up.any() and abs(float(b[up].mean())) > EPSILON else None
    )
    down_capture = (
        float(p[down].mean() / b[down].mean() * 100.0)
        if down.any() and abs(float(b[down].mean())) > EPSILON else None
    )

    return {
        "beta": _round(beta),
        "correlation": _round(correlation),
        "tracking_error_percent": _round(tracking_error * 100.0),
        "information_ratio": _round(information),
        "alpha_annualized_percent": _round(alpha * 100.0) if alpha is not None else None,
        "up_capture_percent": _round(up_capture),
        "down_capture_percent": _round(down_capture),
        "observations": int(len(returns)),
        "methodology": {
            "beta": "Covarianza(portafolio, benchmark) / varianza(benchmark)",
            "tracking_error": "Desvío estándar anualizado del retorno activo",
            "information_ratio": "Retorno activo medio / tracking error",
            "alpha": "Alpha diario de Jensen anualizado de forma aritmética",
        },
    }


def aggregate_sector_industry(holdings: list[dict], total_equity: float) -> dict:
    denominator = float(total_equity) if float(total_equity) > EPSILON else 1.0
    sector_values: dict[str, float] = defaultdict(float)
    industry_values: dict[str, float] = defaultdict(float)
    classified_value = 0.0
    for holding in holdings:
        value = float(holding.get("market_value") or 0.0)
        sector = str(holding.get("sector") or "Sin clasificar").strip() or "Sin clasificar"
        industry = str(holding.get("industry") or "Sin clasificar").strip() or "Sin clasificar"
        sector_values[sector] += value
        industry_values[industry] += value
        if sector != "Sin clasificar":
            classified_value += value

    def rows(values: dict[str, float]) -> list[dict]:
        return [
            {
                "key": key,
                "label": key,
                "value": _round(value),
                "percent": _round(value / denominator * 100.0),
            }
            for key, value in sorted(values.items(), key=lambda item: item[1], reverse=True)
            if abs(value) > EPSILON
        ]

    invested = sum(float(item.get("market_value") or 0.0) for item in holdings)
    coverage = classified_value / invested * 100.0 if invested > EPSILON else 0.0
    return {
        "by_sector": rows(sector_values),
        "by_industry": rows(industry_values),
        "classified_coverage_percent": _round(coverage),
        "is_partial": coverage < 99.0 and bool(holdings),
    }


def compare_assets(
    symbols: Iterable[str],
    period: str,
    base_currency: str,
    history_loader: Callable[[str, str, str], dict],
    fx_history_loader: Callable[[str, str, str], dict] | None,
) -> dict:
    unique: list[str] = []
    for raw in symbols:
        symbol = str(raw or "").strip().upper()
        if symbol and symbol not in unique:
            unique.append(symbol)
    if len(unique) < 2:
        raise PortfolioValidationError("El comparador requiere al menos dos símbolos")
    if len(unique) > 6:
        raise PortfolioValidationError("El comparador admite hasta seis símbolos")

    prices_map: dict[str, pd.Series] = {}
    metadata: dict[str, dict] = {}
    errors: list[str] = []
    for symbol in unique:
        try:
            history = history_loader(symbol, period, "1d")
            prices = history_close_series(history)
            if len(prices) < 3:
                raise PortfolioValidationError("histórico insuficiente")
            currency = str(history.get("currency") or base_currency).upper()
            converted, fx_error = _convert_price_series_to_base(
                prices, currency, base_currency, period, fx_history_loader
            )
            if fx_error:
                errors.append(f"{symbol}: {fx_error}")
            if len(converted) < 3:
                raise PortfolioValidationError("histórico convertido insuficiente")
            prices_map[symbol] = converted
            metadata[symbol] = {"currency": currency, "source": history.get("source")}
        except Exception as exc:
            errors.append(f"{symbol}: {exc}")

    if len(prices_map) < 2:
        raise PortfolioValidationError("No se pudieron obtener al menos dos históricos comparables")

    prices = pd.concat(prices_map, axis=1).sort_index().ffill().dropna(how="all")
    returns = prices.pct_change(fill_method=None)
    normalized = prices.div(prices.iloc[0]).mul(100.0)
    rows: list[dict] = []
    for symbol in prices.columns:
        clean_prices = prices[symbol].dropna()
        clean_returns = returns[symbol].dropna()
        total_return = float(clean_prices.iloc[-1] / clean_prices.iloc[0] - 1.0)
        elapsed = max((clean_prices.index[-1] - clean_prices.index[0]).days, 1)
        annualized = (1 + total_return) ** (365.0 / elapsed) - 1.0 if total_return > -1 else -1.0
        volatility = float(clean_returns.std(ddof=1) * math.sqrt(TRADING_DAYS)) if len(clean_returns) >= 2 else 0.0
        wealth = (1 + clean_returns.fillna(0)).cumprod()
        drawdown = wealth / wealth.cummax() - 1
        tail = calculate_downside_and_tail_risk(
            clean_returns,
            annualized_return_percent=annualized * 100.0,
            risk_free_rate_percent=0.0,
            max_drawdown_percent=float(drawdown.min()) * 100.0 if not drawdown.empty else 0.0,
        )
        rows.append({
            "symbol": symbol,
            "currency": metadata[symbol]["currency"],
            "return_percent": _round(total_return * 100.0),
            "annualized_return_percent": _round(annualized * 100.0),
            "annualized_volatility_percent": _round(volatility * 100.0),
            "max_drawdown_percent": _round(float(drawdown.min()) * 100.0) if not drawdown.empty else 0.0,
            "sortino_ratio": tail["sortino_ratio"],
            "var_95_percent": tail["var"].get("95"),
            "cvar_95_percent": tail["cvar"].get("95"),
            "observations": int(len(clean_prices)),
            "source": metadata[symbol].get("source"),
        })

    correlation = returns[list(prices.columns)].corr(min_periods=2).fillna(0.0)
    points = [
        {
            "date": index.date().isoformat(),
            "values": {
                symbol: _round(normalized.loc[index, symbol])
                for symbol in normalized.columns
                if pd.notna(normalized.loc[index, symbol])
            },
        }
        for index in normalized.index
    ]
    return {
        "period": period,
        "base_currency": base_currency,
        "assets": rows,
        "points": points,
        "correlation_matrix": [
            {"symbol": row, "values": {column: _round(correlation.loc[row, column], 5) for column in correlation.columns}}
            for row in correlation.index
        ],
        "is_partial": bool(errors) or len(prices_map) < len(unique),
        "errors": errors,
        "methodology": "Precios convertidos a moneda base, normalizados a 100 y retornos diarios comparables.",
    }


def build_risk_summary(
    *,
    performance: dict,
    concentration: dict,
    advanced_risk: dict,
    covariance_risk: dict,
    benchmark_relationship: dict,
    sector_industry: dict,
    is_partial: bool,
) -> dict:
    flags: list[dict] = []

    def add(level: str, code: str, title: str, detail: str) -> None:
        flags.append({"level": level, "code": code, "title": title, "detail": detail})

    largest = float(concentration.get("largest_position_percent") or 0.0)
    if largest >= 50:
        add("high", "single_asset_concentration", "Concentración alta", f"La mayor posición representa {largest:.1f}% del patrimonio.")
    elif largest >= 30:
        add("medium", "single_asset_concentration", "Concentración relevante", f"La mayor posición representa {largest:.1f}% del patrimonio.")

    max_dd = abs(float(performance.get("max_drawdown_percent") or 0.0))
    if max_dd >= 30:
        add("high", "drawdown", "Drawdown profundo", f"El drawdown máximo histórico del período fue {max_dd:.1f}%.")
    elif max_dd >= 15:
        add("medium", "drawdown", "Drawdown significativo", f"El drawdown máximo histórico del período fue {max_dd:.1f}%.")

    var95 = float((advanced_risk.get("var") or {}).get("95") or 0.0)
    if var95 >= 4:
        add("high", "var95", "Pérdida diaria de cola elevada", f"El VaR histórico 95% es aproximadamente {var95:.2f}% diario.")
    elif var95 >= 2:
        add("medium", "var95", "Riesgo diario relevante", f"El VaR histórico 95% es aproximadamente {var95:.2f}% diario.")

    average_corr = covariance_risk.get("average_correlation")
    if average_corr is not None and float(average_corr) >= 0.75:
        add("medium", "correlation", "Diversificación limitada", f"La correlación media entre posiciones es {float(average_corr):.2f}.")

    top_risk = (covariance_risk.get("risk_contributions") or [{}])[0]
    top_risk_value = abs(float(top_risk.get("risk_contribution_percent") or 0.0))
    if top_risk_value >= 60:
        add("high", "risk_contribution", "Riesgo dominado por una posición", f"{top_risk.get('symbol', 'Una posición')} aporta {top_risk_value:.1f}% del riesgo estimado.")
    elif top_risk_value >= 40:
        add("medium", "risk_contribution", "Riesgo concentrado", f"{top_risk.get('symbol', 'Una posición')} aporta {top_risk_value:.1f}% del riesgo estimado.")

    beta = benchmark_relationship.get("beta")
    if beta is not None and float(beta) >= 1.3:
        add("medium", "beta", "Sensibilidad alta al benchmark", f"La beta estimada es {float(beta):.2f}.")

    coverage = float(sector_industry.get("classified_coverage_percent") or 0.0)
    if coverage < 70 and sector_industry.get("is_partial"):
        add("info", "sector_coverage", "Sectores incompletos", f"Sólo {coverage:.1f}% del valor invertido tiene sector clasificado.")
    if is_partial:
        add("info", "partial_data", "Datos parciales", "Algunas métricas se calcularon con menos activos o fechas por falta de datos.")

    severity_weights = {"high": 18, "medium": 9, "info": 2}
    score = max(0, 100 - sum(severity_weights.get(item["level"], 0) for item in flags))
    level = "low"
    if score < 55:
        level = "high"
    elif score < 78:
        level = "medium"

    return {
        "score": score,
        "level": level,
        "flags": flags,
        "headline": "Riesgo elevado" if level == "high" else "Riesgo moderado" if level == "medium" else "Riesgo controlado según las métricas disponibles",
        "future_ai_ready": True,
        "educational_only": True,
    }


def analytics_csv_report(data: dict) -> str:
    output = io.StringIO(newline="")
    writer = csv.writer(output)
    writer.writerow(["QuantLab AI - Reporte Analytics avanzado"])
    writer.writerow(["portfolio_id", data.get("portfolio_id")])
    writer.writerow(["period", data.get("period")])
    writer.writerow(["currency", data.get("currency")])
    writer.writerow(["last_updated", data.get("last_updated")])
    writer.writerow([])

    writer.writerow(["METRICA", "VALOR"])
    performance = data.get("performance") or {}
    advanced = data.get("advanced_risk") or {}
    benchmark = data.get("benchmark_relationship") or {}
    metric_rows = [
        ("Retorno período %", (performance.get("period_returns") or {}).get("selected_period_percent")),
        ("Retorno anualizado %", performance.get("annualized_return_percent")),
        ("Volatilidad anualizada %", performance.get("annualized_volatility_percent")),
        ("Sharpe", performance.get("sharpe_ratio")),
        ("Sortino", advanced.get("sortino_ratio")),
        ("Drawdown máximo %", performance.get("max_drawdown_percent")),
        ("VaR 95 diario %", (advanced.get("var") or {}).get("95")),
        ("CVaR 95 diario %", (advanced.get("cvar") or {}).get("95")),
        ("Beta", benchmark.get("beta")),
        ("Tracking error %", benchmark.get("tracking_error_percent")),
        ("Information ratio", benchmark.get("information_ratio")),
    ]
    writer.writerows(metric_rows)
    writer.writerow([])

    writer.writerow(["POSICION", "PESO %", "VOLATILIDAD %", "CONTRIBUCION AL RIESGO %"])
    for row in (data.get("covariance_risk") or {}).get("risk_contributions", []):
        writer.writerow([
            row.get("symbol"), row.get("weight_percent"), row.get("asset_volatility_percent"),
            row.get("risk_contribution_percent"),
        ])
    writer.writerow([])

    writer.writerow(["ACTIVO", "VALOR", "REALIZADO", "NO REALIZADO", "PRECIO", "FX", "DIVIDENDOS", "TOTAL"])
    for row in data.get("positions", []):
        writer.writerow([
            row.get("symbol"), row.get("market_value"), row.get("realized_pnl"),
            row.get("unrealized_pnl"), row.get("price_effect"), row.get("fx_effect"),
            row.get("dividends"), row.get("total_pnl"),
        ])
    writer.writerow([])

    writer.writerow(["ALERTA", "NIVEL", "DETALLE"])
    for flag in (data.get("risk_summary") or {}).get("flags", []):
        writer.writerow([flag.get("title"), flag.get("level"), flag.get("detail")])
    return output.getvalue()
