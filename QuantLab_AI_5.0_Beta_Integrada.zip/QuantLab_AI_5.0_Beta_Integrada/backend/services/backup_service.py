from __future__ import annotations

import hashlib
import io
import json
import os
import shutil
import sqlite3
import tempfile
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from backend.core.config import DATABASE_PATH, DATA_DIR, settings
from backend.core.database import SCHEMA_VERSION, get_connection, initialize_database


class BackupError(RuntimeError):
    """Raised when a backup is invalid or cannot be restored safely."""


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _safe_name(value: str) -> str:
    return "".join(ch if ch.isalnum() or ch in "-_." else "_" for ch in value)[:180]


def _snapshot_database(destination: Path) -> None:
    initialize_database()
    destination.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(DATABASE_PATH) as source, sqlite3.connect(destination) as target:
        source.backup(target)
        target.execute("PRAGMA wal_checkpoint(TRUNCATE)")


def _database_summary(path: Path) -> dict[str, Any]:
    with sqlite3.connect(path) as connection:
        connection.row_factory = sqlite3.Row
        check = connection.execute("PRAGMA quick_check").fetchone()
        if check is None or str(check[0]).lower() != "ok":
            raise BackupError("La base incluida no supera PRAGMA quick_check")
        tables = {
            str(row[0]) for row in connection.execute(
                "SELECT name FROM sqlite_master WHERE type='table'"
            ).fetchall()
        }
        required = {"portfolios", "portfolio_transactions", "portfolio_cash_movements"}
        missing = required - tables
        if missing:
            raise BackupError(f"El backup no contiene las tablas requeridas: {', '.join(sorted(missing))}")
        schema_row = connection.execute(
            "SELECT MAX(version) FROM schema_migrations"
        ).fetchone() if "schema_migrations" in tables else (0,)
        schema_version = int(schema_row[0] or 0)
        counts = {}
        for table in (
            "portfolios", "portfolio_transactions", "portfolio_cash_movements",
            "portfolio_fx_conversions", "portfolio_assets", "watchlist",
            "ai_analysis_sessions", "ai_analysis_messages", "ai_tool_runs",
        ):
            counts[table] = int(connection.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]) if table in tables else 0
    return {"schema_version": schema_version, "counts": counts, "quick_check": "ok"}


def create_backup(note: str = "", backup_type: str = "manual") -> dict:
    backup_dir = DATA_DIR / "backups"
    backup_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    filename = f"QuantLab_backup_{stamp}.qlbackup"
    archive_path = backup_dir / filename
    with tempfile.TemporaryDirectory(prefix="quantlab_backup_") as temp_dir:
        snapshot = Path(temp_dir) / "quantlab.db"
        _snapshot_database(snapshot)
        db_bytes = snapshot.read_bytes()
        summary = _database_summary(snapshot)
        manifest = {
            "format": "quantlab-backup-v1",
            "app_version": settings.version,
            "schema_version": summary["schema_version"],
            "created_at": datetime.now(timezone.utc).isoformat(),
            "database_file": "quantlab.db",
            "database_sha256": _sha256(db_bytes),
            "database_size": len(db_bytes),
            "backup_type": backup_type,
            "note": note.strip()[:240],
            "counts": summary["counts"],
        }
        with zipfile.ZipFile(archive_path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            archive.writestr("manifest.json", json.dumps(manifest, ensure_ascii=False, indent=2))
            archive.writestr("quantlab.db", db_bytes)
    with get_connection() as connection:
        connection.execute(
            """
            INSERT INTO backup_history
                (filename, backup_type, schema_version, size_bytes, checksum_sha256, note, action)
            VALUES (?, ?, ?, ?, ?, ?, 'CREATE')
            """,
            (
                filename, backup_type, manifest["schema_version"], archive_path.stat().st_size,
                _sha256(archive_path.read_bytes()), manifest["note"],
            ),
        )
    return {**manifest, "filename": filename, "archive_size": archive_path.stat().st_size, "download_url": f"/api/data/backups/{filename}"}


def validate_backup_bytes(raw: bytes, filename: str = "backup.qlbackup") -> dict:
    if not raw:
        raise BackupError("El archivo de backup está vacío")
    if len(raw) > settings.max_backup_bytes:
        raise BackupError(
            f"El backup supera el límite de {settings.max_backup_bytes // (1024 * 1024)} MB"
        )
    try:
        with zipfile.ZipFile(io.BytesIO(raw)) as archive:
            names = set(archive.namelist())
            if not {"manifest.json", "quantlab.db"}.issubset(names):
                raise BackupError("El archivo no es un backup QuantLab válido")
            if any(name.startswith("/") or ".." in Path(name).parts for name in names):
                raise BackupError("El backup contiene rutas inseguras")
            manifest = json.loads(archive.read("manifest.json").decode("utf-8"))
            db_bytes = archive.read("quantlab.db")
    except (zipfile.BadZipFile, json.JSONDecodeError, UnicodeDecodeError) as exc:
        raise BackupError("El archivo de backup está dañado o tiene un formato inválido") from exc
    if manifest.get("format") != "quantlab-backup-v1":
        raise BackupError("Versión de formato de backup no reconocida")
    if _sha256(db_bytes) != manifest.get("database_sha256"):
        raise BackupError("El checksum de la base no coincide con el manifiesto")
    with tempfile.TemporaryDirectory(prefix="quantlab_validate_") as temp_dir:
        db_path = Path(temp_dir) / "quantlab.db"
        db_path.write_bytes(db_bytes)
        summary = _database_summary(db_path)
    if summary["schema_version"] > SCHEMA_VERSION:
        raise BackupError(
            f"El backup usa el esquema {summary['schema_version']}, superior al soportado ({SCHEMA_VERSION})"
        )
    return {
        "valid": True,
        "filename": _safe_name(filename),
        "format": manifest["format"],
        "created_at": manifest.get("created_at"),
        "app_version": manifest.get("app_version"),
        "schema_version": summary["schema_version"],
        "will_migrate": summary["schema_version"] < SCHEMA_VERSION,
        "database_size": len(db_bytes),
        "counts": summary["counts"],
        "note": manifest.get("note", ""),
        "database_sha256": manifest["database_sha256"],
    }


def _extract_database(raw: bytes, destination: Path) -> None:
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        destination.write_bytes(archive.read("quantlab.db"))


def restore_backup(raw: bytes, filename: str, confirmation: str) -> dict:
    if confirmation.strip().upper() != "RESTAURAR":
        raise BackupError("Escribí RESTAURAR para confirmar la restauración")
    validation = validate_backup_bytes(raw, filename)
    safety = create_backup("Backup automático previo a una restauración", "pre_restore")
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    temp_path = DATABASE_PATH.with_suffix(".restore.tmp")
    old_copy = DATABASE_PATH.with_suffix(".before_restore.tmp")
    if DATABASE_PATH.exists():
        shutil.copy2(DATABASE_PATH, old_copy)
    try:
        _extract_database(raw, temp_path)
        for suffix in ("-wal", "-shm"):
            Path(str(DATABASE_PATH) + suffix).unlink(missing_ok=True)
        os.replace(temp_path, DATABASE_PATH)
        initialize_database()
        with sqlite3.connect(DATABASE_PATH) as connection:
            result = connection.execute("PRAGMA quick_check").fetchone()
            if result is None or str(result[0]).lower() != "ok":
                raise BackupError("La base restaurada no supera la verificación final")
        with get_connection() as connection:
            connection.execute(
                """
                INSERT INTO backup_history
                    (filename, backup_type, schema_version, size_bytes, checksum_sha256, note, action)
                VALUES (?, 'restore', ?, ?, ?, ?, 'RESTORE')
                """,
                (
                    _safe_name(filename), validation["schema_version"], len(raw), _sha256(raw),
                    f"Restaurado; backup de seguridad: {safety['filename']}",
                ),
            )
    except Exception:
        if old_copy.exists():
            os.replace(old_copy, DATABASE_PATH)
            initialize_database()
        raise
    finally:
        temp_path.unlink(missing_ok=True)
        old_copy.unlink(missing_ok=True)
    return {
        "restored": True,
        "source": validation,
        "safety_backup": safety,
        "current_schema_version": SCHEMA_VERSION,
        "message": "Backup restaurado y migraciones aplicadas correctamente",
    }


def list_backups() -> list[dict]:
    backup_dir = DATA_DIR / "backups"
    backup_dir.mkdir(parents=True, exist_ok=True)
    history: dict[str, dict] = {}
    with get_connection() as connection:
        rows = connection.execute(
            """
            SELECT id, filename, backup_type, schema_version, size_bytes, checksum_sha256,
                   note, action, created_at FROM backup_history ORDER BY id DESC
            """
        ).fetchall()
        history = {str(row["filename"]): dict(row) for row in rows}
    items: list[dict] = []
    for path in backup_dir.iterdir():
        if not path.is_file() or path.suffix not in {".qlbackup", ".db"}:
            continue
        item = history.get(path.name, {})
        item.update({
            "filename": path.name,
            "size_bytes": path.stat().st_size,
            "created_at": item.get("created_at") or datetime.fromtimestamp(path.stat().st_mtime, timezone.utc).isoformat(),
            "downloadable": path.suffix == ".qlbackup",
            "download_url": f"/api/data/backups/{path.name}" if path.suffix == ".qlbackup" else None,
            "backup_type": item.get("backup_type") or ("migration" if path.suffix == ".db" else "manual"),
        })
        items.append(item)
    return sorted(items, key=lambda item: str(item["created_at"]), reverse=True)


def backup_path(filename: str) -> Path:
    safe = _safe_name(filename)
    if safe != filename or not safe.endswith(".qlbackup"):
        raise BackupError("Nombre de backup inválido")
    path = DATA_DIR / "backups" / safe
    if not path.exists() or not path.is_file():
        raise BackupError("El backup solicitado no existe")
    return path
