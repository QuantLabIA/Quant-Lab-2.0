from __future__ import annotations

import csv
import hashlib
import io
import json
import os
import sqlite3
import tempfile
from pathlib import Path
from datetime import date, datetime, timezone
from typing import Any, Callable

from pydantic import ValidationError

from backend.core.config import DATABASE_PATH, settings
from backend.core.database import get_connection, initialize_database
from backend.models import (
    PortfolioCashMovementCreate,
    PortfolioFxConversionCreate,
    PortfolioTransactionCreate,
    PortfolioCorporateActionCreate,
)
from backend.services.dividends_service import list_dividends
from backend.services.corporate_actions_service import (
    _candidate as _corporate_action_candidate,
    create_corporate_action,
    list_corporate_actions,
)
from backend.services.portfolio_service import (
    PortfolioValidationError,
    _calculate_for_portfolio,
    _fx_conversion_candidate,
    _load_fx_rate,
    create_cash_movement,
    create_fx_conversion,
    create_portfolio_transaction,
    get_portfolio_asset,
    get_portfolio_overview,
    get_portfolio_settings,
    list_cash_movements,
    list_fx_conversions,
    list_portfolio_transactions,
)

CSV_COLUMNS = [
    "record_type", "occurred_at", "symbol", "transaction_type", "quantity", "price",
    "fees", "movement_type", "amount", "currency", "pricing_mode", "asset_name",
    "asset_type", "asset_currency", "exchange", "fx_rate_to_base", "from_currency",
    "to_currency", "from_amount", "exchange_rate", "fee_amount", "fee_currency",
    "from_fx_rate_to_base", "to_fx_rate_to_base", "action_type", "target_symbol",
    "quantity_ratio", "cost_allocation_percent", "cash_amount", "cash_currency",
    "target_name", "target_asset_type", "target_currency", "target_exchange", "source", "notes",
]
SUPPORTED_RECORD_TYPES = {"TRANSACTION", "CASH_MOVEMENT", "FX_CONVERSION", "CORPORATE_ACTION"}


class CsvImportError(PortfolioValidationError):
    """Raised when a CSV file cannot be safely processed."""


def _clean(value: Any) -> str:
    return str(value or "").strip()


def _optional_float(value: Any) -> float | None:
    text = _clean(value)
    if not text:
        return None
    normalized = text.replace(" ", "")
    if "," in normalized and "." not in normalized:
        normalized = normalized.replace(",", ".")
    try:
        return float(normalized)
    except ValueError as exc:
        raise CsvImportError(f"Número inválido: {text}") from exc


def _required_float(value: Any, label: str) -> float:
    parsed = _optional_float(value)
    if parsed is None:
        raise CsvImportError(f"Falta {label}")
    return parsed


def _parse_date(value: Any) -> datetime:
    text = _clean(value)
    if not text:
        raise CsvImportError("Falta occurred_at")
    candidates = [
        text,
        text.replace("Z", "+00:00"),
    ]
    for candidate in candidates:
        try:
            parsed = datetime.fromisoformat(candidate)
            if parsed.tzinfo is None:
                parsed = parsed.replace(tzinfo=timezone.utc)
            return parsed.astimezone(timezone.utc)
        except ValueError:
            pass
    for pattern in ("%d/%m/%Y %H:%M", "%d/%m/%Y", "%Y-%m-%d %H:%M"):
        try:
            return datetime.strptime(text, pattern).replace(tzinfo=timezone.utc)
        except ValueError:
            pass
    raise CsvImportError(f"Fecha inválida: {text}")


def _sniff_dialect(content: str) -> csv.Dialect:
    sample = content[:4096]
    try:
        return csv.Sniffer().sniff(sample, delimiters=",;\t")
    except csv.Error:
        return csv.excel


def parse_csv(content: str) -> list[dict[str, str]]:
    if len(content.encode("utf-8")) > settings.max_csv_bytes:
        raise CsvImportError(
            f"El CSV supera el límite de {settings.max_csv_bytes // (1024 * 1024)} MB"
        )
    content = content.lstrip("\ufeff")
    if not content.strip():
        raise CsvImportError("El archivo CSV está vacío")
    reader = csv.DictReader(io.StringIO(content), dialect=_sniff_dialect(content))
    if not reader.fieldnames:
        raise CsvImportError("El CSV no contiene encabezados")
    normalized_fields = [_clean(field).lower() for field in reader.fieldnames]
    if "record_type" not in normalized_fields:
        raise CsvImportError("Falta la columna obligatoria record_type")
    rows: list[dict[str, str]] = []
    for raw in reader:
        normalized = {
            _clean(key).lower(): _clean(value)
            for key, value in raw.items()
            if key is not None
        }
        if not any(normalized.values()):
            continue
        rows.append(normalized)
    if not rows:
        raise CsvImportError("El CSV no contiene filas de datos")
    if len(rows) > settings.max_csv_rows:
        raise CsvImportError(f"El CSV supera el límite de {settings.max_csv_rows} filas")
    return rows


def _fingerprint(record_type: str, payload: dict[str, Any]) -> str:
    ignored = {"notes", "asset_name", "exchange"}
    canonical = {
        key: value.isoformat() if isinstance(value, datetime) else value
        for key, value in payload.items()
        if key not in ignored and value not in (None, "")
    }
    raw = json.dumps(
        {"record_type": record_type, "payload": canonical},
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _existing_fingerprints(portfolio_id: int) -> set[str]:
    fingerprints: set[str] = set()
    with get_connection() as connection:
        for table in (
            "portfolio_transactions", "portfolio_cash_movements", "portfolio_fx_conversions",
            "portfolio_corporate_actions",
        ):
            rows = connection.execute(
                f"SELECT import_fingerprint FROM {table} "
                "WHERE portfolio_id = ? AND is_deleted = 0 AND import_fingerprint IS NOT NULL",
                (portfolio_id,),
            ).fetchall()
            fingerprints.update(str(row[0]) for row in rows if row[0])
    for item in list_portfolio_transactions(portfolio_id=portfolio_id, include_deleted=False):
        payload = {
            "symbol": item["symbol"], "transaction_type": item["transaction_type"],
            "quantity": item["quantity"], "price": item["price"], "fees": item["fees"],
            "occurred_at": _parse_date(item["occurred_at"]), "pricing_mode": item["pricing_mode"],
            "asset_type": item["asset_type"], "asset_currency": item["asset_currency"],
            "fx_rate_to_base": item["fx_rate_to_base"],
        }
        fingerprints.add(_fingerprint("TRANSACTION", payload))
    for item in list_cash_movements(portfolio_id=portfolio_id, include_deleted=False):
        payload = {
            "movement_type": item["movement_type"], "amount": item["amount"],
            "currency": item["currency"], "symbol": item.get("symbol"),
            "occurred_at": _parse_date(item["occurred_at"]),
            "fx_rate_to_base": item["fx_rate_to_base"],
        }
        fingerprints.add(_fingerprint("CASH_MOVEMENT", payload))
    for item in list_fx_conversions(portfolio_id=portfolio_id, include_deleted=False):
        payload = {
            "from_currency": item["from_currency"], "to_currency": item["to_currency"],
            "from_amount": item["from_amount"], "exchange_rate": item["exchange_rate"],
            "pricing_mode": item["pricing_mode"], "fee_amount": item["fee_amount"],
            "fee_currency": item.get("fee_currency"),
            "occurred_at": _parse_date(item["occurred_at"]),
            "from_fx_rate_to_base": item["from_fx_rate_to_base"],
            "to_fx_rate_to_base": item["to_fx_rate_to_base"],
        }
        fingerprints.add(_fingerprint("FX_CONVERSION", payload))
    for item in list_corporate_actions(portfolio_id=portfolio_id, include_deleted=False):
        payload = {
            "action_type": item["action_type"], "symbol": item["symbol"],
            "target_symbol": item.get("target_symbol"),
            "quantity_ratio": item["quantity_ratio"],
            "cost_allocation_percent": item["cost_allocation_percent"],
            "cash_amount": item["cash_amount"], "cash_currency": item.get("cash_currency"),
            "fx_rate_to_base": item.get("fx_rate_to_base"),
            "target_name": item.get("target_name", ""),
            "target_asset_type": item.get("target_asset_type", "EQUITY"),
            "target_currency": item.get("target_currency"),
            "target_exchange": item.get("target_exchange", ""),
            "occurred_at": _parse_date(item["occurred_at"]),
            "source": item.get("source", "IMPORT"),
        }
        fingerprints.add(_fingerprint("CORPORATE_ACTION", payload))
    return fingerprints


def _transaction_payload(row: dict[str, str]) -> PortfolioTransactionCreate:
    asset_currency = _clean(row.get("asset_currency") or row.get("currency")).upper() or None
    pricing_mode = _clean(row.get("pricing_mode")).upper() or ("MANUAL" if asset_currency else "AUTO")
    return PortfolioTransactionCreate(
        symbol=row.get("symbol", ""),
        transaction_type=_clean(row.get("transaction_type")).upper(),
        quantity=_required_float(row.get("quantity"), "quantity"),
        price=_required_float(row.get("price"), "price"),
        fees=_optional_float(row.get("fees")) or 0,
        occurred_at=_parse_date(row.get("occurred_at")),
        notes=row.get("notes", ""),
        pricing_mode=pricing_mode,
        asset_name=row.get("asset_name") or None,
        asset_type=row.get("asset_type") or None,
        asset_currency=asset_currency,
        exchange=row.get("exchange") or None,
        fx_rate_to_base=_optional_float(row.get("fx_rate_to_base")),
    )


def _cash_payload(row: dict[str, str]) -> PortfolioCashMovementCreate:
    return PortfolioCashMovementCreate(
        movement_type=_clean(row.get("movement_type")).upper(),
        amount=_required_float(row.get("amount"), "amount"),
        currency=_clean(row.get("currency")).upper(),
        symbol=row.get("symbol") or None,
        occurred_at=_parse_date(row.get("occurred_at")),
        notes=row.get("notes", ""),
        fx_rate_to_base=_optional_float(row.get("fx_rate_to_base")),
    )


def _fx_payload(row: dict[str, str]) -> PortfolioFxConversionCreate:
    return PortfolioFxConversionCreate(
        from_currency=_clean(row.get("from_currency")).upper(),
        to_currency=_clean(row.get("to_currency")).upper(),
        from_amount=_required_float(row.get("from_amount"), "from_amount"),
        exchange_rate=_optional_float(row.get("exchange_rate")),
        pricing_mode=_clean(row.get("pricing_mode")).upper() or "MANUAL",
        fee_amount=_optional_float(row.get("fee_amount")) or 0,
        fee_currency=row.get("fee_currency") or None,
        occurred_at=_parse_date(row.get("occurred_at")),
        notes=row.get("notes", ""),
        from_fx_rate_to_base=_optional_float(row.get("from_fx_rate_to_base")),
        to_fx_rate_to_base=_optional_float(row.get("to_fx_rate_to_base")),
    )


def _corporate_payload(row: dict[str, str]) -> PortfolioCorporateActionCreate:
    return PortfolioCorporateActionCreate(
        action_type=_clean(row.get("action_type")).upper(),
        symbol=row.get("symbol", ""),
        target_symbol=row.get("target_symbol") or None,
        quantity_ratio=_optional_float(row.get("quantity_ratio")) or 1.0,
        cost_allocation_percent=_optional_float(row.get("cost_allocation_percent")) or 0,
        cash_amount=_optional_float(row.get("cash_amount")) or 0,
        cash_currency=row.get("cash_currency") or None,
        fx_rate_to_base=_optional_float(row.get("fx_rate_to_base")),
        target_name=row.get("target_name", ""),
        target_asset_type=row.get("target_asset_type") or "EQUITY",
        target_currency=row.get("target_currency") or None,
        target_exchange=row.get("target_exchange", ""),
        occurred_at=_parse_date(row.get("occurred_at")),
        notes=row.get("notes", ""),
        source=_clean(row.get("source")).upper() or "IMPORT",
    )


def _candidate_transaction(
    payload: PortfolioTransactionCreate,
    portfolio_id: int,
    quote_loader: Callable[[str], dict | None] | None,
    fx_loader: Callable[[str, str, datetime | date | None], dict] | None,
    settings_data: dict,
) -> dict:
    if payload.occurred_at > datetime.now(timezone.utc).replace(microsecond=0):
        raise CsvImportError("La fecha de la operación no puede estar en el futuro")
    existing = get_portfolio_asset(payload.symbol, portfolio_id)
    if payload.pricing_mode == "AUTO":
        quote = quote_loader(payload.symbol) if quote_loader else None
        if quote is None and existing is None:
            raise CsvImportError(
                f"No se encontró {payload.symbol}; indicá asset_currency y pricing_mode=MANUAL"
            )
        source = quote or existing or {}
        asset = {
            "name": source.get("name") or payload.asset_name or payload.symbol,
            "asset_type": source.get("asset_type") or payload.asset_type or "OTHER",
            "currency": str(source.get("currency") or payload.asset_currency or settings_data["base_currency"]).upper(),
            "exchange": source.get("exchange") or source.get("market") or payload.exchange or "",
            "pricing_mode": "AUTO",
        }
    else:
        asset = {
            "name": payload.asset_name or (existing or {}).get("name") or payload.symbol,
            "asset_type": (payload.asset_type or (existing or {}).get("asset_type") or "OTHER").upper(),
            "currency": payload.asset_currency or (existing or {}).get("currency") or settings_data["base_currency"],
            "exchange": payload.exchange or (existing or {}).get("exchange") or "Manual",
            "pricing_mode": "MANUAL",
        }
    fx_rate = _load_fx_rate(
        asset["currency"], settings_data["base_currency"], payload.occurred_at,
        payload.fx_rate_to_base, fx_loader,
    )
    return {
        "portfolio_id": portfolio_id, "symbol": payload.symbol,
        "transaction_type": payload.transaction_type, "quantity": payload.quantity,
        "price": payload.price, "fees": payload.fees, "asset_name": asset["name"],
        "asset_type": asset["asset_type"], "asset_currency": asset["currency"],
        "exchange": asset["exchange"], "pricing_mode": asset["pricing_mode"],
        "fx_rate_to_base": fx_rate, "occurred_at": payload.occurred_at.isoformat(),
        "notes": payload.notes,
    }


def _candidate_cash(
    payload: PortfolioCashMovementCreate,
    portfolio_id: int,
    fx_loader: Callable[[str, str, datetime | date | None], dict] | None,
    settings_data: dict,
) -> dict:
    if payload.occurred_at > datetime.now(timezone.utc).replace(microsecond=0):
        raise CsvImportError("La fecha del movimiento no puede estar en el futuro")
    fx_rate = _load_fx_rate(
        payload.currency, settings_data["base_currency"], payload.occurred_at,
        payload.fx_rate_to_base, fx_loader,
    )
    return {
        "portfolio_id": portfolio_id, "movement_type": payload.movement_type,
        "amount": payload.amount, "currency": payload.currency,
        "fx_rate_to_base": fx_rate, "symbol": payload.symbol,
        "occurred_at": payload.occurred_at.isoformat(), "notes": payload.notes,
    }


def preview_csv_import(
    content: str,
    portfolio_id: int,
    quote_loader: Callable[[str], dict | None] | None = None,
    fx_loader: Callable[[str, str, datetime | date | None], dict] | None = None,
    *,
    skip_duplicates: bool = True,
) -> dict:
    settings_data = get_portfolio_settings(portfolio_id)
    source_rows = parse_csv(content)
    existing_fingerprints = _existing_fingerprints(portfolio_id)
    file_fingerprints: set[str] = set()
    reports: list[dict[str, Any]] = []
    candidates: list[dict[str, Any]] = []
    quote_cache: dict[str, dict | None] = {}
    fx_cache: dict[tuple[str, str, str], dict] = {}

    def cached_quote(symbol: str) -> dict | None:
        key = symbol.upper()
        if key not in quote_cache:
            quote_cache[key] = quote_loader(key) if quote_loader else None
        return quote_cache[key]

    def cached_fx(source: str, target: str, occurred_at=None) -> dict:
        date_key = _parse_date(occurred_at).date().isoformat() if occurred_at else "current"
        key = (source.upper(), target.upper(), date_key)
        if key not in fx_cache:
            if fx_loader is None:
                raise CsvImportError(f"No hay proveedor FX para {source}/{target}")
            fx_cache[key] = fx_loader(source, target, occurred_at)
        return fx_cache[key]

    for row_number, row in enumerate(source_rows, start=2):
        record_type = _clean(row.get("record_type")).upper()
        report: dict[str, Any] = {
            "row_number": row_number, "record_type": record_type or "UNKNOWN",
            "status": "rejected", "message": "", "normalized": None,
        }
        try:
            if record_type not in SUPPORTED_RECORD_TYPES:
                raise CsvImportError(
                    f"record_type debe ser: {', '.join(sorted(SUPPORTED_RECORD_TYPES))}"
                )
            if record_type == "TRANSACTION":
                model = _transaction_payload(row)
                candidate = _candidate_transaction(model, portfolio_id, cached_quote, cached_fx, settings_data)
            elif record_type == "CASH_MOVEMENT":
                model = _cash_payload(row)
                candidate = _candidate_cash(model, portfolio_id, cached_fx, settings_data)
            elif record_type == "FX_CONVERSION":
                model = _fx_payload(row)
                candidate = _fx_conversion_candidate(model, settings_data, cached_fx)
            else:
                model = _corporate_payload(row)
                candidate = _corporate_action_candidate(
                    model, settings_data, portfolio_id, cached_quote, cached_fx
                )
            payload_data = model.model_dump()
            fingerprint = _fingerprint(record_type, payload_data)
            if fingerprint in existing_fingerprints or fingerprint in file_fingerprints:
                report.update({
                    "status": "duplicate", "message": "Registro duplicado; no se importará",
                    "normalized": payload_data, "fingerprint": fingerprint,
                })
                if not skip_duplicates:
                    report["status"] = "rejected"
                reports.append(report)
                continue
            file_fingerprints.add(fingerprint)
            candidates.append({
                "row_number": row_number, "record_type": record_type,
                "model": model, "candidate": candidate, "fingerprint": fingerprint,
                "report": report,
            })
        except (CsvImportError, PortfolioValidationError, ValidationError, ValueError) as exc:
            report["message"] = str(exc)
            reports.append(report)

    transactions = list_portfolio_transactions(ascending=True, portfolio_id=portfolio_id)
    movements = list_cash_movements(ascending=True, portfolio_id=portfolio_id)
    conversions = list_fx_conversions(ascending=True, portfolio_id=portfolio_id)
    corporate_actions = list_corporate_actions(portfolio_id, ascending=True)
    next_ids = {
        "TRANSACTION": max((int(item["id"]) for item in transactions), default=0) + 1,
        "CASH_MOVEMENT": max((int(item["id"]) for item in movements), default=0) + 1,
        "FX_CONVERSION": max((int(item["id"]) for item in conversions), default=0) + 1,
        "CORPORATE_ACTION": max((int(item["id"]) for item in corporate_actions), default=0) + 1,
    }
    priority = {"CASH_MOVEMENT": 0, "FX_CONVERSION": 1, "CORPORATE_ACTION": 2, "TRANSACTION": 3}
    candidates.sort(
        key=lambda item: (
            _parse_date(item["candidate"]["occurred_at"]),
            priority[item["record_type"]], item["row_number"],
        )
    )
    for item in candidates:
        record_type = item["record_type"]
        candidate = dict(item["candidate"])
        candidate["id"] = next_ids[record_type]
        next_ids[record_type] += 1
        try:
            next_transactions = [*transactions, candidate] if record_type == "TRANSACTION" else transactions
            next_movements = [*movements, candidate] if record_type == "CASH_MOVEMENT" else movements
            next_conversions = [*conversions, candidate] if record_type == "FX_CONVERSION" else conversions
            next_actions = [*corporate_actions, candidate] if record_type == "CORPORATE_ACTION" else corporate_actions
            _calculate_for_portfolio(
                settings_data, next_transactions, next_movements, next_conversions, next_actions
            )
            transactions, movements, conversions, corporate_actions = (
                next_transactions, next_movements, next_conversions, next_actions
            )
            item["report"].update({
                "status": "accepted", "message": "Fila válida",
                "normalized": item["model"].model_dump(),
                "fingerprint": item["fingerprint"],
            })
        except PortfolioValidationError as exc:
            item["report"]["message"] = str(exc)
        reports.append(item["report"])

    reports.sort(key=lambda item: item["row_number"])
    counts = {
        status: sum(1 for item in reports if item["status"] == status)
        for status in ("accepted", "rejected", "duplicate")
    }
    return {
        "portfolio_id": portfolio_id,
        "schema": "quantlab-generic-csv-v1",
        "total_rows": len(reports),
        **counts,
        "can_commit": counts["accepted"] > 0,
        "rows": reports,
    }


def _record_import_metadata(
    table: str, entity_id: int, portfolio_id: int, batch_id: int,
    row_number: int, fingerprint: str,
) -> None:
    with get_connection() as connection:
        connection.execute(
            f"""
            UPDATE {table}
            SET import_fingerprint = ?, import_batch_id = ?, import_row_number = ?
            WHERE id = ? AND portfolio_id = ?
            """,
            (fingerprint, batch_id, row_number, entity_id, portfolio_id),
        )


def commit_csv_import(
    content: str,
    filename: str,
    portfolio_id: int,
    quote_loader: Callable[[str], dict | None] | None = None,
    fx_loader: Callable[[str, str, datetime | date | None], dict] | None = None,
    *,
    import_valid_only: bool = True,
    skip_duplicates: bool = True,
    adapter: str = "generic",
) -> dict:
    preview = preview_csv_import(
        content, portfolio_id, quote_loader, fx_loader, skip_duplicates=skip_duplicates
    )
    if preview["rejected"] and not import_valid_only:
        raise CsvImportError(
            "La importación fue cancelada porque existen filas rechazadas y el modo parcial está desactivado"
        )
    file_hash = hashlib.sha256(content.encode("utf-8")).hexdigest()
    strict_snapshot: str | None = None
    if not import_valid_only:
        handle = tempfile.NamedTemporaryFile(prefix="quantlab_strict_import_", suffix=".db", delete=False)
        strict_snapshot = handle.name
        handle.close()
        with sqlite3.connect(DATABASE_PATH) as source, sqlite3.connect(strict_snapshot) as target:
            source.backup(target)

    with get_connection() as connection:
        cursor = connection.execute(
            """
            INSERT INTO portfolio_import_batches
                (portfolio_id, filename, adapter, file_sha256, status, total_rows,
                 accepted_rows, rejected_rows, duplicate_rows, report_json)
            VALUES (?, ?, ?, ?, 'PROCESSING', ?, 0, ?, ?, ?)
            """,
            (
                portfolio_id, filename[:240], adapter[:40], file_hash, preview["total_rows"],
                preview["rejected"], preview["duplicate"], json.dumps(preview, default=str),
            ),
        )
        batch_id = int(cursor.lastrowid)

    committed: list[dict[str, Any]] = []
    failed: list[dict[str, Any]] = []
    quote_cache: dict[str, dict | None] = {}
    fx_cache: dict[tuple[str, str, str], dict] = {}

    def cached_quote(symbol: str) -> dict | None:
        key = symbol.upper()
        if key not in quote_cache:
            quote_cache[key] = quote_loader(key) if quote_loader else None
        return quote_cache[key]

    def cached_fx(source: str, target: str, occurred_at=None) -> dict:
        date_key = _parse_date(occurred_at).date().isoformat() if occurred_at else "current"
        key = (source.upper(), target.upper(), date_key)
        if key not in fx_cache:
            if fx_loader is None:
                raise CsvImportError(f"No hay proveedor FX para {source}/{target}")
            fx_cache[key] = fx_loader(source, target, occurred_at)
        return fx_cache[key]

    accepted_rows = [row for row in preview["rows"] if row["status"] == "accepted"]
    commit_priority = {"CASH_MOVEMENT": 0, "FX_CONVERSION": 1, "CORPORATE_ACTION": 2, "TRANSACTION": 3}
    accepted_rows.sort(
        key=lambda row: (
            _parse_date(row["normalized"]["occurred_at"]),
            commit_priority[row["record_type"]], row["row_number"],
        )
    )
    for row in accepted_rows:
        try:
            if row["record_type"] == "TRANSACTION":
                created = create_portfolio_transaction(
                    PortfolioTransactionCreate.model_validate(row["normalized"]),
                    cached_quote, cached_fx, portfolio_id,
                )
                table = "portfolio_transactions"
            elif row["record_type"] == "CASH_MOVEMENT":
                created = create_cash_movement(
                    PortfolioCashMovementCreate.model_validate(row["normalized"]),
                    cached_fx, portfolio_id,
                )
                table = "portfolio_cash_movements"
            elif row["record_type"] == "FX_CONVERSION":
                created = create_fx_conversion(
                    PortfolioFxConversionCreate.model_validate(row["normalized"]),
                    cached_fx, portfolio_id,
                )
                table = "portfolio_fx_conversions"
            else:
                created = create_corporate_action(
                    PortfolioCorporateActionCreate.model_validate(row["normalized"]),
                    cached_quote, cached_fx, portfolio_id,
                )
                table = "portfolio_corporate_actions"
            _record_import_metadata(
                table, int(created["id"]), portfolio_id, batch_id,
                int(row["row_number"]), str(row["fingerprint"]),
            )
            committed.append({
                "row_number": row["row_number"], "record_type": row["record_type"],
                "entity_id": created["id"], "status": "imported",
            })
        except Exception as exc:  # Keep a complete partial-import report.
            failed.append({
                "row_number": row["row_number"], "record_type": row["record_type"],
                "status": "rejected", "message": str(exc),
            })

    if failed and not import_valid_only and strict_snapshot:
        for suffix in ("-wal", "-shm"):
            Path(str(DATABASE_PATH) + suffix).unlink(missing_ok=True)
        os.replace(strict_snapshot, DATABASE_PATH)
        strict_snapshot = None
        initialize_database()
        raise CsvImportError(
            "La importación estricta falló durante la confirmación y todos sus cambios fueron revertidos"
        )

    if strict_snapshot:
        Path(strict_snapshot).unlink(missing_ok=True)

    final_status = (
        "COMPLETED" if committed and not failed
        else "PARTIAL" if committed
        else "FAILED"
    )
    final_report = {**preview, "batch_id": batch_id, "committed": committed, "commit_failures": failed}
    with get_connection() as connection:
        connection.execute(
            """
            UPDATE portfolio_import_batches
            SET status = ?, accepted_rows = ?, rejected_rows = ?, report_json = ?,
                committed_at = CURRENT_TIMESTAMP
            WHERE id = ? AND portfolio_id = ?
            """,
            (
                final_status, len(committed), preview["rejected"] + len(failed),
                json.dumps(final_report, ensure_ascii=False, default=str), batch_id, portfolio_id,
            ),
        )
        connection.execute(
            """
            INSERT INTO portfolio_activity_log
                (portfolio_id, action, entity_type, entity_id, details)
            VALUES (?, 'IMPORT_CSV', 'import_batch', ?, ?)
            """,
            (portfolio_id, str(batch_id), f"{filename}: {len(committed)} filas importadas"),
        )
    return final_report


def list_import_batches(portfolio_id: int, limit: int = 50) -> list[dict]:
    get_portfolio_settings(portfolio_id)
    safe_limit = max(1, min(int(limit), 200))
    with get_connection() as connection:
        rows = connection.execute(
            """
            SELECT id, portfolio_id, filename, adapter, file_sha256, status, total_rows,
                   accepted_rows, rejected_rows, duplicate_rows, created_at, committed_at
            FROM portfolio_import_batches
            WHERE portfolio_id = ? ORDER BY id DESC LIMIT ?
            """,
            (portfolio_id, safe_limit),
        ).fetchall()
    return [dict(row) for row in rows]


def _csv_text(rows: list[dict[str, Any]], columns: list[str]) -> str:
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=columns, extrasaction="ignore")
    writer.writeheader()
    for row in rows:
        writer.writerow({key: row.get(key, "") for key in columns})
    return "\ufeff" + output.getvalue()


def generic_template_csv() -> str:
    now = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
    rows = [
        {
            "record_type": "CASH_MOVEMENT", "occurred_at": now,
            "movement_type": "DEPOSIT", "amount": 1000, "currency": "USD",
            "fx_rate_to_base": 1, "notes": "Ejemplo: aporte de fondos",
        },
        {
            "record_type": "TRANSACTION", "occurred_at": now, "symbol": "AAPL",
            "transaction_type": "BUY", "quantity": 1, "price": 200, "fees": 1,
            "pricing_mode": "AUTO", "asset_currency": "USD", "fx_rate_to_base": 1,
            "notes": "Ejemplo: compra",
        },
        {
            "record_type": "CORPORATE_ACTION", "occurred_at": now, "symbol": "AAPL",
            "action_type": "SPLIT", "quantity_ratio": 2, "source": "IMPORT",
            "notes": "Ejemplo: split 2:1",
        },
        {
            "record_type": "FX_CONVERSION", "occurred_at": now,
            "from_currency": "USD", "to_currency": "ARS", "from_amount": 100,
            "pricing_mode": "MANUAL", "exchange_rate": 1500, "fee_amount": 0,
            "from_fx_rate_to_base": 1, "to_fx_rate_to_base": 0.0006666667,
            "notes": "Ejemplo: conversión",
        },
    ]
    return _csv_text(rows, CSV_COLUMNS)


def export_portfolio_csv(
    dataset: str,
    portfolio_id: int,
    quote_loader: Callable[[str], dict | None] | None = None,
    fx_loader: Callable[[str, str, datetime | date | None], dict] | None = None,
    *,
    include_deleted: bool = False,
) -> tuple[str, str]:
    settings_data = get_portfolio_settings(portfolio_id)
    safe_name = "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in settings_data["name"])
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d")
    if dataset == "generic":
        rows: list[dict[str, Any]] = []
        for item in list_cash_movements(portfolio_id=portfolio_id, include_deleted=include_deleted):
            rows.append({
                "record_type": "CASH_MOVEMENT", "occurred_at": item["occurred_at"],
                "movement_type": item["movement_type"], "amount": item["amount"],
                "currency": item["currency"], "symbol": item.get("symbol") or "",
                "fx_rate_to_base": item["fx_rate_to_base"], "notes": item.get("notes", ""),
            })
        for item in list_fx_conversions(portfolio_id=portfolio_id, include_deleted=include_deleted):
            rows.append({
                "record_type": "FX_CONVERSION", "occurred_at": item["occurred_at"],
                "from_currency": item["from_currency"], "to_currency": item["to_currency"],
                "from_amount": item["from_amount"], "exchange_rate": item["exchange_rate"],
                "pricing_mode": item["pricing_mode"], "fee_amount": item["fee_amount"],
                "fee_currency": item.get("fee_currency") or "",
                "from_fx_rate_to_base": item["from_fx_rate_to_base"],
                "to_fx_rate_to_base": item["to_fx_rate_to_base"], "notes": item.get("notes", ""),
            })
        for item in list_corporate_actions(portfolio_id=portfolio_id, include_deleted=include_deleted):
            rows.append({
                "record_type": "CORPORATE_ACTION", "occurred_at": item["occurred_at"],
                "symbol": item["symbol"], "action_type": item["action_type"],
                "target_symbol": item.get("target_symbol") or "",
                "quantity_ratio": item["quantity_ratio"],
                "cost_allocation_percent": item["cost_allocation_percent"],
                "cash_amount": item["cash_amount"], "cash_currency": item.get("cash_currency") or "",
                "fx_rate_to_base": item.get("fx_rate_to_base") or "",
                "target_name": item.get("target_name") or "",
                "target_asset_type": item.get("target_asset_type") or "",
                "target_currency": item.get("target_currency") or "",
                "target_exchange": item.get("target_exchange") or "",
                "source": item.get("source") or "MANUAL", "notes": item.get("notes", ""),
            })
        for item in list_portfolio_transactions(portfolio_id=portfolio_id, include_deleted=include_deleted):
            rows.append({
                "record_type": "TRANSACTION", "occurred_at": item["occurred_at"],
                "symbol": item["symbol"], "transaction_type": item["transaction_type"],
                "quantity": item["quantity"], "price": item["price"], "fees": item["fees"],
                "pricing_mode": item["pricing_mode"], "asset_name": item["asset_name"],
                "asset_type": item["asset_type"], "asset_currency": item["asset_currency"],
                "exchange": item["exchange"], "fx_rate_to_base": item["fx_rate_to_base"],
                "notes": item.get("notes", ""),
            })
        rows.sort(key=lambda row: (row["occurred_at"], row["record_type"]))
        return _csv_text(rows, CSV_COLUMNS), f"{safe_name}_registros_{stamp}.csv"
    if dataset == "transactions":
        data = list_portfolio_transactions(portfolio_id=portfolio_id, include_deleted=include_deleted)
        columns = [
            "id", "symbol", "transaction_type", "quantity", "price", "fees", "asset_name",
            "asset_type", "asset_currency", "exchange", "pricing_mode", "fx_rate_to_base",
            "occurred_at", "notes", "revision", "is_deleted", "deleted_reason",
        ]
        return _csv_text(data, columns), f"{safe_name}_operaciones_{stamp}.csv"
    if dataset == "movements":
        data = list_cash_movements(portfolio_id=portfolio_id, include_deleted=include_deleted)
        columns = [
            "id", "movement_type", "amount", "currency", "fx_rate_to_base", "symbol",
            "occurred_at", "notes", "revision", "is_deleted", "deleted_reason",
        ]
        return _csv_text(data, columns), f"{safe_name}_movimientos_{stamp}.csv"
    if dataset == "fx":
        data = list_fx_conversions(portfolio_id=portfolio_id, include_deleted=include_deleted)
        columns = [
            "id", "from_currency", "to_currency", "from_amount", "to_amount", "exchange_rate",
            "pricing_mode", "fee_amount", "fee_currency", "from_fx_rate_to_base",
            "to_fx_rate_to_base", "realized_fx_pnl_base", "occurred_at", "notes",
            "revision", "is_deleted", "deleted_reason",
        ]
        return _csv_text(data, columns), f"{safe_name}_conversiones_fx_{stamp}.csv"
    if dataset == "corporate-actions":
        data = list_corporate_actions(portfolio_id=portfolio_id, include_deleted=include_deleted)
        columns = [
            "id", "action_type", "symbol", "target_symbol", "quantity_ratio",
            "cost_allocation_percent", "cash_amount", "cash_currency", "fx_rate_to_base",
            "target_name", "target_asset_type", "target_currency", "target_exchange",
            "occurred_at", "source", "notes", "revision", "is_deleted", "deleted_reason",
        ]
        return _csv_text(data, columns), f"{safe_name}_eventos_corporativos_{stamp}.csv"
    if dataset == "dividends":
        data = list_dividends(portfolio_id=portfolio_id, include_deleted=include_deleted)
        columns = [
            "id", "symbol", "occurred_at", "ex_dividend_date", "currency",
            "gross_amount", "withholding_tax", "withholding_percent", "net_amount",
            "dividend_per_share", "shares_held", "dividend_source", "reinvested",
            "reinvest_transaction_id", "fx_rate_to_base", "gross_amount_base",
            "withholding_tax_base", "net_amount_base", "notes", "revision",
            "is_deleted", "deleted_reason",
        ]
        return _csv_text(data, columns), f"{safe_name}_dividendos_{stamp}.csv"
    if dataset in {"positions", "summary"}:
        overview = get_portfolio_overview(quote_loader, fx_loader, portfolio_id)
        if dataset == "positions":
            positions = overview.get("holdings", [])
            allocation = {item["symbol"]: item.get("percent", 0) for item in overview.get("allocation", [])}
            for item in positions:
                item["weight_percent"] = allocation.get(item.get("symbol"), 0)
            columns = [
                "symbol", "name", "asset_type", "currency", "exchange", "pricing_mode",
                "quantity", "average_price", "current_price", "fx_rate_to_base",
                "market_value", "cost_basis", "unrealized_pnl", "unrealized_pnl_percent",
                "realized_pnl", "weight_percent", "valuation_source", "quote_error", "fx_error",
            ]
            return _csv_text(positions, columns), f"{safe_name}_posiciones_{stamp}.csv"
        summary = overview.get("summary", {})
        rows = [{"metric": key, "value": value} for key, value in summary.items() if not isinstance(value, (dict, list))]
        return _csv_text(rows, ["metric", "value"]), f"{safe_name}_resumen_{stamp}.csv"
    raise CsvImportError("Dataset de exportación no permitido")
