from __future__ import annotations

from collections.abc import Callable
import json
from datetime import date, datetime, time, timezone
from typing import Any

from backend.core.database import get_connection
from backend.models import (
    ManualAssetCreate,
    ManualAssetPriceUpdate,
    PortfolioCashMovementCreate,
    PortfolioCashMovementUpdate,
    PortfolioCreate,
    PortfolioFxConversionCreate,
    PortfolioFxConversionUpdate,
    PortfolioSettingsUpdate,
    PortfolioTransactionCreate,
    PortfolioTransactionUpdate,
)


EPSILON = 1e-9
SUPPORTED_CURRENCIES = {
    "USD", "ARS", "EUR", "GBP", "BRL", "CLP", "MXN", "CAD", "AUD", "JPY", "CNY",
    "CHF", "HKD", "SGD", "NZD", "COP", "PEN", "UYU", "ILS", "ZAR", "KRW", "INR",
}
INCOME_TYPES = {"DIVIDEND", "INTEREST"}
EXPENSE_TYPES = {"TAX", "FEE"}
EXTERNAL_TYPES = {"DEPOSIT", "WITHDRAWAL"}


class PortfolioError(RuntimeError):
    """Base error for portfolio operations."""


class PortfolioValidationError(PortfolioError):
    """Raised when an operation would make the portfolio ledger invalid."""


def _round_money(value: float) -> float:
    return round(float(value), 6)


def _parse_datetime(value: str | datetime) -> datetime:
    if isinstance(value, datetime):
        parsed = value
    else:
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def _serialize_transaction(row: Any) -> dict:
    item = dict(row)
    for key in ("quantity", "price", "fees", "fx_rate_to_base"):
        item[key] = float(item[key])
    item["is_deleted"] = bool(item.get("is_deleted", 0))
    item["revision"] = int(item.get("revision") or 1)
    gross = item["quantity"] * item["price"]
    local_cash_effect = -(gross + item["fees"]) if item["transaction_type"] == "BUY" else gross - item["fees"]
    item["gross_amount"] = _round_money(gross)
    item["cash_effect_local"] = _round_money(local_cash_effect)
    item["cash_effect"] = _round_money(local_cash_effect * item["fx_rate_to_base"])
    item["base_amount"] = item["cash_effect"]
    return item


def _serialize_cash_movement(row: Any) -> dict:
    item = dict(row)
    item["amount"] = float(item["amount"])
    item["fx_rate_to_base"] = float(item["fx_rate_to_base"])
    for key in ("gross_amount", "withholding_tax", "withholding_percent", "dividend_per_share", "shares_held"):
        if key in item and item.get(key) is not None:
            item[key] = float(item[key])
    if "reinvested" in item:
        item["reinvested"] = bool(item.get("reinvested", 0))
    if item.get("reinvest_transaction_id") is not None:
        item["reinvest_transaction_id"] = int(item["reinvest_transaction_id"])
    item["is_deleted"] = bool(item.get("is_deleted", 0))
    item["revision"] = int(item.get("revision") or 1)
    sign = 1 if item["movement_type"] in {"DEPOSIT", "DIVIDEND", "INTEREST"} else -1
    item["cash_effect"] = _round_money(sign * item["amount"] * item["fx_rate_to_base"])
    return item


def _audit_payload(item: dict | None) -> str | None:
    if item is None:
        return None
    return json.dumps(item, ensure_ascii=False, sort_keys=True, default=str)


def _write_audit(
    connection: Any,
    portfolio_id: int,
    entity_type: str,
    entity_id: int,
    action: str,
    *,
    before: dict | None = None,
    after: dict | None = None,
    reason: str = "",
) -> None:
    connection.execute(
        """
        INSERT INTO portfolio_audit_log
            (portfolio_id, entity_type, entity_id, action, before_json, after_json, reason)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
        (
            portfolio_id, entity_type, entity_id, action,
            _audit_payload(before), _audit_payload(after), reason.strip(),
        ),
    )


def _serialize_asset(row: Any) -> dict:
    item = dict(row)
    item["manual_price"] = float(item["manual_price"]) if item.get("manual_price") is not None else None
    return item


def _serialize_portfolio(row: Any) -> dict:
    item = dict(row)
    item["initial_cash"] = float(item["initial_cash"])
    item["allow_margin"] = bool(item.get("allow_margin", 0))
    item["is_archived"] = bool(item.get("is_archived", 0))
    return item


def _serialize_fx_conversion(row: Any) -> dict:
    item = dict(row)
    for key in (
        "from_amount", "to_amount", "exchange_rate", "fee_amount",
        "from_fx_rate_to_base", "to_fx_rate_to_base", "realized_fx_pnl_base",
    ):
        item[key] = float(item[key])
    item["is_deleted"] = bool(item.get("is_deleted", 0))
    item["revision"] = int(item.get("revision") or 1)
    return item


def list_portfolios(*, include_archived: bool = False) -> list[dict]:
    where = "" if include_archived else "WHERE is_archived = 0"
    with get_connection() as connection:
        rows = connection.execute(
            f"""
            SELECT id, user_id, name, base_currency, initial_cash, allow_margin, is_archived, created_at, updated_at
            FROM portfolios {where}
            ORDER BY is_archived ASC, updated_at DESC, id ASC
            """
        ).fetchall()
    return [_serialize_portfolio(row) for row in rows]


def get_portfolio_settings(portfolio_id: int = 1, *, include_archived: bool = False) -> dict:
    archived_clause = "" if include_archived else " AND is_archived = 0"
    with get_connection() as connection:
        row = connection.execute(
            f"""
            SELECT id, user_id, name, base_currency, initial_cash, allow_margin, is_archived, created_at, updated_at
            FROM portfolios WHERE id = ?{archived_clause}
            """,
            (portfolio_id,),
        ).fetchone()
    if row is None:
        raise PortfolioValidationError("El portafolio no existe o está archivado")
    return _serialize_portfolio(row)


def create_portfolio(payload: PortfolioCreate) -> dict:
    if payload.base_currency not in SUPPORTED_CURRENCIES:
        raise PortfolioValidationError(
            f"Moneda no soportada todavía. Usá: {', '.join(sorted(SUPPORTED_CURRENCIES))}."
        )
    with get_connection() as connection:
        cursor = connection.execute(
            """
            INSERT INTO portfolios (name, base_currency, initial_cash, allow_margin)
            VALUES (?, ?, ?, ?)
            """,
            (payload.name, payload.base_currency, payload.initial_cash, int(payload.allow_margin)),
        )
        portfolio_id = int(cursor.lastrowid)
        connection.execute(
            """
            INSERT INTO portfolio_activity_log (portfolio_id, action, entity_type, entity_id, details)
            VALUES (?, 'CREATE', 'portfolio', ?, ?)
            """,
            (portfolio_id, str(portfolio_id), f"Creado: {payload.name}"),
        )
    return get_portfolio_settings(portfolio_id)


def archive_portfolio(portfolio_id: int) -> dict:
    portfolio = get_portfolio_settings(portfolio_id)
    if len(list_portfolios()) <= 1:
        raise PortfolioValidationError("Debe quedar al menos un portafolio activo")
    with get_connection() as connection:
        connection.execute(
            "UPDATE portfolios SET is_archived = 1, updated_at = CURRENT_TIMESTAMP WHERE id = ?",
            (portfolio_id,),
        )
        connection.execute(
            """
            INSERT INTO portfolio_activity_log (portfolio_id, action, entity_type, entity_id, details)
            VALUES (?, 'ARCHIVE', 'portfolio', ?, ?)
            """,
            (portfolio_id, str(portfolio_id), f"Archivado: {portfolio['name']}"),
        )
    return get_portfolio_settings(portfolio_id, include_archived=True)


def restore_portfolio(portfolio_id: int) -> dict:
    portfolio = get_portfolio_settings(portfolio_id, include_archived=True)
    with get_connection() as connection:
        connection.execute(
            "UPDATE portfolios SET is_archived = 0, updated_at = CURRENT_TIMESTAMP WHERE id = ?",
            (portfolio_id,),
        )
        connection.execute(
            """
            INSERT INTO portfolio_activity_log (portfolio_id, action, entity_type, entity_id, details)
            VALUES (?, 'RESTORE', 'portfolio', ?, ?)
            """,
            (portfolio_id, str(portfolio_id), f"Restaurado: {portfolio['name']}"),
        )
    return get_portfolio_settings(portfolio_id)


def list_portfolio_assets(portfolio_id: int = 1) -> list[dict]:
    get_portfolio_settings(portfolio_id)
    with get_connection() as connection:
        rows = connection.execute(
            """
            SELECT id, portfolio_id, symbol, name, asset_type, currency, exchange, pricing_mode,
                   manual_price, provider_symbol, sector, industry, metadata_source,
                   metadata_updated_at, created_at, updated_at
            FROM portfolio_assets
            WHERE portfolio_id = ?
            ORDER BY name, symbol
            """,
            (portfolio_id,),
        ).fetchall()
    return [_serialize_asset(row) for row in rows]


def get_portfolio_asset(symbol: str, portfolio_id: int = 1) -> dict | None:
    with get_connection() as connection:
        row = connection.execute(
            """
            SELECT id, portfolio_id, symbol, name, asset_type, currency, exchange, pricing_mode,
                   manual_price, provider_symbol, sector, industry, metadata_source,
                   metadata_updated_at, created_at, updated_at
            FROM portfolio_assets
            WHERE portfolio_id = ? AND symbol = ?
            """,
            (portfolio_id, symbol),
        ).fetchone()
    return _serialize_asset(row) if row is not None else None


def upsert_asset(asset: dict, portfolio_id: int = 1) -> dict:
    get_portfolio_settings(portfolio_id)
    pricing_mode = str(asset.get("pricing_mode") or "AUTO").upper()
    manual_price = asset.get("manual_price")
    with get_connection() as connection:
        connection.execute(
            """
            INSERT INTO portfolio_assets
                (portfolio_id, symbol, name, asset_type, currency, exchange, pricing_mode,
                 manual_price, provider_symbol, sector, industry, metadata_source,
                 metadata_updated_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
            ON CONFLICT(portfolio_id, symbol) DO UPDATE SET
                name = excluded.name,
                asset_type = excluded.asset_type,
                currency = excluded.currency,
                exchange = excluded.exchange,
                pricing_mode = excluded.pricing_mode,
                manual_price = COALESCE(excluded.manual_price, portfolio_assets.manual_price),
                provider_symbol = excluded.provider_symbol,
                sector = CASE WHEN excluded.sector <> '' THEN excluded.sector ELSE portfolio_assets.sector END,
                industry = CASE WHEN excluded.industry <> '' THEN excluded.industry ELSE portfolio_assets.industry END,
                metadata_source = CASE WHEN excluded.metadata_source <> '' THEN excluded.metadata_source ELSE portfolio_assets.metadata_source END,
                metadata_updated_at = COALESCE(excluded.metadata_updated_at, portfolio_assets.metadata_updated_at),
                updated_at = CURRENT_TIMESTAMP
            """,
            (
                portfolio_id,
                asset["symbol"],
                asset.get("name") or asset["symbol"],
                asset.get("asset_type") or "OTHER",
                asset.get("currency") or "USD",
                asset.get("exchange") or "",
                pricing_mode,
                manual_price,
                asset.get("provider_symbol") or (asset["symbol"] if pricing_mode == "AUTO" else None),
                str(asset.get("sector") or "").strip(),
                str(asset.get("industry") or "").strip(),
                str(asset.get("metadata_source") or asset.get("source") or "").strip(),
                asset.get("metadata_updated_at") or asset.get("last_updated"),
            ),
        )
    stored = get_portfolio_asset(asset["symbol"], portfolio_id)
    if stored is None:
        raise PortfolioError("No se pudo guardar el activo")
    return stored


def create_manual_asset(payload: ManualAssetCreate, portfolio_id: int = 1) -> dict:
    existing = get_portfolio_asset(payload.symbol, portfolio_id)
    if existing and existing["pricing_mode"] == "AUTO":
        raise PortfolioValidationError(
            "Ese símbolo ya está asociado a Yahoo Finance en este portafolio. Usá otro identificador manual."
        )
    return upsert_asset(
        {
            "symbol": payload.symbol,
            "name": payload.name,
            "asset_type": payload.asset_type.upper(),
            "currency": payload.currency,
            "exchange": payload.exchange,
            "pricing_mode": "MANUAL",
            "manual_price": payload.current_price,
            "provider_symbol": None,
            "sector": getattr(payload, "sector", None),
            "industry": getattr(payload, "industry", None),
            "metadata_source": "MANUAL",
            "metadata_updated_at": datetime.now(timezone.utc).isoformat(),
        },
        portfolio_id,
    )


def update_manual_asset_price(
    symbol: str,
    payload: ManualAssetPriceUpdate,
    portfolio_id: int = 1,
) -> dict:
    asset = get_portfolio_asset(symbol, portfolio_id)
    if asset is None:
        raise PortfolioValidationError("El activo manual no existe en este portafolio")
    if asset["pricing_mode"] != "MANUAL":
        raise PortfolioValidationError("Los activos automáticos se actualizan desde el proveedor")
    with get_connection() as connection:
        connection.execute(
            """
            UPDATE portfolio_assets
            SET manual_price = ?, updated_at = CURRENT_TIMESTAMP
            WHERE portfolio_id = ? AND symbol = ?
            """,
            (payload.current_price, portfolio_id, symbol),
        )
    updated = get_portfolio_asset(symbol, portfolio_id)
    if updated is None:
        raise PortfolioError("No se pudo actualizar el activo")
    return updated


def list_portfolio_transactions(
    *, ascending: bool = False, portfolio_id: int = 1, include_deleted: bool = False
) -> list[dict]:
    get_portfolio_settings(portfolio_id)
    direction = "ASC" if ascending else "DESC"
    deleted_clause = "" if include_deleted else " AND is_deleted = 0"
    with get_connection() as connection:
        rows = connection.execute(
            f"""
            SELECT id, portfolio_id, symbol, transaction_type, quantity, price, fees,
                   asset_name, asset_type, asset_currency, exchange, pricing_mode,
                   fx_rate_to_base, occurred_at, notes, created_at, updated_at, revision,
                   is_deleted, deleted_at, deleted_reason
            FROM portfolio_transactions
            WHERE portfolio_id = ?{deleted_clause}
            ORDER BY occurred_at {direction}, id {direction}
            """,
            (portfolio_id,),
        ).fetchall()
    return [_serialize_transaction(row) for row in rows]


def get_portfolio_transaction(
    transaction_id: int, portfolio_id: int = 1, *, include_deleted: bool = False
) -> dict:
    items = list_portfolio_transactions(
        portfolio_id=portfolio_id, include_deleted=include_deleted
    )
    item = next((row for row in items if int(row["id"]) == transaction_id), None)
    if item is None:
        raise PortfolioValidationError("La operación no existe en este portafolio")
    return item


def list_cash_movements(
    *, ascending: bool = False, portfolio_id: int = 1, include_deleted: bool = False
) -> list[dict]:
    get_portfolio_settings(portfolio_id)
    direction = "ASC" if ascending else "DESC"
    deleted_clause = "" if include_deleted else " AND is_deleted = 0"
    with get_connection() as connection:
        rows = connection.execute(
            f"""
            SELECT id, portfolio_id, movement_type, amount, currency, fx_rate_to_base,
                   symbol, occurred_at, notes, created_at, updated_at, revision,
                   is_deleted, deleted_at, deleted_reason, gross_amount, withholding_tax,
                   withholding_percent, dividend_per_share, shares_held, dividend_source,
                   reinvested, reinvest_transaction_id, ex_dividend_date
            FROM portfolio_cash_movements
            WHERE portfolio_id = ?{deleted_clause}
            ORDER BY occurred_at {direction}, id {direction}
            """,
            (portfolio_id,),
        ).fetchall()
    return [_serialize_cash_movement(row) for row in rows]


def get_cash_movement(
    movement_id: int, portfolio_id: int = 1, *, include_deleted: bool = False
) -> dict:
    items = list_cash_movements(portfolio_id=portfolio_id, include_deleted=include_deleted)
    item = next((row for row in items if int(row["id"]) == movement_id), None)
    if item is None:
        raise PortfolioValidationError("El movimiento no existe en este portafolio")
    return item


def list_fx_conversions(
    *, ascending: bool = False, portfolio_id: int = 1, include_deleted: bool = False
) -> list[dict]:
    get_portfolio_settings(portfolio_id)
    direction = "ASC" if ascending else "DESC"
    deleted_clause = "" if include_deleted else " AND is_deleted = 0"
    with get_connection() as connection:
        rows = connection.execute(
            f"""
            SELECT id, portfolio_id, from_currency, to_currency, from_amount, to_amount,
                   exchange_rate, pricing_mode, fee_amount, fee_currency,
                   from_fx_rate_to_base, to_fx_rate_to_base, realized_fx_pnl_base,
                   occurred_at, notes, created_at, updated_at, revision,
                   is_deleted, deleted_at, deleted_reason
            FROM portfolio_fx_conversions
            WHERE portfolio_id = ?{deleted_clause}
            ORDER BY occurred_at {direction}, id {direction}
            """,
            (portfolio_id,),
        ).fetchall()
    return [_serialize_fx_conversion(row) for row in rows]


def get_fx_conversion(
    conversion_id: int, portfolio_id: int = 1, *, include_deleted: bool = False
) -> dict:
    items = list_fx_conversions(
        portfolio_id=portfolio_id, include_deleted=include_deleted
    )
    item = next((row for row in items if int(row["id"]) == conversion_id), None)
    if item is None:
        raise PortfolioValidationError("La conversión FX no existe en este portafolio")
    return item


def list_portfolio_audit_log(
    portfolio_id: int = 1, *, limit: int = 100, entity_type: str | None = None
) -> list[dict]:
    get_portfolio_settings(portfolio_id)
    safe_limit = max(1, min(int(limit), 500))
    clause = " AND entity_type = ?" if entity_type else ""
    params: tuple[Any, ...] = (portfolio_id, entity_type, safe_limit) if entity_type else (portfolio_id, safe_limit)
    with get_connection() as connection:
        rows = connection.execute(
            f"""
            SELECT id, portfolio_id, entity_type, entity_id, action, before_json,
                   after_json, reason, created_at
            FROM portfolio_audit_log
            WHERE portfolio_id = ?{clause}
            ORDER BY id DESC LIMIT ?
            """,
            params,
        ).fetchall()
    result: list[dict] = []
    for row in rows:
        item = dict(row)
        item["before"] = json.loads(item.pop("before_json")) if item.get("before_json") else None
        item["after"] = json.loads(item.pop("after_json")) if item.get("after_json") else None
        result.append(item)
    return result


def _active_corporate_actions(portfolio_id: int) -> list[dict]:
    with get_connection() as connection:
        rows = connection.execute(
            """
            SELECT id, portfolio_id, action_type, symbol, target_symbol, quantity_ratio,
                   cost_allocation_percent, cash_amount, cash_currency, fx_rate_to_base,
                   target_name, target_asset_type, target_currency, target_exchange,
                   occurred_at, notes, source, is_deleted, deleted_at, deleted_reason,
                   revision, created_at, updated_at
            FROM portfolio_corporate_actions
            WHERE portfolio_id = ? AND is_deleted = 0
            ORDER BY occurred_at, id
            """,
            (portfolio_id,),
        ).fetchall()
    return [dict(row) for row in rows]


def _combined_events(
    transactions: list[dict],
    cash_movements: list[dict],
    fx_conversions: list[dict] | None = None,
    corporate_actions: list[dict] | None = None,
) -> list[tuple[str, dict]]:
    events = (
        [("transaction", item) for item in transactions]
        + [("cash", item) for item in cash_movements]
        + [("fx", item) for item in (fx_conversions or [])]
        + [("corporate", item) for item in (corporate_actions or [])]
    )
    event_priority = {"cash": 0, "fx": 1, "corporate": 2, "transaction": 3}
    return sorted(
        events,
        key=lambda event: (
            _parse_datetime(event[1]["occurred_at"]),
            event_priority[event[0]],
            int(event[1].get("id") or 0),
        ),
    )


def _cash_account(accounts: dict[str, dict[str, float]], currency: str, fx_rate: float) -> dict[str, float]:
    code = str(currency or "USD").upper()
    account = accounts.setdefault(
        code,
        {"balance": 0.0, "cost_basis_base": 0.0, "last_fx_rate_to_base": float(fx_rate)},
    )
    if fx_rate > 0:
        account["last_fx_rate_to_base"] = float(fx_rate)
    return account


def _add_cash(
    accounts: dict[str, dict[str, float]],
    currency: str,
    amount: float,
    fx_rate: float,
    *,
    base_cost: float | None = None,
) -> None:
    account = _cash_account(accounts, currency, fx_rate)
    account["balance"] += float(amount)
    account["cost_basis_base"] += float(base_cost if base_cost is not None else amount * fx_rate)


def _consume_cash(
    accounts: dict[str, dict[str, float]],
    currency: str,
    amount: float,
    fx_rate: float,
    *,
    allow_margin: bool,
    context: str,
) -> float:
    account = _cash_account(accounts, currency, fx_rate)
    requested = float(amount)
    balance_before = float(account["balance"])
    if not allow_margin and requested - balance_before > EPSILON:
        raise PortfolioValidationError(
            f"Efectivo insuficiente en {currency} para {context}. "
            f"Disponible: {balance_before:.6f} {currency}; necesario: {requested:.6f} {currency}."
        )

    positive_balance = max(balance_before, 0.0)
    consumed_funded = min(requested, positive_balance)
    average_cost = (
        float(account["cost_basis_base"]) / positive_balance
        if positive_balance > EPSILON
        else float(fx_rate)
    )
    removed_cost = consumed_funded * average_cost
    deficit = max(requested - consumed_funded, 0.0)
    account["balance"] = balance_before - requested
    account["cost_basis_base"] -= removed_cost
    if deficit > EPSILON:
        account["cost_basis_base"] -= deficit * float(fx_rate)
        removed_cost += deficit * float(fx_rate)
    if abs(account["balance"]) <= EPSILON:
        account["balance"] = 0.0
        account["cost_basis_base"] = 0.0
    return removed_cost


def calculate_ledger(
    transactions: list[dict],
    initial_cash: float,
    cash_movements: list[dict] | None = None,
    fx_conversions: list[dict] | None = None,
    corporate_actions: list[dict] | None = None,
    *,
    base_currency: str = "USD",
    allow_margin: bool = False,
) -> dict:
    base_currency = str(base_currency or "USD").upper()
    cash_accounts: dict[str, dict[str, float]] = {}
    _add_cash(cash_accounts, base_currency, float(initial_cash), 1.0)

    states: dict[str, dict[str, Any]] = {}
    realized_pnl = 0.0
    realized_fx_pnl = 0.0
    fx_fees = 0.0
    dividends = 0.0
    interest = 0.0
    taxes = 0.0
    other_fees = 0.0
    deposits = 0.0
    withdrawals = 0.0

    for event_type, item in _combined_events(
        transactions, cash_movements or [], fx_conversions or [], corporate_actions or []
    ):
        occurred_at = str(item["occurred_at"])
        if event_type == "cash":
            currency = str(item.get("currency") or base_currency).upper()
            fx_rate = float(item.get("fx_rate_to_base", 1))
            amount = float(item["amount"])
            amount_base = amount * fx_rate
            movement_type = str(item["movement_type"])
            if movement_type == "DEPOSIT":
                _add_cash(cash_accounts, currency, amount, fx_rate)
                deposits += amount_base
            elif movement_type == "WITHDRAWAL":
                _consume_cash(
                    cash_accounts, currency, amount, fx_rate,
                    allow_margin=allow_margin,
                    context=f"retirar fondos el {occurred_at}",
                )
                withdrawals += amount_base
            elif movement_type == "DIVIDEND":
                _add_cash(cash_accounts, currency, amount, fx_rate)
                dividends += amount_base
            elif movement_type == "INTEREST":
                _add_cash(cash_accounts, currency, amount, fx_rate)
                interest += amount_base
            elif movement_type == "TAX":
                _consume_cash(
                    cash_accounts, currency, amount, fx_rate,
                    allow_margin=allow_margin,
                    context=f"registrar el impuesto del {occurred_at}",
                )
                taxes += amount_base
            elif movement_type == "FEE":
                _consume_cash(
                    cash_accounts, currency, amount, fx_rate,
                    allow_margin=allow_margin,
                    context=f"registrar el gasto del {occurred_at}",
                )
                other_fees += amount_base
            else:
                raise PortfolioValidationError(f"Movimiento no reconocido: {movement_type}")
            continue

        if event_type == "fx":
            from_currency = str(item["from_currency"]).upper()
            to_currency = str(item["to_currency"]).upper()
            from_amount = float(item["from_amount"])
            to_amount = float(item["to_amount"])
            from_fx = float(item.get("from_fx_rate_to_base", 1))
            to_fx = float(item.get("to_fx_rate_to_base", 1))
            fee_amount = float(item.get("fee_amount", 0))
            fee_currency = str(item.get("fee_currency") or from_currency).upper()

            disposed_cost = _consume_cash(
                cash_accounts, from_currency, from_amount, from_fx,
                allow_margin=allow_margin,
                context=f"convertir {from_currency} a {to_currency} el {occurred_at}",
            )
            fee_base = 0.0
            if fee_amount > EPSILON and fee_currency == from_currency:
                _consume_cash(
                    cash_accounts, from_currency, fee_amount, from_fx,
                    allow_margin=allow_margin,
                    context=f"pagar la comisión FX el {occurred_at}",
                )
                fee_base = fee_amount * from_fx
                received_amount = to_amount
            elif fee_amount > EPSILON and fee_currency == to_currency:
                if fee_amount - to_amount > EPSILON:
                    raise PortfolioValidationError("La comisión FX no puede superar el importe recibido")
                fee_base = fee_amount * to_fx
                received_amount = to_amount - fee_amount
            else:
                received_amount = to_amount

            received_value_base = received_amount * to_fx
            gross_received_value_base = to_amount * to_fx
            _add_cash(
                cash_accounts, to_currency, received_amount, to_fx,
                base_cost=received_value_base,
            )
            # El resultado cambiario compara valores brutos; las comisiones se informan
            # por separado para no descontarlas dos veces cuando se cobran en destino.
            realized_fx_pnl += gross_received_value_base - disposed_cost
            fx_fees += fee_base
            continue

        if event_type == "corporate":
            action_type = str(item["action_type"])
            symbol = str(item["symbol"])
            state = states.get(symbol)
            if state is None or float(state.get("quantity", 0)) <= EPSILON:
                raise PortfolioValidationError(
                    f"No hay tenencia de {symbol} para aplicar {action_type} el {occurred_at}."
                )
            ratio = float(item.get("quantity_ratio") or 1.0)
            if action_type in {"SPLIT", "REVERSE_SPLIT"}:
                state["quantity"] *= ratio
            elif action_type == "STOCK_DIVIDEND":
                state["quantity"] += float(state["quantity"]) * ratio
            elif action_type in {"TICKER_CHANGE", "MERGER"}:
                target_symbol = str(item.get("target_symbol") or "").upper()
                if not target_symbol:
                    raise PortfolioValidationError(f"{action_type} requiere símbolo de destino")
                target = states.setdefault(
                    target_symbol,
                    {
                        "quantity": 0.0,
                        "cost_basis": 0.0,
                        "realized_pnl": 0.0,
                        "name": item.get("target_name") or target_symbol,
                        "asset_type": item.get("target_asset_type") or state.get("asset_type") or "OTHER",
                        "currency": item.get("target_currency") or state.get("currency") or base_currency,
                        "exchange": item.get("target_exchange") or state.get("exchange") or "",
                        "pricing_mode": state.get("pricing_mode") or "AUTO",
                    },
                )
                target["quantity"] += float(state["quantity"]) * ratio
                target["cost_basis"] += float(state["cost_basis"])
                target["realized_pnl"] += float(state.get("realized_pnl", 0))
                state["quantity"] = 0.0
                state["cost_basis"] = 0.0
                state["realized_pnl"] = 0.0
            elif action_type == "SPINOFF":
                target_symbol = str(item.get("target_symbol") or "").upper()
                allocation = float(item.get("cost_allocation_percent") or 0) / 100.0
                if not target_symbol or not (0 < allocation < 1):
                    raise PortfolioValidationError("El spin-off requiere destino y asignación de costo válida")
                child_cost = float(state["cost_basis"]) * allocation
                state["cost_basis"] -= child_cost
                child = states.setdefault(
                    target_symbol,
                    {
                        "quantity": 0.0,
                        "cost_basis": 0.0,
                        "realized_pnl": 0.0,
                        "name": item.get("target_name") or target_symbol,
                        "asset_type": item.get("target_asset_type") or "EQUITY",
                        "currency": item.get("target_currency") or state.get("currency") or base_currency,
                        "exchange": item.get("target_exchange") or state.get("exchange") or "",
                        "pricing_mode": "AUTO",
                    },
                )
                child["quantity"] += float(state["quantity"]) * ratio
                child["cost_basis"] += child_cost
            elif action_type == "RETURN_OF_CAPITAL":
                amount = float(item.get("cash_amount") or 0)
                currency = str(item.get("cash_currency") or state.get("currency") or base_currency).upper()
                fx_rate = float(item.get("fx_rate_to_base") or 1.0)
                if amount <= 0:
                    raise PortfolioValidationError("La devolución de capital requiere un importe positivo")
                _add_cash(cash_accounts, currency, amount, fx_rate)
                amount_base = amount * fx_rate
                reduction = min(amount_base, float(state["cost_basis"]))
                state["cost_basis"] -= reduction
                excess = amount_base - reduction
                if excess > EPSILON:
                    state["realized_pnl"] += excess
                    realized_pnl += excess
            else:
                raise PortfolioValidationError(f"Evento corporativo no reconocido: {action_type}")
            continue

        symbol = str(item["symbol"])
        transaction_type = str(item["transaction_type"])
        quantity = float(item["quantity"])
        price = float(item["price"])
        fees = float(item.get("fees", 0))
        fx_rate = float(item.get("fx_rate_to_base", 1))
        asset_currency = str(item.get("asset_currency") or base_currency).upper()
        state = states.setdefault(
            symbol,
            {
                "quantity": 0.0,
                "cost_basis": 0.0,
                "realized_pnl": 0.0,
                "name": item.get("asset_name") or symbol,
                "asset_type": item.get("asset_type") or "OTHER",
                "currency": asset_currency,
                "exchange": item.get("exchange") or "",
                "pricing_mode": item.get("pricing_mode") or "AUTO",
            },
        )

        if transaction_type == "BUY":
            required_local = quantity * price + fees
            _consume_cash(
                cash_accounts, asset_currency, required_local, fx_rate,
                allow_margin=allow_margin,
                context=f"comprar {symbol} el {occurred_at}",
            )
            required_base = required_local * fx_rate
            state["quantity"] += quantity
            state["cost_basis"] += required_base
        elif transaction_type == "SELL":
            if quantity - float(state["quantity"]) > EPSILON:
                raise PortfolioValidationError(
                    f"No podés vender {quantity:g} unidades de {symbol}; en esa fecha había {state['quantity']:g}."
                )
            average_base = float(state["cost_basis"]) / float(state["quantity"]) if state["quantity"] else 0.0
            proceeds_local = quantity * price - fees
            proceeds_base = proceeds_local * fx_rate
            realized = proceeds_base - quantity * average_base
            _add_cash(cash_accounts, asset_currency, proceeds_local, fx_rate)
            state["quantity"] -= quantity
            state["cost_basis"] -= quantity * average_base
            if abs(float(state["quantity"])) <= EPSILON:
                state["quantity"] = 0.0
                state["cost_basis"] = 0.0
            state["realized_pnl"] += realized
            realized_pnl += realized
        else:
            raise PortfolioValidationError(f"Tipo de operación no reconocido: {transaction_type}")

    for state in states.values():
        state["average_price_base"] = (
            float(state["cost_basis"]) / float(state["quantity"])
            if float(state["quantity"]) > EPSILON else 0.0
        )
        state["average_price"] = state["average_price_base"]

    balances: list[dict] = []
    cash_balance_base = 0.0
    margin_used_base = 0.0
    for currency, account in sorted(cash_accounts.items()):
        balance = float(account["balance"])
        rate = float(account.get("last_fx_rate_to_base") or (1.0 if currency == base_currency else 0.0))
        base_value = balance * rate
        cash_balance_base += base_value
        if balance < -EPSILON:
            margin_used_base += abs(base_value)
        average_cost_rate = (
            float(account["cost_basis_base"]) / balance
            if balance > EPSILON else rate
        )
        balances.append(
            {
                "currency": currency,
                "balance": _round_money(balance),
                "fx_rate_to_base": _round_money(rate),
                "base_value": _round_money(base_value),
                "cost_basis_base": _round_money(float(account["cost_basis_base"])),
                "average_cost_rate": _round_money(average_cost_rate),
                "is_negative": balance < -EPSILON,
            }
        )

    return {
        "cash_balance": cash_balance_base,
        "cash_balances": balances,
        "cash_accounts": cash_accounts,
        "states": states,
        "realized_pnl": realized_pnl,
        "realized_fx_pnl": realized_fx_pnl,
        "fx_fees": fx_fees,
        "dividends": dividends,
        "interest": interest,
        "taxes": taxes,
        "other_fees": other_fees,
        "deposits": deposits,
        "withdrawals": withdrawals,
        "net_contributions": deposits - withdrawals,
        "income": dividends + interest,
        "expenses": taxes + other_fees + fx_fees,
        "margin_used_base": margin_used_base,
        "allow_margin": bool(allow_margin),
        "base_currency": base_currency,
    }


def _calculate_for_portfolio(
    settings: dict,
    transactions: list[dict],
    movements: list[dict],
    conversions: list[dict],
    corporate_actions: list[dict] | None = None,
) -> dict:
    actions = corporate_actions
    if actions is None:
        actions = _active_corporate_actions(int(settings.get("id") or 1))
    return calculate_ledger(
        transactions,
        settings["initial_cash"],
        movements,
        conversions,
        actions,
        base_currency=settings["base_currency"],
        allow_margin=bool(settings.get("allow_margin", False)),
    )


def update_portfolio_settings(
    payload: PortfolioSettingsUpdate,
    portfolio_id: int = 1,
) -> dict:
    if payload.base_currency not in SUPPORTED_CURRENCIES:
        raise PortfolioValidationError(
            f"Moneda no soportada todavía. Usá: {', '.join(sorted(SUPPORTED_CURRENCIES))}."
        )
    current = get_portfolio_settings(portfolio_id)
    transactions = list_portfolio_transactions(ascending=True, portfolio_id=portfolio_id)
    cash_movements = list_cash_movements(ascending=True, portfolio_id=portfolio_id)
    fx_conversions = list_fx_conversions(ascending=True, portfolio_id=portfolio_id)
    if (transactions or cash_movements or fx_conversions) and payload.base_currency != current["base_currency"]:
        raise PortfolioValidationError(
            "No se puede cambiar la moneda base cuando ya hay movimientos, porque cambiaría el histórico FX."
        )
    proposed_settings = {
        **current,
        "name": payload.name,
        "base_currency": payload.base_currency,
        "initial_cash": payload.initial_cash,
        "allow_margin": payload.allow_margin,
    }
    _calculate_for_portfolio(proposed_settings, transactions, cash_movements, fx_conversions)
    with get_connection() as connection:
        connection.execute(
            """
            UPDATE portfolios
            SET name = ?, base_currency = ?, initial_cash = ?, allow_margin = ?, updated_at = CURRENT_TIMESTAMP
            WHERE id = ? AND is_archived = 0
            """,
            (payload.name, payload.base_currency, payload.initial_cash, int(payload.allow_margin), portfolio_id),
        )
        connection.execute(
            """
            INSERT INTO portfolio_activity_log (portfolio_id, action, entity_type, entity_id, details)
            VALUES (?, 'UPDATE', 'portfolio', ?, ?)
            """,
            (portfolio_id, str(portfolio_id), "Configuración actualizada"),
        )
    return get_portfolio_settings(portfolio_id)


def _load_fx_rate(
    currency: str,
    base_currency: str,
    occurred_at: datetime,
    requested_rate: float | None,
    fx_loader: Callable[[str, str, datetime | date | None], dict] | None,
) -> float:
    if currency == base_currency:
        return 1.0
    if requested_rate is not None:
        return float(requested_rate)
    if fx_loader is None:
        raise PortfolioValidationError(
            f"Se necesita una tasa de conversión {currency}/{base_currency}."
        )
    try:
        result = fx_loader(currency, base_currency, occurred_at)
        return float(result["rate"])
    except Exception as exc:
        raise PortfolioValidationError(
            f"No se pudo convertir {currency} a {base_currency}: {exc}. Podés ingresar la tasa manualmente."
        ) from exc


def create_portfolio_transaction(
    payload: PortfolioTransactionCreate,
    quote_loader: Callable[[str], dict | None] | None = None,
    fx_loader: Callable[[str, str, datetime | date | None], dict] | None = None,
    portfolio_id: int = 1,
) -> dict:
    settings = get_portfolio_settings(portfolio_id)
    if payload.occurred_at > datetime.now(timezone.utc).replace(microsecond=0):
        raise PortfolioValidationError("La fecha de la operación no puede estar en el futuro.")

    asset: dict
    if payload.pricing_mode == "AUTO":
        quote = quote_loader(payload.symbol) if quote_loader is not None else None
        if quote is None:
            raise PortfolioValidationError(
                f"No se encontró {payload.symbol} en Yahoo Finance. Podés crearlo como activo manual."
            )
        asset = {
            "symbol": payload.symbol,
            "name": quote.get("name") or payload.asset_name or payload.symbol,
            "asset_type": quote.get("asset_type") or payload.asset_type or "OTHER",
            "currency": str(quote.get("currency") or payload.asset_currency or settings["base_currency"]).upper(),
            "exchange": quote.get("exchange") or quote.get("market") or payload.exchange or "",
            "pricing_mode": "AUTO",
            "manual_price": None,
            "provider_symbol": payload.symbol,
        }
    else:
        existing = get_portfolio_asset(payload.symbol, portfolio_id)
        asset = {
            "symbol": payload.symbol,
            "name": payload.asset_name or (existing or {}).get("name") or payload.symbol,
            "asset_type": (payload.asset_type or (existing or {}).get("asset_type") or "OTHER").upper(),
            "currency": payload.asset_currency or (existing or {}).get("currency") or settings["base_currency"],
            "exchange": payload.exchange or (existing or {}).get("exchange") or "Manual",
            "pricing_mode": "MANUAL",
            "manual_price": (existing or {}).get("manual_price") or payload.price,
            "provider_symbol": None,
        }
    asset = upsert_asset(asset, portfolio_id)
    fx_rate = _load_fx_rate(
        asset["currency"], settings["base_currency"], payload.occurred_at, payload.fx_rate_to_base, fx_loader
    )

    transactions = list_portfolio_transactions(ascending=True, portfolio_id=portfolio_id)
    cash_movements = list_cash_movements(ascending=True, portfolio_id=portfolio_id)
    fx_conversions = list_fx_conversions(ascending=True, portfolio_id=portfolio_id)
    proposed = {
        "id": max((int(item["id"]) for item in transactions), default=0) + 1,
        "portfolio_id": portfolio_id,
        "symbol": payload.symbol,
        "transaction_type": payload.transaction_type,
        "quantity": payload.quantity,
        "price": payload.price,
        "fees": payload.fees,
        "asset_name": asset["name"],
        "asset_type": asset["asset_type"],
        "asset_currency": asset["currency"],
        "exchange": asset["exchange"],
        "pricing_mode": asset["pricing_mode"],
        "fx_rate_to_base": fx_rate,
        "occurred_at": payload.occurred_at.isoformat(),
        "notes": payload.notes,
    }
    _calculate_for_portfolio(settings, [*transactions, proposed], cash_movements, fx_conversions)

    with get_connection() as connection:
        cursor = connection.execute(
            """
            INSERT INTO portfolio_transactions
                (portfolio_id, symbol, transaction_type, quantity, price, fees, asset_name, asset_type,
                 asset_currency, exchange, pricing_mode, fx_rate_to_base, occurred_at, notes,
                 updated_at, revision, is_deleted)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, 1, 0)
            """,
            (
                portfolio_id, payload.symbol, payload.transaction_type, payload.quantity, payload.price,
                payload.fees, asset["name"], asset["asset_type"], asset["currency"], asset["exchange"],
                asset["pricing_mode"], fx_rate, payload.occurred_at.isoformat(), payload.notes,
            ),
        )
        transaction_id = int(cursor.lastrowid)
        row = connection.execute(
            """
            SELECT id, portfolio_id, symbol, transaction_type, quantity, price, fees, asset_name, asset_type,
                   asset_currency, exchange, pricing_mode, fx_rate_to_base, occurred_at, notes, created_at,
                   updated_at, revision, is_deleted, deleted_at, deleted_reason
            FROM portfolio_transactions WHERE id = ? AND portfolio_id = ?
            """,
            (transaction_id, portfolio_id),
        ).fetchone()
        created = _serialize_transaction(row)
        _write_audit(
            connection, portfolio_id, "transaction", transaction_id, "CREATE",
            after=created, reason="Operación registrada",
        )
    return created


def _ledger_impact(before_ledger: dict, after_ledger: dict, symbol: str | None = None) -> dict:
    before_balances = {item["currency"]: item for item in before_ledger.get("cash_balances", [])}
    after_balances = {item["currency"]: item for item in after_ledger.get("cash_balances", [])}
    currencies = sorted(set(before_balances) | set(after_balances))
    cash_by_currency = []
    for currency in currencies:
        before_amount = float((before_balances.get(currency) or {}).get("balance", 0))
        after_amount = float((after_balances.get(currency) or {}).get("balance", 0))
        cash_by_currency.append(
            {
                "currency": currency,
                "before": _round_money(before_amount),
                "after": _round_money(after_amount),
                "change": _round_money(after_amount - before_amount),
            }
        )
    impact = {
        "cash_balance_before": _round_money(before_ledger["cash_balance"]),
        "cash_balance_after": _round_money(after_ledger["cash_balance"]),
        "cash_balance_change": _round_money(after_ledger["cash_balance"] - before_ledger["cash_balance"]),
        "cash_by_currency": cash_by_currency,
        "realized_pnl_before": _round_money(before_ledger["realized_pnl"]),
        "realized_pnl_after": _round_money(after_ledger["realized_pnl"]),
        "realized_pnl_change": _round_money(after_ledger["realized_pnl"] - before_ledger["realized_pnl"]),
        "realized_fx_pnl_before": _round_money(before_ledger.get("realized_fx_pnl", 0)),
        "realized_fx_pnl_after": _round_money(after_ledger.get("realized_fx_pnl", 0)),
        "realized_fx_pnl_change": _round_money(
            after_ledger.get("realized_fx_pnl", 0) - before_ledger.get("realized_fx_pnl", 0)
        ),
    }
    if symbol:
        before_state = before_ledger["states"].get(symbol, {})
        after_state = after_ledger["states"].get(symbol, {})
        impact["position"] = {
            "symbol": symbol,
            "quantity_before": _round_money(before_state.get("quantity", 0)),
            "quantity_after": _round_money(after_state.get("quantity", 0)),
            "cost_basis_before": _round_money(before_state.get("cost_basis", 0)),
            "cost_basis_after": _round_money(after_state.get("cost_basis", 0)),
        }
    return impact


def _updated_transaction_candidate(
    current: dict,
    payload: PortfolioTransactionUpdate,
    settings: dict,
    portfolio_id: int,
    quote_loader: Callable[[str], dict | None] | None = None,
    fx_loader: Callable[[str, str, datetime | date | None], dict] | None = None,
) -> dict:
    if payload.occurred_at > datetime.now(timezone.utc).replace(microsecond=0):
        raise PortfolioValidationError("La fecha de la operación no puede estar en el futuro.")

    same_identity = (
        payload.symbol == current["symbol"]
        and payload.pricing_mode == current["pricing_mode"]
    )
    if payload.pricing_mode == "AUTO":
        if same_identity:
            asset = {
                "symbol": current["symbol"],
                "name": payload.asset_name or current["asset_name"],
                "asset_type": payload.asset_type or current["asset_type"],
                "currency": payload.asset_currency or current["asset_currency"],
                "exchange": payload.exchange or current["exchange"],
                "pricing_mode": "AUTO",
                "manual_price": None,
                "provider_symbol": current["symbol"],
            }
        else:
            quote = quote_loader(payload.symbol) if quote_loader is not None else None
            if quote is None:
                raise PortfolioValidationError(
                    f"No se encontró {payload.symbol} en Yahoo Finance. Podés usarlo como activo manual."
                )
            asset = {
                "symbol": payload.symbol,
                "name": quote.get("name") or payload.asset_name or payload.symbol,
                "asset_type": quote.get("asset_type") or payload.asset_type or "OTHER",
                "currency": str(
                    quote.get("currency") or payload.asset_currency or settings["base_currency"]
                ).upper(),
                "exchange": quote.get("exchange") or quote.get("market") or payload.exchange or "",
                "pricing_mode": "AUTO",
                "manual_price": None,
                "provider_symbol": payload.symbol,
            }
    else:
        existing = get_portfolio_asset(payload.symbol, portfolio_id)
        asset = {
            "symbol": payload.symbol,
            "name": payload.asset_name or (existing or {}).get("name") or payload.symbol,
            "asset_type": (
                payload.asset_type or (existing or {}).get("asset_type") or "OTHER"
            ).upper(),
            "currency": payload.asset_currency
            or (existing or {}).get("currency")
            or settings["base_currency"],
            "exchange": payload.exchange or (existing or {}).get("exchange") or "Manual",
            "pricing_mode": "MANUAL",
            "manual_price": (existing or {}).get("manual_price") or payload.price,
            "provider_symbol": None,
        }

    same_fx_context = (
        str(asset["currency"]).upper() == str(current["asset_currency"]).upper()
        and payload.occurred_at.date() == _parse_datetime(current["occurred_at"]).date()
    )
    requested_rate = payload.fx_rate_to_base
    if requested_rate is None and same_fx_context:
        requested_rate = float(current["fx_rate_to_base"])
    fx_rate = _load_fx_rate(
        str(asset["currency"]).upper(),
        settings["base_currency"],
        payload.occurred_at,
        requested_rate,
        fx_loader,
    )

    candidate = dict(current)
    candidate.update(
        {
            "symbol": asset["symbol"],
            "transaction_type": payload.transaction_type,
            "quantity": payload.quantity,
            "price": payload.price,
            "fees": payload.fees,
            "asset_name": asset["name"],
            "asset_type": asset["asset_type"],
            "asset_currency": str(asset["currency"]).upper(),
            "exchange": asset["exchange"],
            "pricing_mode": asset["pricing_mode"],
            "fx_rate_to_base": fx_rate,
            "occurred_at": payload.occurred_at.isoformat(),
            "notes": payload.notes,
            "is_deleted": False,
            "_asset": asset,
        }
    )
    return candidate


def preview_portfolio_transaction_update(
    transaction_id: int,
    payload: PortfolioTransactionUpdate,
    quote_loader: Callable[[str], dict | None] | None = None,
    fx_loader: Callable[[str, str, datetime | date | None], dict] | None = None,
    portfolio_id: int = 1,
) -> dict:
    current = get_portfolio_transaction(transaction_id, portfolio_id)
    settings = get_portfolio_settings(portfolio_id)
    candidate = _updated_transaction_candidate(
        current, payload, settings, portfolio_id, quote_loader, fx_loader
    )
    candidate_for_ledger = {key: value for key, value in candidate.items() if key != "_asset"}
    transactions = list_portfolio_transactions(ascending=True, portfolio_id=portfolio_id)
    proposed = [
        candidate_for_ledger if int(item["id"]) == transaction_id else item
        for item in transactions
    ]
    movements = list_cash_movements(ascending=True, portfolio_id=portfolio_id)
    conversions = list_fx_conversions(ascending=True, portfolio_id=portfolio_id)
    before_ledger = _calculate_for_portfolio(settings, transactions, movements, conversions)
    after_ledger = _calculate_for_portfolio(settings, proposed, movements, conversions)
    warnings: list[str] = []
    if current["occurred_at"] != candidate["occurred_at"]:
        warnings.append("La fecha modificada puede cambiar el orden contable de operaciones posteriores.")
    if current["symbol"] != candidate["symbol"]:
        warnings.append("El cambio de activo recalcula por separado las posiciones del símbolo anterior y del nuevo.")
    return {
        "portfolio_id": portfolio_id,
        "transaction_id": transaction_id,
        "before": current,
        "after": _serialize_transaction(candidate_for_ledger),
        "asset": candidate["_asset"],
        "impact": _ledger_impact(before_ledger, after_ledger, candidate["symbol"]),
        "warnings": warnings,
    }


def update_portfolio_transaction(
    transaction_id: int,
    payload: PortfolioTransactionUpdate,
    quote_loader: Callable[[str], dict | None] | None = None,
    fx_loader: Callable[[str, str, datetime | date | None], dict] | None = None,
    portfolio_id: int = 1,
) -> dict:
    preview = preview_portfolio_transaction_update(
        transaction_id, payload, quote_loader, fx_loader, portfolio_id
    )
    current = preview["before"]
    candidate = preview["after"]
    upsert_asset(preview["asset"], portfolio_id)
    with get_connection() as connection:
        connection.execute(
            """
            UPDATE portfolio_transactions
            SET symbol = ?, transaction_type = ?, quantity = ?, price = ?, fees = ?,
                asset_name = ?, asset_type = ?, asset_currency = ?, exchange = ?, pricing_mode = ?,
                fx_rate_to_base = ?, occurred_at = ?, notes = ?, updated_at = CURRENT_TIMESTAMP,
                revision = revision + 1
            WHERE id = ? AND portfolio_id = ? AND is_deleted = 0
            """,
            (
                candidate["symbol"], candidate["transaction_type"], candidate["quantity"],
                candidate["price"], candidate["fees"], candidate["asset_name"],
                candidate["asset_type"], candidate["asset_currency"], candidate["exchange"],
                candidate["pricing_mode"], candidate["fx_rate_to_base"], candidate["occurred_at"],
                candidate["notes"], transaction_id, portfolio_id,
            ),
        )
        row = connection.execute(
            """
            SELECT id, portfolio_id, symbol, transaction_type, quantity, price, fees, asset_name, asset_type,
                   asset_currency, exchange, pricing_mode, fx_rate_to_base, occurred_at, notes, created_at,
                   updated_at, revision, is_deleted, deleted_at, deleted_reason
            FROM portfolio_transactions WHERE id = ? AND portfolio_id = ?
            """,
            (transaction_id, portfolio_id),
        ).fetchone()
        updated = _serialize_transaction(row)
        _write_audit(
            connection, portfolio_id, "transaction", transaction_id, "UPDATE",
            before=current, after=updated, reason=payload.reason,
        )
    return {"item": updated, "impact": preview["impact"], "warnings": preview["warnings"]}


def delete_portfolio_transaction(
    transaction_id: int, portfolio_id: int = 1, reason: str = "Eliminación solicitada por el usuario"
) -> dict:
    current = get_portfolio_transaction(transaction_id, portfolio_id)
    with get_connection() as connection:
        linked_dividend = connection.execute(
            """
            SELECT id
            FROM portfolio_cash_movements
            WHERE portfolio_id = ? AND reinvest_transaction_id = ? AND is_deleted = 0
            LIMIT 1
            """,
            (portfolio_id, transaction_id),
        ).fetchone()
    if linked_dividend is not None:
        raise PortfolioValidationError(
            "Esta compra pertenece a una reinversión de dividendos. Eliminá el dividendo vinculado "
            "para mantener ambos registros sincronizados."
        )
    transactions = list_portfolio_transactions(ascending=True, portfolio_id=portfolio_id)
    remaining = [item for item in transactions if int(item["id"]) != transaction_id]
    settings = get_portfolio_settings(portfolio_id)
    _calculate_for_portfolio(
        settings,
        remaining,
        list_cash_movements(ascending=True, portfolio_id=portfolio_id),
        list_fx_conversions(ascending=True, portfolio_id=portfolio_id),
    )
    with get_connection() as connection:
        connection.execute(
            """
            UPDATE portfolio_transactions
            SET is_deleted = 1, deleted_at = CURRENT_TIMESTAMP, deleted_reason = ?,
                updated_at = CURRENT_TIMESTAMP, revision = revision + 1
            WHERE id = ? AND portfolio_id = ? AND is_deleted = 0
            """,
            (reason.strip(), transaction_id, portfolio_id),
        )
        row = connection.execute(
            """
            SELECT id, portfolio_id, symbol, transaction_type, quantity, price, fees, asset_name, asset_type,
                   asset_currency, exchange, pricing_mode, fx_rate_to_base, occurred_at, notes, created_at,
                   updated_at, revision, is_deleted, deleted_at, deleted_reason
            FROM portfolio_transactions WHERE id = ? AND portfolio_id = ?
            """,
            (transaction_id, portfolio_id),
        ).fetchone()
        deleted = _serialize_transaction(row)
        _write_audit(
            connection, portfolio_id, "transaction", transaction_id, "DELETE",
            before=current, after=deleted, reason=reason,
        )
    return deleted


def restore_portfolio_transaction(
    transaction_id: int, portfolio_id: int = 1, reason: str = "Restauración solicitada por el usuario"
) -> dict:
    current = get_portfolio_transaction(transaction_id, portfolio_id, include_deleted=True)
    if not current["is_deleted"]:
        raise PortfolioValidationError("La operación no está eliminada")
    active = list_portfolio_transactions(ascending=True, portfolio_id=portfolio_id)
    candidate = dict(current)
    candidate["is_deleted"] = False
    settings = get_portfolio_settings(portfolio_id)
    _calculate_for_portfolio(
        settings,
        [*active, candidate],
        list_cash_movements(ascending=True, portfolio_id=portfolio_id),
        list_fx_conversions(ascending=True, portfolio_id=portfolio_id),
    )
    with get_connection() as connection:
        connection.execute(
            """
            UPDATE portfolio_transactions
            SET is_deleted = 0, deleted_at = NULL, deleted_reason = '',
                updated_at = CURRENT_TIMESTAMP, revision = revision + 1
            WHERE id = ? AND portfolio_id = ? AND is_deleted = 1
            """,
            (transaction_id, portfolio_id),
        )
        row = connection.execute(
            """
            SELECT id, portfolio_id, symbol, transaction_type, quantity, price, fees, asset_name, asset_type,
                   asset_currency, exchange, pricing_mode, fx_rate_to_base, occurred_at, notes, created_at,
                   updated_at, revision, is_deleted, deleted_at, deleted_reason
            FROM portfolio_transactions WHERE id = ? AND portfolio_id = ?
            """,
            (transaction_id, portfolio_id),
        ).fetchone()
        restored = _serialize_transaction(row)
        _write_audit(
            connection, portfolio_id, "transaction", transaction_id, "RESTORE",
            before=current, after=restored, reason=reason,
        )
    return restored


def create_cash_movement(
    payload: PortfolioCashMovementCreate,
    fx_loader: Callable[[str, str, datetime | date | None], dict] | None = None,
    portfolio_id: int = 1,
) -> dict:
    settings = get_portfolio_settings(portfolio_id)
    if payload.occurred_at > datetime.now(timezone.utc).replace(microsecond=0):
        raise PortfolioValidationError("La fecha del movimiento no puede estar en el futuro.")
    fx_rate = _load_fx_rate(
        payload.currency, settings["base_currency"], payload.occurred_at, payload.fx_rate_to_base, fx_loader
    )
    transactions = list_portfolio_transactions(ascending=True, portfolio_id=portfolio_id)
    movements = list_cash_movements(ascending=True, portfolio_id=portfolio_id)
    proposed = {
        "id": max((int(item["id"]) for item in movements), default=0) + 1,
        "portfolio_id": portfolio_id,
        "movement_type": payload.movement_type,
        "amount": payload.amount,
        "currency": payload.currency,
        "fx_rate_to_base": fx_rate,
        "symbol": payload.symbol,
        "occurred_at": payload.occurred_at.isoformat(),
        "notes": payload.notes,
    }
    _calculate_for_portfolio(
        settings,
        transactions,
        [*movements, proposed],
        list_fx_conversions(ascending=True, portfolio_id=portfolio_id),
    )
    with get_connection() as connection:
        cursor = connection.execute(
            """
            INSERT INTO portfolio_cash_movements
                (portfolio_id, movement_type, amount, currency, fx_rate_to_base, symbol, occurred_at, notes,
                 updated_at, revision, is_deleted)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, 1, 0)
            """,
            (
                portfolio_id, payload.movement_type, payload.amount, payload.currency, fx_rate,
                payload.symbol, payload.occurred_at.isoformat(), payload.notes,
            ),
        )
        movement_id = int(cursor.lastrowid)
        row = connection.execute(
            """
            SELECT id, portfolio_id, movement_type, amount, currency, fx_rate_to_base,
                   symbol, occurred_at, notes, created_at, updated_at, revision, is_deleted, deleted_at, deleted_reason,
                   gross_amount, withholding_tax, withholding_percent, dividend_per_share, shares_held,
                   dividend_source, reinvested, reinvest_transaction_id, ex_dividend_date
            FROM portfolio_cash_movements WHERE id = ? AND portfolio_id = ?
            """,
            (movement_id, portfolio_id),
        ).fetchone()
        created = _serialize_cash_movement(row)
        _write_audit(
            connection, portfolio_id, "cash_movement", movement_id, "CREATE",
            after=created, reason="Movimiento registrado",
        )
    return created


def _updated_cash_candidate(
    current: dict, payload: PortfolioCashMovementUpdate, settings: dict,
    fx_loader: Callable[[str, str, datetime | date | None], dict] | None = None,
) -> dict:
    if payload.occurred_at > datetime.now(timezone.utc).replace(microsecond=0):
        raise PortfolioValidationError("La fecha del movimiento no puede estar en el futuro.")
    fx_rate = _load_fx_rate(
        payload.currency, settings["base_currency"], payload.occurred_at,
        payload.fx_rate_to_base, fx_loader,
    )
    candidate = dict(current)
    candidate.update(
        {
            "movement_type": payload.movement_type,
            "amount": payload.amount,
            "currency": payload.currency,
            "fx_rate_to_base": fx_rate,
            "symbol": payload.symbol,
            "occurred_at": payload.occurred_at.isoformat(),
            "notes": payload.notes,
            "is_deleted": False,
        }
    )
    return candidate


def preview_cash_movement_update(
    movement_id: int, payload: PortfolioCashMovementUpdate,
    fx_loader: Callable[[str, str, datetime | date | None], dict] | None = None,
    portfolio_id: int = 1,
) -> dict:
    current = get_cash_movement(movement_id, portfolio_id)
    if current["movement_type"] == "DIVIDEND":
        raise PortfolioValidationError(
            "Los dividendos se gestionan desde el módulo Dividendos para conservar bruto, "
            "retención y reinversión. Eliminá y volvé a registrar el dividendo si necesitás corregirlo."
        )
    settings = get_portfolio_settings(portfolio_id)
    candidate = _updated_cash_candidate(current, payload, settings, fx_loader)
    transactions = list_portfolio_transactions(ascending=True, portfolio_id=portfolio_id)
    movements = list_cash_movements(ascending=True, portfolio_id=portfolio_id)
    proposed = [candidate if int(item["id"]) == movement_id else item for item in movements]
    conversions = list_fx_conversions(ascending=True, portfolio_id=portfolio_id)
    before_ledger = _calculate_for_portfolio(settings, transactions, movements, conversions)
    after_ledger = _calculate_for_portfolio(settings, transactions, proposed, conversions)
    return {
        "portfolio_id": portfolio_id,
        "movement_id": movement_id,
        "before": current,
        "after": _serialize_cash_movement(candidate),
        "impact": _ledger_impact(before_ledger, after_ledger),
        "warnings": [
            "La fecha modificada puede cambiar el efectivo disponible para operaciones posteriores."
        ] if current["occurred_at"] != candidate["occurred_at"] else [],
    }


def update_cash_movement(
    movement_id: int, payload: PortfolioCashMovementUpdate,
    fx_loader: Callable[[str, str, datetime | date | None], dict] | None = None,
    portfolio_id: int = 1,
) -> dict:
    preview = preview_cash_movement_update(movement_id, payload, fx_loader, portfolio_id)
    current = preview["before"]
    candidate = preview["after"]
    with get_connection() as connection:
        connection.execute(
            """
            UPDATE portfolio_cash_movements
            SET movement_type = ?, amount = ?, currency = ?, fx_rate_to_base = ?, symbol = ?,
                occurred_at = ?, notes = ?, updated_at = CURRENT_TIMESTAMP, revision = revision + 1
            WHERE id = ? AND portfolio_id = ? AND is_deleted = 0
            """,
            (
                candidate["movement_type"], candidate["amount"], candidate["currency"],
                candidate["fx_rate_to_base"], candidate["symbol"], candidate["occurred_at"],
                candidate["notes"], movement_id, portfolio_id,
            ),
        )
        row = connection.execute(
            """
            SELECT id, portfolio_id, movement_type, amount, currency, fx_rate_to_base,
                   symbol, occurred_at, notes, created_at, updated_at, revision, is_deleted, deleted_at, deleted_reason,
                   gross_amount, withholding_tax, withholding_percent, dividend_per_share, shares_held,
                   dividend_source, reinvested, reinvest_transaction_id, ex_dividend_date
            FROM portfolio_cash_movements WHERE id = ? AND portfolio_id = ?
            """,
            (movement_id, portfolio_id),
        ).fetchone()
        updated = _serialize_cash_movement(row)
        _write_audit(
            connection, portfolio_id, "cash_movement", movement_id, "UPDATE",
            before=current, after=updated, reason=payload.reason,
        )
    return {"item": updated, "impact": preview["impact"], "warnings": preview["warnings"]}


def delete_cash_movement(
    movement_id: int, portfolio_id: int = 1, reason: str = "Eliminación solicitada por el usuario"
) -> dict:
    current = get_cash_movement(movement_id, portfolio_id)
    linked_transaction_id = int(current.get("reinvest_transaction_id") or 0)
    linked_transaction = (
        get_portfolio_transaction(linked_transaction_id, portfolio_id)
        if linked_transaction_id
        else None
    )

    movements = list_cash_movements(ascending=True, portfolio_id=portfolio_id)
    remaining_movements = [item for item in movements if int(item["id"]) != movement_id]
    transactions = list_portfolio_transactions(ascending=True, portfolio_id=portfolio_id)
    remaining_transactions = [
        item for item in transactions if int(item["id"]) != linked_transaction_id
    ] if linked_transaction_id else transactions

    settings = get_portfolio_settings(portfolio_id)
    _calculate_for_portfolio(
        settings,
        remaining_transactions,
        remaining_movements,
        list_fx_conversions(ascending=True, portfolio_id=portfolio_id),
    )
    with get_connection() as connection:
        connection.execute(
            """
            UPDATE portfolio_cash_movements
            SET is_deleted = 1, deleted_at = CURRENT_TIMESTAMP, deleted_reason = ?,
                updated_at = CURRENT_TIMESTAMP, revision = revision + 1
            WHERE id = ? AND portfolio_id = ? AND is_deleted = 0
            """,
            (reason.strip(), movement_id, portfolio_id),
        )
        if linked_transaction_id:
            connection.execute(
                """
                UPDATE portfolio_transactions
                SET is_deleted = 1, deleted_at = CURRENT_TIMESTAMP, deleted_reason = ?,
                    updated_at = CURRENT_TIMESTAMP, revision = revision + 1
                WHERE id = ? AND portfolio_id = ? AND is_deleted = 0
                """,
                (f"Reinversión vinculada al dividendo {movement_id}: {reason.strip()}", linked_transaction_id, portfolio_id),
            )
            tx_row = connection.execute(
                """
                SELECT id, portfolio_id, symbol, transaction_type, quantity, price, fees, asset_name, asset_type,
                       asset_currency, exchange, pricing_mode, fx_rate_to_base, occurred_at, notes, created_at,
                       updated_at, revision, is_deleted, deleted_at, deleted_reason
                FROM portfolio_transactions WHERE id = ? AND portfolio_id = ?
                """,
                (linked_transaction_id, portfolio_id),
            ).fetchone()
            _write_audit(
                connection, portfolio_id, "transaction", linked_transaction_id, "DELETE",
                before=linked_transaction, after=_serialize_transaction(tx_row),
                reason=f"Eliminación conjunta con dividendo {movement_id}: {reason}",
            )
        row = connection.execute(
            """
            SELECT id, portfolio_id, movement_type, amount, currency, fx_rate_to_base,
                   symbol, occurred_at, notes, created_at, updated_at, revision, is_deleted, deleted_at, deleted_reason,
                   gross_amount, withholding_tax, withholding_percent, dividend_per_share, shares_held,
                   dividend_source, reinvested, reinvest_transaction_id, ex_dividend_date
            FROM portfolio_cash_movements WHERE id = ? AND portfolio_id = ?
            """,
            (movement_id, portfolio_id),
        ).fetchone()
        deleted = _serialize_cash_movement(row)
        _write_audit(
            connection, portfolio_id, "cash_movement", movement_id, "DELETE",
            before=current, after=deleted, reason=reason,
        )
    deleted["linked_transaction_deleted"] = linked_transaction_id or None
    return deleted


def restore_cash_movement(
    movement_id: int, portfolio_id: int = 1, reason: str = "Restauración solicitada por el usuario"
) -> dict:
    current = get_cash_movement(movement_id, portfolio_id, include_deleted=True)
    if not current["is_deleted"]:
        raise PortfolioValidationError("El movimiento no está eliminado")

    linked_transaction_id = int(current.get("reinvest_transaction_id") or 0)
    linked_transaction = None
    active_transactions = list_portfolio_transactions(ascending=True, portfolio_id=portfolio_id)
    candidate_transactions = list(active_transactions)
    if linked_transaction_id:
        linked_transaction = get_portfolio_transaction(
            linked_transaction_id, portfolio_id, include_deleted=True
        )
        if linked_transaction["is_deleted"]:
            restored_linked = dict(linked_transaction)
            restored_linked["is_deleted"] = False
            candidate_transactions.append(restored_linked)
        elif not any(int(item["id"]) == linked_transaction_id for item in active_transactions):
            candidate_transactions.append(linked_transaction)

    active_movements = list_cash_movements(ascending=True, portfolio_id=portfolio_id)
    candidate = dict(current)
    candidate["is_deleted"] = False
    settings = get_portfolio_settings(portfolio_id)
    _calculate_for_portfolio(
        settings,
        candidate_transactions,
        [*active_movements, candidate],
        list_fx_conversions(ascending=True, portfolio_id=portfolio_id),
    )
    with get_connection() as connection:
        connection.execute(
            """
            UPDATE portfolio_cash_movements
            SET is_deleted = 0, deleted_at = NULL, deleted_reason = '',
                updated_at = CURRENT_TIMESTAMP, revision = revision + 1
            WHERE id = ? AND portfolio_id = ? AND is_deleted = 1
            """,
            (movement_id, portfolio_id),
        )
        if linked_transaction_id and linked_transaction and linked_transaction["is_deleted"]:
            connection.execute(
                """
                UPDATE portfolio_transactions
                SET is_deleted = 0, deleted_at = NULL, deleted_reason = '',
                    updated_at = CURRENT_TIMESTAMP, revision = revision + 1
                WHERE id = ? AND portfolio_id = ? AND is_deleted = 1
                """,
                (linked_transaction_id, portfolio_id),
            )
            tx_row = connection.execute(
                """
                SELECT id, portfolio_id, symbol, transaction_type, quantity, price, fees, asset_name, asset_type,
                       asset_currency, exchange, pricing_mode, fx_rate_to_base, occurred_at, notes, created_at,
                       updated_at, revision, is_deleted, deleted_at, deleted_reason
                FROM portfolio_transactions WHERE id = ? AND portfolio_id = ?
                """,
                (linked_transaction_id, portfolio_id),
            ).fetchone()
            _write_audit(
                connection, portfolio_id, "transaction", linked_transaction_id, "RESTORE",
                before=linked_transaction, after=_serialize_transaction(tx_row),
                reason=f"Restauración conjunta con dividendo {movement_id}: {reason}",
            )
        row = connection.execute(
            """
            SELECT id, portfolio_id, movement_type, amount, currency, fx_rate_to_base,
                   symbol, occurred_at, notes, created_at, updated_at, revision, is_deleted, deleted_at, deleted_reason,
                   gross_amount, withholding_tax, withholding_percent, dividend_per_share, shares_held,
                   dividend_source, reinvested, reinvest_transaction_id, ex_dividend_date
            FROM portfolio_cash_movements WHERE id = ? AND portfolio_id = ?
            """,
            (movement_id, portfolio_id),
        ).fetchone()
        restored = _serialize_cash_movement(row)
        _write_audit(
            connection, portfolio_id, "cash_movement", movement_id, "RESTORE",
            before=current, after=restored, reason=reason,
        )
    restored["linked_transaction_restored"] = (
        linked_transaction_id if linked_transaction and linked_transaction["is_deleted"] else None
    )
    return restored


def _fx_conversion_candidate(
    payload: PortfolioFxConversionCreate | PortfolioFxConversionUpdate,
    settings: dict,
    fx_loader: Callable[[str, str, datetime | date | None], dict] | None,
    *,
    current: dict | None = None,
) -> dict:
    if payload.occurred_at > datetime.now(timezone.utc).replace(microsecond=0):
        raise PortfolioValidationError("La fecha de la conversión no puede estar en el futuro.")
    if payload.from_currency not in SUPPORTED_CURRENCIES or payload.to_currency not in SUPPORTED_CURRENCIES:
        raise PortfolioValidationError(
            f"Moneda no soportada. Usá: {', '.join(sorted(SUPPORTED_CURRENCIES))}."
        )
    if payload.pricing_mode == "AUTO":
        if fx_loader is None:
            raise PortfolioValidationError("La tasa automática requiere un proveedor FX")
        try:
            exchange_rate = float(
                fx_loader(payload.from_currency, payload.to_currency, payload.occurred_at)["rate"]
            )
        except Exception as exc:
            raise PortfolioValidationError(
                f"No se pudo obtener la tasa {payload.from_currency}/{payload.to_currency}: {exc}. "
                "Podés elegir tasa manual."
            ) from exc
    else:
        if payload.exchange_rate is None:
            raise PortfolioValidationError("La conversión manual requiere un tipo de cambio")
        exchange_rate = float(payload.exchange_rate)

    from_fx = _load_fx_rate(
        payload.from_currency,
        settings["base_currency"],
        payload.occurred_at,
        payload.from_fx_rate_to_base,
        fx_loader,
    )
    to_fx = _load_fx_rate(
        payload.to_currency,
        settings["base_currency"],
        payload.occurred_at,
        payload.to_fx_rate_to_base,
        fx_loader,
    )
    fee_currency = payload.fee_currency or payload.from_currency
    candidate = dict(current or {})
    candidate.update(
        {
            "portfolio_id": settings["id"],
            "from_currency": payload.from_currency,
            "to_currency": payload.to_currency,
            "from_amount": float(payload.from_amount),
            "to_amount": float(payload.from_amount) * exchange_rate,
            "exchange_rate": exchange_rate,
            "pricing_mode": payload.pricing_mode,
            "fee_amount": float(payload.fee_amount),
            "fee_currency": fee_currency,
            "from_fx_rate_to_base": from_fx,
            "to_fx_rate_to_base": to_fx,
            "realized_fx_pnl_base": float((current or {}).get("realized_fx_pnl_base", 0)),
            "occurred_at": payload.occurred_at.isoformat(),
            "notes": payload.notes,
            "is_deleted": False,
        }
    )
    return candidate


def preview_fx_conversion_create(
    payload: PortfolioFxConversionCreate,
    fx_loader: Callable[[str, str, datetime | date | None], dict] | None = None,
    portfolio_id: int = 1,
) -> dict:
    settings = get_portfolio_settings(portfolio_id)
    candidate = _fx_conversion_candidate(payload, settings, fx_loader)
    transactions = list_portfolio_transactions(ascending=True, portfolio_id=portfolio_id)
    movements = list_cash_movements(ascending=True, portfolio_id=portfolio_id)
    conversions = list_fx_conversions(ascending=True, portfolio_id=portfolio_id)
    candidate["id"] = max((int(item["id"]) for item in conversions), default=0) + 1
    before = _calculate_for_portfolio(settings, transactions, movements, conversions)
    after = _calculate_for_portfolio(settings, transactions, movements, [*conversions, candidate])
    candidate["realized_fx_pnl_base"] = _round_money(
        after["realized_fx_pnl"] - before["realized_fx_pnl"]
    )
    return {
        "portfolio_id": portfolio_id,
        "after": _serialize_fx_conversion(candidate),
        "impact": _ledger_impact(before, after),
        "warnings": [],
    }


def create_fx_conversion(
    payload: PortfolioFxConversionCreate,
    fx_loader: Callable[[str, str, datetime | date | None], dict] | None = None,
    portfolio_id: int = 1,
) -> dict:
    settings = get_portfolio_settings(portfolio_id)
    candidate = _fx_conversion_candidate(payload, settings, fx_loader)
    transactions = list_portfolio_transactions(ascending=True, portfolio_id=portfolio_id)
    movements = list_cash_movements(ascending=True, portfolio_id=portfolio_id)
    conversions = list_fx_conversions(ascending=True, portfolio_id=portfolio_id)
    candidate["id"] = max((int(item["id"]) for item in conversions), default=0) + 1
    before = _calculate_for_portfolio(settings, transactions, movements, conversions)
    after = _calculate_for_portfolio(settings, transactions, movements, [*conversions, candidate])
    candidate["realized_fx_pnl_base"] = _round_money(
        after["realized_fx_pnl"] - before["realized_fx_pnl"]
    )
    with get_connection() as connection:
        cursor = connection.execute(
            """
            INSERT INTO portfolio_fx_conversions
                (portfolio_id, from_currency, to_currency, from_amount, to_amount,
                 exchange_rate, pricing_mode, fee_amount, fee_currency,
                 from_fx_rate_to_base, to_fx_rate_to_base, realized_fx_pnl_base,
                 occurred_at, notes, updated_at, revision, is_deleted)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, 1, 0)
            """,
            (
                portfolio_id, candidate["from_currency"], candidate["to_currency"],
                candidate["from_amount"], candidate["to_amount"], candidate["exchange_rate"],
                candidate["pricing_mode"], candidate["fee_amount"], candidate["fee_currency"],
                candidate["from_fx_rate_to_base"], candidate["to_fx_rate_to_base"],
                candidate["realized_fx_pnl_base"], candidate["occurred_at"], candidate["notes"],
            ),
        )
        conversion_id = int(cursor.lastrowid)
        row = connection.execute(
            """
            SELECT id, portfolio_id, from_currency, to_currency, from_amount, to_amount,
                   exchange_rate, pricing_mode, fee_amount, fee_currency,
                   from_fx_rate_to_base, to_fx_rate_to_base, realized_fx_pnl_base,
                   occurred_at, notes, created_at, updated_at, revision,
                   is_deleted, deleted_at, deleted_reason
            FROM portfolio_fx_conversions WHERE id = ? AND portfolio_id = ?
            """,
            (conversion_id, portfolio_id),
        ).fetchone()
        created = _serialize_fx_conversion(row)
        _write_audit(
            connection, portfolio_id, "fx_conversion", conversion_id, "CREATE",
            after=created, reason="Conversión de divisas registrada",
        )
    return created


def preview_fx_conversion_update(
    conversion_id: int,
    payload: PortfolioFxConversionUpdate,
    fx_loader: Callable[[str, str, datetime | date | None], dict] | None = None,
    portfolio_id: int = 1,
) -> dict:
    current = get_fx_conversion(conversion_id, portfolio_id)
    settings = get_portfolio_settings(portfolio_id)
    candidate = _fx_conversion_candidate(payload, settings, fx_loader, current=current)
    transactions = list_portfolio_transactions(ascending=True, portfolio_id=portfolio_id)
    movements = list_cash_movements(ascending=True, portfolio_id=portfolio_id)
    conversions = list_fx_conversions(ascending=True, portfolio_id=portfolio_id)
    proposed = [candidate if int(item["id"]) == conversion_id else item for item in conversions]
    before = _calculate_for_portfolio(settings, transactions, movements, conversions)
    after = _calculate_for_portfolio(settings, transactions, movements, proposed)
    candidate["realized_fx_pnl_base"] = _round_money(
        current.get("realized_fx_pnl_base", 0)
        + after["realized_fx_pnl"] - before["realized_fx_pnl"]
    )
    return {
        "portfolio_id": portfolio_id,
        "conversion_id": conversion_id,
        "before": current,
        "after": _serialize_fx_conversion(candidate),
        "impact": _ledger_impact(before, after),
        "warnings": [
            "La fecha modificada puede cambiar los saldos disponibles para operaciones posteriores."
        ] if current["occurred_at"] != candidate["occurred_at"] else [],
    }


def update_fx_conversion(
    conversion_id: int,
    payload: PortfolioFxConversionUpdate,
    fx_loader: Callable[[str, str, datetime | date | None], dict] | None = None,
    portfolio_id: int = 1,
) -> dict:
    preview = preview_fx_conversion_update(conversion_id, payload, fx_loader, portfolio_id)
    current = preview["before"]
    candidate = preview["after"]
    with get_connection() as connection:
        connection.execute(
            """
            UPDATE portfolio_fx_conversions
            SET from_currency = ?, to_currency = ?, from_amount = ?, to_amount = ?,
                exchange_rate = ?, pricing_mode = ?, fee_amount = ?, fee_currency = ?,
                from_fx_rate_to_base = ?, to_fx_rate_to_base = ?, realized_fx_pnl_base = ?,
                occurred_at = ?, notes = ?, updated_at = CURRENT_TIMESTAMP, revision = revision + 1
            WHERE id = ? AND portfolio_id = ? AND is_deleted = 0
            """,
            (
                candidate["from_currency"], candidate["to_currency"], candidate["from_amount"],
                candidate["to_amount"], candidate["exchange_rate"], candidate["pricing_mode"],
                candidate["fee_amount"], candidate["fee_currency"],
                candidate["from_fx_rate_to_base"], candidate["to_fx_rate_to_base"],
                candidate["realized_fx_pnl_base"], candidate["occurred_at"], candidate["notes"],
                conversion_id, portfolio_id,
            ),
        )
        row = connection.execute(
            """
            SELECT id, portfolio_id, from_currency, to_currency, from_amount, to_amount,
                   exchange_rate, pricing_mode, fee_amount, fee_currency,
                   from_fx_rate_to_base, to_fx_rate_to_base, realized_fx_pnl_base,
                   occurred_at, notes, created_at, updated_at, revision,
                   is_deleted, deleted_at, deleted_reason
            FROM portfolio_fx_conversions WHERE id = ? AND portfolio_id = ?
            """,
            (conversion_id, portfolio_id),
        ).fetchone()
        updated = _serialize_fx_conversion(row)
        _write_audit(
            connection, portfolio_id, "fx_conversion", conversion_id, "UPDATE",
            before=current, after=updated, reason=payload.reason,
        )
    return {"item": updated, "impact": preview["impact"], "warnings": preview["warnings"]}


def delete_fx_conversion(
    conversion_id: int,
    portfolio_id: int = 1,
    reason: str = "Eliminación solicitada por el usuario",
) -> dict:
    current = get_fx_conversion(conversion_id, portfolio_id)
    settings = get_portfolio_settings(portfolio_id)
    conversions = list_fx_conversions(ascending=True, portfolio_id=portfolio_id)
    remaining = [item for item in conversions if int(item["id"]) != conversion_id]
    _calculate_for_portfolio(
        settings,
        list_portfolio_transactions(ascending=True, portfolio_id=portfolio_id),
        list_cash_movements(ascending=True, portfolio_id=portfolio_id),
        remaining,
    )
    with get_connection() as connection:
        connection.execute(
            """
            UPDATE portfolio_fx_conversions
            SET is_deleted = 1, deleted_at = CURRENT_TIMESTAMP, deleted_reason = ?,
                updated_at = CURRENT_TIMESTAMP, revision = revision + 1
            WHERE id = ? AND portfolio_id = ? AND is_deleted = 0
            """,
            (reason.strip(), conversion_id, portfolio_id),
        )
        row = connection.execute(
            """
            SELECT id, portfolio_id, from_currency, to_currency, from_amount, to_amount,
                   exchange_rate, pricing_mode, fee_amount, fee_currency,
                   from_fx_rate_to_base, to_fx_rate_to_base, realized_fx_pnl_base,
                   occurred_at, notes, created_at, updated_at, revision,
                   is_deleted, deleted_at, deleted_reason
            FROM portfolio_fx_conversions WHERE id = ? AND portfolio_id = ?
            """,
            (conversion_id, portfolio_id),
        ).fetchone()
        deleted = _serialize_fx_conversion(row)
        _write_audit(
            connection, portfolio_id, "fx_conversion", conversion_id, "DELETE",
            before=current, after=deleted, reason=reason,
        )
    return deleted


def restore_fx_conversion(
    conversion_id: int,
    portfolio_id: int = 1,
    reason: str = "Restauración solicitada por el usuario",
) -> dict:
    current = get_fx_conversion(conversion_id, portfolio_id, include_deleted=True)
    if not current["is_deleted"]:
        raise PortfolioValidationError("La conversión FX no está eliminada")
    settings = get_portfolio_settings(portfolio_id)
    candidate = dict(current)
    candidate["is_deleted"] = False
    _calculate_for_portfolio(
        settings,
        list_portfolio_transactions(ascending=True, portfolio_id=portfolio_id),
        list_cash_movements(ascending=True, portfolio_id=portfolio_id),
        [*list_fx_conversions(ascending=True, portfolio_id=portfolio_id), candidate],
    )
    with get_connection() as connection:
        connection.execute(
            """
            UPDATE portfolio_fx_conversions
            SET is_deleted = 0, deleted_at = NULL, deleted_reason = '',
                updated_at = CURRENT_TIMESTAMP, revision = revision + 1
            WHERE id = ? AND portfolio_id = ? AND is_deleted = 1
            """,
            (conversion_id, portfolio_id),
        )
        row = connection.execute(
            """
            SELECT id, portfolio_id, from_currency, to_currency, from_amount, to_amount,
                   exchange_rate, pricing_mode, fee_amount, fee_currency,
                   from_fx_rate_to_base, to_fx_rate_to_base, realized_fx_pnl_base,
                   occurred_at, notes, created_at, updated_at, revision,
                   is_deleted, deleted_at, deleted_reason
            FROM portfolio_fx_conversions WHERE id = ? AND portfolio_id = ?
            """,
            (conversion_id, portfolio_id),
        ).fetchone()
        restored = _serialize_fx_conversion(row)
        _write_audit(
            connection, portfolio_id, "fx_conversion", conversion_id, "RESTORE",
            before=current, after=restored, reason=reason,
        )
    return restored


def import_dividends(
    symbol: str,
    period: str,
    dividend_loader: Callable[[str, str], dict],
    fx_loader: Callable[[str, str, datetime | date | None], dict] | None = None,
    portfolio_id: int = 1,
) -> dict:
    asset = get_portfolio_asset(symbol, portfolio_id)
    if asset is None:
        raise PortfolioValidationError("Primero registrá una operación del activo en este portafolio")
    if asset["pricing_mode"] != "AUTO":
        raise PortfolioValidationError("La importación automática sólo está disponible para activos de Yahoo Finance")

    transactions = [
        item for item in list_portfolio_transactions(ascending=True, portfolio_id=portfolio_id)
        if item["symbol"] == symbol
    ]
    if not transactions:
        raise PortfolioValidationError("No hay operaciones del activo para calcular la tenencia histórica")

    try:
        history = dividend_loader(symbol, period)
    except Exception as exc:
        raise PortfolioValidationError(f"No se pudieron consultar dividendos: {exc}") from exc

    existing_markers = {
        str(item.get("notes") or "")
        for item in list_cash_movements(ascending=True, portfolio_id=portfolio_id)
        if item["movement_type"] == "DIVIDEND" and item.get("symbol") == symbol
    }
    imported: list[dict] = []
    skipped = 0
    for event in history.get("events", []):
        event_date = _parse_datetime(str(event["date"]))
        marker = f"AUTO_DIVIDEND:{symbol}:{event_date.date().isoformat()}"
        if any(marker in note for note in existing_markers):
            skipped += 1
            continue
        quantity = 0.0
        for transaction in transactions:
            if _parse_datetime(transaction["occurred_at"]) > event_date:
                break
            quantity += (
                float(transaction["quantity"])
                if transaction["transaction_type"] == "BUY"
                else -float(transaction["quantity"])
            )
        amount_per_unit = float(event["amount_per_unit"])
        total_amount = quantity * amount_per_unit
        if quantity <= EPSILON or total_amount <= EPSILON:
            skipped += 1
            continue
        payload = PortfolioCashMovementCreate(
            movement_type="DIVIDEND",
            amount=total_amount,
            currency=asset["currency"],
            symbol=symbol,
            occurred_at=event_date,
            notes=f"Importado desde yfinance · {amount_per_unit:.8g} por unidad · {marker}",
        )
        imported.append(create_cash_movement(payload, fx_loader, portfolio_id))
        existing_markers.add(marker)

    return {
        "portfolio_id": portfolio_id,
        "symbol": symbol,
        "period": period,
        "imported_count": len(imported),
        "skipped_count": skipped,
        "movements": imported,
        "source": history.get("source") or "Yahoo Finance vía yfinance",
    }


def _xnpv(rate: float, cash_flows: list[tuple[date, float]]) -> float:
    if rate <= -0.999999:
        return float("inf")
    first_date = cash_flows[0][0]
    return sum(amount / ((1 + rate) ** (((flow_date - first_date).days) / 365.0)) for flow_date, amount in cash_flows)


def calculate_xirr(cash_flows: list[tuple[date, float]]) -> float | None:
    if len(cash_flows) < 2 or not any(amount < 0 for _, amount in cash_flows) or not any(amount > 0 for _, amount in cash_flows):
        return None
    ordered = sorted(cash_flows, key=lambda item: item[0])
    low, high = -0.9999, 10.0
    low_value, high_value = _xnpv(low, ordered), _xnpv(high, ordered)
    attempts = 0
    while low_value * high_value > 0 and high < 1_000_000 and attempts < 20:
        high *= 2
        high_value = _xnpv(high, ordered)
        attempts += 1
    if low_value * high_value > 0:
        return None
    for _ in range(200):
        midpoint = (low + high) / 2
        value = _xnpv(midpoint, ordered)
        if abs(value) < 1e-7:
            return midpoint
        if low_value * value <= 0:
            high = midpoint
            high_value = value
        else:
            low = midpoint
            low_value = value
    return (low + high) / 2


def get_portfolio_overview(
    quote_loader: Callable[[str], dict | None] | None = None,
    fx_loader: Callable[[str, str, datetime | date | None], dict] | None = None,
    portfolio_id: int = 1,
) -> dict:
    settings = get_portfolio_settings(portfolio_id)
    transactions = list_portfolio_transactions(ascending=True, portfolio_id=portfolio_id)
    movements = list_cash_movements(ascending=True, portfolio_id=portfolio_id)
    conversions = list_fx_conversions(ascending=True, portfolio_id=portfolio_id)
    corporate_actions = _active_corporate_actions(portfolio_id)
    ledger = _calculate_for_portfolio(settings, transactions, movements, conversions, corporate_actions)
    catalog = {item["symbol"]: item for item in list_portfolio_assets(portfolio_id)}

    holdings: list[dict] = []
    unpriced_assets = 0
    currencies: set[str] = set()
    for symbol, state in sorted(ledger["states"].items()):
        quantity = float(state["quantity"])
        if quantity <= EPSILON:
            continue
        asset = catalog.get(symbol, {})
        asset_currency = str(asset.get("currency") or state.get("currency") or settings["base_currency"]).upper()
        currencies.add(asset_currency)
        name = str(asset.get("name") or state.get("name") or symbol)
        asset_type = str(asset.get("asset_type") or state.get("asset_type") or "OTHER")
        exchange = str(asset.get("exchange") or state.get("exchange") or "")
        pricing_mode = str(asset.get("pricing_mode") or state.get("pricing_mode") or "AUTO")
        sector = str(asset.get("sector") or "").strip()
        industry = str(asset.get("industry") or "").strip()
        quote_error: str | None = None
        fx_rate = 1.0
        fx_error: str | None = None
        last_updated: str | None = None
        valuation_source = "cost_basis_fallback"
        current_price_local = 0.0

        if pricing_mode == "MANUAL":
            manual_price = asset.get("manual_price")
            if manual_price is not None:
                current_price_local = float(manual_price)
                valuation_source = "manual"
                last_updated = asset.get("updated_at")
        elif quote_loader is not None:
            try:
                quote = quote_loader(symbol)
                if quote:
                    current_price_local = float(quote["price"])
                    name = str(quote.get("name") or name)
                    asset_currency = str(quote.get("currency") or asset_currency).upper()
                    asset_type = str(quote.get("asset_type") or asset_type)
                    exchange = str(quote.get("exchange") or quote.get("market") or exchange)
                    sector = str(quote.get("sector") or sector or "").strip()
                    industry = str(quote.get("industry") or industry or "").strip()
                    last_updated = quote.get("last_updated")
                    valuation_source = "market"
                    if sector or industry:
                        try:
                            upsert_asset({
                                "symbol": symbol, "name": name, "asset_type": asset_type,
                                "currency": asset_currency, "exchange": exchange,
                                "pricing_mode": pricing_mode, "manual_price": asset.get("manual_price"),
                                "provider_symbol": asset.get("provider_symbol") or symbol,
                                "sector": sector, "industry": industry,
                                "metadata_source": quote.get("source") or "market",
                                "metadata_updated_at": last_updated,
                            }, portfolio_id)
                        except Exception:
                            pass
            except Exception as exc:
                quote_error = str(exc)

        if asset_currency != settings["base_currency"]:
            try:
                if fx_loader is None:
                    raise PortfolioError("Falta el proveedor FX")
                fx_rate = float(fx_loader(asset_currency, settings["base_currency"], None)["rate"])
            except Exception as exc:
                fx_error = str(exc)
                valuation_source = "cost_basis_fallback"

        cost_basis_base = float(state["cost_basis"])
        if valuation_source == "cost_basis_fallback" or current_price_local <= 0:
            market_value_base = cost_basis_base
            current_price_base = float(state["average_price_base"])
            unpriced_assets += 1
        else:
            current_price_base = current_price_local * fx_rate
            market_value_base = quantity * current_price_base
        unrealized = market_value_base - cost_basis_base
        average_local = (
            cost_basis_base / quantity / fx_rate
            if quantity > EPSILON and fx_rate > EPSILON else 0.0
        )
        holdings.append(
            {
                "symbol": symbol,
                "name": name,
                "asset_type": asset_type,
                "sector": sector or "Sin clasificar",
                "industry": industry or "Sin clasificar",
                "exchange": exchange,
                "pricing_mode": pricing_mode,
                "quantity": _round_money(quantity),
                "average_price": _round_money(average_local),
                "average_price_base": _round_money(float(state["average_price_base"])),
                "cost_basis": _round_money(cost_basis_base),
                "current_price": _round_money(current_price_local if current_price_local > 0 else average_local),
                "current_price_base": _round_money(current_price_base),
                "market_value": _round_money(market_value_base),
                "unrealized_pnl": _round_money(unrealized),
                "unrealized_pnl_percent": _round_money((unrealized / cost_basis_base * 100) if cost_basis_base else 0.0),
                "realized_pnl": _round_money(float(state["realized_pnl"])),
                "currency": asset_currency,
                "base_currency": settings["base_currency"],
                "fx_rate_to_base": _round_money(fx_rate),
                "last_updated": last_updated,
                "valuation_source": valuation_source,
                "quote_error": quote_error,
                "fx_error": fx_error,
            }
        )

    cash_balances: list[dict] = []
    cash_balance = 0.0
    unrealized_cash_fx_pnl = 0.0
    cash_valuation_errors = 0
    for balance in ledger["cash_balances"]:
        currency = str(balance["currency"]).upper()
        currencies.add(currency)
        current_rate = float(balance["fx_rate_to_base"])
        fx_status = "stored"
        fx_error: str | None = None
        if currency == settings["base_currency"]:
            current_rate = 1.0
            fx_status = "base"
        elif fx_loader is not None:
            try:
                current_rate = float(fx_loader(currency, settings["base_currency"], None)["rate"])
                fx_status = "market"
            except Exception as exc:
                fx_error = str(exc)
                cash_valuation_errors += 1
        base_value = float(balance["balance"]) * current_rate
        cost_basis_base = float(balance["cost_basis_base"])
        cash_fx_pnl = base_value - cost_basis_base if float(balance["balance"]) > EPSILON else 0.0
        cash_balance += base_value
        unrealized_cash_fx_pnl += cash_fx_pnl
        cash_balances.append(
            {
                **balance,
                "fx_rate_to_base": _round_money(current_rate),
                "base_value": _round_money(base_value),
                "unrealized_fx_pnl": _round_money(cash_fx_pnl),
                "valuation_source": fx_status,
                "fx_error": fx_error,
            }
        )

    invested_cost = sum(item["cost_basis"] for item in holdings)
    market_value = sum(item["market_value"] for item in holdings)
    unrealized_pnl = market_value - invested_cost
    total_equity = cash_balance + market_value
    external_capital = float(settings["initial_cash"]) + float(ledger["net_contributions"])
    investment_profit = total_equity - external_capital
    allocation_total = market_value or 1.0
    allocation = [
        {
            "symbol": item["symbol"],
            "value": item["market_value"],
            "percent": _round_money(item["market_value"] / allocation_total * 100),
        }
        for item in sorted(holdings, key=lambda holding: holding["market_value"], reverse=True)
    ]

    xirr_flows: list[tuple[date, float]] = [
        (_parse_datetime(settings["created_at"]).date(), -float(settings["initial_cash"]))
    ]
    for movement in movements:
        amount = abs(float(movement["cash_effect"]))
        if movement["movement_type"] == "DEPOSIT":
            xirr_flows.append((_parse_datetime(movement["occurred_at"]).date(), -amount))
        elif movement["movement_type"] == "WITHDRAWAL":
            xirr_flows.append((_parse_datetime(movement["occurred_at"]).date(), amount))
    xirr_flows.append((datetime.now(timezone.utc).date(), total_equity))
    xirr = calculate_xirr(xirr_flows)

    valuation_partial = unpriced_assets > 0 or cash_valuation_errors > 0
    return {
        "portfolio_id": portfolio_id,
        "settings": settings,
        "summary": {
            "initial_cash": _round_money(float(settings["initial_cash"])),
            "cash_balance": _round_money(cash_balance),
            "invested_cost": _round_money(invested_cost),
            "market_value": _round_money(market_value),
            "total_equity": _round_money(total_equity),
            "realized_pnl": _round_money(float(ledger["realized_pnl"])),
            "realized_fx_pnl": _round_money(float(ledger["realized_fx_pnl"])),
            "unrealized_cash_fx_pnl": _round_money(unrealized_cash_fx_pnl),
            "unrealized_pnl": _round_money(unrealized_pnl),
            "dividends": _round_money(float(ledger["dividends"])),
            "interest": _round_money(float(ledger["interest"])),
            "taxes": _round_money(float(ledger["taxes"])),
            "other_fees": _round_money(float(ledger["other_fees"])),
            "fx_fees": _round_money(float(ledger["fx_fees"])),
            "income": _round_money(float(ledger["income"])),
            "expenses": _round_money(float(ledger["expenses"])),
            "deposits": _round_money(float(ledger["deposits"])),
            "withdrawals": _round_money(float(ledger["withdrawals"])),
            "net_contributions": _round_money(float(ledger["net_contributions"])),
            "external_capital": _round_money(external_capital),
            "investment_profit": _round_money(investment_profit),
            "total_pnl": _round_money(investment_profit),
            "total_return_percent": _round_money(
                (investment_profit / external_capital * 100) if external_capital > EPSILON else 0.0
            ),
            "xirr_percent": _round_money(xirr * 100) if xirr is not None else None,
            "holdings_count": len(holdings),
            "transactions_count": len(transactions),
            "cash_movements_count": len(movements),
            "fx_conversions_count": len(conversions),
            "corporate_actions_count": len(corporate_actions),
            "assets_count": len(catalog),
            "currencies_count": len(currencies),
            "priced_assets": len(holdings) - unpriced_assets,
            "unpriced_assets": unpriced_assets,
            "cash_valuation_errors": cash_valuation_errors,
            "valuation_status": "partial" if valuation_partial else "complete",
            "margin_used": _round_money(float(ledger["margin_used_base"])),
            "allow_margin": bool(settings.get("allow_margin", False)),
            "currency": settings["base_currency"],
        },
        "cash_balances": cash_balances,
        "holdings": holdings,
        "allocation": allocation,
        "transactions": list(reversed(transactions)),
        "cash_movements": list(reversed(movements)),
        "fx_conversions": list(reversed(conversions)),
        "corporate_actions": list(reversed(corporate_actions)),
        "assets": list(catalog.values()),
        "is_demo": False,
        "source": "SQLite + Yahoo Finance vía yfinance + saldos y conversiones FX",
        "last_updated": datetime.now(timezone.utc).isoformat(),
    }


def _date_from_timestamp(value: str) -> date:
    return _parse_datetime(value).date()


def get_equity_curve(
    period: str,
    history_loader: Callable[[str, str, str], dict],
    fx_history_loader: Callable[[str, str, str], dict] | None = None,
    portfolio_id: int = 1,
) -> dict:
    settings = get_portfolio_settings(portfolio_id)
    transactions = list_portfolio_transactions(ascending=True, portfolio_id=portfolio_id)
    movements = list_cash_movements(ascending=True, portfolio_id=portfolio_id)
    conversions = list_fx_conversions(ascending=True, portfolio_id=portfolio_id)
    corporate_actions = _active_corporate_actions(portfolio_id)
    catalog = {asset["symbol"]: asset for asset in list_portfolio_assets(portfolio_id)}
    if not transactions and not movements and not conversions and not corporate_actions:
        return {
            "portfolio_id": portfolio_id,
            "period": period,
            "currency": settings["base_currency"],
            "points": [{
                "date": datetime.now(timezone.utc).date().isoformat(),
                "equity": _round_money(float(settings["initial_cash"])),
                "cash": _round_money(float(settings["initial_cash"])),
                "market_value": 0.0,
                "external_flow": 0.0,
                "cash_balances": {settings["base_currency"]: _round_money(float(settings["initial_cash"]))},
            }],
            "twr_percent": 0.0,
            "is_partial": False,
            "errors": [],
        }

    symbols = sorted(
        {str(item["symbol"]) for item in transactions}
        | {str(item.get("target_symbol")) for item in corporate_actions if item.get("target_symbol")}
    )
    price_maps: dict[str, dict[date, float]] = {}
    fx_maps: dict[str, dict[date, float]] = {settings["base_currency"]: {}}
    all_events = transactions + movements + conversions + corporate_actions
    all_dates: set[date] = {_parse_datetime(item["occurred_at"]).date() for item in all_events}
    errors: list[str] = []

    for symbol in symbols:
        asset = catalog.get(symbol, {})
        if asset.get("pricing_mode") == "MANUAL":
            continue
        try:
            history = history_loader(symbol, period, "1d")
            prices: dict[date, float] = {}
            for candle in history.get("candles", []):
                candle_date = _date_from_timestamp(str(candle["date"]))
                prices[candle_date] = float(candle["close"])
                all_dates.add(candle_date)
            if prices:
                price_maps[symbol] = prices
            else:
                errors.append(f"{symbol}: histórico vacío")
        except Exception as exc:
            errors.append(f"{symbol}: {exc}")

    currencies = {settings["base_currency"]}
    currencies.update(str((catalog.get(symbol) or {}).get("currency") or settings["base_currency"]) for symbol in symbols)
    currencies.update(str(item.get("currency") or settings["base_currency"]) for item in movements)
    for item in conversions:
        currencies.add(str(item["from_currency"]))
        currencies.add(str(item["to_currency"]))
    for item in corporate_actions:
        if item.get("cash_currency"):
            currencies.add(str(item["cash_currency"]))
        if item.get("target_currency"):
            currencies.add(str(item["target_currency"]))

    for currency in currencies:
        if currency == settings["base_currency"]:
            continue
        if fx_history_loader is None:
            errors.append(f"{currency}: histórico FX no disponible")
            continue
        try:
            history = fx_history_loader(currency, settings["base_currency"], period)
            fx_maps[currency] = {
                _date_from_timestamp(str(candle["date"])): float(candle["close"])
                for candle in history.get("candles", [])
            }
            all_dates.update(fx_maps[currency].keys())
        except Exception as exc:
            errors.append(f"FX {currency}: {exc}")

    all_dates.add(datetime.now(timezone.utc).date())
    dates = sorted(all_dates)
    cash_balances: dict[str, float] = {settings["base_currency"]: float(settings["initial_cash"])}
    states: dict[str, dict[str, float]] = {}
    last_prices: dict[str, float] = {}
    last_fx: dict[str, float] = {settings["base_currency"]: 1.0}
    events = _combined_events(transactions, movements, conversions, corporate_actions)
    event_index = 0
    points: list[dict] = []
    twr_factor = 1.0
    previous_equity: float | None = None

    def add_cash(currency: str, amount: float) -> None:
        cash_balances[currency] = cash_balances.get(currency, 0.0) + amount

    for current_date in dates:
        end_of_day = datetime.combine(current_date, time.max, tzinfo=timezone.utc)
        external_flow = 0.0
        while event_index < len(events) and _parse_datetime(events[event_index][1]["occurred_at"]) <= end_of_day:
            event_type, item = events[event_index]
            if event_type == "cash":
                currency = str(item.get("currency") or settings["base_currency"])
                amount = float(item["amount"])
                rate = float(item.get("fx_rate_to_base", 1))
                last_fx[currency] = rate
                movement_type = str(item["movement_type"])
                if movement_type == "DEPOSIT":
                    add_cash(currency, amount)
                    external_flow += amount * rate
                elif movement_type == "WITHDRAWAL":
                    add_cash(currency, -amount)
                    external_flow -= amount * rate
                elif movement_type in {"DIVIDEND", "INTEREST"}:
                    add_cash(currency, amount)
                else:
                    add_cash(currency, -amount)
            elif event_type == "fx":
                from_currency = str(item["from_currency"])
                to_currency = str(item["to_currency"])
                from_rate = float(item.get("from_fx_rate_to_base", 1))
                to_rate = float(item.get("to_fx_rate_to_base", 1))
                last_fx[from_currency] = from_rate
                last_fx[to_currency] = to_rate
                add_cash(from_currency, -float(item["from_amount"]))
                received = float(item["to_amount"])
                fee = float(item.get("fee_amount", 0))
                fee_currency = str(item.get("fee_currency") or from_currency)
                if fee > 0 and fee_currency == from_currency:
                    add_cash(from_currency, -fee)
                elif fee > 0 and fee_currency == to_currency:
                    received -= fee
                add_cash(to_currency, received)
            elif event_type == "corporate":
                action_type = str(item["action_type"])
                symbol = str(item["symbol"])
                state = states.get(symbol)
                if state is None or state["quantity"] <= EPSILON:
                    raise PortfolioValidationError(
                        f"No hay tenencia de {symbol} para aplicar {action_type} en la curva histórica."
                    )
                ratio = float(item.get("quantity_ratio") or 1.0)
                if action_type in {"SPLIT", "REVERSE_SPLIT"}:
                    state["quantity"] *= ratio
                elif action_type == "STOCK_DIVIDEND":
                    state["quantity"] += state["quantity"] * ratio
                elif action_type in {"TICKER_CHANGE", "MERGER"}:
                    target_symbol = str(item.get("target_symbol") or "")
                    target = states.setdefault(target_symbol, {"quantity": 0.0, "cost_basis": 0.0})
                    target["quantity"] += state["quantity"] * ratio
                    target["cost_basis"] += state["cost_basis"]
                    state["quantity"] = 0.0
                    state["cost_basis"] = 0.0
                elif action_type == "SPINOFF":
                    target_symbol = str(item.get("target_symbol") or "")
                    allocation = float(item.get("cost_allocation_percent") or 0) / 100.0
                    child_cost = state["cost_basis"] * allocation
                    state["cost_basis"] -= child_cost
                    target = states.setdefault(target_symbol, {"quantity": 0.0, "cost_basis": 0.0})
                    target["quantity"] += state["quantity"] * ratio
                    target["cost_basis"] += child_cost
                elif action_type == "RETURN_OF_CAPITAL":
                    amount = float(item.get("cash_amount") or 0)
                    currency = str(item.get("cash_currency") or settings["base_currency"])
                    rate = float(item.get("fx_rate_to_base") or 1.0)
                    last_fx[currency] = rate
                    add_cash(currency, amount)
                    state["cost_basis"] = max(0.0, state["cost_basis"] - amount * rate)
            else:
                symbol = str(item["symbol"])
                currency = str(item.get("asset_currency") or settings["base_currency"])
                rate = float(item.get("fx_rate_to_base", 1))
                last_fx[currency] = rate
                state = states.setdefault(symbol, {"quantity": 0.0, "cost_basis": 0.0})
                quantity = float(item["quantity"])
                price = float(item["price"])
                fees = float(item["fees"])
                if item["transaction_type"] == "BUY":
                    required_local = quantity * price + fees
                    add_cash(currency, -required_local)
                    state["quantity"] += quantity
                    state["cost_basis"] += required_local * rate
                else:
                    average = state["cost_basis"] / state["quantity"] if state["quantity"] else 0.0
                    add_cash(currency, quantity * price - fees)
                    state["quantity"] -= quantity
                    state["cost_basis"] -= quantity * average
                    if abs(state["quantity"]) <= EPSILON:
                        state["quantity"] = 0.0
                        state["cost_basis"] = 0.0
            event_index += 1

        for symbol, prices in price_maps.items():
            if current_date in prices:
                last_prices[symbol] = prices[current_date]
        for currency, rates in fx_maps.items():
            if current_date in rates:
                last_fx[currency] = rates[current_date]

        cash_base = 0.0
        for currency, amount in cash_balances.items():
            rate = last_fx.get(currency, 1.0 if currency == settings["base_currency"] else 0.0)
            cash_base += amount * rate

        market_value = 0.0
        for symbol, state in states.items():
            if state["quantity"] <= EPSILON:
                continue
            asset = catalog.get(symbol, {})
            currency = str(asset.get("currency") or settings["base_currency"])
            fx_rate = last_fx.get(currency)
            if fx_rate is None:
                tx_rates = [float(tx.get("fx_rate_to_base", 1)) for tx in transactions if tx["symbol"] == symbol]
                fx_rate = tx_rates[-1] if tx_rates else 1.0
            if asset.get("pricing_mode") == "MANUAL" and asset.get("manual_price") is not None:
                local_price = float(asset["manual_price"])
            else:
                fallback_local = (
                    state["cost_basis"] / state["quantity"] / fx_rate
                    if state["quantity"] and fx_rate else 0.0
                )
                local_price = last_prices.get(symbol, fallback_local)
            market_value += state["quantity"] * local_price * fx_rate

        equity = cash_base + market_value
        if previous_equity is not None and previous_equity > EPSILON:
            subperiod_return = (equity - external_flow) / previous_equity - 1
            twr_factor *= 1 + subperiod_return
        previous_equity = equity
        points.append({
            "date": current_date.isoformat(),
            "equity": _round_money(equity),
            "cash": _round_money(cash_base),
            "market_value": _round_money(market_value),
            "external_flow": _round_money(external_flow),
            "cash_balances": {currency: _round_money(amount) for currency, amount in sorted(cash_balances.items())},
        })

    return {
        "portfolio_id": portfolio_id,
        "period": period,
        "currency": settings["base_currency"],
        "points": points,
        "twr_percent": _round_money((twr_factor - 1) * 100),
        "is_partial": bool(errors),
        "errors": errors,
    }

