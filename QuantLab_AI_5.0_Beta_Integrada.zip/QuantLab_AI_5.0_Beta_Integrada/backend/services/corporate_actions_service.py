from __future__ import annotations

from datetime import date, datetime, timezone
from typing import Callable

from backend.core.database import get_connection
from backend.models import PortfolioCorporateActionCreate, PortfolioCorporateActionUpdate
from backend.services.portfolio_service import (
    EPSILON,
    PortfolioValidationError,
    _calculate_for_portfolio,
    _ledger_impact,
    _write_audit,
    get_portfolio_settings,
    list_cash_movements,
    list_fx_conversions,
    list_portfolio_assets,
    list_portfolio_transactions,
)


def _serialize(row) -> dict:
    item = dict(row)
    for key in ("quantity_ratio", "cost_allocation_percent", "cash_amount", "fx_rate_to_base"):
        if item.get(key) is not None:
            item[key] = float(item[key])
    item["is_deleted"] = bool(item.get("is_deleted", 0))
    item["revision"] = int(item.get("revision") or 1)
    return item



def _get_from_connection(connection, action_id: int, portfolio_id: int) -> dict:
    row = connection.execute(
        """
        SELECT id, portfolio_id, action_type, symbol, target_symbol, quantity_ratio,
               cost_allocation_percent, cash_amount, cash_currency, fx_rate_to_base,
               target_name, target_asset_type, target_currency, target_exchange,
               occurred_at, notes, source, is_deleted, deleted_at, deleted_reason,
               revision, created_at, updated_at
        FROM portfolio_corporate_actions WHERE id = ? AND portfolio_id = ?
        """,
        (action_id, portfolio_id),
    ).fetchone()
    if row is None:
        raise PortfolioValidationError("El evento corporativo no existe")
    return _serialize(row)

def list_corporate_actions(
    portfolio_id: int = 1,
    *,
    include_deleted: bool = False,
    ascending: bool = False,
) -> list[dict]:
    deleted_clause = "" if include_deleted else " AND is_deleted = 0"
    direction = "ASC" if ascending else "DESC"
    with get_connection() as connection:
        rows = connection.execute(
            f"""
            SELECT id, portfolio_id, action_type, symbol, target_symbol, quantity_ratio,
                   cost_allocation_percent, cash_amount, cash_currency, fx_rate_to_base,
                   target_name, target_asset_type, target_currency, target_exchange,
                   occurred_at, notes, source, is_deleted, deleted_at, deleted_reason,
                   revision, created_at, updated_at
            FROM portfolio_corporate_actions
            WHERE portfolio_id = ?{deleted_clause}
            ORDER BY occurred_at {direction}, id {direction}
            """,
            (portfolio_id,),
        ).fetchall()
    return [_serialize(row) for row in rows]


def get_corporate_action(
    action_id: int,
    portfolio_id: int = 1,
    *,
    include_deleted: bool = False,
) -> dict:
    deleted_clause = "" if include_deleted else " AND is_deleted = 0"
    with get_connection() as connection:
        row = connection.execute(
            f"""
            SELECT id, portfolio_id, action_type, symbol, target_symbol, quantity_ratio,
                   cost_allocation_percent, cash_amount, cash_currency, fx_rate_to_base,
                   target_name, target_asset_type, target_currency, target_exchange,
                   occurred_at, notes, source, is_deleted, deleted_at, deleted_reason,
                   revision, created_at, updated_at
            FROM portfolio_corporate_actions
            WHERE id = ? AND portfolio_id = ?{deleted_clause}
            """,
            (action_id, portfolio_id),
        ).fetchone()
    if row is None:
        raise PortfolioValidationError("El evento corporativo no existe")
    return _serialize(row)


def _resolve_fx_rate(
    payload: PortfolioCorporateActionCreate,
    settings: dict,
    fx_loader: Callable[[str, str, datetime | date | None], dict] | None,
) -> float | None:
    if payload.action_type != "RETURN_OF_CAPITAL":
        return None
    currency = (payload.cash_currency or settings["base_currency"]).upper()
    if currency == settings["base_currency"]:
        return 1.0
    if payload.fx_rate_to_base is not None:
        return float(payload.fx_rate_to_base)
    if fx_loader is None:
        raise PortfolioValidationError("Falta la tasa FX para la devolución de capital")
    return float(fx_loader(currency, settings["base_currency"], payload.occurred_at)["rate"])


def _resolve_target(
    payload: PortfolioCorporateActionCreate,
    portfolio_id: int,
    quote_loader: Callable[[str], dict | None] | None,
) -> dict:
    if not payload.target_symbol:
        return {
            "target_name": payload.target_name,
            "target_asset_type": payload.target_asset_type,
            "target_currency": payload.target_currency,
            "target_exchange": payload.target_exchange,
        }
    assets = {item["symbol"]: item for item in list_portfolio_assets(portfolio_id)}
    existing = assets.get(payload.target_symbol)
    source_asset = assets.get(payload.symbol) or {}
    quote = None
    if existing is None and quote_loader is not None:
        try:
            quote = quote_loader(payload.target_symbol)
        except Exception:
            quote = None
    source = existing or quote or {}
    return {
        "target_name": payload.target_name or source.get("name") or payload.target_symbol,
        "target_asset_type": payload.target_asset_type or source.get("asset_type") or source_asset.get("asset_type") or "EQUITY",
        "target_currency": (
            payload.target_currency or source.get("currency") or source_asset.get("currency") or "USD"
        ).upper(),
        "target_exchange": payload.target_exchange or source.get("exchange") or source.get("market") or source_asset.get("exchange") or "",
    }


def _candidate(
    payload: PortfolioCorporateActionCreate,
    settings: dict,
    portfolio_id: int,
    quote_loader: Callable[[str], dict | None] | None,
    fx_loader: Callable[[str, str, datetime | date | None], dict] | None,
    *,
    action_id: int = 0,
) -> dict:
    if payload.occurred_at > datetime.now(timezone.utc).replace(microsecond=0):
        raise PortfolioValidationError("La fecha del evento corporativo no puede estar en el futuro")
    target = _resolve_target(payload, portfolio_id, quote_loader)
    fx_rate = _resolve_fx_rate(payload, settings, fx_loader)
    return {
        "id": action_id,
        "portfolio_id": portfolio_id,
        "action_type": payload.action_type,
        "symbol": payload.symbol,
        "target_symbol": payload.target_symbol,
        "quantity_ratio": float(payload.quantity_ratio),
        "cost_allocation_percent": float(payload.cost_allocation_percent),
        "cash_amount": float(payload.cash_amount),
        "cash_currency": (
            payload.cash_currency or settings["base_currency"]
        ).upper() if payload.action_type == "RETURN_OF_CAPITAL" else None,
        "fx_rate_to_base": fx_rate,
        **target,
        "occurred_at": payload.occurred_at.isoformat(),
        "notes": payload.notes,
        "source": payload.source,
        "is_deleted": False,
    }


def _ledger_context(portfolio_id: int):
    settings = get_portfolio_settings(portfolio_id)
    transactions = list_portfolio_transactions(ascending=True, portfolio_id=portfolio_id)
    movements = list_cash_movements(ascending=True, portfolio_id=portfolio_id)
    conversions = list_fx_conversions(ascending=True, portfolio_id=portfolio_id)
    actions = list_corporate_actions(portfolio_id, ascending=True)
    return settings, transactions, movements, conversions, actions


def preview_corporate_action(
    payload: PortfolioCorporateActionCreate,
    quote_loader: Callable[[str], dict | None] | None = None,
    fx_loader: Callable[[str, str, datetime | date | None], dict] | None = None,
    portfolio_id: int = 1,
) -> dict:
    settings, transactions, movements, conversions, actions = _ledger_context(portfolio_id)
    candidate = _candidate(
        payload, settings, portfolio_id, quote_loader, fx_loader,
        action_id=max((int(item["id"]) for item in actions), default=0) + 1,
    )
    before = _calculate_for_portfolio(settings, transactions, movements, conversions, actions)
    after = _calculate_for_portfolio(settings, transactions, movements, conversions, [*actions, candidate])
    target = payload.target_symbol or payload.symbol
    return {
        "valid": True,
        "event": candidate,
        "impact": _ledger_impact(before, after, target),
        "source_position_before": before["states"].get(payload.symbol),
        "source_position_after": after["states"].get(payload.symbol),
        "target_position_after": after["states"].get(target),
    }


def _upsert_target_asset(connection, event: dict) -> None:
    target_symbol = event.get("target_symbol")
    if not target_symbol:
        return
    connection.execute(
        """
        INSERT INTO portfolio_assets
            (portfolio_id, symbol, name, asset_type, currency, exchange, pricing_mode,
             manual_price, provider_symbol, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, 'AUTO', NULL, ?, CURRENT_TIMESTAMP)
        ON CONFLICT(portfolio_id, symbol) DO UPDATE SET
            name = excluded.name,
            asset_type = excluded.asset_type,
            currency = excluded.currency,
            exchange = excluded.exchange,
            provider_symbol = excluded.provider_symbol,
            updated_at = CURRENT_TIMESTAMP
        """,
        (
            event["portfolio_id"], target_symbol,
            event.get("target_name") or target_symbol,
            event.get("target_asset_type") or "EQUITY",
            event.get("target_currency") or "USD",
            event.get("target_exchange") or "",
            target_symbol,
        ),
    )
    if event["action_type"] == "TICKER_CHANGE":
        connection.execute(
            """
            INSERT INTO market_symbol_aliases (old_symbol, new_symbol, notes, updated_at)
            VALUES (?, ?, ?, CURRENT_TIMESTAMP)
            ON CONFLICT(old_symbol) DO UPDATE SET
                new_symbol = excluded.new_symbol,
                notes = excluded.notes,
                updated_at = CURRENT_TIMESTAMP
            """,
            (event["symbol"], target_symbol, "Cambio de ticker registrado en el portafolio"),
        )


def create_corporate_action(
    payload: PortfolioCorporateActionCreate,
    quote_loader: Callable[[str], dict | None] | None = None,
    fx_loader: Callable[[str, str, datetime | date | None], dict] | None = None,
    portfolio_id: int = 1,
) -> dict:
    preview = preview_corporate_action(payload, quote_loader, fx_loader, portfolio_id)
    event = preview["event"]
    with get_connection() as connection:
        cursor = connection.execute(
            """
            INSERT INTO portfolio_corporate_actions
                (portfolio_id, action_type, symbol, target_symbol, quantity_ratio,
                 cost_allocation_percent, cash_amount, cash_currency, fx_rate_to_base,
                 target_name, target_asset_type, target_currency, target_exchange,
                 occurred_at, notes, source, revision, is_deleted, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 0, CURRENT_TIMESTAMP)
            """,
            (
                portfolio_id, event["action_type"], event["symbol"], event["target_symbol"],
                event["quantity_ratio"], event["cost_allocation_percent"], event["cash_amount"],
                event["cash_currency"], event["fx_rate_to_base"], event["target_name"],
                event["target_asset_type"], event["target_currency"], event["target_exchange"],
                event["occurred_at"], event["notes"], event["source"],
            ),
        )
        action_id = int(cursor.lastrowid)
        created = _get_from_connection(connection, action_id, portfolio_id)
        _upsert_target_asset(connection, created)
        _write_audit(
            connection, portfolio_id, "corporate_action", action_id, "CREATE",
            after=created, reason="Evento corporativo registrado",
        )
    return get_corporate_action(action_id, portfolio_id)


def preview_corporate_action_update(
    action_id: int,
    payload: PortfolioCorporateActionUpdate,
    quote_loader: Callable[[str], dict | None] | None = None,
    fx_loader: Callable[[str, str, datetime | date | None], dict] | None = None,
    portfolio_id: int = 1,
) -> dict:
    current = get_corporate_action(action_id, portfolio_id)
    settings, transactions, movements, conversions, actions = _ledger_context(portfolio_id)
    candidate = _candidate(payload, settings, portfolio_id, quote_loader, fx_loader, action_id=action_id)
    proposed = [candidate if int(item["id"]) == action_id else item for item in actions]
    before = _calculate_for_portfolio(settings, transactions, movements, conversions, actions)
    after = _calculate_for_portfolio(settings, transactions, movements, conversions, proposed)
    return {
        "valid": True,
        "before": current,
        "after": candidate,
        "impact": _ledger_impact(before, after, payload.target_symbol or payload.symbol),
    }


def update_corporate_action(
    action_id: int,
    payload: PortfolioCorporateActionUpdate,
    quote_loader: Callable[[str], dict | None] | None = None,
    fx_loader: Callable[[str, str, datetime | date | None], dict] | None = None,
    portfolio_id: int = 1,
) -> dict:
    preview = preview_corporate_action_update(action_id, payload, quote_loader, fx_loader, portfolio_id)
    before, event = preview["before"], preview["after"]
    with get_connection() as connection:
        if before.get("action_type") == "TICKER_CHANGE" and (
            event.get("action_type") != "TICKER_CHANGE"
            or before.get("symbol") != event.get("symbol")
            or before.get("target_symbol") != event.get("target_symbol")
        ):
            connection.execute(
                "DELETE FROM market_symbol_aliases WHERE old_symbol = ?",
                (before.get("symbol"),),
            )
        connection.execute(
            """
            UPDATE portfolio_corporate_actions SET
                action_type = ?, symbol = ?, target_symbol = ?, quantity_ratio = ?,
                cost_allocation_percent = ?, cash_amount = ?, cash_currency = ?, fx_rate_to_base = ?,
                target_name = ?, target_asset_type = ?, target_currency = ?, target_exchange = ?,
                occurred_at = ?, notes = ?, source = ?, revision = revision + 1,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ? AND portfolio_id = ? AND is_deleted = 0
            """,
            (
                event["action_type"], event["symbol"], event["target_symbol"], event["quantity_ratio"],
                event["cost_allocation_percent"], event["cash_amount"], event["cash_currency"],
                event["fx_rate_to_base"], event["target_name"], event["target_asset_type"],
                event["target_currency"], event["target_exchange"], event["occurred_at"],
                event["notes"], event["source"], action_id, portfolio_id,
            ),
        )
        updated = _get_from_connection(connection, action_id, portfolio_id)
        _upsert_target_asset(connection, updated)
        _write_audit(
            connection, portfolio_id, "corporate_action", action_id, "UPDATE",
            before=before, after=updated, reason=payload.reason,
        )
    return get_corporate_action(action_id, portfolio_id)


def delete_corporate_action(
    action_id: int,
    portfolio_id: int = 1,
    reason: str = "Eliminación solicitada por el usuario",
) -> None:
    current = get_corporate_action(action_id, portfolio_id)
    settings, transactions, movements, conversions, actions = _ledger_context(portfolio_id)
    proposed = [item for item in actions if int(item["id"]) != action_id]
    _calculate_for_portfolio(settings, transactions, movements, conversions, proposed)
    with get_connection() as connection:
        if current.get("action_type") == "TICKER_CHANGE":
            connection.execute(
                "DELETE FROM market_symbol_aliases WHERE old_symbol = ?",
                (current.get("symbol"),),
            )
        connection.execute(
            """
            UPDATE portfolio_corporate_actions
            SET is_deleted = 1, deleted_at = CURRENT_TIMESTAMP, deleted_reason = ?,
                revision = revision + 1, updated_at = CURRENT_TIMESTAMP
            WHERE id = ? AND portfolio_id = ? AND is_deleted = 0
            """,
            (reason.strip(), action_id, portfolio_id),
        )
        after = _get_from_connection(connection, action_id, portfolio_id)
        _write_audit(
            connection, portfolio_id, "corporate_action", action_id, "DELETE",
            before=current, after=after, reason=reason,
        )


def restore_corporate_action(
    action_id: int,
    portfolio_id: int = 1,
    reason: str = "Restauración solicitada por el usuario",
) -> dict:
    current = get_corporate_action(action_id, portfolio_id, include_deleted=True)
    if not current["is_deleted"]:
        return current
    settings, transactions, movements, conversions, actions = _ledger_context(portfolio_id)
    candidate = {**current, "is_deleted": False}
    _calculate_for_portfolio(settings, transactions, movements, conversions, [*actions, candidate])
    with get_connection() as connection:
        connection.execute(
            """
            UPDATE portfolio_corporate_actions
            SET is_deleted = 0, deleted_at = NULL, deleted_reason = '',
                revision = revision + 1, updated_at = CURRENT_TIMESTAMP
            WHERE id = ? AND portfolio_id = ?
            """,
            (action_id, portfolio_id),
        )
        restored = _get_from_connection(connection, action_id, portfolio_id)
        _upsert_target_asset(connection, restored)
        _write_audit(
            connection, portfolio_id, "corporate_action", action_id, "RESTORE",
            before=current, after=restored, reason=reason,
        )
    return get_corporate_action(action_id, portfolio_id)
