# Changelog

## 5.0.0 Beta 1 — Integración completa

- Primer release acumulativo: no requiere ensamblar fases anteriores.
- Integra el núcleo completo de Alpha 1.4, 1.5 y 1.6 en una única carpeta.
- Nombre y versión unificados como `5.0.0-beta.1-integrated`.
- Nuevo `README.md` orientado a instalación limpia y actualización segura.
- Nuevo `LEEME_PRIMERO.txt` con instrucciones de doble clic.
- `iniciar_windows.bat` mejorado: detecta una instancia activa, espera el health check y ejecuta sin modo reload.
- Nuevo `verificar_windows.bat` para dependencias, compilación y 114 pruebas.
- `run.ps1` y `run.sh` ajustados para ejecución estable.
- Documentos `INTEGRACION_COMPLETA.md` e `INSTALACION_Y_ACTUALIZACION.md`.
- Auditoría de los cursos originales incorporada como documentación.
- Base, logs y backups de validación excluidos del paquete final.
- 114 pruebas automatizadas aprobadas; backend, JavaScript y HTML verificados.

## 4.1.0 Alpha 1.6 — Fase 3

- Centro de alertas educativas por concentración, drawdown, volatilidad y precio.
- Reglas predeterminadas por portafolio y reglas de precio personalizables.
- Severidad, umbral, activación y revisión por regla.
- Eventos con estados activa, atendida, descartada y resuelta.
- Resolución automática cuando la condición deja de cumplirse.
- Cola `ai_notification_outbox` preparada para futuras notificaciones externas.
- Memoria estructurada mediante snapshots verificables por herramienta.
- Sección “Qué cambió desde el análisis anterior” dentro del agente.
- Historial de cambios materiales por portafolio.
- Proveedor de lenguaje desactivado por defecto sin eliminar su interfaz.
- Nuevas tablas `ai_alert_rules`, `ai_alert_events`, `ai_analysis_snapshots` y `ai_notification_outbox`.
- Migración al esquema 15 y backup automático desde Fase 2.
- Interfaz responsive para reglas, eventos y memoria.
- 114 pruebas automatizadas aprobadas.

## 4.1.0 Alpha 1.6 — Fase 2

- Análisis fundamental con estados financieros, métricas, cobertura y fecha de fuente.
- Puntajes educativos de calidad, crecimiento, fortaleza financiera y valuación.
- Factores favorables, riesgos y datos faltantes separados.
- Comparación fundamental de dos a seis empresas.
- Contexto conversacional por sesión para preguntas de seguimiento.
- Dos nuevas herramientas: `fundamental_analysis` y `fundamental_comparison`.
- Proveedor de lenguaje opcional mediante interfaz y OpenAI Responses API.
- Fallback determinístico obligatorio ante ausencia o error del proveedor.
- Configuración de uso de LLM y estilo por portafolio.
- Archivo `.env` local cargado del lado servidor sin reemplazar variables del sistema.
- Migración al esquema 14 y backup automático desde Fase 1.
- Interfaz actualizada con consultas fundamentales y estado del proveedor.
- 105 pruebas automatizadas aprobadas.

## 4.1.0 Alpha 1.6 — Fase 1

- Nuevo agente financiero verificable con planificador de intención.
- Seis herramientas internas para mercado, técnico, portafolio, actividad, Analytics y comparación.
- Respuestas separadas en hechos, cálculos, interpretación, riesgos y límites.
- Fuentes, fechas, tiempos, estado y calidad de datos por herramienta.
- Historial de conversaciones aislado por portafolio.
- Tablas `ai_analysis_sessions`, `ai_analysis_messages` y `ai_tool_runs`.
- API v1 de capacidades, consultas, sesiones y archivado.
- Interfaz responsive con consultas sugeridas, historial y trazabilidad expandible.
- Barreras: sin órdenes, sin escrituras financieras y sin cifras inventadas.
- Migración al esquema 13 y backup automático desde Alpha 1.5 fase 4.
- Documentación de arquitectura, seguridad y reutilización de cursos.
- 98 pruebas automatizadas aprobadas.

## 4.1.0 Alpha 1.5 — Fase 4

- Sortino, desviación bajista, VaR/CVaR histórico, Calmar y Omega.
- Beta, correlación, alpha, tracking error, information ratio y captura de mercados.
- Matriz de correlación y covarianza anualizada en moneda base.
- Contribución marginal y porcentual de cada posición al riesgo.
- Metadatos y concentración por sector e industria con cobertura parcial visible.
- Comparador de hasta seis activos con normalización base 100.
- Atribución por posición entre precio abierto, FX abierto, dividendos y realizado combinado.
- Resumen de riesgo estructurado para el futuro agente AI.
- Exportación CSV de métricas y alertas.
- Gráficos SVG con zoom temporal y tooltips nativos.
- Migración al esquema 12 y backup automático desde fase 3.
- Reutilización auditada de código y conceptos de los cursos originales.
- 92 pruebas automatizadas aprobadas.

## 4.1.0 Alpha 1.5 — Fase 3

- Motor cronológico de eventos corporativos integrado al ledger.
- Split y reverse split preservando costo total.
- Cambio de ticker con transferencia de posición y alias de mercado.
- Fusión por intercambio de acciones.
- Spin-off con asignación porcentual del costo.
- Dividendo en acciones sin ingreso ficticio.
- Devolución de capital con reducción de base y exceso realizado.
- Vista previa, edición, revisiones, eliminación lógica, restauración y auditoría.
- Integración con posiciones, resumen y curva patrimonial.
- Nueva tabla `portfolio_corporate_actions`.
- Migración al esquema 11 y backup automático desde fase 2.
- Interfaz responsive y API v1 para eventos.
- Inventario de reutilización de cursos actualizado.
- 85 pruebas automatizadas aprobadas.

## 4.1.0 Alpha 1.5 — Fase 2

- Dividendos brutos, retenciones y netos almacenados por separado.
- Configuración predeterminada de retención, reinversión y horizonte de calendario por portafolio.
- Registro avanzado de dividendos con moneda, FX, cantidad histórica e importe por acción.
- Reinversión opcional mediante una compra vinculada y auditable.
- Eliminación/restauración conjunta de dividendos reinvertidos y bloqueo de borrado aislado de la compra vinculada.
- Importación histórica de Yahoo Finance con retención configurable y control de duplicados.
- Reinversión de importados mediante el cierre histórico más cercano cuando está disponible.
- Resumen por portafolio y por activo: bruto, impuesto, neto, yield sobre costo y valor de mercado.
- Calendario histórico y estimado, diferenciando explícitamente proyecciones de hechos registrados.
- Exportación CSV específica de dividendos.
- Atribución del P&L no realizado entre efecto precio y efecto FX para posiciones abiertas.
- Nueva tabla `portfolio_dividend_settings` y columnas de dividendos en `portfolio_cash_movements`.
- Migración al esquema 10 con backup automático desde Alpha 1.5 fase 1.
- Nueva interfaz responsive para registro, importación, preferencias, métricas y calendario.
- Inventario de reutilización de cursos actualizado.
- 71 pruebas automatizadas aprobadas.

## 4.1.0 Alpha 1.5 — Fase 1

- Nueva pantalla Analytics aislada por portafolio.
- Motor TWR diario neutralizado por depósitos y retiros.
- Retornos diario, MTD, YTD, por período seleccionado y desde el inicio.
- Benchmark configurable por cartera: SPY, QQQ, ^MERV, BTC-USD, personalizado o desactivado.
- Comparación base 100 y diferencia de rendimiento.
- Alineación de calendarios y conversión histórica del benchmark a moneda base.
- Volatilidad anualizada y ratio de Sharpe educativo.
- Drawdown máximo, actual, mejor día, peor día y curva de drawdown.
- Concentración por activo, moneda y tipo; HHI y puntaje de diversificación.
- Rendimiento por posición con P&L realizado, no realizado y dividendos.
- Descomposición de resultados entre activos, dividendos, intereses, FX e impuestos/comisiones.
- Nueva tabla `portfolio_analytics_settings`.
- Migración de esquema 9 y backup automático desde Alpha 1.4 completa.
- API `GET/PUT /api/v1/analytics/settings` y `GET /api/v1/analytics/overview`.
- Documentación de metodología y de reutilización de código/conceptos de los cursos.
- Interfaz responsive con gráficos SVG, pestañas de concentración y estados parciales.
- 63 pruebas automatizadas aprobadas.

## 4.1.0 Alpha 1.4 — Fase 5

- API oficial versionada bajo `/api/v1` con compatibilidad temporal `/api`.
- Capa `MarketDataProvider` para desacoplar Yahoo Finance.
- Estados de calidad: actualizado, demorado, último cierre, manual o no disponible.
- Reintentos, fallback manual y alias de símbolos.
- Manejo global de errores con `X-Request-ID`.
- Logs JSON rotativos, variables de entorno y CORS configurable.
- Migraciones ordenadas e idempotentes hasta esquema 8.
- Indicador global de carga, toasts, filtros, ordenamiento, tema claro/oscuro y accesibilidad básica.
- Cierre verificado de Alpha 1.4.

## 4.1.0 Alpha 1.4 — Fase 4

- Plantilla CSV genérica para operaciones, movimientos y conversiones FX.
- Vista previa sin escritura y validación cronológica del ledger.
- Reporte por fila aceptada, rechazada o duplicada.
- Importación parcial opcional y modo estricto de todo o nada.
- Fingerprints SHA-256 para detección de duplicados.
- Tabla `portfolio_import_batches` e historial visible de lotes.
- Trazabilidad mediante `import_fingerprint`, `import_batch_id` e `import_row_number`.
- Exportación de registros, operaciones, movimientos, conversiones, posiciones y resumen.
- Backups `.qlbackup` con SQLite y `manifest.json`.
- Checksum SHA-256, `PRAGMA quick_check` y validación de esquema antes de restaurar.
- Backup automático previo a cada restauración.
- Restauración atómica y migraciones posteriores automáticas.
- Tabla `backup_history` y listado de copias desde la interfaz.
- Límites configurables para tamaño de CSV, filas y backups.
- Migración de esquema 7 y backup automático desde Fase 3.
- Interfaz responsive de portabilidad y seguridad.
- 48 pruebas automatizadas.

## 4.1.0 Alpha 1.4 — Fase 3

- Saldos reales separados por moneda.
- Compras financiadas exclusivamente con la moneda del activo.
- Margen opcional por portafolio, desactivado por defecto.
- Tabla `portfolio_fx_conversions` con tasas, importes, comisiones y fechas.
- Conversiones automáticas mediante el proveedor FX y conversiones manuales.
- Vista previa de conversiones nuevas y editadas.
- Edición segura, borrado lógico, restauración y auditoría FX.
- P&L FX realizado y no realizado separado de las comisiones.
- Valuación actual de cada caja en la moneda base.
- Migración de esquema 6 y backup automático desde fase 2.
- Corrección del tratamiento de comisiones cobradas en la moneda de destino para evitar doble descuento.
- Interfaz responsive para saldos, conversiones y configuración de margen.
- 40 pruebas automatizadas.

## 4.1.0 Alpha 1.4 — Fase 2

- Edición segura de compras y ventas sin borrar el registro original.
- Corrección de símbolo, tipo de operación, cantidad, precio, comisión, fecha, notas, moneda, FX y metadatos del activo.
- Edición de depósitos, retiros, dividendos, intereses, impuestos y gastos.
- Vista previa del impacto sobre efectivo, posición, costo y P&L antes de guardar.
- Revalidación completa del ledger después de cada corrección.
- Borrado lógico con `is_deleted`, `deleted_at` y `deleted_reason`.
- Restauración de operaciones y movimientos eliminados.
- Número de revisión por registro y fechas de actualización.
- Tabla `portfolio_audit_log` con estado anterior, estado posterior, motivo y acción.
- Historial de cambios visible desde el módulo Portafolio.
- Opción para mostrar u ocultar registros eliminados.
- Backup automático antes de migrar una base Alpha 1.4 fase 1.
- Registro de esquema mediante `schema_migrations` versión 5.
- 33 pruebas automatizadas, incluidas edición, invalidación, borrado lógico, restauración, auditoría y migración.

## 4.1.0 Alpha 1.4 — Fase 1

- Tabla `portfolios` con nombre, capital inicial, moneda base, archivado y futuro `user_id`.
- Selector global de portafolio activo en el frontend.
- Creación, renombrado, archivado y restauración de portafolios.
- `portfolio_id` incorporado a operaciones, movimientos y catálogo de activos.
- Dashboard, posiciones, métricas, XIRR, TWR y curva patrimonial aislados por cartera.
- Compatibilidad de endpoints antiguos usando `portfolio_id=1` por defecto.
- Migración automática desde Alpha 1.3.
- Backup automático antes de la migración estructural.
- Registro de esquema mediante `schema_migrations` versión 4.
- 27 pruebas automatizadas, incluidas migración y separación entre dos carteras.

## 4.1.0 Alpha 1.3

- Universo multiactivo con búsqueda por nombre o ticker.
- Catálogo local de activos automáticos y manuales.
- Conversión multimoneda actual e histórica.
- Depósitos, retiros, dividendos, intereses, impuestos y gastos.
- Importación de dividendos con control de duplicados.
- Rendimiento ajustado por aportes, XIRR y TWR.
- Curva patrimonial multimoneda.
- Migración automática desde Alpha 1.2.
- 22 pruebas automatizadas.
- Roadmap de consolidación documentado hasta la versión 2.0.

## Alpha 1.4 Fase 4 - Actualizacion Windows

- Se agrego `iniciar_windows.bat` para iniciar QuantLab AI con doble clic.
- El iniciador detecta Python 3.11 o superior.
- Crea automaticamente el entorno virtual `.venv` cuando falta.
- Reinstala dependencias solamente si cambio `requirements.txt` o falta un paquete principal.
- Valida dependencias con `pip check`.
- Abre automaticamente la aplicacion en el navegador.
