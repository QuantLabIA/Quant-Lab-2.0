"use strict";

const API_BASE = "/api/v1";
let pendingRequests = 0;

const qs = (selector, parent = document) => parent.querySelector(selector);
const qsa = (selector, parent = document) => [...parent.querySelectorAll(selector)];
let portfolioLoaded = false;
let selectedPortfolioAsset = null;
let activePortfolioId = Number(localStorage.getItem("quantlab.activePortfolioId") || 1);
let portfolioCatalog = [];
let currentPortfolioData = null;
let editingTransactionId = null;
let editingCashMovementId = null;
let editingFxConversionId = null;
let editingCorporateActionId = null;
let csvImportContent = "";
let csvImportFilename = "";
let csvImportPreview = null;
let backupRestoreBytes = null;
let backupRestoreFilename = "";
let backupValidationResult = null;
let analyticsLoaded = false;
let currentAnalyticsData = null;
let currentDividendData = null;
let activeConcentrationMode = "by_asset";
let analyticsZoomPercent = 100;
let currentComparatorData = null;
let aiSessionId = null;
let aiHistoryLoaded = false;
let aiSettingsLoaded = false;
let aiAlertsLoaded = false;
let aiMemoryLoaded = false;

function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>'"]/g, (character) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    "'": "&#039;",
    '"': "&quot;",
  })[character]);
}

function normalizeApiUrl(url) {
  if (typeof url !== "string") return url;
  if (url === "/api") return API_BASE;
  if (url.startsWith("/api/")) return `${API_BASE}${url.slice(4)}`;
  return url;
}

function setLoading(active) {
  pendingRequests = Math.max(0, pendingRequests + (active ? 1 : -1));
  const indicator = qs("#globalLoading");
  if (indicator) indicator.hidden = pendingRequests === 0;
  document.body.classList.toggle("is-loading", pendingRequests > 0);
}

function showToast(message, type = "success", detail = "") {
  const region = qs("#toastRegion");
  if (!region) return;
  const toast = document.createElement("div");
  toast.className = `toast ${type}`;
  toast.innerHTML = `<strong>${escapeHTML(message)}</strong>${detail ? `<small>${escapeHTML(detail)}</small>` : ""}`;
  region.appendChild(toast);
  window.setTimeout(() => toast.remove(), 4800);
}

async function apiRequest(url, options = {}) {
  let requestUrl = url;
  const isPortfolioData = requestUrl.startsWith("/api/portfolio") && !requestUrl.startsWith("/api/portfolios");
  const isDashboard = requestUrl.startsWith("/api/dashboard");
  const isAnalytics = requestUrl.startsWith("/api/analytics");
  if (isPortfolioData || isDashboard || isAnalytics) {
    const separator = requestUrl.includes("?") ? "&" : "?";
    requestUrl = `${requestUrl}${separator}portfolio_id=${encodeURIComponent(activePortfolioId)}`;
  }
  requestUrl = normalizeApiUrl(requestUrl);
  setLoading(true);
  try {
    const response = await fetch(requestUrl, {
      headers: { "Content-Type": "application/json", ...(options.headers || {}) },
      cache: "no-store",
      ...options,
    });

    if (!response.ok) {
      let message = `Error ${response.status}`;
      let requestId = response.headers.get("X-Request-ID") || "";
      try {
        const body = await response.json();
        message = body.detail || message;
        requestId = body.error?.request_id || requestId;
      } catch (_) {
        // Keep the HTTP fallback message.
      }
      if (requestId) message = `${message} · ID ${requestId}`;
      throw new Error(message);
    }

    return response.status === 204 ? null : response.json();
  } finally {
    setLoading(false);
  }
}

function formatPrice(value, currency = "USD") {
  const number = Number(value);
  if (!Number.isFinite(number)) return "Sin dato";
  try {
    return new Intl.NumberFormat("es-AR", {
      style: "currency",
      currency,
      maximumFractionDigits: number >= 1000 ? 2 : 4,
    }).format(number);
  } catch (_) {
    return `${currency} ${number.toLocaleString("es-AR", { maximumFractionDigits: 4 })}`;
  }
}

function formatDate(value) {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? "Sin hora" : date.toLocaleString("es-AR");
}

function formatBytes(value) {
  const bytes = Number(value || 0);
  if (!Number.isFinite(bytes) || bytes <= 0) return "0 B";
  const units = ["B", "KB", "MB", "GB"];
  const index = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
  return `${(bytes / (1024 ** index)).toLocaleString("es-AR", { maximumFractionDigits: 2 })} ${units[index]}`;
}

function triggerDownload(url, filename = "") {
  const link = document.createElement("a");
  link.href = normalizeApiUrl(url);
  if (filename) link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
}

async function rawApiRequest(url, options = {}) {
  setLoading(true);
  try {
    const response = await fetch(normalizeApiUrl(url), { cache: "no-store", ...options });
    if (!response.ok) {
      let message = `Error ${response.status}`;
      let requestId = response.headers.get("X-Request-ID") || "";
      try {
        const body = await response.json();
        message = body.detail || message;
        requestId = body.error?.request_id || requestId;
      } catch (_) {
        // Keep fallback.
      }
      if (requestId) message = `${message} · ID ${requestId}`;
      throw new Error(message);
    }
    return response.status === 204 ? null : response.json();
  } finally {
    setLoading(false);
  }
}

function toLocalDateTimeInput(value) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "";
  const local = new Date(date.getTime() - date.getTimezoneOffset() * 60000);
  return local.toISOString().slice(0, 16);
}

function impactPreviewHTML(preview, currency) {
  const impact = preview.impact || {};
  const position = impact.position;
  const warnings = (preview.warnings || []).map((item) => `<p class="negative">${escapeHTML(item)}</p>`).join("");
  const currencyRows = (impact.cash_by_currency || []).map((item) => `
    <div><span>${escapeHTML(item.currency)} real</span><strong>${escapeHTML(formatQuantity(item.before))} → ${escapeHTML(formatQuantity(item.after))}</strong><small class="${Number(item.change) >= 0 ? "positive" : "negative"}">${Number(item.change) >= 0 ? "+" : ""}${escapeHTML(formatQuantity(item.change))}</small></div>`).join("");
  const fxChange = Number(impact.realized_fx_pnl_change || 0);
  return `
    <div class="impact-grid">
      <div><span>Valuación anterior</span><strong>${escapeHTML(formatPrice(impact.cash_balance_before, currency))}</strong></div>
      <div><span>Valuación posterior</span><strong>${escapeHTML(formatPrice(impact.cash_balance_after, currency))}</strong></div>
      <div><span>Diferencia base</span><strong class="${Number(impact.cash_balance_change) >= 0 ? "positive" : "negative"}">${escapeHTML(formatPrice(impact.cash_balance_change, currency))}</strong></div>
      ${currencyRows}
      ${Math.abs(fxChange) > 0.0000001 ? `<div><span>P&L FX realizado</span><strong class="${fxChange >= 0 ? "positive" : "negative"}">${escapeHTML(formatPrice(fxChange, currency))}</strong></div>` : ""}
      ${position ? `<div><span>Unidades anteriores</span><strong>${escapeHTML(formatQuantity(position.quantity_before))}</strong></div><div><span>Unidades posteriores</span><strong>${escapeHTML(formatQuantity(position.quantity_after))}</strong></div><div><span>Costo posterior</span><strong>${escapeHTML(formatPrice(position.cost_basis_after, currency))}</strong></div>` : ""}
    </div>${warnings}`;
}

function renderPortfolioCatalog() {
  const select = qs("#activePortfolioSelect");
  if (!select) return;
  select.innerHTML = portfolioCatalog.map((portfolio) => `
    <option value="${portfolio.id}">${escapeHTML(portfolio.name)} · ${escapeHTML(portfolio.base_currency)}</option>`).join("");
  select.value = String(activePortfolioId);
  const active = portfolioCatalog.find((portfolio) => Number(portfolio.id) === Number(activePortfolioId));
  qs("#activePortfolioName").textContent = active?.name || "Portafolio";
  qs("#archivePortfolioButton").disabled = portfolioCatalog.length <= 1;
}

async function loadPortfolioCatalog(preferredId = null) {
  portfolioCatalog = await apiRequest("/api/portfolios");
  if (!portfolioCatalog.length) throw new Error("No hay portafolios activos");
  const requested = Number(preferredId ?? activePortfolioId);
  const exists = portfolioCatalog.some((portfolio) => Number(portfolio.id) === requested);
  activePortfolioId = exists ? requested : Number(portfolioCatalog[0].id);
  localStorage.setItem("quantlab.activePortfolioId", String(activePortfolioId));
  renderPortfolioCatalog();
  return portfolioCatalog;
}

async function switchPortfolio(portfolioId) {
  activePortfolioId = Number(portfolioId);
  localStorage.setItem("quantlab.activePortfolioId", String(activePortfolioId));
  selectedPortfolioAsset = null;
  portfolioLoaded = false;
  analyticsLoaded = false;
  currentAnalyticsData = null;
  currentDividendData = null;
  aiSessionId = null;
  aiHistoryLoaded = false;
  aiSettingsLoaded = false;
  aiAlertsLoaded = false;
  aiMemoryLoaded = false;
  renderPortfolioCatalog();
  await loadDashboard();
  if (qs("#page-portfolio")?.classList.contains("active")) await loadPortfolio();
  if (qs("#page-analytics")?.classList.contains("active")) await loadAnalytics();
  if (qs("#page-ai")?.classList.contains("active")) await Promise.all([loadAISessions(true), loadAISettings(true), loadAIAlerts(true), loadChangeMemory(true)]);
}

function setupPortfolioCatalog() {
  qs("#activePortfolioSelect").addEventListener("change", async (event) => {
    await switchPortfolio(event.target.value);
  });

  qs("#createPortfolioButton").addEventListener("click", () => {
    qs("#newPortfolioMessage").textContent = "";
    qs("#newPortfolioDialog").showModal();
  });
  qs("#cancelPortfolioDialog").addEventListener("click", () => qs("#newPortfolioDialog").close());

  qs("#newPortfolioForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const message = qs("#newPortfolioMessage");
    message.textContent = "Creando portafolio…";
    try {
      const created = await apiRequest("/api/portfolios", {
        method: "POST",
        body: JSON.stringify({
          name: qs("#newPortfolioName").value,
          base_currency: qs("#newPortfolioCurrency").value,
          initial_cash: Number(qs("#newPortfolioCash").value),
          allow_margin: qs("#newPortfolioAllowMargin").checked,
        }),
      });
      qs("#newPortfolioDialog").close();
      qs("#newPortfolioForm").reset();
      qs("#newPortfolioCash").value = "10000";
      qs("#newPortfolioAllowMargin").checked = false;
      await loadPortfolioCatalog(created.id);
      await switchPortfolio(created.id);
    } catch (error) {
      message.textContent = error.message;
    }
  });

  qs("#archivePortfolioButton").addEventListener("click", async () => {
    const active = portfolioCatalog.find((portfolio) => Number(portfolio.id) === Number(activePortfolioId));
    if (!active || portfolioCatalog.length <= 1) return;
    const confirmed = window.confirm(`¿Archivar “${active.name}”? Sus datos se conservarán y podrán restaurarse desde la API.`);
    if (!confirmed) return;
    try {
      await apiRequest(`/api/portfolios/${activePortfolioId}`, { method: "DELETE" });
      await loadPortfolioCatalog();
      await switchPortfolio(activePortfolioId);
    } catch (error) {
      qs("#portfolioMessage").textContent = error.message;
    }
  });
}

function setPage(pageName) {
  qsa(".page").forEach((page) => page.classList.toggle("active", page.id === `page-${pageName}`));
  qsa(".nav-item[data-page]").forEach((item) => item.classList.toggle("active", item.dataset.page === pageName));
  localStorage.setItem("quantlab.currentPage", pageName);
  closeSidebar();
  if (pageName === "portfolio" && !portfolioLoaded) loadPortfolio();
  if (pageName === "analytics" && !analyticsLoaded) loadAnalytics();
  if (pageName === "ai") {
    if (!aiHistoryLoaded) loadAISessions();
    if (!aiSettingsLoaded) loadAISettings();
    if (!aiAlertsLoaded) loadAIAlerts();
    if (!aiMemoryLoaded) loadChangeMemory();
  }
}

function setupNavigation() {
  qsa(".nav-item[data-page]").forEach((button) => {
    button.addEventListener("click", () => setPage(button.dataset.page));
  });
  setPage(localStorage.getItem("quantlab.currentPage") || "dashboard");
}

function openSidebar() {
  qs("#sidebar").classList.add("open");
  qs("#overlay").classList.add("active");
}

function closeSidebar() {
  qs("#sidebar").classList.remove("open");
  qs("#overlay").classList.remove("active");
}

function setupMobileMenu() {
  qs("#menuButton").addEventListener("click", openSidebar);
  qs("#overlay").addEventListener("click", closeSidebar);
}

function drawSeriesChart(svg, values, gradientId = "areaGradient") {
  if (!svg || !values.length) return;
  const width = 800;
  const height = 280;
  const padding = 20;
  const numericValues = values.map(Number).filter(Number.isFinite);
  if (!numericValues.length) return;
  const rawMin = Math.min(...numericValues);
  const rawMax = Math.max(...numericValues);
  const spread = rawMax - rawMin || Math.max(Math.abs(rawMax) * 0.02, 1);
  const min = rawMin - spread * 0.12;
  const max = rawMax + spread * 0.12;
  const xStep = numericValues.length > 1 ? (width - padding * 2) / (numericValues.length - 1) : 0;
  const scaleY = (value) => height - padding - ((value - min) / (max - min)) * (height - padding * 2);
  const points = numericValues.map((value, index) => `${padding + index * xStep},${scaleY(value)}`).join(" ");
  const areaPoints = `${padding},${height - padding} ${points} ${width - padding},${height - padding}`;
  const grid = [60, 120, 180, 240].map((y) => `<line class="chart-grid" x1="0" y1="${y}" x2="800" y2="${y}"></line>`).join("");

  svg.innerHTML = `
    <defs>
      <linearGradient id="${gradientId}" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stop-color="#2979ff" stop-opacity=".55"></stop>
        <stop offset="100%" stop-color="#2979ff" stop-opacity="0"></stop>
      </linearGradient>
    </defs>
    ${grid}
    <polygon class="chart-area" style="fill:url(#${gradientId})" points="${areaPoints}"></polygon>
    <polyline class="chart-line" points="${points}"></polyline>`;
}

function renderMetrics(metrics) {
  qs("#metricGrid").innerHTML = metrics.map((metric) => `
    <article class="metric-card">
      <span class="label">${escapeHTML(metric.label)}</span>
      <strong class="value">${escapeHTML(metric.value)}</strong>
      <span class="variation ${metric.positive ? "positive" : "negative"}">${escapeHTML(metric.variation)}</span>
    </article>`).join("");
}

function renderMarketSummary(items, errorMessage = null) {
  const container = qs("#marketSummary");
  if (errorMessage) {
    container.innerHTML = `<div class="empty-state">${escapeHTML(errorMessage)}</div>`;
    return;
  }
  if (!items.length) {
    container.innerHTML = '<div class="empty-state">No hay cotizaciones disponibles.</div>';
    return;
  }
  container.innerHTML = items.map((item) => {
    const change = Number(item.change_percent);
    const directionClass = change >= 0 ? "positive" : "negative";
    const sign = change >= 0 ? "+" : "";
    return `<div class="market-row"><strong>${escapeHTML(item.symbol)}</strong><span>${escapeHTML(formatPrice(item.value, item.currency))}</span><em class="${directionClass}">${sign}${change.toFixed(2)}%</em></div>`;
  }).join("");
}

async function loadDashboard() {
  const status = qs("#apiStatus");
  try {
    const [health, dashboard] = await Promise.all([
      apiRequest("/api/health"),
      apiRequest("/api/dashboard"),
    ]);
    status.textContent = `${health.version} · API conectada`;
    status.className = "api-status online";
    renderMetrics(dashboard.metrics);
    renderMarketSummary(dashboard.market_summary, dashboard.market_error);
    qs("#portfolioChartLabel").textContent = dashboard.portfolio_curve_label || "Evolución del portafolio";
    const returnBadge = qs("#dashboardPortfolioReturn");
    const returnMetric = dashboard.metrics?.[0];
    returnBadge.textContent = returnMetric?.variation || "—";
    returnBadge.className = returnMetric?.positive ? "positive" : "negative";
    drawSeriesChart(qs("#portfolioChart"), dashboard.portfolio_curve, "portfolioGradient");
  } catch (error) {
    status.textContent = "API sin conexión";
    status.className = "api-status offline";
    console.error(error);
  }
}

function qualityClass(status) {
  return ["updated", "delayed", "stale", "manual", "unavailable"].includes(status) ? status : "delayed";
}

function qualityChip(asset) {
  const status = qualityClass(asset.data_status);
  return `<span class="quality-chip quality-${status}">${escapeHTML(asset.status_label || asset.data_status || "Dato de mercado")}</span>`;
}

function assetCard(asset) {
  const change = Number(asset.change_percent);
  const directionClass = change >= 0 ? "positive" : "negative";
  const sign = change >= 0 ? "+" : "";
  return `
    <article class="asset-card">
      <header><div><strong>${escapeHTML(asset.symbol)}</strong><span>${escapeHTML(asset.name)}</span></div><span>${escapeHTML(asset.market)}</span></header>
      <strong class="price">${escapeHTML(formatPrice(asset.price, asset.currency))}</strong>
      <span class="${directionClass}">${sign}${change.toFixed(2)}%</span>
      <div class="quote-status-line">${qualityChip(asset)}<small>${escapeHTML(asset.market_state || "unknown")}</small></div>
      <small class="data-timestamp">${escapeHTML(formatDate(asset.last_updated))}</small>
    </article>`;
}

async function loadProviderStatus() {
  const status = qs("#marketProviderStatus");
  try {
    const provider = await apiRequest("/api/market/provider/status");
    status.textContent = `${provider.provider} · ${provider.retry_attempts || 1} intento(s) · respaldo manual`;
    status.className = "api-status online";
  } catch (error) {
    status.textContent = "Proveedor no disponible";
    status.className = "api-status offline";
  }
}

async function loadMarket() {
  const grid = qs("#assetGrid");
  grid.innerHTML = '<div class="empty-state">Descargando activos destacados…</div>';
  try {
    const assets = await apiRequest("/api/market");
    grid.innerHTML = assets.map(assetCard).join("");
  } catch (error) {
    grid.innerHTML = `<div class="empty-state">${escapeHTML(error.message)}</div>`;
  }
}

async function searchMarketAsset(symbol, period) {
  const result = qs("#marketResult");
  result.className = "result-panel muted-panel";
  result.textContent = "Descargando cotización e histórico…";

  const [asset, history] = await Promise.all([
    apiRequest(`/api/market/${encodeURIComponent(symbol)}`),
    apiRequest(`/api/market/${encodeURIComponent(symbol)}/history?period=${encodeURIComponent(period)}&interval=1d`),
  ]);

  const change = Number(asset.change_percent);
  const directionClass = change >= 0 ? "positive" : "negative";
  const sign = change >= 0 ? "+" : "";
  result.className = "result-panel";
  result.innerHTML = `
    <div class="quote-heading">
      <div><p class="eyebrow">${escapeHTML(asset.market)}</p><h3>${escapeHTML(asset.symbol)} · ${escapeHTML(asset.name)}</h3></div>
      <div class="quote-price"><strong>${escapeHTML(formatPrice(asset.price, asset.currency))}</strong><span class="${directionClass}">${sign}${change.toFixed(2)}%</span></div>
    </div>
    <div class="quote-stats">
      <span><small>Cierre anterior</small><strong>${escapeHTML(formatPrice(asset.previous_close, asset.currency))}</strong></span>
      <span><small>Variación</small><strong class="${directionClass}">${sign}${escapeHTML(formatPrice(asset.change, asset.currency))}</strong></span>
      <span><small>Actualización</small><strong>${escapeHTML(formatDate(asset.last_updated))}</strong></span>
    </div>
    <div class="quote-status-line">${qualityChip(asset)}<span class="quality-chip">${escapeHTML(asset.price_kind || "precio")}</span><span class="quality-chip">Mercado: ${escapeHTML(asset.market_state || "unknown")}</span></div>
    ${(asset.warnings || []).map((warning) => `<p class="quote-warning">${escapeHTML(warning)}</p>`).join("")}
    <svg id="marketHistoryChart" class="line-chart market-history-chart" viewBox="0 0 800 280" role="img" aria-label="Histórico de ${escapeHTML(asset.symbol)}"></svg>
    <p class="data-source">${escapeHTML(history.source)} · ${history.candles.length} ruedas · ${escapeHTML(history.period)} · ${escapeHTML(history.status_label || "Histórico")}</p>`;
  drawSeriesChart(qs("#marketHistoryChart"), history.candles.map((candle) => candle.close), "marketGradient");
}

function setupManualPriceFallback() {
  const form = qs("#manualPriceForm");
  if (!form) return;
  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    const symbol = qs("#manualPriceSymbol").value.trim().toUpperCase();
    const message = qs("#manualPriceMessage");
    if (!symbol) { message.textContent = "Ingresá un símbolo."; return; }
    message.textContent = "Guardando precio manual…";
    try {
      await apiRequest(`/api/market/manual-prices/${encodeURIComponent(symbol)}`, {
        method: "PUT",
        body: JSON.stringify({
          price: Number(qs("#manualPriceValue").value),
          currency: qs("#manualPriceCurrency").value.trim().toUpperCase(),
          name: qs("#manualPriceName").value.trim(),
          notes: "Respaldo manual desde la interfaz de mercado",
          observed_at: new Date().toISOString(),
        }),
      });
      qs("#marketSymbol").value = symbol;
      message.textContent = "Precio manual guardado. Se usará cuando el proveedor no tenga datos.";
      showToast("Respaldo manual guardado", "success", symbol);
    } catch (error) {
      message.textContent = error.message;
      showToast("No se pudo guardar el precio", "error", error.message);
    }
  });
}

function setupSymbolAlias() {
  const form = qs("#symbolAliasForm");
  if (!form) return;
  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    const oldSymbol = qs("#aliasOldSymbol").value.trim().toUpperCase();
    const newSymbol = qs("#aliasNewSymbol").value.trim().toUpperCase();
    const message = qs("#symbolAliasMessage");
    if (!oldSymbol || !newSymbol) { message.textContent = "Completá ambos símbolos."; return; }
    message.textContent = "Guardando alias…";
    try {
      await apiRequest(`/api/market/aliases/${encodeURIComponent(oldSymbol)}`, {
        method: "PUT",
        body: JSON.stringify({ new_symbol: newSymbol, notes: qs("#aliasNotes").value.trim() }),
      });
      message.textContent = `Alias guardado: ${oldSymbol} → ${newSymbol}.`;
      showToast("Alias de mercado guardado", "success", `${oldSymbol} → ${newSymbol}`);
    } catch (error) {
      message.textContent = error.message;
      showToast("No se pudo guardar el alias", "error", error.message);
    }
  });
}

function setupMarketSearch() {
  qs("#marketForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const symbol = qs("#marketSymbol").value.trim().toUpperCase();
    const period = qs("#marketPeriod").value;
    try {
      await searchMarketAsset(symbol, period);
    } catch (error) {
      const result = qs("#marketResult");
      result.className = "result-panel muted-panel";
      result.innerHTML = `<div class="quote-status-line"><span class="quality-chip quality-unavailable">No disponible</span></div><p>${escapeHTML(error.message)}</p>`;
    }
  });

  qs("#refreshMarket").addEventListener("click", async () => {
    await Promise.all([loadProviderStatus(), loadMarket(), loadDashboard()]);
  });
}

async function getLiveWatchlistQuotes(items) {
  const settled = await Promise.allSettled(items.map((item) => apiRequest(`/api/market/${encodeURIComponent(item.symbol)}`)));
  return settled.map((result) => result.status === "fulfilled" ? result.value : null);
}

async function loadWatchlist() {
  const container = qs("#watchlistItems");
  try {
    const items = await apiRequest("/api/watchlist");
    if (!items.length) {
      container.innerHTML = '<div class="empty-state">Todavía no agregaste activos.</div>';
      return;
    }
    container.innerHTML = '<div class="empty-state">Actualizando cotizaciones de la watchlist…</div>';
    const quotes = await getLiveWatchlistQuotes(items);
    container.innerHTML = items.map((item, index) => {
      const quote = quotes[index];
      const change = quote ? Number(quote.change_percent) : null;
      const liveBlock = quote
        ? `<div class="watch-quote"><strong>${escapeHTML(formatPrice(quote.price, quote.currency))}</strong><span class="${change >= 0 ? "positive" : "negative"}">${change >= 0 ? "+" : ""}${change.toFixed(2)}%</span></div>`
        : '<div class="watch-quote"><small>Sin cotización</small></div>';
      return `
        <div class="watchlist-row">
          <strong>${escapeHTML(item.symbol)}</strong>
          <div>${escapeHTML(item.name)}<br><small>Agregado: ${escapeHTML(new Date(`${item.created_at}Z`).toLocaleString("es-AR"))}</small></div>
          ${liveBlock}
          <button class="danger-button" data-delete-id="${item.id}" type="button">Eliminar</button>
        </div>`;
    }).join("");
    qsa("[data-delete-id]", container).forEach((button) => {
      button.addEventListener("click", async () => {
        try {
          await apiRequest(`/api/watchlist/${button.dataset.deleteId}`, { method: "DELETE" });
          await loadWatchlist();
        } catch (error) {
          qs("#watchlistMessage").textContent = error.message;
        }
      });
    });
  } catch (error) {
    container.innerHTML = `<div class="empty-state">${escapeHTML(error.message)}</div>`;
  }
}

function setupWatchlist() {
  qs("#watchlistForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const message = qs("#watchlistMessage");
    message.textContent = "Guardando…";
    const payload = {
      symbol: qs("#watchSymbol").value,
      name: qs("#watchName").value,
    };
    try {
      await apiRequest("/api/watchlist", { method: "POST", body: JSON.stringify(payload) });
      event.currentTarget.reset();
      message.textContent = "Activo agregado correctamente.";
      await loadWatchlist();
    } catch (error) {
      message.textContent = error.message;
    }
  });
}


function formatQuantity(value) {
  const number = Number(value);
  return Number.isFinite(number)
    ? number.toLocaleString("es-AR", { maximumFractionDigits: 8 })
    : "—";
}

function formatPercent(value) {
  const number = Number(value);
  if (!Number.isFinite(number)) return "Sin dato";
  return `${number >= 0 ? "+" : ""}${number.toFixed(2)}%`;
}

function formatPlainPercent(value) {
  const number = Number(value);
  if (!Number.isFinite(number)) return "Sin dato";
  return `${number.toFixed(2)}%`;
}

function setLocalDateInput(selector) {
  const input = qs(selector);
  if (!input || input.value) return;
  const now = new Date();
  const local = new Date(now.getTime() - now.getTimezoneOffset() * 60000);
  input.value = local.toISOString().slice(0, 16);
}

function setDefaultPortfolioDates() {
  setLocalDateInput("#portfolioDate");
  setLocalDateInput("#cashMovementDate");
  setLocalDateInput("#fxDate");
  setLocalDateInput("#advancedDividendDate");
  setLocalDateInput("#corporateActionDate");
}

function renderPortfolioMetrics(summary) {
  const currency = summary.currency;
  const metrics = [
    { label: "Patrimonio total", value: formatPrice(summary.total_equity, currency), variation: formatPercent(summary.total_return_percent), positive: summary.investment_profit >= 0 },
    { label: "Ganancia real", value: formatPrice(summary.investment_profit, currency), variation: "Ajustada por aportes", positive: summary.investment_profit >= 0 },
    { label: "Efectivo", value: formatPrice(summary.cash_balance, currency), variation: `${summary.holdings_count} posiciones`, positive: summary.cash_balance >= 0 },
    { label: "Valor de mercado", value: formatPrice(summary.market_value, currency), variation: `Costo ${formatPrice(summary.invested_cost, currency)}`, positive: summary.market_value >= summary.invested_cost },
    { label: "Ingresos", value: formatPrice(summary.income, currency), variation: `Gastos ${formatPrice(summary.expenses, currency)}`, positive: summary.income >= summary.expenses },
    { label: "Aportes netos", value: formatPrice(summary.net_contributions, currency), variation: `${summary.currencies_count} monedas`, positive: summary.net_contributions >= 0 },
    { label: "P&L cambiario", value: formatPrice(summary.realized_fx_pnl + summary.unrealized_cash_fx_pnl, currency), variation: `Realizado ${formatPrice(summary.realized_fx_pnl, currency)}`, positive: (summary.realized_fx_pnl + summary.unrealized_cash_fx_pnl) >= 0 },
    { label: "Comisiones FX", value: formatPrice(summary.fx_fees, currency), variation: `${summary.fx_conversions_count} conversiones`, positive: summary.fx_fees <= 0 },
  ];
  qs("#portfolioMetricGrid").innerHTML = metrics.map((metric) => `
    <article class="metric-card">
      <span class="label">${escapeHTML(metric.label)}</span>
      <strong class="value">${escapeHTML(metric.value)}</strong>
      <span class="variation ${metric.positive ? "positive" : "negative"}">${escapeHTML(metric.variation)}</span>
    </article>`).join("");
}

function renderPortfolioPerformance(data, curve = null) {
  const summary = data.summary;
  const items = [
    { label: "Retorno simple", value: formatPercent(summary.total_return_percent), note: "Ganancia / capital aportado" },
    { label: "XIRR anual", value: summary.xirr_percent === null ? "Sin dato" : formatPercent(summary.xirr_percent), note: "Considera fechas de aportes" },
    { label: "TWR del período", value: curve ? formatPercent(curve.twr_percent) : "Calculando…", note: "Neutraliza depósitos y retiros" },
    { label: "P&L realizado", value: formatPrice(summary.realized_pnl, summary.currency), note: `Dividendos ${formatPrice(summary.dividends, summary.currency)}` },
    { label: "Resultado FX", value: formatPrice(summary.realized_fx_pnl + summary.unrealized_cash_fx_pnl, summary.currency), note: `Comisiones ${formatPrice(summary.fx_fees, summary.currency)}` },
  ];
  qs("#portfolioPerformance").innerHTML = items.map((item) => `
    <div class="performance-item"><span>${escapeHTML(item.label)}</span><strong>${escapeHTML(item.value)}</strong><small>${escapeHTML(item.note)}</small></div>`).join("");
}

function renderPortfolioAllocation(data) {
  const donut = qs("#portfolioDonut");
  const legend = qs("#portfolioAllocation");
  const count = data.summary.holdings_count;
  donut.innerHTML = `<div><strong>${count}</strong><span>${count === 1 ? "posición" : "posiciones"}</span></div>`;
  if (!data.allocation.length) {
    donut.style.background = "conic-gradient(#263247 0 100%)";
    legend.innerHTML = '<span class="muted-copy">Todavía no hay posiciones.</span>';
    return;
  }
  const palette = ["#2979ff", "#16c784", "#f59e0b", "#8b5cf6", "#06b6d4", "#ec4899", "#f97316", "#84cc16"];
  let cursor = 0;
  const segments = data.allocation.map((item, index) => {
    const start = cursor;
    cursor += Number(item.percent);
    return `${palette[index % palette.length]} ${start}% ${cursor}%`;
  });
  donut.style.background = `conic-gradient(${segments.join(", ")})`;
  legend.innerHTML = data.allocation.map((item, index) => `
    <span><i style="background:${palette[index % palette.length]}"></i>${escapeHTML(item.symbol)} ${Number(item.percent).toFixed(1)}%</span>`).join("");
}

function renderPortfolioHoldings(data) {
  const tbody = qs("#portfolioHoldings");
  if (!data.holdings.length) {
    tbody.innerHTML = '<tr><td colspan="9" class="table-empty">Todavía no registraste compras.</td></tr>';
    return;
  }
  tbody.innerHTML = data.holdings.map((holding) => {
    const positive = Number(holding.unrealized_pnl) >= 0;
    const sourceLabel = holding.valuation_source === "market" ? "Yahoo" : holding.valuation_source === "manual" ? "Manual" : "Costo";
    return `
      <tr>
        <td><strong>${escapeHTML(holding.symbol)}</strong><small>${escapeHTML(holding.name)} · ${escapeHTML(holding.exchange || sourceLabel)}</small></td>
        <td><span class="asset-type-badge">${escapeHTML(holding.asset_type)}</span></td>
        <td>${escapeHTML(formatQuantity(holding.quantity))}</td>
        <td>${escapeHTML(formatPrice(holding.average_price, holding.currency))}</td>
        <td>${escapeHTML(formatPrice(holding.current_price, holding.currency))}<small>${escapeHTML(sourceLabel)}</small></td>
        <td>${Number(holding.fx_rate_to_base).toLocaleString("es-AR", { maximumFractionDigits: 6 })}<small>${escapeHTML(holding.currency)}→${escapeHTML(holding.base_currency)}</small></td>
        <td>${escapeHTML(formatPrice(holding.cost_basis, holding.base_currency))}</td>
        <td>${escapeHTML(formatPrice(holding.market_value, holding.base_currency))}</td>
        <td><strong class="${positive ? "positive" : "negative"}">${escapeHTML(formatPrice(holding.unrealized_pnl, holding.base_currency))}</strong><small class="${positive ? "positive" : "negative"}">${formatPercent(holding.unrealized_pnl_percent)}</small></td>
      </tr>`;
  }).join("");
}

function renderPortfolioTransactions(data) {
  const tbody = qs("#portfolioTransactions");
  const source = data.all_transactions || data.transactions || [];
  const transactions = qs("#showDeletedRecords")?.checked
    ? source
    : source.filter((item) => !item.is_deleted);
  if (!transactions.length) {
    tbody.innerHTML = '<tr><td colspan="8" class="table-empty">No hay operaciones registradas.</td></tr>';
    return;
  }
  tbody.innerHTML = transactions.map((transaction) => {
    const isBuy = transaction.transaction_type === "BUY";
    const actions = transaction.is_deleted
      ? `<span class="deleted-badge">Eliminada</span><button class="secondary-button compact-button restore-button" data-restore-transaction="${transaction.id}" type="button">Restaurar</button>`
      : `<button class="secondary-button compact-button" data-edit-transaction="${transaction.id}" type="button">Editar</button><button class="danger-button compact-button" data-delete-transaction="${transaction.id}" type="button">Eliminar</button>`;
    return `
      <tr data-record="transaction" data-type="${escapeHTML(transaction.transaction_type)}" data-currency="${escapeHTML(transaction.asset_currency)}" data-date="${escapeHTML(String(transaction.occurred_at).slice(0, 10))}" data-search="${escapeHTML(`${transaction.symbol} ${transaction.asset_type} ${transaction.asset_currency} ${transaction.notes || ""}`.toLowerCase())}" class="${transaction.is_deleted ? "deleted-row" : ""}">
        <td>${escapeHTML(formatDate(transaction.occurred_at))}<small class="revision-badge">rev. ${transaction.revision || 1}</small></td>
        <td><span class="operation-badge ${isBuy ? "buy" : "sell"}">${isBuy ? "Compra" : "Venta"}</span></td>
        <td><strong>${escapeHTML(transaction.symbol)}</strong><small>${escapeHTML(transaction.asset_type)} · ${escapeHTML(transaction.asset_currency)}</small></td>
        <td>${escapeHTML(formatQuantity(transaction.quantity))}</td>
        <td>${escapeHTML(formatPrice(transaction.price, transaction.asset_currency))}</td>
        <td>${Number(transaction.fx_rate_to_base).toLocaleString("es-AR", { maximumFractionDigits: 6 })}</td>
        <td class="${transaction.cash_effect >= 0 ? "positive" : "negative"}">${escapeHTML(formatPrice(transaction.cash_effect, data.summary.currency))}</td>
        <td><div class="table-actions">${actions}</div></td>
      </tr>`;
  }).join("");

  qsa("[data-edit-transaction]", tbody).forEach((button) => {
    button.addEventListener("click", () => openTransactionEdit(Number(button.dataset.editTransaction)));
  });
  qsa("[data-delete-transaction]", tbody).forEach((button) => {
    button.addEventListener("click", async () => {
      const transaction = source.find((item) => Number(item.id) === Number(button.dataset.deleteTransaction));
      if (!transaction) return;
      const confirmed = window.confirm(`¿Eliminar lógicamente la ${transaction.transaction_type === "BUY" ? "compra" : "venta"} de ${transaction.quantity} ${transaction.symbol}? Podrá restaurarse.`);
      if (!confirmed) return;
      const reason = window.prompt("Motivo de la eliminación:", "Operación duplicada o incorrecta");
      if (reason === null) return;
      const message = qs("#portfolioMessage");
      message.textContent = "Validando y archivando operación…";
      try {
        await apiRequest(`/api/portfolio/transactions/${transaction.id}?reason=${encodeURIComponent(reason || "Eliminación solicitada por el usuario")}`, { method: "DELETE" });
        await Promise.all([loadPortfolio(), loadDashboard()]);
      } catch (error) { message.textContent = error.message; }
    });
  });
  qsa("[data-restore-transaction]", tbody).forEach((button) => {
    button.addEventListener("click", async () => {
      if (!window.confirm("¿Restaurar esta operación? QuantLab validará nuevamente todo el historial.")) return;
      try {
        await apiRequest(`/api/portfolio/transactions/${button.dataset.restoreTransaction}/restore`, { method: "POST" });
        await Promise.all([loadPortfolio(), loadDashboard()]);
      } catch (error) { qs("#portfolioMessage").textContent = error.message; }
    });
  });
}

function portfolioFilterValues() {
  return {
    text: (qs("#portfolioTextFilter")?.value || "").trim().toLowerCase(),
    type: qs("#portfolioRecordTypeFilter")?.value || "",
    currency: (qs("#portfolioCurrencyFilter")?.value || "").trim().toUpperCase(),
    from: qs("#portfolioDateFrom")?.value || "",
    to: qs("#portfolioDateTo")?.value || "",
  };
}

function applyPortfolioTableFilters() {
  const filters = portfolioFilterValues();
  const rows = qsa("#portfolioTransactions tr[data-record], #portfolioCashMovements tr[data-record], #portfolioFxConversions tr[data-record]");
  let visible = 0;
  rows.forEach((row) => {
    const matchesText = !filters.text || (row.dataset.search || "").includes(filters.text);
    const matchesType = !filters.type || row.dataset.type === filters.type;
    const matchesCurrency = !filters.currency || (row.dataset.currency || "").split(",").includes(filters.currency);
    const date = row.dataset.date || "";
    const matchesFrom = !filters.from || date >= filters.from;
    const matchesTo = !filters.to || date <= filters.to;
    const show = matchesText && matchesType && matchesCurrency && matchesFrom && matchesTo;
    row.classList.toggle("filtered-out", !show);
    if (show) visible += 1;
  });
  const status = qs("#portfolioFilterStatus");
  if (status) status.textContent = rows.length ? `${visible} de ${rows.length} registros visibles.` : "No hay registros para filtrar.";
}

function setupPortfolioFilters() {
  ["#portfolioTextFilter", "#portfolioRecordTypeFilter", "#portfolioCurrencyFilter", "#portfolioDateFrom", "#portfolioDateTo"].forEach((selector) => {
    qs(selector)?.addEventListener("input", applyPortfolioTableFilters);
    qs(selector)?.addEventListener("change", applyPortfolioTableFilters);
  });
  ["#portfolioTransactions", "#portfolioCashMovements", "#portfolioFxConversions"].forEach((selector) => {
    const target = qs(selector);
    if (target) new MutationObserver(applyPortfolioTableFilters).observe(target, { childList: true });
  });
  qs("#clearPortfolioFilters")?.addEventListener("click", () => {
    ["#portfolioTextFilter", "#portfolioRecordTypeFilter", "#portfolioCurrencyFilter", "#portfolioDateFrom", "#portfolioDateTo"].forEach((selector) => {
      const element = qs(selector);
      if (element) element.value = "";
    });
    applyPortfolioTableFilters();
  });
}

function sortTable(table, columnIndex, direction) {
  const tbody = table.tBodies[0];
  if (!tbody) return;
  const rows = [...tbody.rows].filter((row) => row.dataset.record);
  rows.sort((a, b) => {
    const av = a.cells[columnIndex]?.textContent.trim() || "";
    const bv = b.cells[columnIndex]?.textContent.trim() || "";
    const an = Number(av.replace(/[^0-9,.-]/g, "").replace(/\./g, "").replace(",", "."));
    const bn = Number(bv.replace(/[^0-9,.-]/g, "").replace(/\./g, "").replace(",", "."));
    const comparison = Number.isFinite(an) && Number.isFinite(bn) ? an - bn : av.localeCompare(bv, "es", { numeric: true });
    return direction === "ascending" ? comparison : -comparison;
  });
  rows.forEach((row) => tbody.appendChild(row));
}

function setupSortableTables() {
  qsa(".data-table").forEach((table) => {
    qsa("th", table).forEach((header, index, headers) => {
      if (index === headers.length - 1 && !header.textContent.trim()) return;
      header.tabIndex = 0;
      const activate = () => {
        const direction = header.getAttribute("aria-sort") === "ascending" ? "descending" : "ascending";
        headers.forEach((item) => item.removeAttribute("aria-sort"));
        header.setAttribute("aria-sort", direction);
        sortTable(table, index, direction);
      };
      header.addEventListener("click", activate);
      header.addEventListener("keydown", (event) => { if (event.key === "Enter" || event.key === " ") { event.preventDefault(); activate(); } });
    });
  });
}

const movementLabels = {
  DEPOSIT: "Depósito", WITHDRAWAL: "Retiro", DIVIDEND: "Dividendo", INTEREST: "Interés", TAX: "Impuesto", FEE: "Gasto",
};

function renderCashMovements(data) {
  const tbody = qs("#portfolioCashMovements");
  const source = data.all_cash_movements || data.cash_movements || [];
  const movements = qs("#showDeletedRecords")?.checked
    ? source
    : source.filter((item) => !item.is_deleted);
  if (!movements.length) {
    tbody.innerHTML = '<tr><td colspan="8" class="table-empty">No hay movimientos de efectivo.</td></tr>';
    return;
  }
  tbody.innerHTML = movements.map((movement) => {
    const isDividend = movement.movement_type === "DIVIDEND";
    const actions = movement.is_deleted
      ? `<span class="deleted-badge">Eliminado</span><button class="secondary-button compact-button restore-button" data-restore-cash="${movement.id}" type="button">Restaurar</button>`
      : `${isDividend ? '<span class="revision-badge" title="Bruto, retención y reinversión se conservan desde el módulo Dividendos">Gestionar en Dividendos</span>' : `<button class="secondary-button compact-button" data-edit-cash="${movement.id}" type="button">Editar</button>`}<button class="danger-button compact-button" data-delete-cash="${movement.id}" type="button">Eliminar</button>`;
    return `
      <tr data-record="cash" data-type="${escapeHTML(movement.movement_type)}" data-currency="${escapeHTML(movement.currency)}" data-date="${escapeHTML(String(movement.occurred_at).slice(0, 10))}" data-search="${escapeHTML(`${movement.movement_type} ${movement.symbol || ""} ${movement.currency} ${movement.notes || ""}`.toLowerCase())}" class="${movement.is_deleted ? "deleted-row" : ""}">
        <td>${escapeHTML(formatDate(movement.occurred_at))}<small class="revision-badge">rev. ${movement.revision || 1}</small></td>
        <td><span class="movement-badge movement-${movement.movement_type.toLowerCase()}">${escapeHTML(movementLabels[movement.movement_type] || movement.movement_type)}</span></td>
        <td>${escapeHTML(movement.symbol || "—")}</td>
        <td>${escapeHTML(formatPrice(movement.amount, movement.currency))}</td>
        <td>${Number(movement.fx_rate_to_base).toLocaleString("es-AR", { maximumFractionDigits: 6 })}</td>
        <td class="${movement.cash_effect >= 0 ? "positive" : "negative"}">${escapeHTML(formatPrice(movement.cash_effect, data.summary.currency))}</td>
        <td>${escapeHTML(movement.notes || "—")}</td>
        <td><div class="table-actions">${actions}</div></td>
      </tr>`;
  }).join("");

  qsa("[data-edit-cash]", tbody).forEach((button) => {
    button.addEventListener("click", () => openCashEdit(Number(button.dataset.editCash)));
  });
  qsa("[data-delete-cash]", tbody).forEach((button) => {
    button.addEventListener("click", async () => {
      const movement = source.find((item) => Number(item.id) === Number(button.dataset.deleteCash));
      if (!movement) return;
      if (!window.confirm(`¿Eliminar lógicamente este ${movementLabels[movement.movement_type] || "movimiento"}? Podrá restaurarse.`)) return;
      const reason = window.prompt("Motivo de la eliminación:", "Movimiento duplicado o incorrecto");
      if (reason === null) return;
      try {
        await apiRequest(`/api/portfolio/cash-movements/${movement.id}?reason=${encodeURIComponent(reason || "Eliminación solicitada por el usuario")}`, { method: "DELETE" });
        await Promise.all([loadPortfolio(), loadDashboard()]);
      } catch (error) { qs("#portfolioMessage").textContent = error.message; }
    });
  });
  qsa("[data-restore-cash]", tbody).forEach((button) => {
    button.addEventListener("click", async () => {
      if (!window.confirm("¿Restaurar este movimiento? QuantLab validará nuevamente todo el historial.")) return;
      try {
        await apiRequest(`/api/portfolio/cash-movements/${button.dataset.restoreCash}/restore`, { method: "POST" });
        await Promise.all([loadPortfolio(), loadDashboard()]);
      } catch (error) { qs("#portfolioMessage").textContent = error.message; }
    });
  });
}

function renderCashBalances(data) {
  const container = qs("#cashBalanceGrid");
  const balances = data.cash_balances || [];
  const badge = qs("#marginStatusBadge");
  badge.textContent = data.summary.allow_margin ? "Margen habilitado" : "Sin margen";
  badge.classList.toggle("margin-enabled", Boolean(data.summary.allow_margin));
  if (!balances.length) {
    container.innerHTML = '<p class="muted-copy">No hay saldos de efectivo.</p>';
    return;
  }
  container.innerHTML = balances.map((balance) => {
    const amount = Number(balance.balance);
    const fxPnl = Number(balance.unrealized_fx_pnl || 0);
    return `
      <article class="cash-balance-card ${amount < 0 ? "negative-cash" : ""}">
        <div class="cash-balance-heading"><strong>${escapeHTML(balance.currency)}</strong><span>${escapeHTML(balance.valuation_source || "stored")}</span></div>
        <div class="cash-local-value">${escapeHTML(formatPrice(amount, balance.currency))}</div>
        <small>Valuación: ${escapeHTML(formatPrice(balance.base_value, data.summary.currency))}</small>
        <small>FX ${Number(balance.fx_rate_to_base).toLocaleString("es-AR", { maximumFractionDigits: 8 })}</small>
        <small class="${fxPnl >= 0 ? "positive" : "negative"}">P&L FX no realizado ${escapeHTML(formatPrice(fxPnl, data.summary.currency))}</small>
      </article>`;
  }).join("");
}

function renderFxConversions(data) {
  const tbody = qs("#portfolioFxConversions");
  const source = data.all_fx_conversions || data.fx_conversions || [];
  const conversions = qs("#showDeletedRecords")?.checked ? source : source.filter((item) => !item.is_deleted);
  if (!conversions.length) {
    tbody.innerHTML = '<tr><td colspan="8" class="table-empty">No hay conversiones de divisas.</td></tr>';
    return;
  }
  tbody.innerHTML = conversions.map((conversion) => {
    const actions = conversion.is_deleted
      ? `<span class="deleted-badge">Eliminada</span><button class="secondary-button compact-button restore-button" data-restore-fx="${conversion.id}" type="button">Restaurar</button>`
      : `<button class="secondary-button compact-button" data-edit-fx="${conversion.id}" type="button">Editar</button><button class="danger-button compact-button" data-delete-fx="${conversion.id}" type="button">Eliminar</button>`;
    const pnl = Number(conversion.realized_fx_pnl_base || 0);
    return `
      <tr data-record="fx" data-type="FX" data-currency="${escapeHTML(`${conversion.from_currency},${conversion.to_currency},${conversion.fee_currency || ""}`)}" data-date="${escapeHTML(String(conversion.occurred_at).slice(0, 10))}" data-search="${escapeHTML(`${conversion.from_currency} ${conversion.to_currency} ${conversion.notes || ""}`.toLowerCase())}" class="${conversion.is_deleted ? "deleted-row" : ""}">
        <td>${escapeHTML(formatDate(conversion.occurred_at))}<small class="revision-badge">rev. ${conversion.revision || 1}</small></td>
        <td><strong>${escapeHTML(conversion.from_currency)}/${escapeHTML(conversion.to_currency)}</strong><small>${escapeHTML(conversion.pricing_mode)}</small></td>
        <td>${escapeHTML(formatPrice(conversion.from_amount, conversion.from_currency))}</td>
        <td>${escapeHTML(formatPrice(conversion.to_amount, conversion.to_currency))}</td>
        <td>${Number(conversion.exchange_rate).toLocaleString("es-AR", { maximumFractionDigits: 8 })}</td>
        <td>${escapeHTML(formatPrice(conversion.fee_amount, conversion.fee_currency))}</td>
        <td class="${pnl >= 0 ? "positive" : "negative"}">${escapeHTML(formatPrice(pnl, data.summary.currency))}</td>
        <td><div class="table-actions">${actions}</div></td>
      </tr>`;
  }).join("");

  qsa("[data-edit-fx]", tbody).forEach((button) => button.addEventListener("click", () => openFxEdit(Number(button.dataset.editFx))));
  qsa("[data-delete-fx]", tbody).forEach((button) => {
    button.addEventListener("click", async () => {
      const item = source.find((conversion) => Number(conversion.id) === Number(button.dataset.deleteFx));
      if (!item || !window.confirm(`¿Eliminar lógicamente la conversión ${item.from_currency}/${item.to_currency}? Podrá restaurarse.`)) return;
      const reason = window.prompt("Motivo de la eliminación:", "Conversión duplicada o incorrecta");
      if (reason === null) return;
      try {
        await apiRequest(`/api/portfolio/fx-conversions/${item.id}?reason=${encodeURIComponent(reason || "Eliminación solicitada por el usuario")}`, { method: "DELETE" });
        await Promise.all([loadPortfolio(), loadDashboard()]);
      } catch (error) { qs("#portfolioMessage").textContent = error.message; }
    });
  });
  qsa("[data-restore-fx]", tbody).forEach((button) => {
    button.addEventListener("click", async () => {
      if (!window.confirm("¿Restaurar esta conversión? QuantLab validará todos los saldos posteriores.")) return;
      try {
        await apiRequest(`/api/portfolio/fx-conversions/${button.dataset.restoreFx}/restore`, { method: "POST" });
        await Promise.all([loadPortfolio(), loadDashboard()]);
      } catch (error) { qs("#portfolioMessage").textContent = error.message; }
    });
  });
}

const corporateActionLabels = {
  SPLIT: "Split",
  REVERSE_SPLIT: "Reverse split",
  TICKER_CHANGE: "Cambio de ticker",
  MERGER: "Fusión",
  SPINOFF: "Spin-off",
  STOCK_DIVIDEND: "Dividendo en acciones",
  RETURN_OF_CAPITAL: "Devolución de capital",
};

function corporateActionPayload() {
  const occurredAt = new Date(qs("#corporateActionDate").value);
  const optionalNumber = (selector) => {
    const value = Number(qs(selector).value);
    return Number.isFinite(value) && value > 0 ? value : null;
  };
  return {
    action_type: qs("#corporateActionType").value,
    symbol: qs("#corporateActionSymbol").value,
    target_symbol: qs("#corporateActionTarget").value || null,
    quantity_ratio: Number(qs("#corporateActionRatio").value || 1),
    cost_allocation_percent: Number(qs("#corporateActionAllocation").value || 0),
    cash_amount: Number(qs("#corporateActionCash").value || 0),
    cash_currency: qs("#corporateActionCurrency").value || null,
    fx_rate_to_base: optionalNumber("#corporateActionFx"),
    target_name: qs("#corporateActionTargetName").value,
    target_asset_type: "EQUITY",
    target_currency: qs("#corporateActionCurrency").value || null,
    target_exchange: "",
    occurred_at: occurredAt.toISOString(),
    notes: qs("#corporateActionNotes").value,
    source: "MANUAL",
  };
}

function toggleCorporateActionFields() {
  const type = qs("#corporateActionType").value;
  const targetRequired = ["TICKER_CHANGE", "MERGER", "SPINOFF"].includes(type);
  qs("#corporateActionTarget").required = targetRequired;
  qs("#corporateActionAllocation").disabled = type !== "SPINOFF";
  qs("#corporateActionCash").disabled = type !== "RETURN_OF_CAPITAL";
  qs("#corporateActionFx").disabled = type !== "RETURN_OF_CAPITAL";
  if (type === "SPLIT" || type === "REVERSE_SPLIT") {
    qs("#corporateRatioHelp").textContent = "Cantidad nueva ÷ cantidad anterior. Ej.: 2 para 2:1; 0,1 para 1:10.";
  } else if (type === "STOCK_DIVIDEND") {
    qs("#corporateRatioHelp").textContent = "Acciones nuevas por cada acción existente. Ej.: 0,10 para 10%.";
  } else if (type === "SPINOFF" || type === "MERGER") {
    qs("#corporateRatioHelp").textContent = "Acciones del nuevo activo por cada acción original.";
  } else {
    qs("#corporateRatioHelp").textContent = "Usá 1 salvo que el evento indique otra relación.";
  }
}

async function previewCorporateAction() {
  const panel = qs("#corporateActionPreview");
  panel.textContent = "Reproduciendo el ledger completo sin guardar…";
  try {
    const payload = corporateActionPayload();
    if (editingCorporateActionId) payload.reason = "Vista previa de corrección";
    const endpoint = editingCorporateActionId
      ? `/api/portfolio/corporate-actions/${editingCorporateActionId}/preview`
      : "/api/portfolio/corporate-actions/preview";
    const preview = await apiRequest(endpoint, {
      method: "POST", body: JSON.stringify(payload),
    });
    const impact = preview.impact || {};
    const position = impact.position || {};
    panel.innerHTML = `<strong>Evento válido.</strong> Efectivo: ${escapeHTML(formatPrice(impact.cash_balance_before || 0, currentPortfolioData?.summary?.currency || "USD"))} → ${escapeHTML(formatPrice(impact.cash_balance_after || 0, currentPortfolioData?.summary?.currency || "USD"))}. ${position.symbol ? `${escapeHTML(position.symbol)}: ${escapeHTML(formatQuantity(position.quantity_before || 0))} → ${escapeHTML(formatQuantity(position.quantity_after || 0))} unidades; costo ${escapeHTML(formatPrice(position.cost_basis_before || 0, currentPortfolioData?.summary?.currency || "USD"))} → ${escapeHTML(formatPrice(position.cost_basis_after || 0, currentPortfolioData?.summary?.currency || "USD"))}.` : ""}`;
  } catch (error) {
    panel.innerHTML = `<span class="negative">${escapeHTML(error.message)}</span>`;
  }
}

function renderCorporateActions(data) {
  const tbody = qs("#portfolioCorporateActions");
  const source = data.all_corporate_actions || data.corporate_actions || [];
  const actions = qs("#showDeletedRecords")?.checked ? source : source.filter((item) => !item.is_deleted);
  if (!actions.length) {
    tbody.innerHTML = '<tr><td colspan="7" class="table-empty">No hay eventos corporativos registrados.</td></tr>';
    return;
  }
  tbody.innerHTML = actions.map((item) => {
    const ratioOrCash = item.action_type === "RETURN_OF_CAPITAL"
      ? formatPrice(item.cash_amount, item.cash_currency || data.summary.currency)
      : Number(item.quantity_ratio).toLocaleString("es-AR", { maximumFractionDigits: 8 });
    const buttons = item.is_deleted
      ? `<span class="deleted-badge">Eliminado</span><button class="secondary-button compact-button" data-restore-corporate="${item.id}" type="button">Restaurar</button>`
      : `<button class="secondary-button compact-button" data-edit-corporate="${item.id}" type="button">Editar</button><button class="danger-button compact-button" data-delete-corporate="${item.id}" type="button">Eliminar</button>`;
    return `<tr class="${item.is_deleted ? "deleted-row" : ""}">
      <td>${escapeHTML(formatDate(item.occurred_at))}<small class="revision-badge">rev. ${item.revision || 1}</small></td>
      <td>${escapeHTML(corporateActionLabels[item.action_type] || item.action_type)}</td>
      <td><strong>${escapeHTML(item.symbol)}</strong></td>
      <td>${escapeHTML(item.target_symbol || "—")}</td>
      <td>${escapeHTML(ratioOrCash)}${item.action_type === "SPINOFF" ? `<small>${escapeHTML(String(item.cost_allocation_percent))}% del costo</small>` : ""}</td>
      <td>${item.is_deleted ? "Recuperable" : escapeHTML(item.source || "MANUAL")}</td>
      <td><div class="table-actions">${buttons}</div></td>
    </tr>`;
  }).join("");
  qsa("[data-edit-corporate]", tbody).forEach((button) => button.addEventListener("click", () => {
    const item = source.find((entry) => Number(entry.id) === Number(button.dataset.editCorporate));
    if (!item) return;
    editingCorporateActionId = Number(item.id);
    qs("#corporateActionType").value = item.action_type;
    qs("#corporateActionSymbol").value = item.symbol;
    qs("#corporateActionTarget").value = item.target_symbol || "";
    qs("#corporateActionRatio").value = item.quantity_ratio || 1;
    qs("#corporateActionAllocation").value = item.cost_allocation_percent || 0;
    qs("#corporateActionCash").value = item.cash_amount || 0;
    qs("#corporateActionCurrency").value = item.cash_currency || item.target_currency || currentPortfolioData?.summary?.currency || "USD";
    qs("#corporateActionFx").value = item.fx_rate_to_base || "";
    qs("#corporateActionTargetName").value = item.target_name || "";
    qs("#corporateActionDate").value = toLocalDateTimeInput(item.occurred_at);
    qs("#corporateActionNotes").value = item.notes || "";
    qs("#saveCorporateAction").textContent = "Guardar corrección";
    qs("#cancelCorporateActionEdit").hidden = false;
    toggleCorporateActionFields();
    qs("#corporateActionForm").scrollIntoView({ behavior: "smooth", block: "center" });
  }));
  qsa("[data-delete-corporate]", tbody).forEach((button) => button.addEventListener("click", async () => {
    const item = source.find((entry) => Number(entry.id) === Number(button.dataset.deleteCorporate));
    if (!item || !window.confirm(`¿Eliminar lógicamente ${corporateActionLabels[item.action_type] || item.action_type} de ${item.symbol}?`)) return;
    const reason = window.prompt("Motivo:", "Evento incorrecto o duplicado");
    if (reason === null) return;
    try {
      await apiRequest(`/api/portfolio/corporate-actions/${item.id}?reason=${encodeURIComponent(reason || "Eliminación solicitada por el usuario")}`, { method: "DELETE" });
      await Promise.all([loadPortfolio(), loadDashboard()]);
    } catch (error) { qs("#corporateActionMessage").textContent = error.message; }
  }));
  qsa("[data-restore-corporate]", tbody).forEach((button) => button.addEventListener("click", async () => {
    if (!window.confirm("¿Restaurar el evento? Se validarán todas las operaciones posteriores.")) return;
    try {
      await apiRequest(`/api/portfolio/corporate-actions/${button.dataset.restoreCorporate}/restore`, { method: "POST" });
      await Promise.all([loadPortfolio(), loadDashboard()]);
    } catch (error) { qs("#corporateActionMessage").textContent = error.message; }
  }));
}

function summarizeAuditChange(entry) {
  const before = entry.before || {};
  const after = entry.after || {};
  if (entry.entity_type === "transaction") {
    if (entry.action === "UPDATE") return `${before.symbol}: ${formatQuantity(before.quantity)} → ${formatQuantity(after.quantity)} unidades; precio ${before.price} → ${after.price}`;
    const item = after.symbol ? after : before;
    return `${item.symbol || "Operación"} · ${item.transaction_type || ""} · ${formatQuantity(item.quantity || 0)} unidades`;
  }
  if (entry.entity_type === "cash_movement") {
    if (entry.action === "UPDATE") return `${movementLabels[before.movement_type] || before.movement_type}: ${before.amount} → ${after.amount} ${after.currency || before.currency}`;
    const item = after.movement_type ? after : before;
    return `${movementLabels[item.movement_type] || "Movimiento"} · ${item.amount || 0} ${item.currency || ""}`;
  }
  if (entry.entity_type === "fx_conversion") {
    const item = after.from_currency ? after : before;
    if (entry.action === "UPDATE") return `${before.from_currency}/${before.to_currency}: ${before.from_amount} → ${after.from_amount}; tasa ${before.exchange_rate} → ${after.exchange_rate}`;
    return `${item.from_currency || "FX"}/${item.to_currency || ""} · ${item.from_amount || 0} → ${item.to_amount || 0}`;
  }
  if (entry.entity_type === "corporate_action") {
    const item = after.action_type ? after : before;
    return `${corporateActionLabels[item.action_type] || item.action_type || "Evento"} · ${item.symbol || ""}${item.target_symbol ? ` → ${item.target_symbol}` : ""}`;
  }
  return "Cambio registrado";
}

function renderPortfolioAuditLog(data) {
  const tbody = qs("#portfolioAuditLog");
  const entries = data.audit_log || [];
  if (!entries.length) {
    tbody.innerHTML = '<tr><td colspan="5" class="table-empty">Todavía no hay cambios auditados.</td></tr>';
    return;
  }
  const actionLabels = { CREATE: "Alta", UPDATE: "Corrección", DELETE: "Eliminación", RESTORE: "Restauración" };
  tbody.innerHTML = entries.map((entry) => `
    <tr>
      <td>${escapeHTML(formatDate(`${entry.created_at}Z`))}</td>
      <td><span class="audit-action audit-${entry.action.toLowerCase()}">${escapeHTML(actionLabels[entry.action] || entry.action)}</span></td>
      <td>${entry.entity_type === "transaction" ? "Operación" : entry.entity_type === "fx_conversion" ? "Conversión FX" : entry.entity_type === "corporate_action" ? "Evento corporativo" : "Movimiento"} #${entry.entity_id}</td>
      <td>${escapeHTML(entry.reason || "—")}</td>
      <td class="audit-change">${escapeHTML(summarizeAuditChange(entry))}</td>
    </tr>`).join("");
}

function renderManualAssets(data) {
  const manual = data.assets.filter((asset) => asset.pricing_mode === "MANUAL");
  const container = qs("#manualAssetsList");
  if (!manual.length) {
    container.innerHTML = '<p class="muted-copy">No hay activos manuales creados.</p>';
    return;
  }
  container.innerHTML = manual.map((asset) => `
    <div class="manual-asset-row">
      <div><strong>${escapeHTML(asset.symbol)}</strong><span>${escapeHTML(asset.name)} · ${escapeHTML(asset.asset_type)} · ${escapeHTML(asset.currency)}</span></div>
      <input type="number" min="0.00000001" step="any" value="${asset.manual_price ?? ""}" aria-label="Precio de ${escapeHTML(asset.symbol)}">
      <button class="secondary-button compact-button" data-update-manual="${escapeHTML(asset.symbol)}" type="button">Actualizar precio</button>
    </div>`).join("");
  qsa("[data-update-manual]", container).forEach((button) => {
    button.addEventListener("click", async () => {
      const input = button.previousElementSibling;
      try {
        await apiRequest(`/api/portfolio/assets/${encodeURIComponent(button.dataset.updateManual)}/price`, {
          method: "PUT", body: JSON.stringify({ current_price: Number(input.value) }),
        });
        await Promise.all([loadPortfolio(), loadDashboard()]);
      } catch (error) {
        qs("#portfolioMessage").textContent = error.message;
      }
    });
  });
}

function renderPortfolioSettings(data) {
  qs("#portfolioName").value = data.settings.name;
  qs("#portfolio-title").textContent = data.settings.name;
  qs("#activePortfolioName").textContent = data.settings.name;
  qs("#portfolioInitialCash").value = data.settings.initial_cash;
  qs("#portfolioCurrency").value = data.settings.base_currency;
  qs("#portfolioAllowMargin").checked = Boolean(data.settings.allow_margin);
  qs("#portfolioCurrency").disabled = data.transactions.length > 0 || data.cash_movements.length > 0 || data.fx_conversions.length > 0;
  if (!qs("#cashMovementCurrency").dataset.touched) qs("#cashMovementCurrency").value = data.settings.base_currency;
  if (!qs("#portfolioAssetCurrency").dataset.touched) qs("#portfolioAssetCurrency").value = data.settings.base_currency;
  if (!qs("#manualAssetCurrency").dataset.touched) qs("#manualAssetCurrency").value = data.settings.base_currency;
  if (!qs("#fxFromCurrency").dataset.touched) qs("#fxFromCurrency").value = data.settings.base_currency;
  if (!qs("#fxToCurrency").dataset.touched) qs("#fxToCurrency").value = data.settings.base_currency === "ARS" ? "USD" : "ARS";
  if (!qs("#fxFeeCurrency").dataset.touched) qs("#fxFeeCurrency").value = qs("#fxFromCurrency").value;
}

async function loadPortfolioCurve(data = null) {
  const period = qs("#portfolioCurvePeriod").value;
  const status = qs("#portfolioCurveStatus");
  status.textContent = "Reconstruyendo curva patrimonial y TWR…";
  try {
    const curve = await apiRequest(`/api/portfolio/equity-curve?period=${encodeURIComponent(period)}`);
    drawSeriesChart(qs("#portfolioEquityChart"), curve.points.map((point) => point.equity), "portfolioEquityGradient");
    const first = curve.points[0]?.equity;
    const last = curve.points.at(-1)?.equity;
    const variation = first ? ((last - first) / first) * 100 : 0;
    status.textContent = `${curve.points.length} puntos · variación visual ${formatPercent(variation)} · TWR ${formatPercent(curve.twr_percent)}${curve.is_partial ? " · histórico parcial" : ""}`;
    if (data) renderPortfolioPerformance(data, curve);
    return curve;
  } catch (error) {
    status.textContent = error.message;
    qs("#portfolioEquityChart").innerHTML = "";
    return null;
  }
}

async function loadDividendFormSettings() {
  try {
    const settings = await apiRequest("/api/portfolio/dividends/settings");
    if (qs("#advancedDividendWithholding")) qs("#advancedDividendWithholding").value = settings.default_withholding_percent ?? 0;
    if (qs("#importDividendWithholding")) qs("#importDividendWithholding").value = settings.default_withholding_percent ?? 0;
    if (qs("#importDividendReinvest")) qs("#importDividendReinvest").checked = Boolean(settings.default_reinvest);
  } catch (_) {
    // El portafolio principal puede seguir funcionando aunque la preferencia no cargue.
  }
}

async function loadPortfolio() {
  const message = qs("#portfolioMessage");
  message.textContent = "Actualizando activos, monedas, revisiones y auditoría…";
  try {
    const [data, allTransactions, allCashMovements, allFxConversions, allCorporateActions, auditLog] = await Promise.all([
      apiRequest("/api/portfolio"),
      apiRequest("/api/portfolio/transactions?include_deleted=true"),
      apiRequest("/api/portfolio/cash-movements?include_deleted=true"),
      apiRequest("/api/portfolio/fx-conversions?include_deleted=true"),
      apiRequest("/api/portfolio/corporate-actions?include_deleted=true"),
      apiRequest("/api/portfolio/audit-log?limit=100"),
    ]);
    data.all_transactions = allTransactions;
    data.all_cash_movements = allCashMovements;
    data.all_fx_conversions = allFxConversions;
    data.all_corporate_actions = allCorporateActions;
    data.audit_log = auditLog;
    currentPortfolioData = data;
    renderPortfolioMetrics(data.summary);
    renderPortfolioAllocation(data);
    renderPortfolioHoldings(data);
    renderCashBalances(data);
    renderPortfolioTransactions(data);
    renderCashMovements(data);
    renderFxConversions(data);
    renderCorporateActions(data);
    renderPortfolioAuditLog(data);
    renderManualAssets(data);
    renderPortfolioSettings(data);
    renderPortfolioPerformance(data);
    await loadPortfolioCurve(data);
    await Promise.all([loadDataManagement(), loadDividendFormSettings()]);
    portfolioLoaded = true;
    const deletedCount = allTransactions.filter((item) => item.is_deleted).length
      + allCashMovements.filter((item) => item.is_deleted).length
      + allFxConversions.filter((item) => item.is_deleted).length
      + allCorporateActions.filter((item) => item.is_deleted).length;
    message.textContent = data.summary.valuation_status === "complete"
      ? `Portafolio actualizado · ${formatDate(data.last_updated)} · ${data.summary.assets_count} activos · ${deletedCount} registros recuperables`
      : `Valuación parcial: ${data.summary.unpriced_assets} posiciones usan su costo por falta de precio o FX.`;
  } catch (error) {
    message.textContent = error.message;
  }
}

function renderAssetSearchResults(results) {
  const panel = qs("#portfolioSearchResults");
  if (!results.length) {
    panel.innerHTML = '<button type="button" class="asset-search-empty">Sin resultados. Podés usar un activo manual.</button>';
    panel.hidden = false;
    return;
  }
  panel.innerHTML = results.map((asset) => `
    <button type="button" class="asset-search-option" data-asset-symbol="${escapeHTML(asset.symbol)}">
      <strong>${escapeHTML(asset.symbol)}</strong><span>${escapeHTML(asset.name)}</span><small>${escapeHTML(asset.asset_type)} · ${escapeHTML(asset.exchange)}${asset.currency ? ` · ${escapeHTML(asset.currency)}` : ""}</small>
    </button>`).join("");
  panel.hidden = false;
  qsa("[data-asset-symbol]", panel).forEach((button) => {
    button.addEventListener("click", () => {
      selectedPortfolioAsset = results.find((item) => item.symbol === button.dataset.assetSymbol) || null;
      qs("#portfolioSymbol").value = selectedPortfolioAsset.symbol;
      qs("#portfolioQuoteHint").textContent = `${selectedPortfolioAsset.name} · ${selectedPortfolioAsset.asset_type} · ${selectedPortfolioAsset.exchange}`;
      panel.hidden = true;
    });
  });
}

async function searchPortfolioAssets() {
  const query = qs("#portfolioSymbol").value.trim();
  if (!query) return;
  qs("#portfolioQuoteHint").textContent = `Buscando “${query}”…`;
  try {
    const results = await apiRequest(`/api/market/search?q=${encodeURIComponent(query)}&limit=15`);
    renderAssetSearchResults(results);
    qs("#portfolioQuoteHint").textContent = `${results.length} coincidencias encontradas.`;
  } catch (error) {
    qs("#portfolioQuoteHint").textContent = error.message;
  }
}

function togglePricingMode() {
  const manual = qs("#portfolioPricingMode").value === "MANUAL";
  qsa(".manual-asset-field").forEach((field) => { field.hidden = !manual; });
  qs("#searchPortfolioAsset").disabled = manual;
  qs("#useLivePrice").disabled = manual;
  qs("#portfolioQuoteHint").textContent = manual
    ? "Ingresá los datos del activo manual. El precio ejecutado también se usará como primera valuación."
    : "Buscá el activo por nombre o ticker y usá su cotización.";
}

function openTransactionEdit(transactionId) {
  const transaction = (currentPortfolioData?.all_transactions || []).find(
    (item) => Number(item.id) === Number(transactionId) && !item.is_deleted
  );
  if (!transaction) return;
  editingTransactionId = transactionId;
  qs("#transactionEditIdentity").textContent = `${transaction.symbol} · ${transaction.asset_name || transaction.symbol} · revisión ${transaction.revision || 1}`;
  qs("#editTransactionSymbol").value = transaction.symbol;
  qs("#editTransactionPricingMode").value = transaction.pricing_mode;
  qs("#editTransactionAssetName").value = transaction.asset_name || transaction.symbol;
  qs("#editTransactionAssetType").value = transaction.asset_type || "OTHER";
  qs("#editTransactionCurrency").value = transaction.asset_currency || currentPortfolioData?.summary?.currency || "USD";
  qs("#editTransactionExchange").value = transaction.exchange || "";
  qs("#editTransactionType").value = transaction.transaction_type;
  qs("#editTransactionQuantity").value = transaction.quantity;
  qs("#editTransactionPrice").value = transaction.price;
  qs("#editTransactionFees").value = transaction.fees;
  qs("#editTransactionDate").value = toLocalDateTimeInput(transaction.occurred_at);
  qs("#editTransactionFx").value = transaction.fx_rate_to_base;
  qs("#editTransactionNotes").value = transaction.notes || "";
  qs("#editTransactionReason").value = "Corrección de carga";
  qs("#transactionEditPreview").textContent = "Usá “Vista previa” para validar el efecto antes de guardar.";
  qs("#transactionEditMessage").textContent = "";
  qs("#transactionEditDialog").showModal();
}

function transactionEditPayload() {
  const parsedDate = new Date(qs("#editTransactionDate").value);
  return {
    symbol: qs("#editTransactionSymbol").value,
    pricing_mode: qs("#editTransactionPricingMode").value,
    asset_name: qs("#editTransactionAssetName").value || null,
    asset_type: qs("#editTransactionAssetType").value || null,
    asset_currency: qs("#editTransactionCurrency").value || null,
    exchange: qs("#editTransactionExchange").value || null,
    transaction_type: qs("#editTransactionType").value,
    quantity: Number(qs("#editTransactionQuantity").value),
    price: Number(qs("#editTransactionPrice").value),
    fees: Number(qs("#editTransactionFees").value || 0),
    occurred_at: parsedDate.toISOString(),
    notes: qs("#editTransactionNotes").value,
    fx_rate_to_base: Number(qs("#editTransactionFx").value),
    reason: qs("#editTransactionReason").value,
  };
}

async function previewTransactionEdit() {
  if (!editingTransactionId) return;
  const panel = qs("#transactionEditPreview");
  panel.textContent = "Validando toda la secuencia contable…";
  try {
    const preview = await apiRequest(`/api/portfolio/transactions/${editingTransactionId}/preview`, {
      method: "POST", body: JSON.stringify(transactionEditPayload()),
    });
    panel.innerHTML = impactPreviewHTML(preview, currentPortfolioData?.summary?.currency || "USD");
  } catch (error) {
    panel.innerHTML = `<span class="negative">${escapeHTML(error.message)}</span>`;
  }
}

function openCashEdit(movementId) {
  const movement = (currentPortfolioData?.all_cash_movements || []).find(
    (item) => Number(item.id) === Number(movementId) && !item.is_deleted
  );
  if (!movement) return;
  editingCashMovementId = movementId;
  qs("#cashEditIdentity").textContent = `${movementLabels[movement.movement_type] || movement.movement_type} · revisión ${movement.revision || 1}`;
  qs("#editCashType").value = movement.movement_type;
  qs("#editCashAmount").value = movement.amount;
  qs("#editCashCurrency").value = movement.currency;
  qs("#editCashSymbol").value = movement.symbol || "";
  qs("#editCashDate").value = toLocalDateTimeInput(movement.occurred_at);
  qs("#editCashFx").value = movement.fx_rate_to_base;
  qs("#editCashNotes").value = movement.notes || "";
  qs("#editCashReason").value = "Corrección de movimiento";
  qs("#cashEditPreview").textContent = "Usá “Vista previa” para validar el efecto antes de guardar.";
  qs("#cashEditMessage").textContent = "";
  qs("#cashEditDialog").showModal();
}

function cashEditPayload() {
  const parsedDate = new Date(qs("#editCashDate").value);
  const fxValue = Number(qs("#editCashFx").value);
  return {
    movement_type: qs("#editCashType").value,
    amount: Number(qs("#editCashAmount").value),
    currency: qs("#editCashCurrency").value,
    symbol: qs("#editCashSymbol").value || null,
    occurred_at: parsedDate.toISOString(),
    notes: qs("#editCashNotes").value,
    fx_rate_to_base: Number.isFinite(fxValue) && fxValue > 0 ? fxValue : null,
    reason: qs("#editCashReason").value,
  };
}

async function previewCashEdit() {
  if (!editingCashMovementId) return;
  const panel = qs("#cashEditPreview");
  panel.textContent = "Validando efectivo y operaciones posteriores…";
  try {
    const preview = await apiRequest(`/api/portfolio/cash-movements/${editingCashMovementId}/preview`, {
      method: "POST", body: JSON.stringify(cashEditPayload()),
    });
    panel.innerHTML = impactPreviewHTML(preview, currentPortfolioData?.summary?.currency || "USD");
  } catch (error) {
    panel.innerHTML = `<span class="negative">${escapeHTML(error.message)}</span>`;
  }
}

function fxPayload(prefix = "") {
  const id = (name) => `#${prefix}${name}`;
  const date = new Date(qs(id("Date")).value);
  const rate = Number(qs(id("ExchangeRate")).value);
  const fromBase = Number(qs(id("FromBaseRate")).value);
  const toBase = Number(qs(id("ToBaseRate")).value);
  const payload = {
    from_currency: qs(id("FromCurrency")).value,
    to_currency: qs(id("ToCurrency")).value,
    from_amount: Number(qs(id("FromAmount")).value),
    pricing_mode: qs(id("PricingMode")).value,
    exchange_rate: Number.isFinite(rate) && rate > 0 ? rate : null,
    fee_amount: Number(qs(id("FeeAmount")).value || 0),
    fee_currency: qs(id("FeeCurrency")).value || null,
    occurred_at: date.toISOString(),
    notes: qs(id("Notes")).value,
    from_fx_rate_to_base: Number.isFinite(fromBase) && fromBase > 0 ? fromBase : null,
    to_fx_rate_to_base: Number.isFinite(toBase) && toBase > 0 ? toBase : null,
  };
  if (prefix === "editFx") payload.reason = qs("#editFxReason").value;
  return payload;
}

function toggleFxPricingMode(prefix = "fx") {
  const mode = qs(`#${prefix}PricingMode`).value;
  const rate = qs(`#${prefix}ExchangeRate`);
  rate.required = mode === "MANUAL";
  rate.placeholder = mode === "MANUAL" ? "Obligatorio" : "Automático";
}

async function previewNewFxConversion() {
  const panel = qs("#fxCreatePreview");
  panel.textContent = "Consultando tasas y validando saldos por moneda…";
  try {
    const preview = await apiRequest("/api/portfolio/fx-conversions/preview", {
      method: "POST", body: JSON.stringify(fxPayload("fx")),
    });
    panel.innerHTML = impactPreviewHTML(preview, currentPortfolioData?.summary?.currency || "USD");
    if (preview.after) {
      panel.innerHTML += `<p class="data-source">Recibirás ${escapeHTML(formatPrice(preview.after.to_amount, preview.after.to_currency))} a una tasa de ${Number(preview.after.exchange_rate).toLocaleString("es-AR", { maximumFractionDigits: 8 })}.</p>`;
    }
  } catch (error) {
    panel.innerHTML = `<span class="negative">${escapeHTML(error.message)}</span>`;
  }
}

function openFxEdit(conversionId) {
  const conversion = (currentPortfolioData?.all_fx_conversions || []).find(
    (item) => Number(item.id) === Number(conversionId) && !item.is_deleted
  );
  if (!conversion) return;
  editingFxConversionId = conversionId;
  qs("#fxEditIdentity").textContent = `${conversion.from_currency}/${conversion.to_currency} · revisión ${conversion.revision || 1}`;
  qs("#editFxFromCurrency").value = conversion.from_currency;
  qs("#editFxToCurrency").value = conversion.to_currency;
  qs("#editFxFromAmount").value = conversion.from_amount;
  qs("#editFxPricingMode").value = conversion.pricing_mode;
  qs("#editFxExchangeRate").value = conversion.exchange_rate;
  qs("#editFxFeeAmount").value = conversion.fee_amount;
  qs("#editFxFeeCurrency").value = conversion.fee_currency || conversion.from_currency;
  qs("#editFxDate").value = toLocalDateTimeInput(conversion.occurred_at);
  qs("#editFxFromBaseRate").value = conversion.from_fx_rate_to_base;
  qs("#editFxToBaseRate").value = conversion.to_fx_rate_to_base;
  qs("#editFxNotes").value = conversion.notes || "";
  qs("#editFxReason").value = "Corrección de conversión FX";
  toggleFxPricingMode("editFx");
  qs("#fxEditPreview").textContent = "Usá “Vista previa” para validar ambos saldos antes de guardar.";
  qs("#fxEditMessage").textContent = "";
  qs("#fxEditDialog").showModal();
}

async function previewFxEdit() {
  if (!editingFxConversionId) return;
  const panel = qs("#fxEditPreview");
  panel.textContent = "Validando saldos y movimientos posteriores…";
  try {
    const preview = await apiRequest(`/api/portfolio/fx-conversions/${editingFxConversionId}/preview`, {
      method: "POST", body: JSON.stringify(fxPayload("editFx")),
    });
    panel.innerHTML = impactPreviewHTML(preview, currentPortfolioData?.summary?.currency || "USD");
  } catch (error) {
    panel.innerHTML = `<span class="negative">${escapeHTML(error.message)}</span>`;
  }
}

function setupSafeEditing() {
  qs("#showDeletedRecords").addEventListener("change", () => {
    if (!currentPortfolioData) return;
    renderPortfolioTransactions(currentPortfolioData);
    renderCashMovements(currentPortfolioData);
    renderFxConversions(currentPortfolioData);
    renderCorporateActions(currentPortfolioData);
  });

  qs("#cancelTransactionEdit").addEventListener("click", () => qs("#transactionEditDialog").close());
  qs("#previewTransactionEdit").addEventListener("click", previewTransactionEdit);
  qs("#transactionEditForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    if (!editingTransactionId) return;
    const message = qs("#transactionEditMessage");
    message.textContent = "Guardando corrección y registrando auditoría…";
    try {
      await apiRequest(`/api/portfolio/transactions/${editingTransactionId}`, {
        method: "PUT", body: JSON.stringify(transactionEditPayload()),
      });
      qs("#transactionEditDialog").close();
      editingTransactionId = null;
      await Promise.all([loadPortfolio(), loadDashboard()]);
    } catch (error) { message.textContent = error.message; }
  });

  qs("#cancelCashEdit").addEventListener("click", () => qs("#cashEditDialog").close());
  qs("#previewCashEdit").addEventListener("click", previewCashEdit);
  qs("#cashEditForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    if (!editingCashMovementId) return;
    const message = qs("#cashEditMessage");
    message.textContent = "Guardando corrección y registrando auditoría…";
    try {
      await apiRequest(`/api/portfolio/cash-movements/${editingCashMovementId}`, {
        method: "PUT", body: JSON.stringify(cashEditPayload()),
      });
      qs("#cashEditDialog").close();
      editingCashMovementId = null;
      await Promise.all([loadPortfolio(), loadDashboard()]);
    } catch (error) { message.textContent = error.message; }
  });


  qs("#cancelFxEdit").addEventListener("click", () => qs("#fxEditDialog").close());
  qs("#editFxPricingMode").addEventListener("change", () => toggleFxPricingMode("editFx"));
  qs("#previewFxEdit").addEventListener("click", previewFxEdit);
  qs("#fxEditForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    if (!editingFxConversionId) return;
    const message = qs("#fxEditMessage");
    message.textContent = "Guardando corrección FX y registrando auditoría…";
    try {
      await apiRequest(`/api/portfolio/fx-conversions/${editingFxConversionId}`, {
        method: "PUT", body: JSON.stringify(fxPayload("editFx")),
      });
      qs("#fxEditDialog").close();
      editingFxConversionId = null;
      await Promise.all([loadPortfolio(), loadDashboard()]);
    } catch (error) { message.textContent = error.message; }
  });
}

function setupPortfolio() {
  setDefaultPortfolioDates();
  setupSafeEditing();
  ["#cashMovementCurrency", "#portfolioAssetCurrency", "#manualAssetCurrency", "#fxFromCurrency", "#fxToCurrency", "#fxFeeCurrency"].forEach((selector) => {
    qs(selector).addEventListener("input", (event) => { event.currentTarget.dataset.touched = "true"; });
  });
  qs("#fxPricingMode").addEventListener("change", () => toggleFxPricingMode("fx"));
  qs("#previewFxConversion").addEventListener("click", previewNewFxConversion);
  qs("#fxFromCurrency").addEventListener("input", (event) => {
    if (!qs("#fxFeeCurrency").dataset.touched) qs("#fxFeeCurrency").value = event.currentTarget.value.toUpperCase();
  });
  toggleFxPricingMode("fx");
  qs("#portfolioPricingMode").addEventListener("change", togglePricingMode);
  qs("#searchPortfolioAsset").addEventListener("click", searchPortfolioAssets);
  qs("#portfolioSymbol").addEventListener("input", () => { selectedPortfolioAsset = null; });
  qs("#portfolioSymbol").addEventListener("keydown", (event) => {
    if (event.key === "Enter") { event.preventDefault(); searchPortfolioAssets(); }
  });

  qs("#useLivePrice").addEventListener("click", async () => {
    const symbol = qs("#portfolioSymbol").value.trim().toUpperCase();
    const hint = qs("#portfolioQuoteHint");
    if (!symbol) { hint.textContent = "Ingresá un símbolo primero."; return; }
    hint.textContent = `Consultando ${symbol}…`;
    try {
      const quote = await apiRequest(`/api/market/${encodeURIComponent(symbol)}`);
      selectedPortfolioAsset = quote;
      qs("#portfolioPrice").value = quote.price;
      hint.textContent = `${quote.name} · ${quote.asset_type} · ${formatPrice(quote.price, quote.currency)} · ${quote.exchange || quote.market}`;
    } catch (error) { hint.textContent = error.message; }
  });

  qs("#portfolioTransactionForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const message = qs("#portfolioMessage");
    const parsedDate = new Date(qs("#portfolioDate").value);
    if (Number.isNaN(parsedDate.getTime())) { message.textContent = "Ingresá una fecha válida."; return; }
    const manual = qs("#portfolioPricingMode").value === "MANUAL";
    const fxValue = Number(qs("#portfolioFxRate").value);
    const payload = {
      transaction_type: qs("#portfolioType").value,
      pricing_mode: manual ? "MANUAL" : "AUTO",
      symbol: qs("#portfolioSymbol").value,
      quantity: Number(qs("#portfolioQuantity").value),
      price: Number(qs("#portfolioPrice").value),
      fees: Number(qs("#portfolioFees").value || 0),
      occurred_at: parsedDate.toISOString(),
      notes: qs("#portfolioNotes").value,
      asset_name: manual ? qs("#portfolioAssetName").value : selectedPortfolioAsset?.name,
      asset_type: manual ? qs("#portfolioAssetType").value : selectedPortfolioAsset?.asset_type,
      asset_currency: manual ? qs("#portfolioAssetCurrency").value : selectedPortfolioAsset?.currency,
      exchange: manual ? "Manual" : selectedPortfolioAsset?.exchange,
      fx_rate_to_base: Number.isFinite(fxValue) && fxValue > 0 ? fxValue : null,
    };
    message.textContent = "Validando efectivo, activo y conversión FX…";
    try {
      await apiRequest("/api/portfolio/transactions", { method: "POST", body: JSON.stringify(payload) });
      qs("#portfolioQuantity").value = "1";
      qs("#portfolioPrice").value = "";
      qs("#portfolioFees").value = "0";
      qs("#portfolioFxRate").value = "";
      qs("#portfolioNotes").value = "";
      qs("#portfolioDate").value = "";
      selectedPortfolioAsset = null;
      setDefaultPortfolioDates();
      await Promise.all([loadPortfolio(), loadDashboard()]);
    } catch (error) { message.textContent = error.message; }
  });

  qs("#corporateActionType").addEventListener("change", toggleCorporateActionFields);
  qs("#previewCorporateAction").addEventListener("click", previewCorporateAction);
  qs("#cancelCorporateActionEdit").addEventListener("click", () => {
    editingCorporateActionId = null;
    qs("#corporateActionForm").reset();
    qs("#corporateActionRatio").value = "2";
    qs("#corporateActionCurrency").value = currentPortfolioData?.summary?.currency || "USD";
    qs("#saveCorporateAction").textContent = "Registrar evento";
    qs("#cancelCorporateActionEdit").hidden = true;
    qs("#corporateActionPreview").textContent = "Edición cancelada.";
    setDefaultPortfolioDates();
    toggleCorporateActionFields();
  });
  qs("#corporateActionForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const message = qs("#corporateActionMessage");
    message.textContent = "Validando evento y operaciones posteriores…";
    try {
      const payload = corporateActionPayload();
      if (editingCorporateActionId) payload.reason = "Corrección desde la interfaz";
      const endpoint = editingCorporateActionId
        ? `/api/portfolio/corporate-actions/${editingCorporateActionId}`
        : "/api/portfolio/corporate-actions";
      const created = await apiRequest(endpoint, {
        method: editingCorporateActionId ? "PUT" : "POST", body: JSON.stringify(payload),
      });
      message.textContent = `${corporateActionLabels[created.action_type] || created.action_type} ${editingCorporateActionId ? "corregido" : "registrado"} para ${created.symbol}.`;
      editingCorporateActionId = null;
      event.currentTarget.reset();
      qs("#corporateActionRatio").value = "2";
      qs("#corporateActionAllocation").value = "0";
      qs("#corporateActionCash").value = "0";
      qs("#corporateActionCurrency").value = currentPortfolioData?.summary?.currency || "USD";
      qs("#corporateActionPreview").textContent = "Evento guardado y ledger recalculado.";
      qs("#saveCorporateAction").textContent = "Registrar evento";
      qs("#cancelCorporateActionEdit").hidden = true;
      setDefaultPortfolioDates();
      toggleCorporateActionFields();
      await Promise.all([loadPortfolio(), loadDashboard()]);
    } catch (error) { message.textContent = error.message; }
  });

  qs("#advancedDividendReinvest").addEventListener("change", (event) => {
    qs("#advancedDividendReinvestPrice").required = event.currentTarget.checked;
  });

  qs("#advancedDividendForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const message = qs("#advancedDividendMessage");
    const occurredAt = new Date(qs("#advancedDividendDate").value);
    const optionalNumber = (selector) => {
      const value = Number(qs(selector).value);
      return Number.isFinite(value) && value > 0 ? value : null;
    };
    const reinvest = qs("#advancedDividendReinvest").checked;
    const payload = {
      symbol: qs("#advancedDividendSymbol").value,
      gross_amount: Number(qs("#advancedDividendGross").value),
      currency: qs("#advancedDividendCurrency").value,
      withholding_percent: Number(qs("#advancedDividendWithholding").value || 0),
      dividend_per_share: optionalNumber("#advancedDividendPerShare"),
      shares_held: optionalNumber("#advancedDividendShares"),
      occurred_at: occurredAt.toISOString(),
      notes: qs("#advancedDividendNotes").value,
      fx_rate_to_base: optionalNumber("#advancedDividendFx"),
      source: "MANUAL",
      reinvest,
      reinvest_price: reinvest ? optionalNumber("#advancedDividendReinvestPrice") : null,
      reinvest_fees: Number(qs("#advancedDividendReinvestFees").value || 0),
    };
    message.textContent = "Calculando bruto, retención, neto y posible reinversión…";
    try {
      const created = await apiRequest("/api/portfolio/dividends", {
        method: "POST", body: JSON.stringify(payload),
      });
      message.textContent = `Dividendo neto ${formatPrice(created.net_amount, created.currency)} registrado${created.reinvested ? ` · ${formatQuantity(created.reinvest_quantity)} unidades reinvertidas` : ""}.`;
      event.currentTarget.reset();
      qs("#advancedDividendCurrency").value = currentPortfolioData?.summary?.currency || "USD";
      qs("#advancedDividendReinvestFees").value = "0";
      setDefaultPortfolioDates();
      await Promise.all([loadPortfolio(), loadDashboard()]);
      if (qs("#page-analytics")?.classList.contains("active")) await loadDividendAnalytics();
    } catch (error) { message.textContent = error.message; }
  });

  qs("#importAdvancedDividends").addEventListener("click", async () => {
    const symbol = qs("#advancedDividendSymbol").value.trim().toUpperCase() || qs("#portfolioSymbol").value.trim().toUpperCase();
    const message = qs("#advancedDividendMessage");
    if (!symbol) { message.textContent = "Ingresá el símbolo que querés importar."; return; }
    message.textContent = `Importando dividendos históricos de ${symbol}…`;
    try {
      const result = await apiRequest(`/api/portfolio/dividends/import/${encodeURIComponent(symbol)}?period=5y`, {
        method: "POST",
        body: JSON.stringify({
          withholding_percent: Number(qs("#importDividendWithholding").value || 0),
          reinvest: qs("#importDividendReinvest").checked,
          reinvest_fees: 0,
          price_strategy: "HISTORICAL_CLOSE",
        }),
      });
      message.textContent = `${result.imported_count} importados · ${result.skipped_count} omitidos · ${result.error_count || 0} con error.`;
      await Promise.all([loadPortfolio(), loadDashboard()]);
      if (qs("#page-analytics")?.classList.contains("active")) await loadDividendAnalytics();
    } catch (error) { message.textContent = error.message; }
  });

  qs("#importPortfolioDividends").addEventListener("click", async () => {
    const symbol = qs("#cashMovementSymbol").value.trim().toUpperCase() || qs("#portfolioSymbol").value.trim().toUpperCase();
    if (!symbol) { qs("#portfolioMessage").textContent = "Ingresá el activo relacionado para importar dividendos."; return; }
    qs("#portfolioMessage").textContent = `Buscando dividendos históricos de ${symbol}…`;
    try {
      const result = await apiRequest(`/api/portfolio/dividends/import/${encodeURIComponent(symbol)}?period=5y`, { method: "POST" });
      qs("#portfolioMessage").textContent = `${result.imported_count} dividendos importados; ${result.skipped_count} omitidos.`;
      await Promise.all([loadPortfolio(), loadDashboard()]);
    } catch (error) { qs("#portfolioMessage").textContent = error.message; }
  });

  qs("#portfolioCashForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const parsedDate = new Date(qs("#cashMovementDate").value);
    const fxValue = Number(qs("#cashMovementFx").value);
    const payload = {
      movement_type: qs("#cashMovementType").value,
      amount: Number(qs("#cashMovementAmount").value),
      currency: qs("#cashMovementCurrency").value,
      symbol: qs("#cashMovementSymbol").value || null,
      occurred_at: parsedDate.toISOString(),
      notes: qs("#cashMovementNotes").value,
      fx_rate_to_base: Number.isFinite(fxValue) && fxValue > 0 ? fxValue : null,
    };
    try {
      await apiRequest("/api/portfolio/cash-movements", { method: "POST", body: JSON.stringify(payload) });
      event.currentTarget.reset();
      qs("#cashMovementCurrency").dataset.touched = "";
      qs("#cashMovementDate").value = "";
      setDefaultPortfolioDates();
      await Promise.all([loadPortfolio(), loadDashboard()]);
    } catch (error) { qs("#portfolioMessage").textContent = error.message; }
  });

  qs("#fxConversionForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const message = qs("#portfolioMessage");
    message.textContent = "Registrando conversión y recalculando saldos…";
    try {
      const created = await apiRequest("/api/portfolio/fx-conversions", {
        method: "POST", body: JSON.stringify(fxPayload("fx")),
      });
      event.currentTarget.reset();
      qs("#fxFromCurrency").value = currentPortfolioData?.summary?.currency || "USD";
      qs("#fxToCurrency").value = "ARS";
      qs("#fxFeeCurrency").value = qs("#fxFromCurrency").value;
      qs("#fxFeeCurrency").dataset.touched = "";
      qs("#fxDate").value = "";
      qs("#fxCreatePreview").textContent = `${formatPrice(created.from_amount, created.from_currency)} convertidos a ${formatPrice(created.to_amount, created.to_currency)}.`;
      setDefaultPortfolioDates();
      toggleFxPricingMode("fx");
      await Promise.all([loadPortfolio(), loadDashboard()]);
    } catch (error) { message.textContent = error.message; }
  });

  qs("#manualAssetForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const payload = {
      symbol: qs("#manualAssetSymbol").value,
      name: qs("#manualAssetName").value,
      asset_type: qs("#manualAssetType").value,
      currency: qs("#manualAssetCurrency").value,
      current_price: Number(qs("#manualAssetPrice").value),
      exchange: qs("#manualAssetExchange").value,
    };
    try {
      const asset = await apiRequest("/api/portfolio/assets/manual", { method: "POST", body: JSON.stringify(payload) });
      qs("#portfolioPricingMode").value = "MANUAL";
      togglePricingMode();
      qs("#portfolioSymbol").value = asset.symbol;
      qs("#portfolioAssetName").value = asset.name;
      qs("#portfolioAssetType").value = asset.asset_type;
      qs("#portfolioAssetCurrency").value = asset.currency;
      qs("#portfolioPrice").value = asset.manual_price;
      event.currentTarget.reset();
      await loadPortfolio();
    } catch (error) { qs("#portfolioMessage").textContent = error.message; }
  });

  qs("#portfolioSettingsForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const payload = {
      name: qs("#portfolioName").value,
      initial_cash: Number(qs("#portfolioInitialCash").value),
      base_currency: qs("#portfolioCurrency").value,
      allow_margin: qs("#portfolioAllowMargin").checked,
    };
    try {
      await apiRequest("/api/portfolio/settings", { method: "PUT", body: JSON.stringify(payload) });
      await loadPortfolioCatalog(activePortfolioId);
      await Promise.all([loadPortfolio(), loadDashboard()]);
    } catch (error) { qs("#portfolioMessage").textContent = error.message; }
  });

  qs("#refreshPortfolio").addEventListener("click", async () => { await Promise.all([loadPortfolio(), loadDashboard()]); });
  qs("#portfolioCurvePeriod").addEventListener("change", () => loadPortfolioCurve());
  document.addEventListener("click", (event) => {
    if (!event.target.closest(".asset-search-field")) qs("#portfolioSearchResults").hidden = true;
  });
  togglePricingMode();
}

function renderCsvPreview(preview) {
  const summary = qs("#csvImportSummary");
  const table = qs("#csvPreviewTable");
  csvImportPreview = preview;
  summary.innerHTML = `
    <div><span>Total</span><strong>${preview.total_rows}</strong></div>
    <div><span>Aceptadas</span><strong class="positive">${preview.accepted}</strong></div>
    <div><span>Duplicadas</span><strong>${preview.duplicate}</strong></div>
    <div><span>Rechazadas</span><strong class="negative">${preview.rejected}</strong></div>`;
  const rows = preview.rows || [];
  table.innerHTML = rows.length ? `
    <table class="data-table"><thead><tr><th>Fila</th><th>Tipo</th><th>Estado</th><th>Detalle</th></tr></thead><tbody>
      ${rows.map((row) => `<tr>
        <td>${row.row_number}</td>
        <td>${escapeHTML(row.record_type)}</td>
        <td><span class="import-status import-${escapeHTML(row.status)}">${escapeHTML(row.status)}</span></td>
        <td>${escapeHTML(row.message || "")}</td>
      </tr>`).join("")}
    </tbody></table>` : "";
  qs("#commitCsvImport").disabled = !preview.can_commit;
}

function renderImportHistory(items) {
  const container = qs("#csvImportHistory");
  if (!items.length) {
    container.innerHTML = '<p class="data-source">Todavía no hay importaciones registradas.</p>';
    return;
  }
  container.innerHTML = items.slice(0, 8).map((item) => `
    <div class="data-history-item">
      <div><strong>${escapeHTML(item.filename)}</strong><span>${escapeHTML(item.status)} · ${item.accepted_rows} importadas · ${item.rejected_rows} rechazadas · ${item.duplicate_rows} duplicadas</span><small>${escapeHTML(formatDate(item.committed_at || item.created_at))}</small></div>
      <span class="revision-badge">Lote #${item.id}</span>
    </div>`).join("");
}

function renderBackupHistory(items) {
  const container = qs("#backupHistory");
  if (!items.length) {
    container.innerHTML = '<p class="data-source">Todavía no hay copias disponibles.</p>';
    return;
  }
  container.innerHTML = items.slice(0, 10).map((item) => `
    <div class="data-history-item">
      <div><strong>${escapeHTML(item.filename)}</strong><span>${escapeHTML(item.backup_type || "backup")} · ${escapeHTML(formatBytes(item.size_bytes))}${item.schema_version ? ` · esquema ${item.schema_version}` : ""}</span><small>${escapeHTML(formatDate(item.created_at))}${item.note ? ` · ${escapeHTML(item.note)}` : ""}</small></div>
      ${item.downloadable ? `<button class="secondary-button compact-button" type="button" data-backup-download="${escapeHTML(item.filename)}">Descargar</button>` : '<span class="revision-badge">Migración</span>'}
    </div>`).join("");
  qsa("[data-backup-download]", container).forEach((button) => {
    button.addEventListener("click", () => triggerDownload(`/api/data/backups/${encodeURIComponent(button.dataset.backupDownload)}`));
  });
}

function renderBackupValidation(data) {
  const container = qs("#backupValidation");
  if (!data) {
    container.innerHTML = "";
    return;
  }
  container.innerHTML = `
    <div><span>Estado</span><strong class="positive">Backup válido</strong></div>
    <div><span>Esquema</span><strong>${escapeHTML(String(data.schema_version))}${data.will_migrate ? " → migrará" : ""}</strong></div>
    <div><span>Versión</span><strong>${escapeHTML(data.app_version || "Sin dato")}</strong></div>
    <div><span>Tamaño DB</span><strong>${escapeHTML(formatBytes(data.database_size))}</strong></div>`;
}

async function loadDataManagement() {
  if (!qs("#csvImportHistory") || !qs("#backupHistory")) return;
  try {
    const [imports, backups] = await Promise.all([
      apiRequest(`/api/data/csv/imports?portfolio_id=${encodeURIComponent(activePortfolioId)}&limit=20`),
      apiRequest("/api/data/backups"),
    ]);
    renderImportHistory(imports);
    renderBackupHistory(backups);
  } catch (error) {
    qs("#csvImportMessage").textContent = error.message;
  }
}

function setupDataManagement() {
  const csvFile = qs("#csvImportFile");
  csvFile.addEventListener("change", async () => {
    const file = csvFile.files?.[0];
    csvImportContent = "";
    csvImportFilename = "";
    csvImportPreview = null;
    qs("#commitCsvImport").disabled = true;
    qs("#csvPreviewTable").innerHTML = "";
    qs("#csvImportSummary").innerHTML = "";
    if (!file) return;
    try {
      csvImportContent = await file.text();
      csvImportFilename = file.name;
      qs("#csvImportMessage").textContent = `${file.name} cargado · ${formatBytes(file.size)}. Ejecutá la vista previa.`;
    } catch (error) {
      qs("#csvImportMessage").textContent = `No se pudo leer el CSV: ${error.message}`;
    }
  });

  qs("#previewCsvImport").addEventListener("click", async () => {
    const message = qs("#csvImportMessage");
    if (!csvImportContent) {
      message.textContent = "Seleccioná un archivo CSV primero.";
      return;
    }
    message.textContent = "Validando formato, duplicados y consistencia contable…";
    try {
      const preview = await apiRequest(`/api/data/csv/preview?portfolio_id=${encodeURIComponent(activePortfolioId)}`, {
        method: "POST",
        body: JSON.stringify({
          content: csvImportContent,
          filename: csvImportFilename,
          skip_duplicates: qs("#csvSkipDuplicates").checked,
          import_valid_only: qs("#csvImportValidOnly").checked,
          adapter: "generic",
        }),
      });
      renderCsvPreview(preview);
      message.textContent = `${preview.accepted} filas listas; ${preview.rejected} rechazadas y ${preview.duplicate} duplicadas.`;
    } catch (error) {
      message.textContent = error.message;
      qs("#commitCsvImport").disabled = true;
    }
  });

  qs("#commitCsvImport").addEventListener("click", async () => {
    const message = qs("#csvImportMessage");
    if (!csvImportContent || !csvImportPreview?.can_commit) return;
    message.textContent = "Importando filas válidas y registrando el lote…";
    qs("#commitCsvImport").disabled = true;
    try {
      const result = await apiRequest(`/api/data/csv/import?portfolio_id=${encodeURIComponent(activePortfolioId)}`, {
        method: "POST",
        body: JSON.stringify({
          content: csvImportContent,
          filename: csvImportFilename,
          skip_duplicates: qs("#csvSkipDuplicates").checked,
          import_valid_only: qs("#csvImportValidOnly").checked,
          adapter: "generic",
        }),
      });
      message.textContent = `Lote #${result.batch_id}: ${result.committed.length} filas importadas.`;
      await Promise.all([loadPortfolio(), loadDashboard()]);
    } catch (error) {
      message.textContent = error.message;
      qs("#commitCsvImport").disabled = false;
    }
  });

  qsa("[data-csv-export]").forEach((button) => {
    button.addEventListener("click", () => {
      const dataset = button.dataset.csvExport;
      triggerDownload(`/api/data/csv/export/${encodeURIComponent(dataset)}?portfolio_id=${encodeURIComponent(activePortfolioId)}`);
    });
  });

  qs("#createBackup").addEventListener("click", async () => {
    const message = qs("#backupMessage");
    message.textContent = "Creando snapshot consistente y checksum…";
    try {
      const result = await apiRequest("/api/data/backups", {
        method: "POST",
        body: JSON.stringify({ note: qs("#backupNote").value }),
      });
      message.textContent = `${result.filename} creado · esquema ${result.schema_version}.`;
      triggerDownload(result.download_url, result.filename);
      await loadDataManagement();
    } catch (error) {
      message.textContent = error.message;
    }
  });

  qs("#backupRestoreFile").addEventListener("change", async (event) => {
    const file = event.currentTarget.files?.[0];
    backupRestoreBytes = null;
    backupRestoreFilename = "";
    backupValidationResult = null;
    qs("#restoreBackup").disabled = true;
    renderBackupValidation(null);
    if (!file) return;
    try {
      backupRestoreBytes = await file.arrayBuffer();
      backupRestoreFilename = file.name;
      qs("#backupMessage").textContent = `${file.name} cargado · ${formatBytes(file.size)}. Validalo antes de restaurar.`;
    } catch (error) {
      qs("#backupMessage").textContent = error.message;
    }
  });

  qs("#validateBackup").addEventListener("click", async () => {
    const message = qs("#backupMessage");
    if (!backupRestoreBytes) {
      message.textContent = "Seleccioná un archivo .qlbackup primero.";
      return;
    }
    message.textContent = "Verificando formato, checksum, SQLite y versión de esquema…";
    try {
      backupValidationResult = await rawApiRequest(`/api/data/backups/validate?filename=${encodeURIComponent(backupRestoreFilename)}`, {
        method: "POST", headers: { "Content-Type": "application/octet-stream" }, body: backupRestoreBytes,
      });
      renderBackupValidation(backupValidationResult);
      qs("#restoreBackup").disabled = false;
      message.textContent = "Backup válido. Para continuar, escribí RESTAURAR.";
    } catch (error) {
      message.textContent = error.message;
      qs("#restoreBackup").disabled = true;
    }
  });

  qs("#restoreBackup").addEventListener("click", async () => {
    const confirmation = qs("#backupConfirmation").value.trim().toUpperCase();
    const message = qs("#backupMessage");
    if (!backupRestoreBytes || !backupValidationResult) return;
    if (confirmation !== "RESTAURAR") {
      message.textContent = "Escribí RESTAURAR para confirmar.";
      return;
    }
    if (!window.confirm("Se reemplazará la base actual. QuantLab creará un backup de seguridad antes de continuar. ¿Confirmás?")) return;
    message.textContent = "Creando backup de seguridad y restaurando la base…";
    qs("#restoreBackup").disabled = true;
    try {
      const result = await rawApiRequest(`/api/data/backups/restore?filename=${encodeURIComponent(backupRestoreFilename)}&confirmation=RESTAURAR`, {
        method: "POST", headers: { "Content-Type": "application/octet-stream" }, body: backupRestoreBytes,
      });
      activePortfolioId = 1;
      localStorage.setItem("quantlab.activePortfolioId", "1");
      message.textContent = `${result.message}. Backup previo: ${result.safety_backup.filename}.`;
      await loadPortfolioCatalog(1);
      await Promise.all([loadPortfolio(), loadDashboard(), loadWatchlist()]);
    } catch (error) {
      message.textContent = error.message;
      qs("#restoreBackup").disabled = false;
    }
  });
}

function analyticsMetricCard(label, value, detail = "", positive = null) {
  const variationClass = positive === null ? "" : (positive ? "positive" : "negative");
  return `
    <article class="metric-card analytics-metric-card">
      <span class="label">${escapeHTML(label)}</span>
      <strong class="value">${escapeHTML(value)}</strong>
      <span class="variation ${variationClass}">${escapeHTML(detail)}</span>
    </article>`;
}

function drawAnalyticsComparisonChart(svg, points, fallbackSeries = []) {
  if (!svg) return;
  const sourceRows = points?.length
    ? points.map((point) => ({
      date: point.date,
      portfolio: Number(point.portfolio_index),
      benchmark: Number(point.benchmark_index),
    }))
    : fallbackSeries.map((point) => ({
      date: point.date,
      portfolio: Number(point.wealth_index),
      benchmark: null,
    }));
  const usableAll = sourceRows.filter((row) => Number.isFinite(row.portfolio));
  const visibleCount = Math.max(2, Math.ceil(usableAll.length * analyticsZoomPercent / 100));
  const usable = usableAll.slice(-visibleCount);
  if (!usable.length) {
    svg.innerHTML = `<text class="chart-empty" x="400" y="140" text-anchor="middle">Sin datos suficientes para graficar</text>`;
    return;
  }

  const width = 800;
  const height = 280;
  const padding = 24;
  const allValues = usable.flatMap((row) => [row.portfolio, row.benchmark]).filter(Number.isFinite);
  const rawMin = Math.min(...allValues);
  const rawMax = Math.max(...allValues);
  const spread = rawMax - rawMin || Math.max(Math.abs(rawMax) * 0.02, 1);
  const min = rawMin - spread * 0.12;
  const max = rawMax + spread * 0.12;
  const xStep = usable.length > 1 ? (width - padding * 2) / (usable.length - 1) : 0;
  const scaleY = (value) => height - padding - ((value - min) / (max - min)) * (height - padding * 2);
  const toPoints = (key) => usable
    .map((row, index) => Number.isFinite(row[key]) ? `${padding + index * xStep},${scaleY(row[key])}` : null)
    .filter(Boolean)
    .join(" ");
  const portfolioPoints = toPoints("portfolio");
  const benchmarkPoints = toPoints("benchmark");
  const grid = [60, 120, 180, 240]
    .map((y) => `<line class="chart-grid" x1="0" y1="${y}" x2="800" y2="${y}"></line>`)
    .join("");
  const baseY = scaleY(100);
  const pointStep = Math.max(1, Math.ceil(usable.length / 50));
  const hoverPoints = usable.map((row, index) => {
    if (index % pointStep !== 0 && index !== usable.length - 1) return "";
    const x = padding + index * xStep;
    const circles = [`<circle class="analytics-hover-point portfolio-hover" cx="${x}" cy="${scaleY(row.portfolio)}" r="5"><title>${escapeHTML(row.date || "")} · Portafolio ${Number(row.portfolio).toFixed(2)}</title></circle>`];
    if (Number.isFinite(row.benchmark)) circles.push(`<circle class="analytics-hover-point benchmark-hover" cx="${x}" cy="${scaleY(row.benchmark)}" r="5"><title>${escapeHTML(row.date || "")} · Benchmark ${Number(row.benchmark).toFixed(2)}</title></circle>`);
    return circles.join("");
  }).join("");
  svg.innerHTML = `
    ${grid}
    ${baseY >= 0 && baseY <= height ? `<line class="analytics-base-line" x1="0" y1="${baseY}" x2="800" y2="${baseY}"></line>` : ""}
    <polyline class="analytics-line analytics-portfolio-line" points="${portfolioPoints}"></polyline>
    ${benchmarkPoints ? `<polyline class="analytics-line analytics-benchmark-line" points="${benchmarkPoints}"></polyline>` : ""}
    ${hoverPoints}`;
}
function drawAnalyticsDrawdown(svg, series) {
  if (!svg) return;
  const rows = (series || []).map((point) => ({ date: point.date, value: Number(point.drawdown_percent) })).filter((item) => Number.isFinite(item.value));
  const visibleCount = Math.max(2, Math.ceil(rows.length * analyticsZoomPercent / 100));
  const visibleRows = rows.slice(-visibleCount);
  const values = visibleRows.map((item) => item.value);
  if (!values.length) {
    svg.innerHTML = `<text class="chart-empty" x="400" y="140" text-anchor="middle">Sin datos suficientes para graficar</text>`;
    return;
  }
  const width = 800;
  const height = 280;
  const padding = 24;
  const minimum = Math.min(...values, -1);
  const maximum = 0;
  const spread = maximum - minimum || 1;
  const xStep = values.length > 1 ? (width - padding * 2) / (values.length - 1) : 0;
  const scaleY = (value) => height - padding - ((value - minimum) / spread) * (height - padding * 2);
  const points = values.map((value, index) => `${padding + index * xStep},${scaleY(value)}`).join(" ");
  const zeroY = scaleY(0);
  const areaPoints = `${padding},${zeroY} ${points} ${width - padding},${zeroY}`;
  const grid = [60, 120, 180, 240]
    .map((y) => `<line class="chart-grid" x1="0" y1="${y}" x2="800" y2="${y}"></line>`)
    .join("");
  svg.innerHTML = `
    <defs>
      <linearGradient id="drawdownGradient" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stop-color="#ff6b6b" stop-opacity=".08"></stop>
        <stop offset="100%" stop-color="#ff6b6b" stop-opacity=".5"></stop>
      </linearGradient>
    </defs>
    ${grid}
    <polygon class="analytics-drawdown-area" points="${areaPoints}"></polygon>
    <polyline class="analytics-line analytics-drawdown-line" points="${points}"></polyline>
    ${visibleRows.map((item, index) => {
      const step = Math.max(1, Math.ceil(visibleRows.length / 50));
      if (index % step !== 0 && index !== visibleRows.length - 1) return "";
      return `<circle class="analytics-hover-point drawdown-hover" cx="${padding + index * xStep}" cy="${scaleY(item.value)}" r="5"><title>${escapeHTML(item.date || "")} · ${item.value.toFixed(2)}%</title></circle>`;
    }).join("")}`;
}

function syncAnalyticsSettingsForm(settings) {
  const symbol = String(settings?.benchmark_symbol || "SPY").toUpperCase();
  const preset = qs("#benchmarkPreset");
  const matching = qsa("option", preset).find((option) => option.value.split("|")[0] === symbol);
  preset.value = matching ? matching.value : "CUSTOM|Personalizado";
  qs("#benchmarkSymbol").value = symbol === "NONE" ? "" : symbol;
  qs("#benchmarkSymbol").disabled = symbol === "NONE";
  qs("#analyticsRiskFreeRate").value = Number(settings?.risk_free_rate_percent || 0);
}

function renderAnalyticsConcentration(mode = activeConcentrationMode) {
  activeConcentrationMode = mode;
  qsa(".analytics-tab").forEach((tab) => {
    const active = tab.dataset.concentration === mode;
    tab.classList.toggle("active", active);
    tab.setAttribute("aria-selected", String(active));
  });
  const container = qs("#analyticsConcentration");
  const items = currentAnalyticsData?.concentration?.[mode] || [];
  if (!items.length) {
    container.innerHTML = `<div class="empty-state compact-empty">Todavía no hay distribución para mostrar.</div>`;
    return;
  }
  container.innerHTML = items.map((item) => {
    const percent = Number(item.percent || 0);
    const width = Math.min(Math.abs(percent), 100);
    return `
      <div class="concentration-row">
        <div class="concentration-heading"><span>${escapeHTML(item.label || item.key)}</span><strong>${escapeHTML(formatPlainPercent(percent))}</strong></div>
        <div class="concentration-track"><span style="width:${width}%"></span></div>
        <small>${escapeHTML(formatPrice(item.value, currentAnalyticsData.currency))}</small>
      </div>`;
  }).join("");
}

function renderDividendAnalytics(data) {
  currentDividendData = data;
  const currency = data.currency || "USD";
  const totals = data.totals || {};
  const metrics = [
    ["Bruto acumulado", formatPrice(totals.gross, currency), `${data.events_count || 0} eventos`],
    ["Retenciones", formatPrice(totals.tax, currency), `${Number(data.effective_withholding_percent || 0).toFixed(2)}% efectiva`],
    ["Neto recibido", formatPrice(totals.net, currency), "Efectivo real acreditado"],
    ["Últimos 12 meses", formatPrice(totals.trailing_12m_net, currency), "Dividendos netos"],
    ["Neto reinvertido", formatPrice(totals.reinvested_net, currency), "Compras vinculadas"],
  ];
  qs("#analyticsDividendMetrics").innerHTML = metrics.map(([label, value, detail]) => analyticsMetricCard(label, value, detail, null)).join("");
  qs("#analyticsDividendStatus").textContent = `${data.events_count || 0} dividendos`;
  qs("#analyticsDividendByAsset").innerHTML = (data.by_symbol || []).length
    ? data.by_symbol.map((item) => `<tr>
        <td><strong>${escapeHTML(item.symbol)}</strong><small>${escapeHTML(item.currency || "")}</small></td>
        <td>${escapeHTML(formatPrice(item.gross, currency))}</td>
        <td>${escapeHTML(formatPrice(item.tax, currency))}</td>
        <td>${escapeHTML(formatPrice(item.net, currency))}</td>
        <td>${escapeHTML(String(item.events || 0))}</td>
        <td>${item.yield_on_cost_percent === null ? "—" : escapeHTML(formatPercent(item.yield_on_cost_percent))}</td>
      </tr>`).join("")
    : `<tr><td colspan="6"><div class="empty-state compact-empty">Todavía no hay dividendos registrados.</div></td></tr>`;

  const history = (data.history || []).map((item) => ({
    date: item.occurred_at, symbol: item.symbol, amount: item.net_amount_base, status: item.reinvested ? "Reinvertido" : "Cobrado", estimate: false,
  }));
  const forecast = (data.forecast || []).map((item) => ({
    date: item.date, symbol: item.symbol, amount: item.estimated_gross_amount, status: `Estimado · ${item.confidence}`, estimate: true,
  }));
  const calendar = [...history, ...forecast].sort((a, b) => new Date(b.date) - new Date(a.date)).slice(0, 60);
  qs("#analyticsDividendCalendar").innerHTML = calendar.length
    ? calendar.map((item) => `<tr class="${item.estimate ? "estimated-row" : ""}">
        <td>${escapeHTML(formatDate(item.date))}</td><td><strong>${escapeHTML(item.symbol || "—")}</strong></td>
        <td>${escapeHTML(formatPrice(item.amount, currency))}</td><td>${escapeHTML(item.status)}</td></tr>`).join("")
    : `<tr><td colspan="4"><div class="empty-state compact-empty">Sin calendario disponible.</div></td></tr>`;
  qs("#analyticsDividendDisclaimer").textContent = data.forecast_disclaimer || "Las proyecciones no son pagos confirmados.";
  if (data.settings) {
    qs("#dividendDefaultWithholding").value = data.settings.default_withholding_percent ?? 0;
    qs("#dividendDefaultReinvest").checked = Boolean(data.settings.default_reinvest);
    qs("#dividendForecastMonths").value = data.settings.forecast_months ?? 12;
  }
}

async function loadDividendAnalytics() {
  try {
    const data = await apiRequest("/api/portfolio/dividends/summary");
    renderDividendAnalytics(data);
    return data;
  } catch (error) {
    qs("#analyticsDividendStatus").textContent = "No disponible";
    qs("#analyticsDividendDisclaimer").textContent = error.message;
    return null;
  }
}

function renderAdvancedRisk(data) {
  const advanced = data.advanced_risk || {};
  const relation = data.benchmark_relationship || {};
  const risk = data.risk || {};
  const metrics = [
    ["Sortino", advanced.sortino_ratio == null ? "Sin dato" : Number(advanced.sortino_ratio).toFixed(2), "Sólo penaliza volatilidad negativa"],
    ["VaR 95 diario", formatPlainPercent(advanced.var?.["95"]), "Percentil histórico de pérdida"],
    ["CVaR 95 diario", formatPlainPercent(advanced.cvar?.["95"]), "Pérdida media en la cola"],
    ["Beta", relation.beta == null ? "Sin dato" : Number(relation.beta).toFixed(2), data.benchmark?.symbol || "Benchmark"],
    ["Tracking error", formatPlainPercent(relation.tracking_error_percent), "Volatilidad del retorno activo"],
    ["Information ratio", relation.information_ratio == null ? "Sin dato" : Number(relation.information_ratio).toFixed(2), "Exceso por unidad de tracking error"],
    ["Captura alcista", formatPlainPercent(relation.up_capture_percent), "Días positivos del benchmark"],
    ["Captura bajista", formatPlainPercent(relation.down_capture_percent), "Días negativos del benchmark"],
  ];
  qs("#advancedRiskMetrics").innerHTML = metrics.map(([label, value, detail]) => analyticsMetricCard(label, value, detail, null)).join("");
  qs("#advancedRiskStatus").textContent = `${advanced.observations || 0} retornos`;

  const summary = data.risk_summary || {};
  qs("#riskSummaryScore").textContent = `${Number(summary.score || 0).toFixed(0)}/100`;
  qs("#riskSummaryScore").className = `risk-level-${summary.level || "low"}`;
  const flags = summary.flags || [];
  qs("#riskSummaryFlags").innerHTML = flags.length ? flags.map((flag) => `
    <div class="risk-flag risk-${escapeHTML(flag.level)}">
      <div><strong>${escapeHTML(flag.title)}</strong><span>${escapeHTML(flag.detail)}</span></div>
      <small>${escapeHTML(flag.level)}</small>
    </div>`).join("") : `<div class="empty-state compact-empty">No se detectaron alertas relevantes con los datos disponibles.</div>`;

  const covariance = data.covariance_risk || {};
  const symbols = covariance.symbols || [];
  qs("#correlationStatus").textContent = symbols.length ? `${symbols.length} activos · correlación media ${covariance.average_correlation == null ? "—" : Number(covariance.average_correlation).toFixed(2)}` : "Sin matriz";
  qs("#correlationHead").innerHTML = symbols.length ? `<tr><th>Activo</th>${symbols.map((symbol) => `<th>${escapeHTML(symbol)}</th>`).join("")}</tr>` : "";
  qs("#correlationBody").innerHTML = symbols.length ? (covariance.correlation_matrix || []).map((row) => `<tr><th>${escapeHTML(row.symbol)}</th>${symbols.map((symbol) => {
    const value = Number(row.values?.[symbol] || 0);
    const intensity = Math.min(Math.abs(value), 1);
    return `<td><span class="correlation-cell ${value < 0 ? "negative-correlation" : "positive-correlation"}" style="--corr:${intensity}">${value.toFixed(2)}</span></td>`;
  }).join("")}</tr>`).join("") : `<tr><td><div class="empty-state compact-empty">Se necesitan al menos dos activos con histórico comparable.</div></td></tr>`;
  qs("#riskContributionBody").innerHTML = (covariance.risk_contributions || []).length ? covariance.risk_contributions.map((item) => `<tr>
      <td><strong>${escapeHTML(item.symbol)}</strong></td>
      <td>${escapeHTML(formatPlainPercent(item.weight_percent))}</td>
      <td>${escapeHTML(formatPlainPercent(item.asset_volatility_percent))}</td>
      <td>${escapeHTML(formatPlainPercent(item.risk_contribution_percent))}</td>
    </tr>`).join("") : `<tr><td colspan="4"><div class="empty-state compact-empty">Sin contribuciones calculables.</div></td></tr>`;
}

function drawAssetComparator(data) {
  const svg = qs("#assetComparatorChart");
  if (!svg) return;
  const points = data?.points || [];
  const symbols = (data?.assets || []).map((item) => item.symbol);
  if (!points.length || !symbols.length) {
    svg.innerHTML = `<text class="chart-empty" x="400" y="150" text-anchor="middle">Ingresá activos para comparar</text>`;
    return;
  }
  const width = 800;
  const height = 300;
  const padding = 28;
  const values = points.flatMap((point) => symbols.map((symbol) => Number(point.values?.[symbol]))).filter(Number.isFinite);
  const minRaw = Math.min(...values);
  const maxRaw = Math.max(...values);
  const spread = maxRaw - minRaw || 1;
  const min = minRaw - spread * .1;
  const max = maxRaw + spread * .1;
  const xStep = points.length > 1 ? (width - padding * 2) / (points.length - 1) : 0;
  const y = (value) => height - padding - ((value - min) / (max - min)) * (height - padding * 2);
  const classes = ["compare-line-1", "compare-line-2", "compare-line-3", "compare-line-4", "compare-line-5", "compare-line-6"];
  const lines = symbols.map((symbol, symbolIndex) => {
    const coordinates = points.map((point, index) => Number.isFinite(Number(point.values?.[symbol])) ? `${padding + index * xStep},${y(Number(point.values[symbol]))}` : null).filter(Boolean).join(" ");
    return `<polyline class="analytics-line comparator-line ${classes[symbolIndex]}" points="${coordinates}"><title>${escapeHTML(symbol)}</title></polyline>`;
  }).join("");
  const step = Math.max(1, Math.ceil(points.length / 45));
  const dots = points.map((point, index) => {
    if (index % step !== 0 && index !== points.length - 1) return "";
    return symbols.map((symbol, symbolIndex) => {
      const value = Number(point.values?.[symbol]);
      if (!Number.isFinite(value)) return "";
      return `<circle class="analytics-hover-point ${classes[symbolIndex]}" cx="${padding + index * xStep}" cy="${y(value)}" r="5"><title>${escapeHTML(point.date)} · ${escapeHTML(symbol)} ${value.toFixed(2)}</title></circle>`;
    }).join("");
  }).join("");
  svg.innerHTML = `${[60,120,180,240].map((gridY) => `<line class="chart-grid" x1="0" y1="${gridY}" x2="800" y2="${gridY}"></line>`).join("")}<line class="analytics-base-line" x1="0" y1="${y(100)}" x2="800" y2="${y(100)}"></line>${lines}${dots}`;
}

function renderAssetComparator(data) {
  currentComparatorData = data;
  qs("#assetComparatorStatus").textContent = `${data.assets?.length || 0} activos`;
  drawAssetComparator(data);
  qs("#assetComparatorBody").innerHTML = (data.assets || []).map((item) => `<tr>
      <td><strong>${escapeHTML(item.symbol)}</strong><small>${escapeHTML(item.currency || "")}</small></td>
      <td class="${Number(item.return_percent || 0) >= 0 ? "positive" : "negative"}">${escapeHTML(formatPercent(item.return_percent))}</td>
      <td>${escapeHTML(formatPlainPercent(item.annualized_volatility_percent))}</td>
      <td class="negative">${escapeHTML(formatPercent(item.max_drawdown_percent))}</td>
      <td>${item.sortino_ratio == null ? "—" : Number(item.sortino_ratio).toFixed(2)}</td>
      <td>${escapeHTML(formatPlainPercent(item.var_95_percent))}</td>
    </tr>`).join("");
  qs("#assetComparatorMessage").textContent = [data.methodology, ...(data.errors || [])].filter(Boolean).join(" · ");
}

async function loadAssetComparator() {
  const raw = String(qs("#assetComparatorSymbols")?.value || "");
  const symbols = raw.split(",").map((item) => item.trim().toUpperCase()).filter(Boolean);
  if (symbols.length < 2 || symbols.length > 6) {
    qs("#assetComparatorMessage").textContent = "Ingresá entre dos y seis símbolos separados por coma.";
    return;
  }
  qs("#assetComparatorMessage").textContent = "Descargando históricos comparables…";
  try {
    const period = qs("#analyticsPeriod").value;
    const data = await apiRequest(`/api/analytics/compare?period=${encodeURIComponent(period)}&symbols=${encodeURIComponent(symbols.join(","))}`);
    renderAssetComparator(data);
  } catch (error) {
    qs("#assetComparatorMessage").textContent = error.message;
  }
}

function renderAnalytics(data) {
  currentAnalyticsData = data;
  const performance = data.performance || {};
  const periods = performance.period_returns || {};
  const benchmark = data.benchmark || {};
  const risk = data.risk || {};
  const excess = Number(benchmark.excess_return_percent);
  const sinceInception = Number(periods.since_inception_percent || 0);
  const selectedPeriod = Number(periods.selected_period_percent || 0);
  const metrics = [
    ["Último día", formatPercent(periods.daily_percent), "Retorno TWR diario", Number(periods.daily_percent || 0) >= 0],
    ["Mes actual", formatPercent(periods.month_to_date_percent), "Desde el primer día del mes", Number(periods.month_to_date_percent || 0) >= 0],
    ["Año actual", formatPercent(periods.year_to_date_percent), "Desde el 1 de enero", Number(periods.year_to_date_percent || 0) >= 0],
    ["Período elegido", formatPercent(periods.selected_period_percent), qs("#analyticsPeriod")?.selectedOptions?.[0]?.textContent || data.period, selectedPeriod >= 0],
    ["Desde el inicio", formatPercent(periods.since_inception_percent), performance.lifetime_start_date || "Historial disponible", sinceInception >= 0],
    ["Volatilidad", formatPlainPercent(risk.annualized_volatility_percent), "Anualizada · 252 ruedas", null],
    ["Sharpe educativo", risk.sharpe_ratio === null || risk.sharpe_ratio === undefined ? "Sin dato" : Number(risk.sharpe_ratio).toFixed(2), `Tasa libre ${Number(risk.risk_free_rate_percent || 0).toFixed(2)}%`, null],
    ["Sortino", risk.sortino_ratio === null || risk.sortino_ratio === undefined ? "Sin dato" : Number(risk.sortino_ratio).toFixed(2), "Riesgo bajista", null],
    ["VaR 95 diario", formatPlainPercent(risk.var_95_percent), "Histórico", null],
    ["Drawdown máximo", formatPercent(risk.max_drawdown_percent), "Caída desde máximo TWR", Number(risk.max_drawdown_percent || 0) >= 0],
    ["Exceso vs benchmark", Number.isFinite(excess) ? formatPercent(excess) : "Sin benchmark", benchmark.symbol || "No configurado", Number.isFinite(excess) ? excess >= 0 : null],
  ];
  qs("#analyticsMetricGrid").innerHTML = metrics
    .map(([label, value, detail, positive]) => analyticsMetricCard(label, value, detail, positive))
    .join("");

  drawAnalyticsComparisonChart(qs("#analyticsComparisonChart"), benchmark.points || [], performance.series || []);
  drawAnalyticsDrawdown(qs("#analyticsDrawdownChart"), performance.series || []);
  renderAdvancedRisk(data);
  qs("#analyticsBenchmarkLabel").textContent = benchmark.enabled
    ? `${data.settings?.benchmark_name || benchmark.name || benchmark.symbol} · índice base 100${benchmark.currency ? ` · ${benchmark.currency}` : ""}`
    : "Benchmark desactivado; se muestra solamente el portafolio.";
  qs("#analyticsExcessReturn").textContent = Number.isFinite(excess) ? `Diferencia ${formatPercent(excess)}` : "Sin comparación";
  qs("#analyticsExcessReturn").className = Number.isFinite(excess) ? (excess >= 0 ? "positive" : "negative") : "";
  qs("#analyticsDrawdownLabel").textContent = `Máximo ${formatPercent(risk.max_drawdown_percent)}`;

  const decompositionLabels = {
    open_asset_price_pnl: "Precio · posiciones abiertas",
    open_asset_fx_pnl: "FX · posiciones abiertas",
    realized_trading_pnl_combined: "Realizado · precio/FX combinado",
    dividends_gross: "Dividendos brutos",
    dividend_withholding: "Retenciones de dividendos",
    dividends: "Dividendos netos",
    interest: "Intereses",
    cash_and_realized_fx_pnl: "Divisas y efectivo",
    taxes_and_fees: "Otros impuestos y comisiones",
    total_investment_profit: "Resultado total",
  };
  qs("#analyticsDecomposition").innerHTML = Object.entries(decompositionLabels).map(([key, label]) => {
    const value = Number(data.decomposition?.[key] || 0);
    return `<div class="analytics-breakdown-row"><span>${escapeHTML(label)}</span><strong class="${value >= 0 ? "positive" : "negative"}">${escapeHTML(formatPrice(value, data.currency))}</strong></div>`;
  }).join("") + `<p class="data-source">${escapeHTML(data.decomposition?.note || "")}</p>`;

  qs("#analyticsDiversification").textContent = `Diversificación ${Number(data.concentration?.diversification_score || 0).toFixed(1)}/100`;
  renderAnalyticsConcentration(activeConcentrationMode);

  const positions = data.positions || [];
  qs("#analyticsPositionStatus").textContent = `${positions.length} posiciones`;
  qs("#analyticsPositions").innerHTML = positions.length ? positions.map((item) => {
    const total = Number(item.total_pnl || 0);
    return `
      <tr>
        <td><strong>${escapeHTML(item.symbol)}</strong><small>${escapeHTML(item.name || "")}</small></td>
        <td>${escapeHTML(formatPrice(item.market_value, data.currency))}</td>
        <td class="${Number(item.realized_pnl || 0) >= 0 ? "positive" : "negative"}">${escapeHTML(formatPrice(item.realized_pnl, data.currency))}</td>
        <td class="${Number(item.price_effect || 0) >= 0 ? "positive" : "negative"}">${escapeHTML(formatPrice(item.price_effect, data.currency))}</td>
        <td class="${Number(item.fx_effect || 0) >= 0 ? "positive" : "negative"}">${escapeHTML(formatPrice(item.fx_effect, data.currency))}</td>
        <td>${escapeHTML(formatPrice(item.dividends, data.currency))}</td>
        <td class="${total >= 0 ? "positive" : "negative"}">${escapeHTML(formatPrice(total, data.currency))}</td>
        <td>${item.total_return_percent === null ? "—" : escapeHTML(formatPercent(item.total_return_percent))}</td>
      </tr>`;
  }).join("") : `<tr><td colspan="8"><div class="empty-state compact-empty">Cargá una posición para ver su rendimiento.</div></td></tr>`;

  qs("#analyticsDisclaimer").textContent = data.disclaimer || "Métricas educativas; no constituyen asesoramiento financiero.";
  const statusParts = [];
  if (data.is_partial) statusParts.push("Análisis parcial");
  if (data.errors?.length) statusParts.push(data.errors.join(" · "));
  statusParts.push(`Actualizado ${formatDate(data.last_updated)}`);
  qs("#analyticsMessage").textContent = statusParts.join(" · ");
}

async function loadAnalytics(options = {}) {
  const message = qs("#analyticsMessage");
  if (!message) return;
  message.textContent = "Reconstruyendo la curva TWR y calculando métricas…";
  try {
    if (options.reloadSettings !== false || !analyticsLoaded) {
      const settings = await apiRequest("/api/analytics/settings");
      syncAnalyticsSettingsForm(settings);
    }
    const period = qs("#analyticsPeriod").value;
    const data = await apiRequest(`/api/analytics/overview?period=${encodeURIComponent(period)}`);
    renderAnalytics(data);
    await loadDividendAnalytics();
    if (!currentComparatorData) await loadAssetComparator();
    analyticsLoaded = true;
  } catch (error) {
    analyticsLoaded = false;
    message.textContent = error.message;
    qs("#analyticsMetricGrid").innerHTML = `<div class="empty-state">${escapeHTML(error.message)}</div>`;
  }
}

function setupAnalytics() {
  const preset = qs("#benchmarkPreset");
  const symbolInput = qs("#benchmarkSymbol");
  if (!preset || !symbolInput) return;

  preset.addEventListener("change", () => {
    const [symbol] = preset.value.split("|");
    if (symbol === "CUSTOM") {
      symbolInput.disabled = false;
      symbolInput.focus();
      return;
    }
    if (symbol === "NONE") {
      symbolInput.value = "";
      symbolInput.disabled = true;
      return;
    }
    symbolInput.disabled = false;
    symbolInput.value = symbol;
  });

  qs("#analyticsSettingsForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const message = qs("#analyticsMessage");
    const [presetSymbol, presetName] = preset.value.split("|");
    const symbol = presetSymbol === "NONE"
      ? "NONE"
      : String(symbolInput.value || presetSymbol).trim().toUpperCase();
    const name = presetSymbol === "CUSTOM" ? symbol : presetName;
    if (!symbol) {
      message.textContent = "Ingresá un símbolo de benchmark o seleccioná Sin benchmark.";
      return;
    }
    message.textContent = "Guardando benchmark y recalculando…";
    try {
      await apiRequest("/api/analytics/settings", {
        method: "PUT",
        body: JSON.stringify({
          benchmark_symbol: symbol,
          benchmark_name: name,
          risk_free_rate_percent: Number(qs("#analyticsRiskFreeRate").value || 0),
        }),
      });
      analyticsLoaded = false;
      await loadAnalytics();
      showToast("Configuración de analytics guardada");
    } catch (error) {
      message.textContent = error.message;
    }
  });

  qs("#analyticsPeriod").addEventListener("change", async () => {
    analyticsLoaded = false;
    currentComparatorData = null;
    await loadAnalytics({ reloadSettings: false });
  });
  qs("#refreshAnalytics").addEventListener("click", async () => {
    analyticsLoaded = false;
    await loadAnalytics({ reloadSettings: false });
  });
  qs("#exportAnalyticsCsv").addEventListener("click", () => {
    const period = qs("#analyticsPeriod").value;
    triggerDownload(`/api/analytics/export.csv?portfolio_id=${encodeURIComponent(activePortfolioId)}&period=${encodeURIComponent(period)}`, `quantlab_analytics_${activePortfolioId}_${period}.csv`);
  });
  qs("#analyticsChartZoom").addEventListener("input", (event) => {
    analyticsZoomPercent = Number(event.target.value || 100);
    if (currentAnalyticsData) {
      drawAnalyticsComparisonChart(qs("#analyticsComparisonChart"), currentAnalyticsData.benchmark?.points || [], currentAnalyticsData.performance?.series || []);
      drawAnalyticsDrawdown(qs("#analyticsDrawdownChart"), currentAnalyticsData.performance?.series || []);
    }
  });
  qs("#assetComparatorForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    await loadAssetComparator();
  });
  qsa(".analytics-tab").forEach((tab) => {
    tab.addEventListener("click", () => renderAnalyticsConcentration(tab.dataset.concentration));
  });
  qs("#dividendSettingsForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    try {
      await apiRequest("/api/portfolio/dividends/settings", {
        method: "PUT",
        body: JSON.stringify({
          default_withholding_percent: Number(qs("#dividendDefaultWithholding").value || 0),
          default_reinvest: qs("#dividendDefaultReinvest").checked,
          forecast_months: Number(qs("#dividendForecastMonths").value || 12),
        }),
      });
      await loadDividendAnalytics();
      await loadDividendFormSettings();
      showToast("Preferencias de dividendos guardadas");
    } catch (error) {
      qs("#analyticsDividendDisclaimer").textContent = error.message;
    }
  });
}

function indicatorCard(label, value, detail = "") {
  return `<div class="indicator-card"><small>${escapeHTML(label)}</small><strong>${escapeHTML(value)}</strong>${detail ? `<span>${escapeHTML(detail)}</span>` : ""}</div>`;
}

function agentSourceRefs(sourceIds = []) {
  const valid = sourceIds.filter(Boolean);
  return valid.length ? valid.map((sourceId) => `<span class="agent-source-ref">[${escapeHTML(sourceId)}]</span>`).join("") : "";
}

function renderAgentResponse(response, historyMessages = []) {
  const result = qs("#aiResult");
  if (!response) {
    result.className = "result-panel muted-panel";
    result.textContent = "No hay una respuesta disponible para esta conversación.";
    return;
  }
  const sections = (response.sections || []).filter((section) => (section.items || []).length);
  const sectionHTML = sections.map((section) => `
    <section class="agent-section">
      <h4>${escapeHTML(section.title)}</h4>
      <ul>${section.items.map((item) => `<li>${escapeHTML(item.text)}${agentSourceRefs(item.source_ids)}</li>`).join("")}</ul>
    </section>`).join("");
  const sourcesHTML = (response.sources || []).map((source) => `
    <div class="agent-source-card">
      <strong>${escapeHTML(source.id)} · ${escapeHTML(source.tool)}</strong>
      <small>${escapeHTML(source.source || "Cálculo interno")}</small>
      <small>${escapeHTML(formatDate(source.observed_at))} · ${source.is_partial ? "parcial" : source.is_delayed ? "demorado" : source.status}</small>
      ${(source.errors || []).length ? `<small class="negative">${escapeHTML(source.errors.join(" · "))}</small>` : ""}
    </div>`).join("");
  const toolsHTML = (response.tools_used || []).map((tool) => `
    <div><strong>${escapeHTML(tool.name)}</strong> · ${escapeHTML(tool.status)} · ${Number(tool.duration_ms || 0).toFixed(1)} ms${tool.error ? ` · ${escapeHTML(tool.error)}` : ""}</div>`).join("");
  const historyHTML = historyMessages.length ? `
    <details class="agent-trace"><summary>Mensajes de esta conversación (${historyMessages.length})</summary>
      <div class="agent-message-history">${historyMessages.map((message) => `<div class="agent-message-bubble ${escapeHTML(message.role)}"><strong>${message.role === "user" ? "Consulta" : "QuantLab AI"}</strong><br>${escapeHTML(message.content)}</div>`).join("")}</div>
    </details>` : "";
  const naturalAnswer = response.language_model?.used
    ? `<div class="agent-natural-answer"><h4>Resumen redactado con evidencia verificada</h4><div>${escapeHTML(response.answer || "").replace(/\n/g, "<br>")}</div><p class="agent-mode-note">El modelo sólo reescribió los datos calculados por QuantLab; las secciones siguientes son la evidencia determinística.</p></div>`
    : response.language_model?.fallback
      ? `<div class="data-notice">El proveedor de lenguaje no estuvo disponible. Se utilizó la respuesta determinística: ${escapeHTML(response.language_model.error || "fallback seguro")}</div>`
      : "";
  result.className = "result-panel";
  result.innerHTML = `
    <div class="agent-response-header">
      <div><p class="eyebrow">${escapeHTML(response.intent || "ANÁLISIS")}</p><h3>Respuesta basada en herramientas internas</h3><p>${escapeHTML(response.question || "")}</p></div>
      <span class="agent-quality ${escapeHTML(response.data_quality || "partial")}">${escapeHTML(response.data_quality || "partial")}</span>
    </div>
    ${naturalAnswer}
    ${sectionHTML}
    <details class="agent-trace"><summary>Fuentes y herramientas utilizadas</summary>
      <div class="agent-source-grid">${sourcesHTML || '<div class="empty-state">No se utilizaron fuentes externas.</div>'}</div>
      <div class="agent-tool-list">${toolsHTML}</div>
    </details>
    ${historyHTML}
    <p class="disclaimer">${escapeHTML(response.disclaimer || "Contenido educativo.")}</p>`;
}

function renderAISessions(sessions) {
  const container = qs("#aiSessionList");
  if (!sessions.length) {
    container.innerHTML = '<div class="empty-state">Todavía no hay conversaciones para este portafolio.</div>';
    return;
  }
  container.innerHTML = sessions.map((session) => `
    <div class="agent-session-actions">
      <button class="agent-session ${Number(session.id) === Number(aiSessionId) ? "active" : ""}" type="button" data-ai-session="${session.id}">
        <strong>${escapeHTML(session.title)}</strong>
        <small>${escapeHTML(formatDate(session.updated_at))} · ${session.messages_count} mensajes</small>
      </button>
      <button class="agent-session-delete" type="button" data-ai-session-delete="${session.id}" aria-label="Archivar conversación">✕</button>
    </div>`).join("");
  qsa("[data-ai-session]", container).forEach((button) => button.addEventListener("click", () => loadAISession(Number(button.dataset.aiSession))));
  qsa("[data-ai-session-delete]", container).forEach((button) => button.addEventListener("click", async () => {
    const sessionId = Number(button.dataset.aiSessionDelete);
    if (!window.confirm("¿Archivar esta conversación AI?")) return;
    await apiRequest(`/api/ai/agent/sessions/${sessionId}?portfolio_id=${encodeURIComponent(activePortfolioId)}`, { method: "DELETE" });
    if (Number(aiSessionId) === sessionId) startNewAISession();
    await loadAISessions(true);
  }));
}

async function loadAISessions(force = false) {
  if (aiHistoryLoaded && !force) return;
  const container = qs("#aiSessionList");
  if (!container) return;
  try {
    const sessions = await apiRequest(`/api/ai/agent/sessions?portfolio_id=${encodeURIComponent(activePortfolioId)}&limit=30`);
    renderAISessions(sessions);
    aiHistoryLoaded = true;
  } catch (error) {
    container.innerHTML = `<div class="empty-state">${escapeHTML(error.message)}</div>`;
  }
}

async function loadAISession(sessionId) {
  try {
    const session = await apiRequest(`/api/ai/agent/sessions/${sessionId}?portfolio_id=${encodeURIComponent(activePortfolioId)}`);
    aiSessionId = sessionId;
    const assistantMessages = (session.messages || []).filter((message) => message.role === "assistant" && message.payload);
    const lastResponse = assistantMessages.at(-1)?.payload;
    renderAgentResponse(lastResponse, session.messages || []);
    aiHistoryLoaded = false;
    await loadAISessions(true);
  } catch (error) {
    showToast("No se pudo abrir la conversación", "error", error.message);
  }
}

function startNewAISession() {
  aiSessionId = null;
  qs("#aiQuestion").value = "";
  qs("#aiSymbols").value = "";
  const result = qs("#aiResult");
  result.className = "result-panel muted-panel";
  result.textContent = "Nueva conversación. Escribí una consulta sobre un activo, una comparación o el portafolio activo.";
  qsa(".agent-session").forEach((item) => item.classList.remove("active"));
}

async function loadAISettings(force = false) {
  if (aiSettingsLoaded && !force) return;
  const status = qs("#aiProviderStatus");
  try {
    const [settings, capabilities] = await Promise.all([
      apiRequest(`/api/ai/agent/settings?portfolio_id=${encodeURIComponent(activePortfolioId)}`),
      apiRequest("/api/ai/agent/capabilities"),
    ]);
    qs("#aiUseLanguageModel").checked = Boolean(settings.use_language_model);
    qs("#aiResponseStyle").value = settings.response_style || "claro";
    const provider = capabilities.language_model || {};
    status.textContent = provider.configured
      ? `Proveedor opcional detectado: ${provider.provider}. Permanece desactivado por defecto; el motor local es la respuesta principal.`
      : "Modo determinístico activo. La integración de lenguaje externo queda reservada para una etapa posterior.";
    aiSettingsLoaded = true;
  } catch (error) {
    status.textContent = error.message;
  }
}

async function saveAISettings() {
  try {
    await apiRequest(`/api/ai/agent/settings?portfolio_id=${encodeURIComponent(activePortfolioId)}`, {
      method: "PUT",
      body: JSON.stringify({
        use_language_model: qs("#aiUseLanguageModel").checked,
        response_style: qs("#aiResponseStyle").value,
      }),
    });
    aiSettingsLoaded = false;
    await loadAISettings(true);
    showToast("Modo del agente guardado");
  } catch (error) {
    showToast("No se pudo guardar el modo AI", "error", error.message);
  }
}


const ALERT_TYPE_LABELS = {
  CONCENTRATION: "Concentración",
  DRAWDOWN: "Drawdown",
  VOLATILITY: "Volatilidad",
  PRICE_ABOVE: "Precio por encima",
  PRICE_BELOW: "Precio por debajo",
};

function alertRulePayloadFromRow(row) {
  return {
    name: row.querySelector('[data-alert-field="name"]').value,
    rule_type: row.querySelector('[data-alert-field="type"]').value,
    symbol: row.querySelector('[data-alert-field="symbol"]').value.trim().toUpperCase(),
    threshold: Number(row.querySelector('[data-alert-field="threshold"]').value),
    severity: row.querySelector('[data-alert-field="severity"]').value,
    cooldown_hours: Number(row.querySelector('[data-alert-field="cooldown"]').value),
    is_enabled: row.querySelector('[data-alert-field="enabled"]').checked,
  };
}

function renderAlertRules(rules) {
  const body = qs("#alertRulesBody");
  if (!body) return;
  if (!rules.length) {
    body.innerHTML = '<tr><td colspan="5" class="empty-cell">No hay reglas configuradas.</td></tr>';
    return;
  }
  body.innerHTML = rules.map((rule) => `
    <tr data-alert-rule-row="${rule.id}" class="${rule.is_enabled ? "" : "alert-rule-disabled"}">
      <td><input data-alert-field="name" value="${escapeHTML(rule.name)}" maxlength="120"><small>${escapeHTML(ALERT_TYPE_LABELS[rule.rule_type] || rule.rule_type)}</small><input data-alert-field="type" type="hidden" value="${escapeHTML(rule.rule_type)}"><input data-alert-field="symbol" type="hidden" value="${escapeHTML(rule.symbol || "")}"></td>
      <td><input data-alert-field="threshold" type="number" min="0.000001" step="any" value="${Number(rule.threshold)}"><small>${escapeHTML(rule.symbol || "%")}</small></td>
      <td><select data-alert-field="severity"><option value="LOW" ${rule.severity === "LOW" ? "selected" : ""}>Baja</option><option value="MEDIUM" ${rule.severity === "MEDIUM" ? "selected" : ""}>Media</option><option value="HIGH" ${rule.severity === "HIGH" ? "selected" : ""}>Alta</option><option value="CRITICAL" ${rule.severity === "CRITICAL" ? "selected" : ""}>Crítica</option></select><input data-alert-field="cooldown" type="hidden" value="${Number(rule.cooldown_hours || 24)}"></td>
      <td><label class="compact-check"><input data-alert-field="enabled" type="checkbox" ${rule.is_enabled ? "checked" : ""}> Activa</label><small>${rule.last_evaluated_at ? escapeHTML(formatDate(rule.last_evaluated_at)) : "Sin evaluar"}</small></td>
      <td><div class="alert-inline-actions"><button class="secondary-button" type="button" data-save-alert-rule="${rule.id}">Guardar</button><button class="secondary-button" type="button" data-disable-alert-rule="${rule.id}">Desactivar</button></div></td>
    </tr>`).join("");
  qsa("[data-save-alert-rule]", body).forEach((button) => button.addEventListener("click", async () => {
    const row = button.closest("tr");
    try {
      await apiRequest(`/api/ai/alerts/rules/${button.dataset.saveAlertRule}?portfolio_id=${encodeURIComponent(activePortfolioId)}`, { method: "PUT", body: JSON.stringify(alertRulePayloadFromRow(row)) });
      showToast("Regla de alerta actualizada");
      await loadAIAlerts(true);
    } catch (error) { showToast("No se pudo actualizar la regla", "error", error.message); }
  }));
  qsa("[data-disable-alert-rule]", body).forEach((button) => button.addEventListener("click", async () => {
    try {
      await apiRequest(`/api/ai/alerts/rules/${button.dataset.disableAlertRule}?portfolio_id=${encodeURIComponent(activePortfolioId)}`, { method: "DELETE" });
      showToast("Regla desactivada");
      await loadAIAlerts(true);
    } catch (error) { showToast("No se pudo desactivar la regla", "error", error.message); }
  }));
}

function renderAlertEvents(events) {
  const container = qs("#alertEventsList");
  if (!container) return;
  if (!events.length) {
    container.innerHTML = '<div class="empty-state">No hay alertas abiertas para este portafolio.</div>';
    return;
  }
  container.innerHTML = events.map((event) => `
    <article class="alert-event-card ${escapeHTML(String(event.severity || "low").toLowerCase())}">
      <div class="alert-event-header"><div><h4>${escapeHTML(event.title)}</h4><span class="alert-status">${escapeHTML(event.status)}</span></div><span class="alert-severity ${escapeHTML(String(event.severity || "low").toLowerCase())}">${escapeHTML(event.severity)}</span></div>
      <p>${escapeHTML(event.message)}</p>
      <div class="alert-event-meta"><span>Detectada ${escapeHTML(formatDate(event.triggered_at))}</span><span>Última revisión ${escapeHTML(formatDate(event.last_seen_at))}</span>${event.user_note ? `<span>Nota: ${escapeHTML(event.user_note)}</span>` : ""}</div>
      <div class="alert-event-actions">
        ${event.status !== "ACKNOWLEDGED" ? `<button class="secondary-button compact-button" type="button" data-alert-event-action="ACKNOWLEDGED" data-alert-event-id="${event.id}">Atendida</button>` : ""}
        ${event.status !== "DISMISSED" ? `<button class="secondary-button compact-button" type="button" data-alert-event-action="DISMISSED" data-alert-event-id="${event.id}">Descartar</button>` : ""}
        ${event.status !== "ACTIVE" ? `<button class="secondary-button compact-button" type="button" data-alert-event-action="ACTIVE" data-alert-event-id="${event.id}">Reactivar</button>` : ""}
      </div>
    </article>`).join("");
  qsa("[data-alert-event-action]", container).forEach((button) => button.addEventListener("click", async () => {
    const note = window.prompt("Nota opcional para esta alerta:", "") || "";
    try {
      await apiRequest(`/api/ai/alerts/events/${button.dataset.alertEventId}?portfolio_id=${encodeURIComponent(activePortfolioId)}`, { method: "PUT", body: JSON.stringify({ status: button.dataset.alertEventAction, note }) });
      await loadAIAlerts(true);
    } catch (error) { showToast("No se pudo actualizar la alerta", "error", error.message); }
  }));
}

async function loadAIAlerts(force = false) {
  if (aiAlertsLoaded && !force) return;
  try {
    const [rules, events, readiness] = await Promise.all([
      apiRequest(`/api/ai/alerts/rules?portfolio_id=${encodeURIComponent(activePortfolioId)}`),
      apiRequest(`/api/ai/alerts/events?portfolio_id=${encodeURIComponent(activePortfolioId)}&status=OPEN&limit=100`),
      apiRequest(`/api/ai/alerts/readiness?portfolio_id=${encodeURIComponent(activePortfolioId)}`),
    ]);
    renderAlertRules(rules);
    renderAlertEvents(events);
    qs("#notificationReadiness").textContent = `${readiness.note} Eventos pendientes para interfaz: ${readiness.pending_in_app_events}.`;
    aiAlertsLoaded = true;
  } catch (error) {
    qs("#alertEvaluationStatus").textContent = error.message;
  }
}

async function evaluateAIAlerts() {
  const status = qs("#alertEvaluationStatus");
  status.textContent = "Evaluando reglas con los datos disponibles…";
  try {
    const result = await apiRequest(`/api/ai/alerts/evaluate?portfolio_id=${encodeURIComponent(activePortfolioId)}&period=${encodeURIComponent(qs("#aiPeriod").value)}`, { method: "POST" });
    status.textContent = `${result.evaluated_rules} reglas evaluadas · ${result.new_events} alertas nuevas · ${result.resolved_events} resueltas${result.is_partial ? " · datos parciales" : ""}.`;
    aiAlertsLoaded = false;
    await loadAIAlerts(true);
  } catch (error) { status.textContent = error.message; }
}

function renderChangeMemory(groups) {
  const container = qs("#changeMemoryList");
  if (!container) return;
  if (!groups.length) {
    container.innerHTML = '<div class="empty-state">Todavía no hay dos análisis comparables con cambios materiales.</div>';
    return;
  }
  container.innerHTML = groups.map((group) => `
    <article class="change-group"><h4>${escapeHTML(group.symbol || group.snapshot_type)}</h4><small>${escapeHTML(formatDate(group.previous_at))} → ${escapeHTML(formatDate(group.current_at))}</small><ul>${(group.changes || []).map((change) => `<li>${escapeHTML(change.text)}</li>`).join("")}</ul></article>`).join("");
}

async function loadChangeMemory(force = false) {
  if (aiMemoryLoaded && !force) return;
  try {
    const groups = await apiRequest(`/api/ai/memory/changes?portfolio_id=${encodeURIComponent(activePortfolioId)}&limit=100`);
    renderChangeMemory(groups);
    aiMemoryLoaded = true;
  } catch (error) { qs("#changeMemoryList").innerHTML = `<div class="empty-state">${escapeHTML(error.message)}</div>`; }
}

function setupAIMonitor() {
  qs("#evaluateAlertsButton").addEventListener("click", evaluateAIAlerts);
  qs("#refreshMemoryButton").addEventListener("click", () => loadChangeMemory(true));
  qs("#alertRuleType").addEventListener("change", (event) => {
    const priceRule = ["PRICE_ABOVE", "PRICE_BELOW"].includes(event.target.value);
    qs("#alertRuleSymbol").disabled = !priceRule;
    if (!priceRule) qs("#alertRuleSymbol").value = "";
  });
  qs("#alertRuleForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const ruleType = qs("#alertRuleType").value;
    try {
      await apiRequest(`/api/ai/alerts/rules?portfolio_id=${encodeURIComponent(activePortfolioId)}`, { method: "POST", body: JSON.stringify({
        name: qs("#alertRuleName").value, rule_type: ruleType,
        symbol: ["PRICE_ABOVE", "PRICE_BELOW"].includes(ruleType) ? qs("#alertRuleSymbol").value.trim().toUpperCase() : "",
        threshold: Number(qs("#alertRuleThreshold").value), severity: qs("#alertRuleSeverity").value,
        cooldown_hours: Number(qs("#alertRuleCooldown").value), is_enabled: true,
      }) });
      showToast("Regla de alerta agregada");
      await loadAIAlerts(true);
    } catch (error) { showToast("No se pudo agregar la regla", "error", error.message); }
  });
}

function setupAI() {
  qs("#aiAgentForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const result = qs("#aiResult");
    result.className = "result-panel muted-panel";
    result.textContent = "Planificando herramientas, consultando datos y verificando fuentes…";
    const symbols = qs("#aiSymbols").value.split(",").map((item) => item.trim().toUpperCase()).filter(Boolean).slice(0, 6);
    const payload = {
      message: qs("#aiQuestion").value,
      portfolio_id: activePortfolioId,
      risk_profile: qs("#aiRisk").value,
      period: qs("#aiPeriod").value,
      scope: qs("#aiScope").value,
      symbols,
      session_id: aiSessionId,
      include_activity: qs("#aiIncludeActivity").checked,
      use_language_model: qs("#aiUseLanguageModel").checked,
    };
    try {
      const response = await apiRequest("/api/ai/agent/query", { method: "POST", body: JSON.stringify(payload) });
      aiSessionId = response.session_id;
      renderAgentResponse(response);
      aiHistoryLoaded = false;
      await loadAISessions(true);
      aiMemoryLoaded = false;
      await loadChangeMemory(true);
    } catch (error) {
      result.className = "result-panel muted-panel";
      result.textContent = error.message;
    }
  });
  qs("#aiNewSession").addEventListener("click", startNewAISession);
  qs("#aiRefreshHistory").addEventListener("click", () => loadAISessions(true));
  qs("#aiSaveSettings").addEventListener("click", saveAISettings);
  qsa("[data-ai-prompt]").forEach((button) => button.addEventListener("click", () => {
    qs("#aiQuestion").value = button.dataset.aiPrompt;
    if (button.dataset.aiPrompt.includes("AAPL")) qs("#aiSymbols").value = "AAPL, SPY, BTC-USD";
    qs("#aiQuestion").focus();
  }));
}

function applySettings(settings) {
  document.body.classList.toggle("high-contrast", settings.highContrast);
  document.body.classList.toggle("no-motion", !settings.motion);
  const systemLight = window.matchMedia?.("(prefers-color-scheme: light)").matches;
  const useLight = settings.theme === "light" || (settings.theme === "system" && systemLight);
  document.body.classList.toggle("theme-light", useLight);
  qs("#contrastToggle").checked = settings.highContrast;
  qs("#motionToggle").checked = settings.motion;
  qs("#themeSelect").value = settings.theme;
  qs("#currencySelect").value = settings.currency;
}

function setupSettings() {
  const defaults = { highContrast: false, motion: true, theme: "dark", currency: "USD" };
  let saved = defaults;
  try {
    saved = { ...defaults, ...JSON.parse(localStorage.getItem("quantlab.settings") || "{}") };
  } catch (_) {
    saved = defaults;
  }
  applySettings(saved);

  qs("#saveSettings").addEventListener("click", () => {
    const settings = {
      highContrast: qs("#contrastToggle").checked,
      motion: qs("#motionToggle").checked,
      theme: qs("#themeSelect").value,
      currency: qs("#currencySelect").value,
    };
    localStorage.setItem("quantlab.settings", JSON.stringify(settings));
    applySettings(settings);
    qs("#settingsMessage").textContent = "Preferencias guardadas en este navegador.";
  });
}

async function initialize() {
  setupMobileMenu();
  setupMarketSearch();
  setupManualPriceFallback();
  setupSymbolAlias();
  setupWatchlist();
  setupPortfolio();
  setupPortfolioCatalog();
  setupDataManagement();
  setupAnalytics();
  setupAI();
  setupAIMonitor();
  setupSettings();
  setupPortfolioFilters();
  setupSortableTables();
  await loadPortfolioCatalog();
  setupNavigation();
  await Promise.all([loadDashboard(), loadProviderStatus(), loadMarket(), loadWatchlist()]);
}

document.addEventListener("DOMContentLoaded", initialize);
