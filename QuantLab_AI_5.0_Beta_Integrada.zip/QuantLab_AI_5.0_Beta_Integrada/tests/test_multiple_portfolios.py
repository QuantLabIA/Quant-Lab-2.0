import pytest
from fastapi.testclient import TestClient

from backend.core.database import get_connection, initialize_database
from backend.main import app


@pytest.fixture(autouse=True)
def reset_multiple_portfolios() -> None:
    initialize_database()
    with get_connection() as connection:
        connection.execute("DELETE FROM portfolio_fx_conversions")
        connection.execute("DELETE FROM portfolio_transactions")
        connection.execute("DELETE FROM portfolio_cash_movements")
        connection.execute("DELETE FROM portfolio_assets")
        connection.execute("DELETE FROM portfolios WHERE id <> 1")
        connection.execute(
            """
            UPDATE portfolios
            SET name = 'Principal', base_currency = 'USD', initial_cash = 1000, allow_margin = 0,
                is_archived = 0, updated_at = CURRENT_TIMESTAMP
            WHERE id = 1
            """
        )


def _create_manual_position(client: TestClient, portfolio_id: int, symbol: str, price: float) -> None:
    asset = client.post(
        f"/api/portfolio/assets/manual?portfolio_id={portfolio_id}",
        json={
            "symbol": symbol,
            "name": f"Activo {symbol}",
            "asset_type": "OTHER",
            "currency": "USD",
            "exchange": "Manual",
            "current_price": price,
        },
    )
    assert asset.status_code == 201
    transaction = client.post(
        f"/api/portfolio/transactions?portfolio_id={portfolio_id}",
        json={
            "symbol": symbol,
            "transaction_type": "BUY",
            "pricing_mode": "MANUAL",
            "asset_name": f"Activo {symbol}",
            "asset_type": "OTHER",
            "asset_currency": "USD",
            "quantity": 1,
            "price": price,
            "fees": 0,
            "occurred_at": "2026-07-01T12:00:00Z",
        },
    )
    assert transaction.status_code == 201


def test_two_portfolios_keep_ledgers_isolated() -> None:
    with TestClient(app) as client:
        created = client.post(
            "/api/portfolios",
            json={"name": "Criptomonedas", "base_currency": "USD", "initial_cash": 500},
        )
        assert created.status_code == 201
        second_id = created.json()["id"]

        _create_manual_position(client, 1, "MANUAL-A", 100)
        _create_manual_position(client, second_id, "MANUAL-B", 200)

        first = client.get("/api/portfolio?portfolio_id=1").json()
        second = client.get(f"/api/portfolio?portfolio_id={second_id}").json()

    assert first["settings"]["name"] == "Principal"
    assert second["settings"]["name"] == "Criptomonedas"
    assert [holding["symbol"] for holding in first["holdings"]] == ["MANUAL-A"]
    assert [holding["symbol"] for holding in second["holdings"]] == ["MANUAL-B"]
    assert first["summary"]["cash_balance"] == pytest.approx(900)
    assert second["summary"]["cash_balance"] == pytest.approx(300)
    assert first["summary"]["transactions_count"] == 1
    assert second["summary"]["transactions_count"] == 1


def test_archiving_preserves_data_and_hides_portfolio() -> None:
    with TestClient(app) as client:
        created = client.post(
            "/api/portfolios",
            json={"name": "Trading", "base_currency": "USD", "initial_cash": 750},
        ).json()
        second_id = created["id"]
        _create_manual_position(client, second_id, "TRADE-01", 50)

        archived = client.delete(f"/api/portfolios/{second_id}")
        active = client.get("/api/portfolios").json()
        all_items = client.get("/api/portfolios?include_archived=true").json()
        blocked_overview = client.get(f"/api/portfolio?portfolio_id={second_id}")
        restored = client.post(f"/api/portfolios/{second_id}/restore")
        overview = client.get(f"/api/portfolio?portfolio_id={second_id}").json()

    assert archived.status_code == 200
    assert archived.json()["is_archived"] is True
    assert all(item["id"] != second_id for item in active)
    assert any(item["id"] == second_id and item["is_archived"] for item in all_items)
    assert blocked_overview.status_code == 422
    assert restored.status_code == 200
    assert overview["summary"]["transactions_count"] == 1


def test_cannot_archive_only_active_portfolio() -> None:
    with TestClient(app) as client:
        response = client.delete("/api/portfolios/1")

    assert response.status_code == 422
    assert "al menos un portafolio" in response.json()["detail"]
