import sqlite3
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from backend.api import portfolio as portfolio_api
from backend.core import database
from backend.core.database import get_connection, initialize_database
from backend.main import app


def fake_fx(source: str, target: str, occurred_at=None) -> dict:
    rates = {
        ("USD", "ARS"): 1000.0,
        ("ARS", "USD"): 0.001,
        ("USD", "EUR"): 0.9,
        ("EUR", "USD"): 1.1111111111,
    }
    return {
        "rate": 1.0 if source == target else rates[(source, target)],
        "from_currency": source,
        "to_currency": target,
    }


@pytest.fixture(autouse=True)
def reset_phase3(monkeypatch) -> None:
    initialize_database()
    monkeypatch.setattr(portfolio_api, "get_fx_rate", fake_fx)
    with get_connection() as connection:
        connection.execute("DELETE FROM portfolio_audit_log")
        connection.execute("DELETE FROM portfolio_fx_conversions")
        connection.execute("DELETE FROM portfolio_transactions")
        connection.execute("DELETE FROM portfolio_cash_movements")
        connection.execute("DELETE FROM portfolio_assets")
        connection.execute("DELETE FROM portfolios WHERE id <> 1")
        connection.execute(
            """
            UPDATE portfolios
            SET name = 'Principal', base_currency = 'USD', initial_cash = 1000,
                allow_margin = 0, is_archived = 0, updated_at = CURRENT_TIMESTAMP
            WHERE id = 1
            """
        )


def _manual_buy(client: TestClient, currency: str, amount: float) -> object:
    return client.post(
        "/api/portfolio/transactions",
        json={
            "symbol": f"MANUAL-{currency}",
            "transaction_type": "BUY",
            "pricing_mode": "MANUAL",
            "asset_name": f"Activo {currency}",
            "asset_type": "OTHER",
            "asset_currency": currency,
            "exchange": "Manual",
            "quantity": 1,
            "price": amount,
            "fees": 0,
            "occurred_at": "2026-07-02T12:00:00Z",
            "fx_rate_to_base": 1 if currency == "USD" else 0.001,
        },
    )


def test_conversion_creates_real_separate_cash_balances() -> None:
    with TestClient(app) as client:
        conversion = client.post(
            "/api/portfolio/fx-conversions",
            json={
                "from_currency": "USD",
                "to_currency": "ARS",
                "from_amount": 100,
                "pricing_mode": "MANUAL",
                "exchange_rate": 1000,
                "fee_amount": 0,
                "occurred_at": "2026-07-01T12:00:00Z",
                "from_fx_rate_to_base": 1,
                "to_fx_rate_to_base": 0.001,
            },
        )
        overview = client.get("/api/portfolio")

    assert conversion.status_code == 201
    balances = {item["currency"]: item for item in overview.json()["cash_balances"]}
    assert balances["USD"]["balance"] == pytest.approx(900)
    assert balances["ARS"]["balance"] == pytest.approx(100000)
    assert balances["ARS"]["base_value"] == pytest.approx(100)
    assert overview.json()["summary"]["cash_balance"] == pytest.approx(1000)
    assert overview.json()["summary"]["net_contributions"] == pytest.approx(0)


def test_purchase_requires_cash_in_the_asset_currency() -> None:
    with TestClient(app) as client:
        blocked = _manual_buy(client, "ARS", 5000)
        client.post(
            "/api/portfolio/fx-conversions",
            json={
                "from_currency": "USD", "to_currency": "ARS", "from_amount": 5,
                "pricing_mode": "MANUAL", "exchange_rate": 1000,
                "occurred_at": "2026-07-01T12:00:00Z",
                "from_fx_rate_to_base": 1, "to_fx_rate_to_base": 0.001,
            },
        )
        allowed = _manual_buy(client, "ARS", 5000)
        overview = client.get("/api/portfolio").json()

    assert blocked.status_code == 422
    assert "Efectivo insuficiente en ARS" in blocked.json()["detail"]
    assert allowed.status_code == 201
    balances = {item["currency"]: item["balance"] for item in overview["cash_balances"]}
    assert balances["USD"] == pytest.approx(995)
    assert balances["ARS"] == pytest.approx(0)


def test_conversion_fee_and_realized_fx_pnl_are_separate() -> None:
    with TestClient(app) as client:
        client.post(
            "/api/portfolio/fx-conversions",
            json={
                "from_currency": "USD", "to_currency": "ARS", "from_amount": 100,
                "pricing_mode": "MANUAL", "exchange_rate": 1000,
                "occurred_at": "2026-07-01T12:00:00Z",
                "from_fx_rate_to_base": 1, "to_fx_rate_to_base": 0.001,
            },
        )
        second = client.post(
            "/api/portfolio/fx-conversions",
            json={
                "from_currency": "ARS", "to_currency": "USD", "from_amount": 50000,
                "pricing_mode": "MANUAL", "exchange_rate": 0.0008,
                "fee_amount": 1, "fee_currency": "USD",
                "occurred_at": "2026-07-02T12:00:00Z",
                "from_fx_rate_to_base": 0.001, "to_fx_rate_to_base": 1,
            },
        )
        overview = client.get("/api/portfolio").json()

    assert second.status_code == 201
    assert second.json()["realized_fx_pnl_base"] == pytest.approx(-10)
    assert overview["summary"]["realized_fx_pnl"] == pytest.approx(-10)
    assert overview["summary"]["fx_fees"] == pytest.approx(1)
    balances = {item["currency"]: item["balance"] for item in overview["cash_balances"]}
    assert balances["USD"] == pytest.approx(939)
    assert balances["ARS"] == pytest.approx(50000)


def test_margin_is_disabled_by_default_and_explicit_when_enabled() -> None:
    with TestClient(app) as client:
        blocked = _manual_buy(client, "USD", 1200)
        settings = client.put(
            "/api/portfolio/settings",
            json={
                "name": "Principal", "base_currency": "USD", "initial_cash": 1000,
                "allow_margin": True,
            },
        )
        allowed = _manual_buy(client, "USD", 1200)
        overview = client.get("/api/portfolio").json()

    assert blocked.status_code == 422
    assert settings.status_code == 200
    assert settings.json()["allow_margin"] is True
    assert allowed.status_code == 201
    assert overview["summary"]["cash_balance"] == pytest.approx(-200)
    assert overview["summary"]["margin_used"] == pytest.approx(200)


def test_fx_preview_edit_soft_delete_restore_and_audit() -> None:
    payload = {
        "from_currency": "USD", "to_currency": "ARS", "from_amount": 100,
        "pricing_mode": "MANUAL", "exchange_rate": 1000,
        "fee_amount": 0, "occurred_at": "2026-07-01T12:00:00Z",
        "from_fx_rate_to_base": 1, "to_fx_rate_to_base": 0.001,
        "notes": "Primera conversión",
    }
    with TestClient(app) as client:
        preview = client.post("/api/portfolio/fx-conversions/preview", json=payload)
        created = client.post("/api/portfolio/fx-conversions", json=payload).json()
        update_payload = {
            **payload,
            "from_amount": 120,
            "reason": "Importe corregido",
        }
        update_preview = client.post(
            f"/api/portfolio/fx-conversions/{created['id']}/preview", json=update_payload
        )
        updated = client.put(
            f"/api/portfolio/fx-conversions/{created['id']}", json=update_payload
        )
        deleted = client.delete(
            f"/api/portfolio/fx-conversions/{created['id']}?reason=Duplicada"
        )
        active = client.get("/api/portfolio/fx-conversions").json()
        all_items = client.get("/api/portfolio/fx-conversions?include_deleted=true").json()
        restored = client.post(f"/api/portfolio/fx-conversions/{created['id']}/restore")
        audit = client.get("/api/portfolio/audit-log?entity_type=fx_conversion").json()

    assert preview.status_code == 200
    by_currency = {item["currency"]: item for item in preview.json()["impact"]["cash_by_currency"]}
    assert by_currency["USD"]["change"] == pytest.approx(-100)
    assert by_currency["ARS"]["change"] == pytest.approx(100000)
    assert update_preview.status_code == 200
    assert updated.status_code == 200
    assert updated.json()["item"]["revision"] == 2
    assert deleted.status_code == 204
    assert active == []
    assert all_items[0]["is_deleted"] is True
    assert restored.status_code == 200
    assert restored.json()["revision"] == 4
    assert [item["action"] for item in audit[:4]] == ["RESTORE", "DELETE", "UPDATE", "CREATE"]


def test_automatic_fx_uses_provider_rate() -> None:
    with TestClient(app) as client:
        response = client.post(
            "/api/portfolio/fx-conversions",
            json={
                "from_currency": "USD", "to_currency": "ARS", "from_amount": 10,
                "pricing_mode": "AUTO", "fee_amount": 0,
                "occurred_at": "2026-07-01T12:00:00Z",
            },
        )

    assert response.status_code == 201
    assert response.json()["exchange_rate"] == pytest.approx(1000)
    assert response.json()["to_amount"] == pytest.approx(10000)


def test_phase2_database_migrates_to_phase3_with_backup(tmp_path: Path, monkeypatch) -> None:
    data_dir = tmp_path / "data"
    data_dir.mkdir()
    db_path = data_dir / "quantlab.db"
    with sqlite3.connect(db_path) as connection:
        connection.executescript(
            """
            CREATE TABLE schema_migrations (
                version INTEGER PRIMARY KEY,
                name TEXT NOT NULL,
                applied_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            INSERT INTO schema_migrations(version, name) VALUES (5, 'safe editing');
            CREATE TABLE portfolios (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                name TEXT NOT NULL,
                base_currency TEXT NOT NULL DEFAULT 'USD',
                initial_cash REAL NOT NULL DEFAULT 10000,
                is_archived INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            INSERT INTO portfolios(id, name, base_currency, initial_cash)
            VALUES (1, 'Principal', 'USD', 1000);
            """
        )

    monkeypatch.setattr(database, "DATA_DIR", data_dir)
    monkeypatch.setattr(database, "DATABASE_PATH", db_path)
    database.initialize_database()

    with sqlite3.connect(db_path) as connection:
        portfolio_columns = {row[1] for row in connection.execute("PRAGMA table_info(portfolios)")}
        fx_table = connection.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name='portfolio_fx_conversions'"
        ).fetchone()
        migration = connection.execute(
            "SELECT name FROM schema_migrations WHERE version = 6"
        ).fetchone()
        allow_margin = connection.execute(
            "SELECT allow_margin FROM portfolios WHERE id = 1"
        ).fetchone()[0]

    assert "allow_margin" in portfolio_columns
    assert allow_margin == 0
    assert fx_table is not None
    assert migration is not None
    assert list((data_dir / "backups").glob("quantlab_pre_alpha14_phase3_*.db"))
