from datetime import datetime, timezone
from pathlib import Path
import sqlite3

import pytest
from fastapi.testclient import TestClient

from backend.core import database
from backend.core.database import initialize_database
from backend.main import app
from backend.models import (
    PortfolioCashMovementUpdate,
    PortfolioDividendCreate,
    PortfolioDividendImportOptions,
    PortfolioSettingsUpdate,
    PortfolioTransactionCreate,
)
from backend.services.dividends_service import (
    asset_price_fx_attribution,
    create_dividend,
    dividend_summary,
    import_dividends,
    list_dividends,
)
from backend.services.portfolio_service import (
    PortfolioValidationError,
    create_portfolio_transaction,
    delete_cash_movement,
    delete_portfolio_transaction,
    get_cash_movement,
    get_portfolio_overview,
    get_portfolio_transaction,
    preview_cash_movement_update,
    restore_cash_movement,
    update_portfolio_settings,
)


def _setup(tmp_path, monkeypatch):
    data_dir = tmp_path / "data"
    data_dir.mkdir()
    db_path = data_dir / "quantlab.db"
    monkeypatch.setattr(database, "DATA_DIR", data_dir)
    monkeypatch.setattr(database, "DATABASE_PATH", db_path)
    initialize_database()
    update_portfolio_settings(
        PortfolioSettingsUpdate(name="Dividendos", base_currency="USD", initial_cash=1000), 1
    )
    fx = lambda source, target, occurred_at=None: {"rate": 1.0}
    quote = lambda symbol: {
        "symbol": symbol, "name": "Activo prueba", "price": 10.0,
        "currency": "USD", "asset_type": "EQUITY", "exchange": "TEST",
    }
    create_portfolio_transaction(
        PortfolioTransactionCreate(
            symbol="TEST",
            transaction_type="BUY",
            quantity=10,
            price=10,
            fees=0,
            occurred_at=datetime(2026, 1, 2, tzinfo=timezone.utc),
        ),
        quote,
        fx,
        1,
    )
    return db_path, fx


def test_dividend_tracks_gross_tax_net_and_summary(tmp_path, monkeypatch) -> None:
    _, fx = _setup(tmp_path, monkeypatch)
    created = create_dividend(
        PortfolioDividendCreate(
            symbol="TEST",
            gross_amount=20,
            currency="USD",
            withholding_percent=25,
            occurred_at=datetime(2026, 2, 2, tzinfo=timezone.utc),
        ),
        fx,
        1,
    )
    summary = dividend_summary(None, fx, 1)

    assert created["gross_amount"] == pytest.approx(20)
    assert created["withholding_tax"] == pytest.approx(5)
    assert created["net_amount"] == pytest.approx(15)
    assert created["shares_held"] == pytest.approx(10)
    assert created["dividend_per_share"] == pytest.approx(2)
    assert summary["totals"]["gross"] == pytest.approx(20)
    assert summary["totals"]["tax"] == pytest.approx(5)
    assert summary["totals"]["net"] == pytest.approx(15)
    assert summary["effective_withholding_percent"] == pytest.approx(25)


def test_dividend_reinvestment_creates_linked_buy(tmp_path, monkeypatch) -> None:
    _, fx = _setup(tmp_path, monkeypatch)
    created = create_dividend(
        PortfolioDividendCreate(
            symbol="TEST",
            gross_amount=11,
            currency="USD",
            withholding_tax=1,
            occurred_at=datetime(2026, 2, 2, tzinfo=timezone.utc),
            reinvest=True,
            reinvest_price=5,
            reinvest_fees=0,
        ),
        fx,
        1,
    )
    overview = get_portfolio_overview(None, fx, 1)

    assert created["reinvested"] is True
    assert created["reinvest_transaction_id"] is not None
    assert created["reinvest_quantity"] == pytest.approx(2)
    assert overview["holdings"][0]["quantity"] == pytest.approx(12)
    assert overview["summary"]["dividends"] == pytest.approx(10)



def test_reinvested_dividend_delete_restore_keeps_linked_buy_synchronized(tmp_path, monkeypatch) -> None:
    _, fx = _setup(tmp_path, monkeypatch)
    created = create_dividend(
        PortfolioDividendCreate(
            symbol="TEST",
            gross_amount=10,
            currency="USD",
            occurred_at=datetime(2026, 2, 2, tzinfo=timezone.utc),
            reinvest=True,
            reinvest_price=5,
        ),
        fx,
        1,
    )
    movement_id = int(created["id"])
    transaction_id = int(created["reinvest_transaction_id"])

    with pytest.raises(PortfolioValidationError, match="reinversión de dividendos"):
        delete_portfolio_transaction(transaction_id, 1)

    deleted = delete_cash_movement(movement_id, 1, "Corrección de dividendo")
    assert deleted["linked_transaction_deleted"] == transaction_id
    assert get_cash_movement(movement_id, 1, include_deleted=True)["is_deleted"] is True
    assert get_portfolio_transaction(transaction_id, 1, include_deleted=True)["is_deleted"] is True
    assert get_portfolio_overview(None, fx, 1)["holdings"][0]["quantity"] == pytest.approx(10)

    restored = restore_cash_movement(movement_id, 1, "Restaurar registro correcto")
    assert restored["linked_transaction_restored"] == transaction_id
    assert get_cash_movement(movement_id, 1)["is_deleted"] is False
    assert get_portfolio_transaction(transaction_id, 1)["is_deleted"] is False
    assert get_portfolio_overview(None, fx, 1)["holdings"][0]["quantity"] == pytest.approx(12)


def test_advanced_dividend_rejects_generic_cash_editor(tmp_path, monkeypatch) -> None:
    _, fx = _setup(tmp_path, monkeypatch)
    created = create_dividend(
        PortfolioDividendCreate(
            symbol="TEST",
            gross_amount=20,
            currency="USD",
            withholding_tax=2,
            occurred_at=datetime(2026, 2, 2, tzinfo=timezone.utc),
        ),
        fx,
        1,
    )
    with pytest.raises(PortfolioValidationError, match="módulo Dividendos"):
        preview_cash_movement_update(
            int(created["id"]),
            PortfolioCashMovementUpdate(
                movement_type="DIVIDEND",
                amount=19,
                currency="USD",
                symbol="TEST",
                occurred_at=datetime(2026, 2, 2, tzinfo=timezone.utc),
                reason="Intento de edición genérica",
            ),
            fx,
            1,
        )

def test_import_dividends_detects_duplicates_and_can_reinvest(tmp_path, monkeypatch) -> None:
    _, fx = _setup(tmp_path, monkeypatch)
    events = {
        "source": "TEST",
        "events": [{"date": "2026-02-02T00:00:00+00:00", "amount_per_unit": 1.0}],
    }
    history = {
        "candles": [{"date": "2026-02-02T00:00:00+00:00", "close": 10.0}],
    }
    first = import_dividends(
        "TEST",
        "1y",
        PortfolioDividendImportOptions(withholding_percent=10, reinvest=True),
        lambda *_: events,
        lambda *_: history,
        fx,
        1,
    )
    second = import_dividends(
        "TEST",
        "1y",
        PortfolioDividendImportOptions(withholding_percent=10, reinvest=True),
        lambda *_: events,
        lambda *_: history,
        fx,
        1,
    )

    assert first["imported_count"] == 1
    assert first["movements"][0]["net_amount"] == pytest.approx(9)
    assert second["imported_count"] == 0
    assert second["skipped_count"] == 1


def test_open_position_attribution_separates_price_and_fx(tmp_path, monkeypatch) -> None:
    _, fx = _setup(tmp_path, monkeypatch)
    overview = get_portfolio_overview(None, fx, 1)
    result = asset_price_fx_attribution(overview, 1)

    assert result["positions"][0]["symbol"] == "TEST"
    assert result["totals"]["open_unrealized"] == pytest.approx(0)
    assert result["totals"]["price_effect"] == pytest.approx(0)
    assert result["totals"]["fx_effect"] == pytest.approx(0)


def test_phase2_migration_and_api_are_available(tmp_path, monkeypatch) -> None:
    db_path, _ = _setup(tmp_path, monkeypatch)
    with sqlite3.connect(db_path) as connection:
        assert connection.execute("SELECT 1 FROM schema_migrations WHERE version = 10").fetchone()
        columns = {row[1] for row in connection.execute("PRAGMA table_info(portfolio_cash_movements)")}
        assert {"gross_amount", "withholding_tax", "reinvest_transaction_id"} <= columns

    with TestClient(app) as client:
        created = client.post(
            "/api/v1/portfolio/dividends?portfolio_id=1",
            json={
                "symbol": "TEST",
                "gross_amount": 10,
                "currency": "USD",
                "withholding_percent": 10,
                "occurred_at": "2026-02-03T00:00:00Z"
            },
        )
        response = client.get("/api/v1/portfolio/dividends/summary?portfolio_id=1")
        settings = client.get("/api/v1/portfolio/dividends/settings?portfolio_id=1")
    assert created.status_code == 201
    assert created.json()["net_amount"] == pytest.approx(9)
    assert response.status_code == 200
    assert settings.status_code == 200


def test_frontend_contains_phase2_dividend_workspace() -> None:
    root = Path(__file__).resolve().parents[1]
    html = (root / "frontend" / "index.html").read_text(encoding="utf-8")
    js = (root / "frontend" / "assets" / "js" / "app.js").read_text(encoding="utf-8")
    assert 'id="advancedDividendForm"' in html
    assert 'id="analyticsDividendCalendar"' in html
    assert "async function loadDividendAnalytics(" in js
