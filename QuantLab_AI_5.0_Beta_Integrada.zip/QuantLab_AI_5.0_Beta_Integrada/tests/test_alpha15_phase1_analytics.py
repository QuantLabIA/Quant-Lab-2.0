from datetime import datetime, timezone
from pathlib import Path
import sqlite3

import pytest
from fastapi.testclient import TestClient

from backend.core import database
from backend.core.database import get_connection, initialize_database
from backend.main import app
from backend.models import AnalyticsSettingsUpdate, PortfolioTransactionCreate
from backend.services.analytics_service import (
    calculate_performance_metrics,
    get_analytics_overview,
    get_analytics_settings,
    update_analytics_settings,
)
from backend.services.portfolio_service import create_portfolio_transaction, update_portfolio_settings
from backend.models import PortfolioSettingsUpdate


def test_performance_metrics_use_cash_flow_adjusted_twr_and_drawdown() -> None:
    points = [
        {"date": "2026-01-01", "equity": 100.0, "external_flow": 0.0},
        {"date": "2026-01-02", "equity": 110.0, "external_flow": 0.0},
        {"date": "2026-01-03", "equity": 99.0, "external_flow": 0.0},
        {"date": "2026-01-04", "equity": 158.9, "external_flow": 50.0},
    ]

    metrics = calculate_performance_metrics(points, risk_free_rate_percent=0.0)

    assert metrics["period_returns"]["since_inception_percent"] == pytest.approx(8.9)
    assert metrics["max_drawdown_percent"] == pytest.approx(-10.0)
    assert metrics["current_drawdown_percent"] == pytest.approx(-1.0)
    assert metrics["annualized_volatility_percent"] > 0
    assert metrics["sharpe_ratio"] is not None
    assert len(metrics["series"]) == 4


def test_analytics_settings_are_saved_per_portfolio() -> None:
    initialize_database()
    saved = update_analytics_settings(
        AnalyticsSettingsUpdate(
            benchmark_symbol="QQQ",
            benchmark_name="Nasdaq 100 (QQQ)",
            risk_free_rate_percent=4.5,
        ),
        portfolio_id=1,
    )
    loaded = get_analytics_settings(1)

    assert saved["benchmark_symbol"] == "QQQ"
    assert loaded["benchmark_name"] == "Nasdaq 100 (QQQ)"
    assert loaded["risk_free_rate_percent"] == pytest.approx(4.5)

    # Dejar el portafolio principal con el valor predeterminado para otras pruebas.
    update_analytics_settings(AnalyticsSettingsUpdate(), portfolio_id=1)


def test_full_analytics_overview_calculates_benchmark_risk_and_concentration(tmp_path, monkeypatch) -> None:
    data_dir = tmp_path / "data"
    data_dir.mkdir()
    db_path = data_dir / "quantlab.db"
    monkeypatch.setattr(database, "DATA_DIR", data_dir)
    monkeypatch.setattr(database, "DATABASE_PATH", db_path)
    initialize_database()

    update_portfolio_settings(
        PortfolioSettingsUpdate(
            name="Analytics",
            base_currency="USD",
            initial_cash=1000,
            allow_margin=False,
        ),
        1,
    )

    quote = lambda symbol: {
        "symbol": symbol,
        "name": "Apple" if symbol == "AAPL" else symbol,
        "price": 120.0 if symbol == "AAPL" else 100.0,
        "currency": "USD",
        "asset_type": "EQUITY" if symbol == "AAPL" else "ETF",
        "exchange": "TEST",
        "last_updated": "2026-01-10T00:00:00Z",
    }
    fx = lambda source, target, occurred_at=None: {"rate": 1.0}
    create_portfolio_transaction(
        PortfolioTransactionCreate(
            symbol="AAPL",
            transaction_type="BUY",
            quantity=5,
            price=100,
            fees=0,
            occurred_at=datetime(2026, 1, 2, tzinfo=timezone.utc),
        ),
        quote,
        fx,
        1,
    )

    def history(symbol: str, period: str, interval: str) -> dict:
        closes = [100, 102, 101, 108, 110, 115, 120] if symbol == "AAPL" else [100, 101, 102, 104, 105, 106, 108]
        return {
            "symbol": symbol,
            "currency": "USD",
            "source": "TEST",
            "candles": [
                {"date": f"2026-01-{day:02d}T00:00:00Z", "close": close}
                for day, close in zip(range(2, 9), closes)
            ],
        }

    result = get_analytics_overview("1y", history, lambda *_: {"candles": []}, quote, fx, 1)

    assert result["benchmark"]["symbol"] == "SPY"
    assert result["benchmark"]["points"]
    assert result["performance"]["period_returns"]["since_inception_percent"] > 0
    assert result["risk"]["max_drawdown_percent"] <= 0
    assert result["concentration"]["by_asset"]
    assert result["positions"][0]["symbol"] == "AAPL"
    assert result["decomposition"]["total_investment_profit"] == pytest.approx(100.0)


def test_analytics_api_is_versioned_and_settings_endpoint_works() -> None:
    initialize_database()
    with TestClient(app) as client:
        saved = client.put(
            "/api/v1/analytics/settings?portfolio_id=1",
            json={
                "benchmark_symbol": "BTC-USD",
                "benchmark_name": "Bitcoin",
                "risk_free_rate_percent": 2.0,
            },
        )
        loaded = client.get("/api/v1/analytics/settings?portfolio_id=1")
    assert saved.status_code == 200
    assert loaded.status_code == 200
    assert loaded.json()["benchmark_symbol"] == "BTC-USD"
    update_analytics_settings(AnalyticsSettingsUpdate(), 1)


def test_alpha14_to_alpha15_migration_creates_backup_and_settings(tmp_path, monkeypatch) -> None:
    data_dir = tmp_path / "data"
    data_dir.mkdir()
    db_path = data_dir / "quantlab.db"
    monkeypatch.setattr(database, "DATA_DIR", data_dir)
    monkeypatch.setattr(database, "DATABASE_PATH", db_path)
    initialize_database()

    with sqlite3.connect(db_path) as connection:
        connection.execute("DELETE FROM schema_migrations WHERE version = 9")
        connection.execute("DROP TABLE IF EXISTS portfolio_analytics_settings")
        connection.commit()

    initialize_database()

    with sqlite3.connect(db_path) as connection:
        version = connection.execute("SELECT 1 FROM schema_migrations WHERE version = 9").fetchone()
        settings = connection.execute(
            "SELECT benchmark_symbol FROM portfolio_analytics_settings WHERE portfolio_id = 1"
        ).fetchone()
    assert version is not None
    assert settings[0] == "SPY"
    assert list((data_dir / "backups").glob("quantlab_pre_alpha15_phase1_*.db"))


def test_frontend_contains_analytics_page() -> None:
    root = Path(__file__).resolve().parents[1]
    html = (root / "frontend" / "index.html").read_text(encoding="utf-8")
    js = (root / "frontend" / "assets" / "js" / "app.js").read_text(encoding="utf-8")
    assert 'data-page="analytics"' in html
    assert 'id="page-analytics"' in html
    assert 'async function loadAnalytics(' in js
