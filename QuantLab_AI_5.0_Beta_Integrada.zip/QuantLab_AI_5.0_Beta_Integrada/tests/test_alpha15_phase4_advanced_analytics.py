from __future__ import annotations

from datetime import datetime, timedelta, timezone
from pathlib import Path
import sqlite3

import numpy as np
import pandas as pd
import pytest
from fastapi.testclient import TestClient

from backend.core import database
from backend.core.database import initialize_database
from backend.main import app
from backend.models import PortfolioSettingsUpdate, PortfolioTransactionCreate
from backend.services.advanced_analytics_service import (
    calculate_benchmark_relationship,
    calculate_covariance_risk,
    calculate_downside_and_tail_risk,
    compare_assets,
)
from backend.services.analytics_service import get_analytics_overview
from backend.services.portfolio_service import create_portfolio_transaction, update_portfolio_settings


def test_downside_tail_metrics_include_sortino_var_and_cvar() -> None:
    returns = pd.Series([0.02, -0.01, 0.005, -0.03, 0.01, -0.02, 0.015, -0.005])
    result = calculate_downside_and_tail_risk(
        returns,
        annualized_return_percent=12.0,
        risk_free_rate_percent=2.0,
        max_drawdown_percent=-8.0,
    )

    assert result["sortino_ratio"] is not None
    assert result["downside_deviation_percent"] > 0
    assert result["var"]["95"] >= 0
    assert result["cvar"]["95"] >= result["var"]["95"]
    assert result["calmar_ratio"] == pytest.approx(1.5)


def test_covariance_risk_builds_matrix_and_reconciles_contributions() -> None:
    returns = pd.DataFrame(
        {
            "AAA": [0.01, -0.005, 0.02, -0.01, 0.015],
            "BBB": [0.006, -0.003, 0.012, -0.006, 0.009],
        }
    )
    result = calculate_covariance_risk(returns, pd.Series({"AAA": 0.6, "BBB": 0.4}))

    assert result["symbols"] == ["AAA", "BBB"]
    assert len(result["correlation_matrix"]) == 2
    assert result["portfolio_volatility_percent"] > 0
    total_contribution = sum(float(item["risk_contribution_percent"]) for item in result["risk_contributions"])
    assert total_contribution == pytest.approx(100.0, abs=0.02)


def test_benchmark_relationship_estimates_beta_tracking_and_capture() -> None:
    start = datetime(2026, 1, 1, tzinfo=timezone.utc)
    benchmark_returns = [0.01, -0.005, 0.02, -0.01, 0.015]
    portfolio_returns = [value * 1.5 for value in benchmark_returns]
    benchmark_index = 100.0
    portfolio_index = 100.0
    portfolio_series = [{"date": start.date().isoformat(), "wealth_index": portfolio_index}]
    benchmark_points = [{"date": start.date().isoformat(), "benchmark_index": benchmark_index}]
    for index, (p_return, b_return) in enumerate(zip(portfolio_returns, benchmark_returns), start=1):
        portfolio_index *= 1 + p_return
        benchmark_index *= 1 + b_return
        day = (start + timedelta(days=index)).date().isoformat()
        portfolio_series.append({"date": day, "wealth_index": portfolio_index})
        benchmark_points.append({"date": day, "benchmark_index": benchmark_index})

    result = calculate_benchmark_relationship(portfolio_series, benchmark_points)
    assert result["beta"] == pytest.approx(1.5, rel=0.02)
    assert result["correlation"] == pytest.approx(1.0)
    assert result["tracking_error_percent"] > 0
    assert result["up_capture_percent"] == pytest.approx(150.0, rel=0.05)


def test_asset_comparator_normalizes_and_calculates_metrics() -> None:
    def history(symbol: str, period: str, interval: str) -> dict:
        values = {
            "AAA": [100, 102, 101, 106, 108],
            "BBB": [100, 99, 101, 100, 103],
        }[symbol]
        return {
            "symbol": symbol,
            "currency": "USD",
            "source": "TEST",
            "candles": [
                {"date": f"2026-01-{day:02d}T00:00:00Z", "close": close}
                for day, close in enumerate(values, start=1)
            ],
        }

    result = compare_assets(["AAA", "BBB"], "1y", "USD", history, None)
    assert len(result["assets"]) == 2
    assert result["points"][0]["values"]["AAA"] == pytest.approx(100.0)
    assert result["assets"][0]["annualized_volatility_percent"] >= 0
    assert len(result["correlation_matrix"]) == 2


def test_full_overview_exposes_phase4_risk_sector_and_attribution(tmp_path, monkeypatch) -> None:
    data_dir = tmp_path / "data"
    data_dir.mkdir()
    db_path = data_dir / "quantlab.db"
    monkeypatch.setattr(database, "DATA_DIR", data_dir)
    monkeypatch.setattr(database, "DATABASE_PATH", db_path)
    initialize_database()
    update_portfolio_settings(
        PortfolioSettingsUpdate(name="Advanced", base_currency="USD", initial_cash=5000, allow_margin=False),
        1,
    )

    def quote(symbol: str) -> dict:
        return {
            "symbol": symbol,
            "name": symbol,
            "price": 120 if symbol == "AAA" else 80,
            "currency": "USD",
            "asset_type": "EQUITY",
            "exchange": "TEST",
            "sector": "Tecnología" if symbol == "AAA" else "Salud",
            "industry": "Software" if symbol == "AAA" else "Biotecnología",
            "last_updated": "2026-01-10T00:00:00Z",
            "source": "TEST",
        }

    fx = lambda *_args, **_kwargs: {"rate": 1.0}
    create_portfolio_transaction(
        PortfolioTransactionCreate(
            symbol="AAA", transaction_type="BUY", quantity=10, price=100,
            occurred_at=datetime(2026, 1, 1, tzinfo=timezone.utc),
        ), quote, fx, 1,
    )
    create_portfolio_transaction(
        PortfolioTransactionCreate(
            symbol="BBB", transaction_type="BUY", quantity=10, price=70,
            occurred_at=datetime(2026, 1, 1, tzinfo=timezone.utc),
        ), quote, fx, 1,
    )

    def history(symbol: str, period: str, interval: str) -> dict:
        bases = {"AAA": [100, 102, 104, 103, 110, 115, 120], "BBB": [70, 72, 71, 74, 76, 78, 80], "SPY": [100, 101, 102, 103, 104, 105, 106]}
        return {
            "symbol": symbol, "currency": "USD", "source": "TEST",
            "candles": [
                {"date": f"2026-01-{day:02d}T00:00:00Z", "close": close}
                for day, close in enumerate(bases[symbol], start=1)
            ],
        }

    result = get_analytics_overview("1y", history, None, quote, fx, 1)
    assert result["advanced_risk"]["var"]["95"] is not None
    assert len(result["covariance_risk"]["symbols"]) == 2
    assert result["sector_industry"]["by_sector"]
    assert result["risk_summary"]["future_ai_ready"] is True
    assert "price_effect" in result["positions"][0]


def test_phase3_to_phase4_migration_adds_metadata_and_backup(tmp_path, monkeypatch) -> None:
    data_dir = tmp_path / "data"
    data_dir.mkdir()
    db_path = data_dir / "quantlab.db"
    monkeypatch.setattr(database, "DATA_DIR", data_dir)
    monkeypatch.setattr(database, "DATABASE_PATH", db_path)
    initialize_database()

    with sqlite3.connect(db_path) as connection:
        connection.execute("DELETE FROM schema_migrations WHERE version = 12")
        # SQLite no permite eliminar columnas en todas las versiones de forma portable;
        # la ausencia de la migración basta para comprobar backup y reaplicación idempotente.
        connection.commit()

    initialize_database()
    with sqlite3.connect(db_path) as connection:
        version = connection.execute("SELECT name FROM schema_migrations WHERE version = 12").fetchone()
        columns = {row[1] for row in connection.execute("PRAGMA table_info(portfolio_assets)")}
    assert version is not None
    assert {"sector", "industry", "metadata_source", "metadata_updated_at"}.issubset(columns)
    assert list((data_dir / "backups").glob("quantlab_pre_alpha15_phase4_*.db"))


def test_phase4_api_and_frontend_are_exposed() -> None:
    initialize_database()
    with TestClient(app) as client:
        openapi = client.get("/openapi.json")
    assert openapi.status_code == 200
    paths = openapi.json()["paths"]
    assert "/api/v1/analytics/compare" in paths
    assert "/api/v1/analytics/export.csv" in paths

    root = Path(__file__).resolve().parents[1]
    html = (root / "frontend" / "index.html").read_text(encoding="utf-8")
    js = (root / "frontend" / "assets" / "js" / "app.js").read_text(encoding="utf-8")
    assert 'id="correlationBody"' in html
    assert 'id="assetComparatorForm"' in html
    assert "function renderAdvancedRisk(" in js
    assert "async function loadAssetComparator(" in js
