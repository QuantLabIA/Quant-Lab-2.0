import sqlite3
from pathlib import Path

from backend.core import database


def test_alpha13_database_migrates_to_multiple_portfolios(tmp_path: Path, monkeypatch) -> None:
    data_dir = tmp_path / "data"
    data_dir.mkdir()
    db_path = data_dir / "quantlab.db"

    with sqlite3.connect(db_path) as connection:
        connection.executescript(
            """
            CREATE TABLE portfolio_settings (
                id INTEGER PRIMARY KEY,
                name TEXT NOT NULL,
                base_currency TEXT NOT NULL,
                initial_cash REAL NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );
            INSERT INTO portfolio_settings VALUES (
                1, 'Cartera migrada', 'ARS', 250000, '2026-01-01 00:00:00', '2026-07-01 00:00:00'
            );

            CREATE TABLE portfolio_transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                symbol TEXT NOT NULL,
                transaction_type TEXT NOT NULL,
                quantity REAL NOT NULL,
                price REAL NOT NULL,
                fees REAL NOT NULL DEFAULT 0,
                occurred_at TEXT NOT NULL,
                notes TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                asset_name TEXT NOT NULL DEFAULT '',
                asset_type TEXT NOT NULL DEFAULT 'EQUITY',
                asset_currency TEXT NOT NULL DEFAULT 'ARS',
                exchange TEXT NOT NULL DEFAULT '',
                pricing_mode TEXT NOT NULL DEFAULT 'AUTO',
                fx_rate_to_base REAL NOT NULL DEFAULT 1
            );
            INSERT INTO portfolio_transactions
                (symbol, transaction_type, quantity, price, fees, occurred_at, asset_name, asset_currency)
            VALUES ('GGAL.BA', 'BUY', 2, 5000, 50, '2026-06-01T12:00:00+00:00', 'Grupo Galicia', 'ARS');

            CREATE TABLE portfolio_assets (
                symbol TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                asset_type TEXT NOT NULL DEFAULT 'OTHER',
                currency TEXT NOT NULL,
                exchange TEXT NOT NULL DEFAULT '',
                pricing_mode TEXT NOT NULL DEFAULT 'AUTO',
                manual_price REAL,
                provider_symbol TEXT,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            INSERT INTO portfolio_assets
                (symbol, name, asset_type, currency, exchange, pricing_mode, provider_symbol)
            VALUES ('GGAL.BA', 'Grupo Galicia', 'EQUITY', 'ARS', 'Buenos Aires', 'AUTO', 'GGAL.BA');

            CREATE TABLE portfolio_cash_movements (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                movement_type TEXT NOT NULL,
                amount REAL NOT NULL,
                currency TEXT NOT NULL,
                fx_rate_to_base REAL NOT NULL,
                symbol TEXT,
                occurred_at TEXT NOT NULL,
                notes TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            INSERT INTO portfolio_cash_movements
                (movement_type, amount, currency, fx_rate_to_base, occurred_at)
            VALUES ('DEPOSIT', 10000, 'ARS', 1, '2026-05-01T12:00:00+00:00');
            """
        )

    monkeypatch.setattr(database, "DATA_DIR", data_dir)
    monkeypatch.setattr(database, "DATABASE_PATH", db_path)
    database.initialize_database()

    with sqlite3.connect(db_path) as connection:
        connection.row_factory = sqlite3.Row
        portfolio = dict(connection.execute("SELECT * FROM portfolios WHERE id = 1").fetchone())
        transaction = dict(connection.execute("SELECT * FROM portfolio_transactions").fetchone())
        movement = dict(connection.execute("SELECT * FROM portfolio_cash_movements").fetchone())
        asset = dict(connection.execute("SELECT * FROM portfolio_assets").fetchone())
        migration = connection.execute("SELECT version FROM schema_migrations WHERE version = 4").fetchone()

    assert portfolio["name"] == "Cartera migrada"
    assert portfolio["base_currency"] == "ARS"
    assert portfolio["initial_cash"] == 250000
    assert transaction["portfolio_id"] == 1
    assert movement["portfolio_id"] == 1
    assert asset["portfolio_id"] == 1
    assert asset["symbol"] == "GGAL.BA"
    assert migration is not None
    assert list((data_dir / "backups").glob("quantlab_pre_alpha14_*.db"))


def test_alpha12_database_can_migrate_directly(tmp_path: Path, monkeypatch) -> None:
    data_dir = tmp_path / "data_alpha12"
    data_dir.mkdir()
    db_path = data_dir / "quantlab.db"

    with sqlite3.connect(db_path) as connection:
        connection.executescript(
            """
            CREATE TABLE portfolio_settings (
                id INTEGER PRIMARY KEY,
                name TEXT NOT NULL,
                base_currency TEXT NOT NULL,
                initial_cash REAL NOT NULL,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            INSERT INTO portfolio_settings (id, name, base_currency, initial_cash)
            VALUES (1, 'Alpha 1.2', 'USD', 5000);

            CREATE TABLE portfolio_transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                symbol TEXT NOT NULL,
                transaction_type TEXT NOT NULL,
                quantity REAL NOT NULL,
                price REAL NOT NULL,
                fees REAL NOT NULL DEFAULT 0,
                occurred_at TEXT NOT NULL,
                notes TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            INSERT INTO portfolio_transactions
                (symbol, transaction_type, quantity, price, fees, occurred_at)
            VALUES ('AAPL', 'BUY', 1, 150, 1, '2026-06-01T12:00:00+00:00');
            """
        )

    monkeypatch.setattr(database, "DATA_DIR", data_dir)
    monkeypatch.setattr(database, "DATABASE_PATH", db_path)
    database.initialize_database()

    with sqlite3.connect(db_path) as connection:
        connection.row_factory = sqlite3.Row
        transaction = dict(connection.execute("SELECT * FROM portfolio_transactions").fetchone())
        asset = dict(connection.execute("SELECT * FROM portfolio_assets").fetchone())
        portfolio = dict(connection.execute("SELECT * FROM portfolios WHERE id = 1").fetchone())

    assert portfolio["name"] == "Alpha 1.2"
    assert transaction["portfolio_id"] == 1
    assert transaction["asset_name"] == "AAPL"
    assert transaction["pricing_mode"] == "AUTO"
    assert asset["portfolio_id"] == 1
    assert asset["symbol"] == "AAPL"


def test_phase1_database_migrates_to_safe_editing_with_backup(tmp_path: Path, monkeypatch) -> None:
    data_dir = tmp_path / "data"
    data_dir.mkdir()
    db_path = data_dir / "quantlab.db"

    with sqlite3.connect(db_path) as connection:
        connection.executescript(
            """
            CREATE TABLE schema_migrations (
                version INTEGER PRIMARY KEY,
                name TEXT NOT NULL,
                applied_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            INSERT INTO schema_migrations (version, name) VALUES (4, 'multiple portfolios');

            CREATE TABLE portfolio_settings (
                id INTEGER PRIMARY KEY CHECK (id = 1),
                name TEXT NOT NULL DEFAULT 'Portafolio principal',
                base_currency TEXT NOT NULL DEFAULT 'USD',
                initial_cash REAL NOT NULL DEFAULT 10000,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            INSERT INTO portfolio_settings (id, name, base_currency, initial_cash)
            VALUES (1, 'Principal', 'USD', 1000);

            CREATE TABLE portfolios (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                name TEXT NOT NULL,
                base_currency TEXT NOT NULL DEFAULT 'USD',
                initial_cash REAL NOT NULL DEFAULT 10000,
                is_archived INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            INSERT INTO portfolios (id, name, base_currency, initial_cash)
            VALUES (1, 'Principal', 'USD', 1000);

            CREATE TABLE portfolio_transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                portfolio_id INTEGER NOT NULL DEFAULT 1,
                symbol TEXT NOT NULL,
                transaction_type TEXT NOT NULL,
                quantity REAL NOT NULL,
                price REAL NOT NULL,
                fees REAL NOT NULL DEFAULT 0,
                occurred_at TEXT NOT NULL,
                notes TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                asset_name TEXT NOT NULL DEFAULT '',
                asset_type TEXT NOT NULL DEFAULT 'EQUITY',
                asset_currency TEXT NOT NULL DEFAULT 'USD',
                exchange TEXT NOT NULL DEFAULT '',
                pricing_mode TEXT NOT NULL DEFAULT 'AUTO',
                fx_rate_to_base REAL NOT NULL DEFAULT 1
            );
            INSERT INTO portfolio_transactions
                (portfolio_id, symbol, transaction_type, quantity, price, occurred_at, asset_name)
            VALUES (1, 'AAPL', 'BUY', 1, 100, '2026-06-01T12:00:00+00:00', 'Apple');

            CREATE TABLE portfolio_assets (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                portfolio_id INTEGER NOT NULL,
                symbol TEXT NOT NULL,
                name TEXT NOT NULL,
                asset_type TEXT NOT NULL DEFAULT 'OTHER',
                currency TEXT NOT NULL,
                exchange TEXT NOT NULL DEFAULT '',
                pricing_mode TEXT NOT NULL DEFAULT 'AUTO',
                manual_price REAL,
                provider_symbol TEXT,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                UNIQUE (portfolio_id, symbol)
            );
            INSERT INTO portfolio_assets
                (portfolio_id, symbol, name, asset_type, currency, pricing_mode, provider_symbol)
            VALUES (1, 'AAPL', 'Apple', 'EQUITY', 'USD', 'AUTO', 'AAPL');

            CREATE TABLE portfolio_cash_movements (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                portfolio_id INTEGER NOT NULL DEFAULT 1,
                movement_type TEXT NOT NULL,
                amount REAL NOT NULL,
                currency TEXT NOT NULL,
                fx_rate_to_base REAL NOT NULL,
                symbol TEXT,
                occurred_at TEXT NOT NULL,
                notes TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE portfolio_activity_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                portfolio_id INTEGER NOT NULL,
                action TEXT NOT NULL,
                entity_type TEXT NOT NULL DEFAULT 'portfolio',
                entity_id TEXT,
                details TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            """
        )

    monkeypatch.setattr(database, "DATA_DIR", data_dir)
    monkeypatch.setattr(database, "DATABASE_PATH", db_path)
    database.initialize_database()

    backups = list((data_dir / "backups").glob("quantlab_pre_alpha14_phase2_*.db"))
    with sqlite3.connect(db_path) as connection:
        transaction_columns = {
            row[1] for row in connection.execute("PRAGMA table_info(portfolio_transactions)")
        }
        cash_columns = {
            row[1] for row in connection.execute("PRAGMA table_info(portfolio_cash_movements)")
        }
        transaction = connection.execute(
            "SELECT symbol, is_deleted, revision, deleted_reason FROM portfolio_transactions"
        ).fetchone()
        migration = connection.execute(
            "SELECT version FROM schema_migrations WHERE version = 5"
        ).fetchone()
        audit_table = connection.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name='portfolio_audit_log'"
        ).fetchone()

    assert len(backups) == 1
    assert {"is_deleted", "deleted_at", "deleted_reason", "updated_at", "revision"} <= transaction_columns
    assert {"is_deleted", "deleted_at", "deleted_reason", "updated_at", "revision"} <= cash_columns
    assert transaction == ("AAPL", 0, 1, "")
    assert migration is not None
    assert audit_table is not None
