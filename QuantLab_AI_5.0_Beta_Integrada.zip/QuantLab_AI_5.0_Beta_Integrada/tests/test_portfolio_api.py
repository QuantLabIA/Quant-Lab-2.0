import pytest
from fastapi.testclient import TestClient

from backend.api import portfolio as portfolio_api
from backend.core.database import get_connection, initialize_database
from backend.main import app


USD_QUOTE = {
    "symbol": "AAPL",
    "name": "Apple Inc.",
    "price": 120.0,
    "previous_close": 118.0,
    "change": 2.0,
    "change_percent": 1.69,
    "market": "NASDAQ",
    "currency": "USD",
    "last_updated": "2026-07-28T20:00:00+00:00",
}


@pytest.fixture(autouse=True)
def reset_portfolio() -> None:
    initialize_database()
    with get_connection() as connection:
        connection.execute("DELETE FROM portfolio_fx_conversions")
        connection.execute("DELETE FROM portfolio_transactions")
        connection.execute("DELETE FROM portfolio_cash_movements")
        connection.execute("DELETE FROM portfolio_assets")
        connection.execute("DELETE FROM portfolios WHERE id <> 1")
        connection.execute("UPDATE portfolios SET is_archived = 0 WHERE id = 1")
        connection.execute(
            """
            UPDATE portfolios
            SET name = 'Portafolio principal', base_currency = 'USD',
                initial_cash = 1000, allow_margin = 0, updated_at = CURRENT_TIMESTAMP
            WHERE id = 1
            """
        )


def test_buy_updates_real_portfolio(monkeypatch) -> None:
    monkeypatch.setattr(portfolio_api, "find_market_asset", lambda symbol: USD_QUOTE)

    with TestClient(app) as client:
        created = client.post(
            "/api/portfolio/transactions",
            json={
                "symbol": "AAPL",
                "transaction_type": "BUY",
                "quantity": 2,
                "price": 100,
                "fees": 1,
                "occurred_at": "2026-07-01T12:00:00Z",
                "notes": "Primera compra",
            },
        )
        overview = client.get("/api/portfolio")

    assert created.status_code == 201
    assert overview.status_code == 200
    body = overview.json()
    assert body["is_demo"] is False
    assert body["summary"]["cash_balance"] == pytest.approx(799)
    assert body["summary"]["market_value"] == pytest.approx(240)
    assert body["summary"]["total_equity"] == pytest.approx(1039)
    assert body["summary"]["unrealized_pnl"] == pytest.approx(39)
    assert body["holdings"][0]["average_price"] == pytest.approx(100.5)


def test_oversell_is_rejected(monkeypatch) -> None:
    monkeypatch.setattr(portfolio_api, "find_market_asset", lambda symbol: USD_QUOTE)

    with TestClient(app) as client:
        client.post(
            "/api/portfolio/transactions",
            json={
                "symbol": "AAPL",
                "transaction_type": "BUY",
                "quantity": 1,
                "price": 100,
                "fees": 0,
                "occurred_at": "2026-07-01T12:00:00Z",
            },
        )
        response = client.post(
            "/api/portfolio/transactions",
            json={
                "symbol": "AAPL",
                "transaction_type": "SELL",
                "quantity": 2,
                "price": 120,
                "fees": 0,
                "occurred_at": "2026-07-02T12:00:00Z",
            },
        )

    assert response.status_code == 422
    assert "No podés vender" in response.json()["detail"]


def test_foreign_currency_purchase_requires_matching_cash(monkeypatch) -> None:
    ars_quote = {**USD_QUOTE, "symbol": "GGAL.BA", "currency": "ARS", "asset_type": "EQUITY"}
    monkeypatch.setattr(portfolio_api, "find_market_asset", lambda symbol: ars_quote)

    def fake_fx(source, target, occurred_at=None):
        if source == target:
            rate = 1
        elif source == "USD" and target == "ARS":
            rate = 1000
        elif source == "ARS" and target == "USD":
            rate = 0.001
        else:
            rate = 1
        return {"rate": rate, "from_currency": source, "to_currency": target}

    monkeypatch.setattr(portfolio_api, "get_fx_rate", fake_fx)

    with TestClient(app) as client:
        blocked = client.post(
            "/api/portfolio/transactions",
            json={
                "symbol": "GGAL.BA", "transaction_type": "BUY", "quantity": 1,
                "price": 5000, "fees": 0, "occurred_at": "2026-07-01T12:00:00Z",
            },
        )
        conversion = client.post(
            "/api/portfolio/fx-conversions",
            json={
                "from_currency": "USD", "to_currency": "ARS", "from_amount": 5,
                "pricing_mode": "AUTO", "fee_amount": 0,
                "occurred_at": "2026-06-30T12:00:00Z",
            },
        )
        response = client.post(
            "/api/portfolio/transactions",
            json={
                "symbol": "GGAL.BA", "transaction_type": "BUY", "quantity": 1,
                "price": 5000, "fees": 0, "occurred_at": "2026-07-01T12:00:00Z",
            },
        )

    assert blocked.status_code == 422
    assert "Efectivo insuficiente en ARS" in blocked.json()["detail"]
    assert conversion.status_code == 201
    assert response.status_code == 201
    assert response.json()["asset_currency"] == "ARS"
    assert response.json()["fx_rate_to_base"] == pytest.approx(0.001)
    assert response.json()["cash_effect"] == pytest.approx(-5)


def test_deleting_required_buy_is_rejected(monkeypatch) -> None:
    monkeypatch.setattr(portfolio_api, "find_market_asset", lambda symbol: USD_QUOTE)

    with TestClient(app) as client:
        buy = client.post(
            "/api/portfolio/transactions",
            json={
                "symbol": "AAPL",
                "transaction_type": "BUY",
                "quantity": 2,
                "price": 100,
                "fees": 0,
                "occurred_at": "2026-07-01T12:00:00Z",
            },
        ).json()
        client.post(
            "/api/portfolio/transactions",
            json={
                "symbol": "AAPL",
                "transaction_type": "SELL",
                "quantity": 1,
                "price": 120,
                "fees": 0,
                "occurred_at": "2026-07-02T12:00:00Z",
            },
        )
        response = client.delete(f"/api/portfolio/transactions/{buy['id']}")

    assert response.status_code == 422
    assert "No podés vender" in response.json()["detail"]
