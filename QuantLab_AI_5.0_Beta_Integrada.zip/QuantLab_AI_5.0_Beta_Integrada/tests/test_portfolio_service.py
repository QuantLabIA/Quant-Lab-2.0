import pytest

from backend.services.portfolio_service import PortfolioValidationError, calculate_ledger


def test_weighted_average_and_realized_profit() -> None:
    transactions = [
        {
            "id": 1,
            "symbol": "AAPL",
            "transaction_type": "BUY",
            "quantity": 2,
            "price": 100,
            "fees": 2,
            "occurred_at": "2026-01-01T12:00:00+00:00",
        },
        {
            "id": 2,
            "symbol": "AAPL",
            "transaction_type": "BUY",
            "quantity": 1,
            "price": 130,
            "fees": 1,
            "occurred_at": "2026-01-02T12:00:00+00:00",
        },
        {
            "id": 3,
            "symbol": "AAPL",
            "transaction_type": "SELL",
            "quantity": 1,
            "price": 150,
            "fees": 1,
            "occurred_at": "2026-01-03T12:00:00+00:00",
        },
    ]

    ledger = calculate_ledger(transactions, initial_cash=1000)
    state = ledger["states"]["AAPL"]

    assert ledger["cash_balance"] == pytest.approx(816)
    assert state["quantity"] == pytest.approx(2)
    assert state["average_price"] == pytest.approx(111)
    assert ledger["realized_pnl"] == pytest.approx(38)


def test_cannot_sell_more_than_owned() -> None:
    transactions = [
        {
            "id": 1,
            "symbol": "AAPL",
            "transaction_type": "SELL",
            "quantity": 1,
            "price": 100,
            "fees": 0,
            "occurred_at": "2026-01-01T12:00:00+00:00",
        }
    ]

    with pytest.raises(PortfolioValidationError, match="No podés vender"):
        calculate_ledger(transactions, initial_cash=1000)


def test_cannot_spend_more_cash_than_available() -> None:
    transactions = [
        {
            "id": 1,
            "symbol": "AAPL",
            "transaction_type": "BUY",
            "quantity": 20,
            "price": 100,
            "fees": 0,
            "occurred_at": "2026-01-01T12:00:00+00:00",
        }
    ]

    with pytest.raises(PortfolioValidationError, match="Efectivo insuficiente"):
        calculate_ledger(transactions, initial_cash=1000)


def test_cash_movements_do_not_distort_profit() -> None:
    transactions = [
        {
            "id": 1,
            "symbol": "SPY",
            "transaction_type": "BUY",
            "quantity": 1,
            "price": 100,
            "fees": 0,
            "fx_rate_to_base": 1,
            "occurred_at": "2026-01-02T12:00:00+00:00",
        }
    ]
    movements = [
        {
            "id": 1,
            "movement_type": "DEPOSIT",
            "amount": 500,
            "currency": "USD",
            "fx_rate_to_base": 1,
            "occurred_at": "2026-01-01T12:00:00+00:00",
        },
        {
            "id": 2,
            "movement_type": "DIVIDEND",
            "amount": 10,
            "currency": "USD",
            "fx_rate_to_base": 1,
            "occurred_at": "2026-01-03T12:00:00+00:00",
        },
        {
            "id": 3,
            "movement_type": "TAX",
            "amount": 2,
            "currency": "USD",
            "fx_rate_to_base": 1,
            "occurred_at": "2026-01-04T12:00:00+00:00",
        },
    ]

    ledger = calculate_ledger(transactions, initial_cash=1000, cash_movements=movements)

    assert ledger["cash_balance"] == pytest.approx(1408)
    assert ledger["net_contributions"] == pytest.approx(500)
    assert ledger["income"] == pytest.approx(10)
    assert ledger["expenses"] == pytest.approx(2)


def test_multicurrency_transaction_uses_stored_fx_rate() -> None:
    transactions = [
        {
            "id": 1,
            "symbol": "GGAL.BA",
            "transaction_type": "BUY",
            "quantity": 2,
            "price": 5000,
            "fees": 100,
            "fx_rate_to_base": 0.001,
            "asset_currency": "ARS",
            "occurred_at": "2026-01-01T12:00:00+00:00",
        }
    ]

    movements = [{
        "id": 1,
        "movement_type": "DEPOSIT",
        "amount": 10100,
        "currency": "ARS",
        "fx_rate_to_base": 0.001,
        "occurred_at": "2025-12-31T12:00:00+00:00",
    }]
    ledger = calculate_ledger(
        transactions, initial_cash=100, cash_movements=movements, base_currency="USD"
    )

    balances = {item["currency"]: item["balance"] for item in ledger["cash_balances"]}
    assert ledger["cash_balance"] == pytest.approx(100)
    assert balances["USD"] == pytest.approx(100)
    assert balances["ARS"] == pytest.approx(0)
    assert ledger["states"]["GGAL.BA"]["cost_basis"] == pytest.approx(10.1)
