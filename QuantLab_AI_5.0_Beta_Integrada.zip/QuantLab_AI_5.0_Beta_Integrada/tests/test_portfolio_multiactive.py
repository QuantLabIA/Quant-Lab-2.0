import pytest
from fastapi.testclient import TestClient

from backend.api import portfolio as portfolio_api
from backend.core.database import get_connection, initialize_database
from backend.main import app
from backend.services.portfolio_service import calculate_xirr


@pytest.fixture(autouse=True)
def reset_multiactive_portfolio() -> None:
    initialize_database()
    with get_connection() as connection:
        connection.execute("DELETE FROM portfolio_fx_conversions")
        connection.execute("DELETE FROM portfolio_transactions")
        connection.execute("DELETE FROM portfolio_cash_movements")
        connection.execute("DELETE FROM portfolio_assets")
        connection.execute("DELETE FROM portfolios WHERE id <> 1")
        connection.execute("UPDATE portfolios SET is_archived = 0 WHERE id = 1")
        connection.execute(
            """
            UPDATE portfolios
            SET name = 'Portafolio principal', base_currency = 'USD', initial_cash = 1000,
                created_at = '2026-01-01 00:00:00', updated_at = CURRENT_TIMESTAMP
            WHERE id = 1
            """
        )


def test_manual_asset_can_be_created_and_bought() -> None:
    with TestClient(app) as client:
        asset_response = client.post(
            "/api/portfolio/assets/manual",
            json={
                "symbol": "CASA-01",
                "name": "Casa de inversión",
                "asset_type": "REAL_ESTATE",
                "currency": "USD",
                "exchange": "Manual",
                "current_price": 250,
            },
        )
        transaction_response = client.post(
            "/api/portfolio/transactions",
            json={
                "symbol": "CASA-01",
                "transaction_type": "BUY",
                "pricing_mode": "MANUAL",
                "asset_name": "Casa de inversión",
                "asset_type": "REAL_ESTATE",
                "asset_currency": "USD",
                "quantity": 2,
                "price": 200,
                "fees": 0,
                "occurred_at": "2026-02-01T12:00:00Z",
            },
        )
        overview = client.get("/api/portfolio")

    assert asset_response.status_code == 201
    assert transaction_response.status_code == 201
    holding = overview.json()["holdings"][0]
    assert holding["pricing_mode"] == "MANUAL"
    assert holding["asset_type"] == "REAL_ESTATE"
    assert holding["market_value"] == pytest.approx(500)
    assert holding["unrealized_pnl"] == pytest.approx(100)


def test_deposit_dividend_and_tax_are_recorded(monkeypatch) -> None:
    monkeypatch.setattr(
        portfolio_api,
        "get_fx_rate",
        lambda source, target, occurred_at=None: {"rate": 1.25, "from_currency": source, "to_currency": target},
    )
    with TestClient(app) as client:
        deposit = client.post(
            "/api/portfolio/cash-movements",
            json={
                "movement_type": "DEPOSIT",
                "amount": 100,
                "currency": "EUR",
                "occurred_at": "2026-02-01T12:00:00Z",
            },
        )
        dividend = client.post(
            "/api/portfolio/cash-movements",
            json={
                "movement_type": "DIVIDEND",
                "amount": 10,
                "currency": "USD",
                "symbol": "SPY",
                "occurred_at": "2026-02-02T12:00:00Z",
            },
        )
        tax = client.post(
            "/api/portfolio/cash-movements",
            json={
                "movement_type": "TAX",
                "amount": 2,
                "currency": "USD",
                "occurred_at": "2026-02-03T12:00:00Z",
            },
        )
        overview = client.get("/api/portfolio").json()

    assert deposit.status_code == 201
    assert dividend.status_code == 201
    assert tax.status_code == 201
    assert overview["summary"]["cash_balance"] == pytest.approx(1133)
    assert overview["summary"]["net_contributions"] == pytest.approx(125)
    assert overview["summary"]["income"] == pytest.approx(10)
    assert overview["summary"]["expenses"] == pytest.approx(2)
    assert overview["summary"]["investment_profit"] == pytest.approx(8)


def test_xirr_returns_annualized_rate() -> None:
    from datetime import date

    rate = calculate_xirr(
        [
            (date(2025, 1, 1), -1000),
            (date(2026, 1, 1), 1100),
        ]
    )

    assert rate == pytest.approx(0.10, abs=0.001)


def test_dividends_can_be_imported_without_duplicates(monkeypatch) -> None:
    quote = {
        "symbol": "SPY",
        "name": "SPDR S&P 500 ETF Trust",
        "price": 110,
        "currency": "USD",
        "asset_type": "ETF",
        "exchange": "NYSE Arca",
    }
    monkeypatch.setattr(portfolio_api, "find_market_asset", lambda symbol: quote)
    monkeypatch.setattr(
        portfolio_api,
        "get_dividend_history",
        lambda symbol, period: {
            "symbol": symbol,
            "period": period,
            "events": [
                {"date": "2026-03-01T12:00:00+00:00", "amount_per_unit": 2.0},
            ],
            "source": "Prueba",
        },
    )

    with TestClient(app) as client:
        client.post(
            "/api/portfolio/transactions",
            json={
                "symbol": "SPY",
                "transaction_type": "BUY",
                "quantity": 3,
                "price": 100,
                "fees": 0,
                "occurred_at": "2026-02-01T12:00:00Z",
            },
        )
        first = client.post("/api/portfolio/dividends/import/SPY?period=5y")
        second = client.post("/api/portfolio/dividends/import/SPY?period=5y")
        overview = client.get("/api/portfolio").json()

    assert first.status_code == 200
    assert first.json()["imported_count"] == 1
    assert first.json()["movements"][0]["amount"] == pytest.approx(6)
    assert second.json()["imported_count"] == 0
    assert second.json()["skipped_count"] == 1
    assert overview["summary"]["dividends"] == pytest.approx(6)
