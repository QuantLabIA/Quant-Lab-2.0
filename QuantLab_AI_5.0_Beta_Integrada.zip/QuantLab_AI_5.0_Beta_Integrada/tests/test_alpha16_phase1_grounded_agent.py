from __future__ import annotations

from pathlib import Path
import sqlite3

from fastapi.testclient import TestClient

from backend.agents import history
from backend.agents.planner import plan_query
from backend.agents import service as agent_service
from backend.core import database
from backend.core.database import initialize_database
from backend.main import app
from backend.models import AIAgentQuery


def test_planner_selects_asset_compare_and_portfolio_tools() -> None:
    asset = plan_query(AIAgentQuery(message="Analizá AAPL", symbols=["AAPL"], scope="auto"))
    comparison = plan_query(AIAgentQuery(message="Compará AAPL y SPY", symbols=["AAPL", "SPY"]))
    portfolio = plan_query(AIAgentQuery(message="¿Cuál es el riesgo de mi portafolio?"))

    assert asset["intent"] == "asset"
    assert [tool["name"] for tool in asset["tools"]] == ["market_quote", "technical_analysis"]
    assert comparison["intent"] == "compare"
    assert comparison["tools"][0]["name"] == "asset_comparison"
    assert portfolio["intent"] == "portfolio_risk"
    assert [tool["name"] for tool in portfolio["tools"]] == ["portfolio_snapshot", "portfolio_analytics"]


def test_grounded_agent_separates_evidence_and_stores_trace(tmp_path, monkeypatch) -> None:
    data_dir = tmp_path / "data"
    data_dir.mkdir()
    db_path = data_dir / "quantlab.db"
    monkeypatch.setattr(database, "DATA_DIR", data_dir)
    monkeypatch.setattr(database, "DATABASE_PATH", db_path)
    initialize_database()

    def controlled_tool(name: str, arguments: dict) -> dict:
        if name == "portfolio_snapshot":
            result = {
                "portfolio_id": 1,
                "summary": {
                    "total_equity": 12000, "cash_balance": 2000, "investment_profit": 2000,
                    "total_return_percent": 20, "holdings_count": 2, "currencies_count": 1,
                    "valuation_status": "complete", "currency": "USD",
                },
                "source": "SQLite TEST", "last_updated": "2026-07-31T20:00:00Z",
            }
        else:
            result = {
                "portfolio_id": 1, "currency": "USD",
                "performance": {
                    "period_returns": {"selected_period_percent": 12},
                    "annualized_volatility_percent": 18,
                    "max_drawdown_percent": -9,
                    "sharpe_ratio": 1.1,
                },
                "advanced_risk": {"sortino_ratio": 1.5},
                "risk_summary": {
                    "headline": "Riesgo moderado", "score": 76,
                    "flags": [{"title": "Concentración", "detail": "La mayor posición pesa 42%."}],
                },
                "benchmark_relationship": {"beta": 1.05, "correlation": 0.8, "tracking_error_percent": 6},
                "source": "Analytics TEST", "last_updated": "2026-07-31T20:00:00Z",
                "is_partial": False, "errors": [],
            }
        return {
            "name": name, "arguments": arguments, "status": "success", "duration_ms": 3.2,
            "result": result, "error": None,
        }

    monkeypatch.setattr(agent_service, "execute_tool", controlled_tool)
    response = agent_service.run_agent_query(
        AIAgentQuery(message="Analizá el riesgo de mi portafolio", portfolio_id=1, scope="risk")
    )

    assert response["data_quality"] == "complete"
    assert response["safety"]["facts_calculations_interpretation_separated"] is True
    assert {section["key"] for section in response["sections"]} >= {"facts", "calculations", "interpretation", "risks", "limitations"}
    assert len(response["sources"]) == 2
    assert len(response["tools_used"]) == 2

    saved = history.get_session(response["session_id"], 1)
    assert saved is not None
    assert [message["role"] for message in saved["messages"]] == ["user", "assistant"]
    with sqlite3.connect(db_path) as connection:
        tool_count = connection.execute("SELECT COUNT(*) FROM ai_tool_runs").fetchone()[0]
    assert tool_count == 2


def test_agent_marks_partial_when_a_tool_fails(tmp_path, monkeypatch) -> None:
    data_dir = tmp_path / "data"
    data_dir.mkdir()
    monkeypatch.setattr(database, "DATA_DIR", data_dir)
    monkeypatch.setattr(database, "DATABASE_PATH", data_dir / "quantlab.db")
    initialize_database()

    monkeypatch.setattr(
        agent_service,
        "execute_tool",
        lambda name, arguments: {
            "name": name, "arguments": arguments, "status": "error", "duration_ms": 1,
            "result": None, "error": "Proveedor no disponible",
        },
    )
    response = agent_service.run_agent_query(
        AIAgentQuery(message="Analizá AAPL", symbols=["AAPL"], scope="asset")
    )
    assert response["data_quality"] == "unavailable"
    assert any("Proveedor no disponible" in item["text"] for section in response["sections"] if section["key"] == "limitations" for item in section["items"])


def test_agent_history_is_isolated_by_portfolio(tmp_path, monkeypatch) -> None:
    data_dir = tmp_path / "data"
    data_dir.mkdir()
    monkeypatch.setattr(database, "DATA_DIR", data_dir)
    monkeypatch.setattr(database, "DATABASE_PATH", data_dir / "quantlab.db")
    initialize_database()
    with database.get_connection() as connection:
        connection.execute(
            "INSERT INTO portfolios (name, base_currency, initial_cash, allow_margin) VALUES ('Segundo', 'USD', 1000, 0)"
        )
    first = history.create_session(1, "Primero", "moderado")
    second = history.create_session(2, "Segundo", "moderado")
    assert [item["id"] for item in history.list_sessions(1)] == [first]
    assert [item["id"] for item in history.list_sessions(2)] == [second]


def test_alpha15_to_alpha16_migration_adds_agent_tables_and_backup(tmp_path, monkeypatch) -> None:
    data_dir = tmp_path / "data"
    data_dir.mkdir()
    db_path = data_dir / "quantlab.db"
    monkeypatch.setattr(database, "DATA_DIR", data_dir)
    monkeypatch.setattr(database, "DATABASE_PATH", db_path)
    initialize_database()
    with sqlite3.connect(db_path) as connection:
        connection.execute("DELETE FROM schema_migrations WHERE version = 13")
        connection.execute("DROP TABLE IF EXISTS ai_tool_runs")
        connection.execute("DROP TABLE IF EXISTS ai_analysis_messages")
        connection.execute("DROP TABLE IF EXISTS ai_analysis_sessions")
        connection.commit()
    initialize_database()
    with sqlite3.connect(db_path) as connection:
        version = connection.execute("SELECT 1 FROM schema_migrations WHERE version = 13").fetchone()
        tables = {row[0] for row in connection.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    assert version is not None
    assert {"ai_analysis_sessions", "ai_analysis_messages", "ai_tool_runs"}.issubset(tables)
    assert list((data_dir / "backups").glob("quantlab_pre_alpha16_phase1_*.db"))


def test_agent_api_and_frontend_are_exposed(monkeypatch) -> None:
    from backend.api import ai as ai_api

    monkeypatch.setattr(
        ai_api,
        "run_agent_query",
        lambda payload: {
            "session_id": 1, "agent_version": "grounded-agent-1", "mode": "deterministic_grounded",
            "intent": "portfolio", "question": payload.message, "answer": "Respuesta trazable",
            "sections": [], "sources": [], "tools_used": [], "data_quality": "complete",
            "missing_information": [], "generated_at": "2026-07-31T20:00:00Z",
            "safety": {"can_modify_portfolio": False}, "disclaimer": "Educativo",
        },
    )
    with TestClient(app) as client:
        capabilities = client.get("/api/v1/ai/agent/capabilities")
        query = client.post(
            "/api/v1/ai/agent/query",
            json={"message": "Analizá mi portafolio", "portfolio_id": 1},
        )
        openapi = client.get("/openapi.json")
    assert capabilities.status_code == 200
    assert len(capabilities.json()["tools"]) >= 6
    assert query.status_code == 200
    assert query.json()["safety"]["can_modify_portfolio"] is False
    assert "/api/v1/ai/agent/query" in openapi.json()["paths"]

    root = Path(__file__).resolve().parents[1]
    html = (root / "frontend" / "index.html").read_text(encoding="utf-8")
    js = (root / "frontend" / "assets" / "js" / "app.js").read_text(encoding="utf-8")
    assert 'id="aiAgentForm"' in html
    assert 'id="aiSessionList"' in html
    assert "function renderAgentResponse(" in js
    assert "async function loadAISessions(" in js
