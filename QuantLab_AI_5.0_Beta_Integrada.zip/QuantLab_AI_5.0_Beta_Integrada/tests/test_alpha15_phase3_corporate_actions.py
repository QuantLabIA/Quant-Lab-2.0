from datetime import datetime, timezone
import csv
import io

import pytest
from fastapi.testclient import TestClient

from backend.core import database
from backend.core.database import initialize_database
from backend.main import app
from backend.api import data_management as data_api
from backend.services.csv_service import CSV_COLUMNS
from backend.services.dividends_service import historical_quantity
from backend.models import (
    PortfolioCorporateActionCreate,
    PortfolioSettingsUpdate,
    PortfolioTransactionCreate,
)
from backend.services.corporate_actions_service import (
    create_corporate_action,
    delete_corporate_action,
    get_corporate_action,
    preview_corporate_action,
    restore_corporate_action,
)
from backend.services.portfolio_service import (
    PortfolioValidationError,
    create_portfolio_transaction,
    get_portfolio_overview,
    update_portfolio_settings,
)


def _setup(tmp_path, monkeypatch, symbol="TEST"):
    data_dir = tmp_path / "data"
    data_dir.mkdir()
    db_path = data_dir / "quantlab.db"
    monkeypatch.setattr(database, "DATA_DIR", data_dir)
    monkeypatch.setattr(database, "DATABASE_PATH", db_path)
    initialize_database()
    update_portfolio_settings(
        PortfolioSettingsUpdate(name="Eventos", base_currency="USD", initial_cash=1000), 1
    )
    fx = lambda source, target, occurred_at=None: {"rate": 1.0}
    quote = lambda ticker: {
        "symbol": ticker,
        "name": f"Activo {ticker}",
        "price": 10.0,
        "currency": "USD",
        "asset_type": "EQUITY",
        "exchange": "TEST",
    }
    create_portfolio_transaction(
        PortfolioTransactionCreate(
            symbol=symbol,
            transaction_type="BUY",
            quantity=10,
            price=10,
            fees=0,
            occurred_at=datetime(2026, 1, 2, tzinfo=timezone.utc),
        ),
        quote,
        fx,
        1,
    )
    return db_path, fx, quote


def _holding(overview, symbol):
    return next(item for item in overview["holdings"] if item["symbol"] == symbol)


def test_split_preserves_total_cost_and_changes_quantity(tmp_path, monkeypatch):
    _, fx, quote = _setup(tmp_path, monkeypatch)
    create_corporate_action(
        PortfolioCorporateActionCreate(
            action_type="SPLIT",
            symbol="TEST",
            quantity_ratio=2,
            occurred_at=datetime(2026, 2, 1, tzinfo=timezone.utc),
        ),
        quote,
        fx,
        1,
    )
    holding = _holding(get_portfolio_overview(None, fx, 1), "TEST")
    assert holding["quantity"] == pytest.approx(20)
    assert holding["cost_basis"] == pytest.approx(100)
    assert holding["average_price_base"] == pytest.approx(5)


def test_stock_dividend_adds_units_without_false_income(tmp_path, monkeypatch):
    _, fx, quote = _setup(tmp_path, monkeypatch)
    create_corporate_action(
        PortfolioCorporateActionCreate(
            action_type="STOCK_DIVIDEND",
            symbol="TEST",
            quantity_ratio=0.10,
            occurred_at=datetime(2026, 2, 1, tzinfo=timezone.utc),
        ),
        quote,
        fx,
        1,
    )
    overview = get_portfolio_overview(None, fx, 1)
    holding = _holding(overview, "TEST")
    assert holding["quantity"] == pytest.approx(11)
    assert holding["cost_basis"] == pytest.approx(100)
    assert overview["summary"]["dividends"] == pytest.approx(0)


def test_ticker_change_moves_position_and_cost(tmp_path, monkeypatch):
    _, fx, quote = _setup(tmp_path, monkeypatch, "OLD")
    create_corporate_action(
        PortfolioCorporateActionCreate(
            action_type="TICKER_CHANGE",
            symbol="OLD",
            target_symbol="NEW",
            quantity_ratio=1,
            occurred_at=datetime(2026, 2, 1, tzinfo=timezone.utc),
        ),
        quote,
        fx,
        1,
    )
    overview = get_portfolio_overview(None, fx, 1)
    assert [item["symbol"] for item in overview["holdings"]] == ["NEW"]
    holding = _holding(overview, "NEW")
    assert holding["quantity"] == pytest.approx(10)
    assert holding["cost_basis"] == pytest.approx(100)


def test_spinoff_allocates_cost_without_changing_equity(tmp_path, monkeypatch):
    _, fx, quote = _setup(tmp_path, monkeypatch, "PARENT")
    create_corporate_action(
        PortfolioCorporateActionCreate(
            action_type="SPINOFF",
            symbol="PARENT",
            target_symbol="CHILD",
            quantity_ratio=0.5,
            cost_allocation_percent=20,
            occurred_at=datetime(2026, 2, 1, tzinfo=timezone.utc),
        ),
        quote,
        fx,
        1,
    )
    overview = get_portfolio_overview(None, fx, 1)
    parent = _holding(overview, "PARENT")
    child = _holding(overview, "CHILD")
    assert parent["cost_basis"] == pytest.approx(80)
    assert child["cost_basis"] == pytest.approx(20)
    assert child["quantity"] == pytest.approx(5)
    assert parent["cost_basis"] + child["cost_basis"] == pytest.approx(100)


def test_return_of_capital_reduces_basis_and_credits_cash(tmp_path, monkeypatch):
    _, fx, quote = _setup(tmp_path, monkeypatch)
    create_corporate_action(
        PortfolioCorporateActionCreate(
            action_type="RETURN_OF_CAPITAL",
            symbol="TEST",
            cash_amount=20,
            cash_currency="USD",
            occurred_at=datetime(2026, 2, 1, tzinfo=timezone.utc),
        ),
        quote,
        fx,
        1,
    )
    overview = get_portfolio_overview(None, fx, 1)
    holding = _holding(overview, "TEST")
    assert holding["cost_basis"] == pytest.approx(80)
    assert overview["summary"]["cash_balance"] == pytest.approx(920)
    assert overview["summary"]["total_equity"] == pytest.approx(1000)


def test_event_before_holding_is_rejected(tmp_path, monkeypatch):
    _, fx, quote = _setup(tmp_path, monkeypatch)
    with pytest.raises(PortfolioValidationError, match="No hay tenencia"):
        preview_corporate_action(
            PortfolioCorporateActionCreate(
                action_type="SPLIT",
                symbol="TEST",
                quantity_ratio=2,
                occurred_at=datetime(2025, 12, 1, tzinfo=timezone.utc),
            ),
            quote,
            fx,
            1,
        )


def test_delete_and_restore_event_replays_ledger(tmp_path, monkeypatch):
    _, fx, quote = _setup(tmp_path, monkeypatch)
    event = create_corporate_action(
        PortfolioCorporateActionCreate(
            action_type="SPLIT",
            symbol="TEST",
            quantity_ratio=2,
            occurred_at=datetime(2026, 2, 1, tzinfo=timezone.utc),
        ),
        quote,
        fx,
        1,
    )
    delete_corporate_action(event["id"], 1, "Prueba")
    assert _holding(get_portfolio_overview(None, fx, 1), "TEST")["quantity"] == pytest.approx(10)
    assert get_corporate_action(event["id"], 1, include_deleted=True)["is_deleted"] is True
    restore_corporate_action(event["id"], 1, "Restaurar")
    assert _holding(get_portfolio_overview(None, fx, 1), "TEST")["quantity"] == pytest.approx(20)


def test_corporate_actions_api_exposes_preview_and_create(tmp_path, monkeypatch):
    _, _, _ = _setup(tmp_path, monkeypatch)
    client = TestClient(app)
    payload = {
        "action_type": "SPLIT",
        "symbol": "TEST",
        "quantity_ratio": 2,
        "occurred_at": "2026-02-01T00:00:00Z",
    }
    preview = client.post("/api/v1/portfolio/corporate-actions/preview?portfolio_id=1", json=payload)
    created = client.post("/api/v1/portfolio/corporate-actions?portfolio_id=1", json=payload)
    listed = client.get("/api/v1/portfolio/corporate-actions?portfolio_id=1")
    assert preview.status_code == 200
    assert preview.json()["valid"] is True
    assert created.status_code == 201
    assert listed.status_code == 200
    assert len(listed.json()) == 1


def test_stock_merger_moves_quantity_by_exchange_ratio(tmp_path, monkeypatch):
    _, fx, quote = _setup(tmp_path, monkeypatch, "OLD")
    create_corporate_action(
        PortfolioCorporateActionCreate(
            action_type="MERGER",
            symbol="OLD",
            target_symbol="NEW",
            quantity_ratio=0.5,
            occurred_at=datetime(2026, 2, 1, tzinfo=timezone.utc),
        ),
        quote,
        fx,
        1,
    )
    holding = _holding(get_portfolio_overview(None, fx, 1), "NEW")
    assert holding["quantity"] == pytest.approx(5)
    assert holding["cost_basis"] == pytest.approx(100)
    assert holding["average_price_base"] == pytest.approx(20)


def test_return_of_capital_above_basis_recognizes_excess_gain(tmp_path, monkeypatch):
    _, fx, quote = _setup(tmp_path, monkeypatch)
    create_corporate_action(
        PortfolioCorporateActionCreate(
            action_type="RETURN_OF_CAPITAL",
            symbol="TEST",
            cash_amount=120,
            cash_currency="USD",
            occurred_at=datetime(2026, 2, 1, tzinfo=timezone.utc),
        ),
        quote,
        fx,
        1,
    )
    overview = get_portfolio_overview(None, fx, 1)
    holding = _holding(overview, "TEST")
    assert holding["cost_basis"] == pytest.approx(0)
    assert overview["summary"]["realized_pnl"] == pytest.approx(20)
    assert overview["summary"]["cash_balance"] == pytest.approx(1020)


def test_corporate_action_update_replays_and_increments_revision(tmp_path, monkeypatch):
    from backend.models import PortfolioCorporateActionUpdate
    from backend.services.corporate_actions_service import update_corporate_action

    _, fx, quote = _setup(tmp_path, monkeypatch)
    event = create_corporate_action(
        PortfolioCorporateActionCreate(
            action_type="SPLIT",
            symbol="TEST",
            quantity_ratio=2,
            occurred_at=datetime(2026, 2, 1, tzinfo=timezone.utc),
        ),
        quote,
        fx,
        1,
    )
    updated = update_corporate_action(
        event["id"],
        PortfolioCorporateActionUpdate(
            action_type="SPLIT",
            symbol="TEST",
            quantity_ratio=3,
            occurred_at=datetime(2026, 2, 1, tzinfo=timezone.utc),
            reason="Ratio corregido según comunicado",
        ),
        quote,
        fx,
        1,
    )
    assert updated["revision"] == 2
    assert _holding(get_portfolio_overview(None, fx, 1), "TEST")["quantity"] == pytest.approx(30)


def test_phase3_migration_creates_backup_and_schema_11(tmp_path, monkeypatch):
    import sqlite3

    data_dir = tmp_path / "data"
    data_dir.mkdir()
    db_path = data_dir / "quantlab.db"
    monkeypatch.setattr(database, "DATA_DIR", data_dir)
    monkeypatch.setattr(database, "DATABASE_PATH", db_path)
    initialize_database()
    with sqlite3.connect(db_path) as connection:
        connection.execute("DROP TABLE portfolio_corporate_actions")
        connection.execute("DELETE FROM schema_migrations WHERE version = 11")
        connection.commit()

    initialize_database()

    backups = list((data_dir / "backups").glob("quantlab_pre_alpha15_phase3_*.db"))
    assert backups
    with sqlite3.connect(db_path) as connection:
        version = connection.execute(
            "SELECT version FROM schema_migrations WHERE version = 11"
        ).fetchone()
        table = connection.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='portfolio_corporate_actions'"
        ).fetchone()
    assert version == (11,)
    assert table == ("portfolio_corporate_actions",)


def test_corporate_action_csv_import_export_isolated(tmp_path, monkeypatch):
    _, fx, quote = _setup(tmp_path, monkeypatch, symbol="CSV-SPLIT")
    monkeypatch.setattr(data_api, "find_market_asset", quote)
    monkeypatch.setattr(data_api, "get_fx_rate", fx)

    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=CSV_COLUMNS)
    writer.writeheader()
    writer.writerow({
        "record_type": "CORPORATE_ACTION",
        "occurred_at": "2026-02-01T10:00:00Z",
        "symbol": "CSV-SPLIT",
        "action_type": "SPLIT",
        "quantity_ratio": 2,
        "source": "IMPORT",
        "notes": "Split 2:1",
    })
    content = output.getvalue()

    with TestClient(app) as client:
        preview = client.post(
            "/api/data/csv/preview?portfolio_id=1",
            json={"filename": "evento.csv", "content": content},
        )
        imported = client.post(
            "/api/data/csv/import?portfolio_id=1",
            json={"filename": "evento.csv", "content": content, "import_valid_only": False},
        )
        overview = client.get("/api/portfolio?portfolio_id=1")
        exported = client.get("/api/data/csv/export/corporate-actions?portfolio_id=1")
        duplicate = client.post(
            "/api/data/csv/preview?portfolio_id=1",
            json={"filename": "evento.csv", "content": content},
        )

    assert preview.status_code == 200 and preview.json()["accepted"] == 1
    assert imported.status_code == 201
    holding = _holding(overview.json(), "CSV-SPLIT")
    assert holding["quantity"] == pytest.approx(20)
    assert holding["cost_basis"] == pytest.approx(100)
    assert exported.status_code == 200
    assert "SPLIT" in exported.text and "CSV-SPLIT" in exported.text
    assert duplicate.json()["accepted"] == 0
    assert duplicate.json()["duplicate"] == 1


def test_historical_dividend_quantity_respects_split(tmp_path, monkeypatch):
    _, fx, quote = _setup(tmp_path, monkeypatch, symbol="DIV-SPLIT")
    create_corporate_action(
        PortfolioCorporateActionCreate(
            action_type="SPLIT",
            symbol="DIV-SPLIT",
            quantity_ratio=3,
            occurred_at=datetime(2026, 2, 1, tzinfo=timezone.utc),
        ),
        quote,
        fx,
        1,
    )
    before = historical_quantity(
        "DIV-SPLIT", datetime(2026, 1, 15, tzinfo=timezone.utc), 1
    )
    after = historical_quantity(
        "DIV-SPLIT", datetime(2026, 2, 15, tzinfo=timezone.utc), 1
    )
    assert before == pytest.approx(10)
    assert after == pytest.approx(30)
