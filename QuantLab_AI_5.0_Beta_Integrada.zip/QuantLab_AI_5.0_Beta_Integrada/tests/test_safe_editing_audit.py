import pytest
from fastapi.testclient import TestClient

from backend.core.database import get_connection, initialize_database
from backend.main import app


@pytest.fixture(autouse=True)
def reset_safe_editing_data() -> None:
    initialize_database()
    with get_connection() as connection:
        connection.execute("DELETE FROM portfolio_audit_log")
        connection.execute("DELETE FROM portfolio_fx_conversions")
        connection.execute("DELETE FROM portfolio_transactions")
        connection.execute("DELETE FROM portfolio_cash_movements")
        connection.execute("DELETE FROM portfolio_assets")
        connection.execute("DELETE FROM portfolios WHERE id <> 1")
        connection.execute(
            """
            UPDATE portfolios
            SET name = 'Principal', base_currency = 'USD', initial_cash = 1000, allow_margin = 0,
                is_archived = 0, updated_at = CURRENT_TIMESTAMP
            WHERE id = 1
            """
        )


def _manual_buy(client: TestClient, quantity: float = 2, price: float = 100) -> dict:
    response = client.post(
        "/api/portfolio/transactions",
        json={
            "symbol": "TEST-01",
            "transaction_type": "BUY",
            "pricing_mode": "MANUAL",
            "asset_name": "Activo de prueba",
            "asset_type": "OTHER",
            "asset_currency": "USD",
            "quantity": quantity,
            "price": price,
            "fees": 0,
            "occurred_at": "2026-07-01T12:00:00Z",
        },
    )
    assert response.status_code == 201
    return response.json()


def _update_payload(*, quantity: float = 3, price: float = 100) -> dict:
    return {
        "symbol": "TEST-01",
        "transaction_type": "BUY",
        "pricing_mode": "MANUAL",
        "asset_name": "Activo de prueba",
        "asset_type": "OTHER",
        "asset_currency": "USD",
        "exchange": "Manual",
        "quantity": quantity,
        "price": price,
        "fees": 0,
        "occurred_at": "2026-07-01T12:00:00Z",
        "notes": "Cantidad corregida",
        "fx_rate_to_base": 1,
        "reason": "Corrección de carga",
    }


def test_preview_and_update_transaction_keep_ledger_valid() -> None:
    with TestClient(app) as client:
        transaction = _manual_buy(client)
        preview = client.post(
            f"/api/portfolio/transactions/{transaction['id']}/preview",
            json=_update_payload(quantity=3),
        )
        updated = client.put(
            f"/api/portfolio/transactions/{transaction['id']}",
            json=_update_payload(quantity=3),
        )
        overview = client.get("/api/portfolio").json()
        audit = client.get("/api/portfolio/audit-log").json()

    assert preview.status_code == 200
    assert preview.json()["impact"]["cash_balance_before"] == pytest.approx(800)
    assert preview.json()["impact"]["cash_balance_after"] == pytest.approx(700)
    assert updated.status_code == 200
    assert updated.json()["item"]["quantity"] == pytest.approx(3)
    assert updated.json()["item"]["revision"] == 2
    assert overview["summary"]["cash_balance"] == pytest.approx(700)
    assert [entry["action"] for entry in audit[:2]] == ["UPDATE", "CREATE"]
    assert audit[0]["before"]["quantity"] == pytest.approx(2)
    assert audit[0]["after"]["quantity"] == pytest.approx(3)


def test_invalid_edit_that_breaks_later_sale_is_rejected() -> None:
    with TestClient(app) as client:
        buy = _manual_buy(client, quantity=2)
        sale = client.post(
            "/api/portfolio/transactions",
            json={
                "symbol": "TEST-01",
                "transaction_type": "SELL",
                "pricing_mode": "MANUAL",
                "asset_name": "Activo de prueba",
                "asset_type": "OTHER",
                "asset_currency": "USD",
                "quantity": 1,
                "price": 120,
                "fees": 0,
                "occurred_at": "2026-07-02T12:00:00Z",
            },
        )
        assert sale.status_code == 201
        response = client.put(
            f"/api/portfolio/transactions/{buy['id']}",
            json=_update_payload(quantity=0.5),
        )

    assert response.status_code == 422
    assert "No podés vender" in response.json()["detail"]


def test_soft_delete_and_restore_transaction() -> None:
    with TestClient(app) as client:
        transaction = _manual_buy(client, quantity=1)
        deleted = client.delete(
            f"/api/portfolio/transactions/{transaction['id']}?reason=Duplicada"
        )
        active = client.get("/api/portfolio/transactions").json()
        all_items = client.get("/api/portfolio/transactions?include_deleted=true").json()
        overview_deleted = client.get("/api/portfolio").json()
        restored = client.post(
            f"/api/portfolio/transactions/{transaction['id']}/restore?reason=Recuperada"
        )
        overview_restored = client.get("/api/portfolio").json()

    assert deleted.status_code == 204
    assert active == []
    assert all_items[0]["is_deleted"] is True
    assert all_items[0]["deleted_at"] is not None
    assert overview_deleted["summary"]["transactions_count"] == 0
    assert restored.status_code == 200
    assert restored.json()["is_deleted"] is False
    assert restored.json()["revision"] == 3
    assert overview_restored["summary"]["transactions_count"] == 1


def test_cash_movement_edit_delete_restore_and_audit() -> None:
    with TestClient(app) as client:
        created = client.post(
            "/api/portfolio/cash-movements",
            json={
                "movement_type": "DEPOSIT",
                "amount": 500,
                "currency": "USD",
                "occurred_at": "2026-06-01T12:00:00Z",
                "notes": "Aporte",
            },
        ).json()
        payload = {
            "movement_type": "DEPOSIT",
            "amount": 600,
            "currency": "USD",
            "occurred_at": "2026-06-01T12:00:00Z",
            "notes": "Aporte corregido",
            "fx_rate_to_base": 1,
            "reason": "Importe corregido",
        }
        preview = client.post(
            f"/api/portfolio/cash-movements/{created['id']}/preview", json=payload
        )
        updated = client.put(
            f"/api/portfolio/cash-movements/{created['id']}", json=payload
        )
        deleted = client.delete(f"/api/portfolio/cash-movements/{created['id']}")
        restored = client.post(f"/api/portfolio/cash-movements/{created['id']}/restore")
        audit = client.get("/api/portfolio/audit-log?entity_type=cash_movement").json()

    assert preview.status_code == 200
    assert preview.json()["impact"]["cash_balance_change"] == pytest.approx(100)
    assert updated.status_code == 200
    assert updated.json()["item"]["amount"] == pytest.approx(600)
    assert deleted.status_code == 204
    assert restored.status_code == 200
    assert [item["action"] for item in audit[:4]] == ["RESTORE", "DELETE", "UPDATE", "CREATE"]


def test_edit_can_relink_manual_asset_symbol_and_currency_metadata() -> None:
    with TestClient(app) as client:
        transaction = _manual_buy(client, quantity=1, price=100)
        payload = _update_payload(quantity=1, price=110)
        payload.update(
            {
                "symbol": "TEST-02",
                "pricing_mode": "MANUAL",
                "asset_name": "Activo corregido",
                "asset_type": "BOND",
                "asset_currency": "USD",
                "exchange": "Privado",
                "reason": "Ticker cargado incorrectamente",
            }
        )
        response = client.put(
            f"/api/portfolio/transactions/{transaction['id']}", json=payload
        )
        overview = client.get("/api/portfolio").json()

    assert response.status_code == 200
    assert response.json()["item"]["symbol"] == "TEST-02"
    assert response.json()["item"]["asset_type"] == "BOND"
    assert [holding["symbol"] for holding in overview["holdings"]] == ["TEST-02"]
    assert overview["holdings"][0]["name"] == "Activo corregido"
