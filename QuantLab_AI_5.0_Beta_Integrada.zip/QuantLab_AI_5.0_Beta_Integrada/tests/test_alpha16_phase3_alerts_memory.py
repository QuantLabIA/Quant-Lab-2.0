from __future__ import annotations

import sqlite3

from fastapi.testclient import TestClient

from backend.agents import alerts, memory, service as agent_service
from backend.core import database
from backend.core.database import initialize_database
from backend.main import app
from backend.models import AIAgentQuery, AIAlertRuleCreate


def setup_temp_database(tmp_path, monkeypatch) -> None:
    data_dir = tmp_path / "data"
    data_dir.mkdir()
    monkeypatch.setattr(database, "DATA_DIR", data_dir)
    monkeypatch.setattr(database, "DATABASE_PATH", data_dir / "quantlab.db")
    initialize_database()


def controlled_analytics() -> dict:
    return {
        "portfolio_id": 1,
        "period": "1y",
        "risk": {
            "annualized_volatility_percent": 42.0,
            "current_drawdown_percent": -18.0,
            "max_drawdown_percent": -22.0,
            "var_95_percent": 2.5,
        },
        "concentration": {
            "largest_position_percent": 44.0,
            "by_asset": [{"key": "AAA", "label": "Empresa AAA", "percent": 44.0}],
        },
        "performance": {"period_returns": {"selected_period_percent": 8.0, "since_inception_percent": 20.0}},
        "benchmark": {"benchmark_return_percent": 7.0, "outperformance_percent": 1.0},
        "source": "TEST ANALYTICS",
        "last_updated": "2026-07-31T22:00:00Z",
        "is_partial": False,
        "errors": [],
    }


def test_phase3_migration_creates_alert_memory_and_outbox_tables(tmp_path, monkeypatch) -> None:
    setup_temp_database(tmp_path, monkeypatch)
    with sqlite3.connect(database.DATABASE_PATH) as connection:
        version = connection.execute("SELECT 1 FROM schema_migrations WHERE version = 15").fetchone()
        tables = {row[0] for row in connection.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        setting = connection.execute("SELECT use_language_model FROM ai_agent_settings WHERE portfolio_id = 1").fetchone()
    assert version is not None
    assert {"ai_alert_rules", "ai_alert_events", "ai_analysis_snapshots", "ai_notification_outbox"}.issubset(tables)
    assert setting == (0,)


def test_default_rules_and_custom_price_rule(tmp_path, monkeypatch) -> None:
    setup_temp_database(tmp_path, monkeypatch)
    rules = alerts.list_rules(1)
    assert {rule["rule_type"] for rule in rules} >= {"CONCENTRATION", "DRAWDOWN", "VOLATILITY"}
    created = alerts.create_rule(1, AIAlertRuleCreate(
        name="AAPL sobre objetivo", rule_type="PRICE_ABOVE", symbol="AAPL",
        threshold=250, severity="MEDIUM", cooldown_hours=12,
    ))
    assert created["symbol"] == "AAPL"
    assert created["is_enabled"] is True


def test_alert_evaluation_triggers_and_resolves_events(tmp_path, monkeypatch) -> None:
    setup_temp_database(tmp_path, monkeypatch)

    def run(name: str, arguments: dict) -> dict:
        if name == "portfolio_analytics":
            result = controlled_analytics()
        else:
            result = {"symbol": arguments["symbol"], "price": 260, "currency": "USD", "source": "TEST"}
        return {"name": name, "arguments": arguments, "status": "success", "duration_ms": 1, "result": result, "error": None}

    monkeypatch.setattr(alerts, "execute_tool", run)
    first = alerts.evaluate_alerts(1)
    assert first["new_events"] == 3
    assert len(alerts.list_events(1)) == 3

    lower = controlled_analytics()
    lower["risk"]["annualized_volatility_percent"] = 10
    lower["risk"]["current_drawdown_percent"] = -2
    lower["concentration"]["largest_position_percent"] = 20
    monkeypatch.setattr(alerts, "execute_tool", lambda name, arguments: {
        "name": name, "arguments": arguments, "status": "success", "duration_ms": 1,
        "result": lower if name == "portfolio_analytics" else {}, "error": None,
    })
    second = alerts.evaluate_alerts(1)
    assert second["resolved_events"] == 3
    assert alerts.list_events(1) == []
    assert len(alerts.list_events(1, "RESOLVED")) == 3


def test_alert_status_and_notification_readiness(tmp_path, monkeypatch) -> None:
    setup_temp_database(tmp_path, monkeypatch)
    monkeypatch.setattr(alerts, "execute_tool", lambda name, arguments: {
        "name": name, "arguments": arguments, "status": "success", "duration_ms": 1,
        "result": controlled_analytics(), "error": None,
    })
    alerts.evaluate_alerts(1)
    event = alerts.list_events(1)[0]
    updated = alerts.update_event_status(1, event["id"], "ACKNOWLEDGED", "Revisada")
    assert updated["status"] == "ACKNOWLEDGED"
    assert updated["user_note"] == "Revisada"
    readiness = alerts.notification_readiness(1)
    assert readiness["delivery_enabled"] is False
    assert readiness["pending_in_app_events"] == 3


def test_memory_detects_material_changes(tmp_path, monkeypatch) -> None:
    setup_temp_database(tmp_path, monkeypatch)
    first_run = [{
        "name": "market_quote", "arguments": {"symbol": "AAA"}, "status": "success",
        "result": {"symbol": "AAA", "price": 100, "change_percent": 1, "currency": "USD"}, "error": None,
    }]
    changes, snapshots = memory.preview_changes(1, first_run)
    assert changes == []
    memory.store_snapshots(1, None, None, snapshots)

    second_run = [{
        "name": "market_quote", "arguments": {"symbol": "AAA"}, "status": "success",
        "result": {"symbol": "AAA", "price": 108, "change_percent": -2, "currency": "USD"}, "error": None,
    }]
    changes, snapshots = memory.preview_changes(1, second_run)
    assert {item["metric"] for item in changes} >= {"price", "change_percent"}
    memory.store_snapshots(1, None, None, snapshots)
    recent = memory.recent_changes(1)
    assert recent[0]["symbol"] == "AAA"


def test_agent_response_includes_change_memory(tmp_path, monkeypatch) -> None:
    setup_temp_database(tmp_path, monkeypatch)
    price = {"value": 100.0}

    def controlled_tool(name: str, arguments: dict) -> dict:
        if name == "market_quote":
            result = {"symbol": "AAA", "name": "AAA", "price": price["value"], "change_percent": 1, "currency": "USD", "source": "TEST"}
        else:
            result = {
                "symbol": "AAA", "name": "AAA", "summary": "Lectura técnica", "risk_note": "Riesgo",
                "indicators": {"price": price["value"], "change_percent": 1, "rsi14": 50, "annualized_volatility_percent": 20, "trend": "alcista", "risk_level": "bajo"},
                "data": {"source": "TEST", "last_updated": "2026-07-31T22:00:00Z", "is_delayed": False},
            }
        return {"name": name, "arguments": arguments, "status": "success", "duration_ms": 1, "result": result, "error": None}

    monkeypatch.setattr(agent_service, "execute_tool", controlled_tool)
    first = agent_service.run_agent_query(AIAgentQuery(message="Analizá AAA", symbols=["AAA"], scope="asset", use_language_model=False))
    price["value"] = 112
    second = agent_service.run_agent_query(AIAgentQuery(message="Analizá AAA nuevamente", symbols=["AAA"], scope="asset", session_id=first["session_id"], use_language_model=False))
    assert second["change_memory"]["changes"]
    assert any(section["key"] == "changes" for section in second["sections"])
    assert second["mode"] == "deterministic_grounded"


def test_phase3_api_exposes_alerts_and_memory(tmp_path, monkeypatch) -> None:
    setup_temp_database(tmp_path, monkeypatch)
    from backend.api import ai as ai_api
    monkeypatch.setattr(ai_api, "evaluate_alerts", lambda portfolio_id, period: {"portfolio_id": portfolio_id, "period": period, "evaluated_rules": 3, "triggered": [], "new_events": 0, "resolved_events": 0, "errors": [], "is_partial": False})
    with TestClient(app) as client:
        rules = client.get("/api/v1/ai/alerts/rules?portfolio_id=1")
        evaluation = client.post("/api/v1/ai/alerts/evaluate?portfolio_id=1&period=1y")
        changes = client.get("/api/v1/ai/memory/changes?portfolio_id=1")
        readiness = client.get("/api/v1/ai/alerts/readiness?portfolio_id=1")
    assert rules.status_code == 200
    assert evaluation.status_code == 200
    assert changes.status_code == 200
    assert readiness.json()["delivery_enabled"] is False


def test_phase3_migration_is_idempotent_and_creates_backup(tmp_path, monkeypatch) -> None:
    setup_temp_database(tmp_path, monkeypatch)
    with sqlite3.connect(database.DATABASE_PATH) as connection:
        connection.execute("DELETE FROM schema_migrations WHERE version = 15")
        connection.execute("DROP TABLE IF EXISTS ai_notification_outbox")
        connection.execute("DROP TABLE IF EXISTS ai_analysis_snapshots")
        connection.execute("DROP TABLE IF EXISTS ai_alert_events")
        connection.execute("DROP TABLE IF EXISTS ai_alert_rules")
        connection.commit()
    initialize_database()
    initialize_database()
    with sqlite3.connect(database.DATABASE_PATH) as connection:
        count = connection.execute("SELECT COUNT(*) FROM ai_alert_rules WHERE portfolio_id = 1").fetchone()[0]
        version = connection.execute("SELECT 1 FROM schema_migrations WHERE version = 15").fetchone()
    assert version is not None
    assert count == 3
    assert list((database.DATA_DIR / "backups").glob("quantlab_pre_alpha16_phase3_*.db"))


def test_language_model_preference_is_not_reset_after_phase3_migration(tmp_path, monkeypatch) -> None:
    setup_temp_database(tmp_path, monkeypatch)
    with database.get_connection() as connection:
        connection.execute("UPDATE ai_agent_settings SET use_language_model = 1 WHERE portfolio_id = 1")
    initialize_database()
    with sqlite3.connect(database.DATABASE_PATH) as connection:
        value = connection.execute("SELECT use_language_model FROM ai_agent_settings WHERE portfolio_id = 1").fetchone()[0]
    assert value == 1
