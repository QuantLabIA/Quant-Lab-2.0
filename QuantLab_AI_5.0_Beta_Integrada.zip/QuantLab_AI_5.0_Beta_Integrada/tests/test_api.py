from fastapi.testclient import TestClient

from backend.api import ai as ai_api
from backend.api import market as market_api
from backend.main import app
from backend.core.config import settings


SAMPLE_QUOTE = {
    "symbol": "AAPL",
    "name": "Apple Inc.",
    "price": 200.0,
    "previous_close": 198.0,
    "change": 2.0,
    "change_percent": 1.0101,
    "market": "NASDAQ",
    "currency": "USD",
    "market_state": "REGULAR",
    "last_updated": "2026-07-28T20:00:00+00:00",
    "source": "Yahoo Finance vía yfinance",
    "is_delayed": True,
}


def test_health_endpoint() -> None:
    with TestClient(app) as client:
        response = client.get("/api/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"
    assert response.json()["version"] == settings.version


def test_market_endpoint(monkeypatch) -> None:
    monkeypatch.setattr(market_api, "find_market_asset", lambda symbol: SAMPLE_QUOTE)
    with TestClient(app) as client:
        response = client.get("/api/market/AAPL")
    assert response.status_code == 200
    assert response.json()["symbol"] == "AAPL"
    assert response.json()["source"].startswith("Yahoo Finance")


def test_market_list_endpoint(monkeypatch) -> None:
    monkeypatch.setattr(market_api, "list_market_assets", lambda: [SAMPLE_QUOTE])
    with TestClient(app) as client:
        response = client.get("/api/market")
    assert response.status_code == 200
    assert response.json()[0]["price"] == 200.0


def test_market_history_endpoint(monkeypatch) -> None:
    monkeypatch.setattr(
        market_api,
        "get_market_history",
        lambda symbol, period, interval: {
            "symbol": symbol,
            "period": period,
            "interval": interval,
            "candles": [{"date": "2026-07-28T00:00:00+00:00", "close": 200.0}],
            "source": "Yahoo Finance vía yfinance",
            "is_delayed": True,
            "last_updated": "2026-07-28T20:00:00+00:00",
        },
    )
    with TestClient(app) as client:
        response = client.get("/api/market/AAPL/history?period=3mo&interval=1d")
    assert response.status_code == 200
    assert response.json()["period"] == "3mo"


def test_unknown_market_symbol(monkeypatch) -> None:
    monkeypatch.setattr(market_api, "find_market_asset", lambda symbol: None)
    with TestClient(app) as client:
        response = client.get("/api/market/UNKNOWN")
    assert response.status_code == 404


def test_provider_status() -> None:
    with TestClient(app) as client:
        response = client.get("/api/market/provider/status")
    assert response.status_code == 200
    assert response.json()["mode"] == "real_delayed"


def test_ai_endpoint_uses_analysis_service(monkeypatch) -> None:
    monkeypatch.setattr(
        ai_api,
        "analyze_asset",
        lambda payload: {
            "symbol": payload.symbol,
            "summary": "Análisis basado en datos reales",
            "indicators": {"rsi14": 55.0},
        },
    )
    with TestClient(app) as client:
        response = client.post("/api/ai/analyze", json={"symbol": "NVDA", "risk_profile": "moderado"})
    assert response.status_code == 200
    assert response.json()["symbol"] == "NVDA"


def test_frontend_is_served() -> None:
    with TestClient(app) as client:
        response = client.get("/")
    assert response.status_code == 200
    assert "DATOS REALES" in response.text
