from pathlib import Path
import sqlite3

from fastapi.testclient import TestClient

from backend.api import market as market_api
from backend.core import database
from backend.core.database import SCHEMA_VERSION, get_connection, initialize_database
from backend.main import app
from backend.providers.yahoo_finance import MarketDataError, _quality_metadata


def setup_module() -> None:
    initialize_database()
    with get_connection() as connection:
        connection.execute("DELETE FROM market_manual_prices")


def teardown_module() -> None:
    with get_connection() as connection:
        connection.execute("DELETE FROM market_manual_prices")


def test_v1_api_and_legacy_alias_are_both_available() -> None:
    with TestClient(app) as client:
        v1 = client.get("/api/v1/health")
        legacy = client.get("/api/health")
    assert v1.status_code == 200
    assert legacy.status_code == 200
    assert v1.json()["api_version"] == "v1"
    assert v1.json()["schema_version"] == SCHEMA_VERSION


def test_errors_are_safe_and_have_request_id() -> None:
    with TestClient(app) as client:
        response = client.get("/api/v1/endpoint-that-does-not-exist")
    assert response.status_code == 404
    body = response.json()
    assert body["detail"] == "Endpoint no encontrado"
    assert body["error"]["code"] == "http_404"
    assert body["error"]["request_id"]
    assert response.headers["X-Request-ID"] == body["error"]["request_id"]


def test_validation_errors_use_uniform_envelope() -> None:
    with TestClient(app) as client:
        response = client.get("/api/v1/market/search?q=")
    assert response.status_code == 422
    body = response.json()
    assert body["error"]["code"] == "validation_error"
    assert body["error"]["fields"]


def test_manual_market_price_is_used_as_provider_fallback(monkeypatch) -> None:
    monkeypatch.setattr(
        market_api,
        "find_market_asset",
        lambda symbol: (_ for _ in ()).throw(MarketDataError("Proveedor temporalmente no disponible")),
    )
    with TestClient(app) as client:
        saved = client.put(
            "/api/v1/market/manual-prices/PRIVADO-1",
            json={
                "price": 125.5,
                "currency": "USD",
                "name": "Activo privado",
                "notes": "Valoración interna",
                "observed_at": "2026-07-31T12:00:00Z",
            },
        )
        quote = client.get("/api/v1/market/PRIVADO-1")
        deleted = client.delete("/api/v1/market/manual-prices/PRIVADO-1")
    assert saved.status_code == 200
    assert quote.status_code == 200
    assert quote.json()["pricing_mode"] == "MANUAL"
    assert quote.json()["data_status"] == "manual"
    assert quote.json()["price"] == 125.5
    assert deleted.status_code == 204


def test_symbol_alias_redirects_changed_ticker(monkeypatch) -> None:
    monkeypatch.setattr(
        market_api,
        "find_market_asset",
        lambda symbol: {
            "symbol": symbol,
            "name": "Meta Platforms",
            "price": 500.0,
            "previous_close": 495.0,
            "change": 5.0,
            "change_percent": 1.01,
            "market": "NASDAQ",
            "currency": "USD",
            "market_state": "open",
            "last_updated": "2026-07-31T12:00:00Z",
            "source": "TEST",
            "is_delayed": True,
            "pricing_mode": "AUTO",
            "warnings": [],
        },
    )
    with TestClient(app) as client:
        saved = client.put(
            "/api/v1/market/aliases/FB",
            json={"new_symbol": "META", "notes": "Cambio de ticker"},
        )
        quote = client.get("/api/v1/market/FB")
        deleted = client.delete("/api/v1/market/aliases/FB")
    assert saved.status_code == 200
    assert quote.status_code == 200
    assert quote.json()["symbol"] == "META"
    assert quote.json()["requested_symbol"] == "FB"
    assert quote.json()["symbol_alias"] == "META"
    assert deleted.status_code == 204


def test_migrations_are_registered_in_order() -> None:
    initialize_database()
    with TestClient(app) as client:
        response = client.get("/api/v1/system/migrations")
    assert response.status_code == 200
    body = response.json()
    versions = [item["version"] for item in body["applied"]]
    assert versions == list(range(1, SCHEMA_VERSION + 1))
    assert body["ordered"] is True


def test_phase4_to_phase5_migration_creates_backup_and_tables(tmp_path, monkeypatch) -> None:
    data_dir = tmp_path / "data"
    data_dir.mkdir()
    db_path = data_dir / "quantlab.db"
    monkeypatch.setattr(database, "DATA_DIR", data_dir)
    monkeypatch.setattr(database, "DATABASE_PATH", db_path)
    database.initialize_database()
    with sqlite3.connect(db_path) as connection:
        connection.execute("DELETE FROM schema_migrations WHERE version = 8")
        connection.execute("DROP TABLE IF EXISTS market_manual_prices")
        connection.execute("DROP TABLE IF EXISTS market_symbol_aliases")
        connection.commit()
    database.initialize_database()
    with sqlite3.connect(db_path) as connection:
        version = connection.execute("SELECT 1 FROM schema_migrations WHERE version = 8").fetchone()
        manual = connection.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='market_manual_prices'").fetchone()
        aliases = connection.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='market_symbol_aliases'").fetchone()
    assert version is not None
    assert manual is not None
    assert aliases is not None
    assert list((data_dir / "backups").glob("quantlab_pre_alpha14_phase5_*.db"))


def test_quote_quality_metadata_classifies_stale_and_closed() -> None:
    quote = _quality_metadata(
        {
            "last_updated": "2026-07-20T12:00:00+00:00",
            "market_state": "closed",
            "is_delayed": True,
            "pricing_mode": "AUTO",
        },
        price_kind="last_close",
    )
    assert quote["data_status"] == "stale"
    assert quote["market_state"] == "closed"
    assert quote["warnings"]


def test_frontend_contains_phase5_accessibility_and_filters() -> None:
    html = (Path(__file__).resolve().parents[1] / "frontend" / "index.html").read_text(encoding="utf-8")
    js = (Path(__file__).resolve().parents[1] / "frontend" / "assets" / "js" / "app.js").read_text(encoding="utf-8")
    assert 'class="skip-link"' in html
    assert 'id="globalLoading"' in html
    assert 'id="portfolioTextFilter"' in html
    assert 'id="themeSelect"' in html
    assert 'const API_BASE = "/api/v1"' in js
