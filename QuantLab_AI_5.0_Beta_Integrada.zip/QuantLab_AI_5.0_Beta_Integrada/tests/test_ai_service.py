from backend.models import AIAnalysisRequest
from backend.services import ai_service


def test_analysis_calculates_real_indicators(monkeypatch) -> None:
    closes = [100 + index * 0.5 for index in range(130)]
    monkeypatch.setattr(
        ai_service,
        "find_market_asset",
        lambda symbol: {
            "symbol": symbol,
            "name": "Empresa de prueba",
            "price": closes[-1],
            "change_percent": 1.2,
            "source": "Proveedor de prueba",
            "last_updated": "2026-07-28T20:00:00+00:00",
            "is_delayed": True,
        },
    )
    monkeypatch.setattr(
        ai_service,
        "get_market_history",
        lambda symbol, period, interval: {"candles": [{"close": close} for close in closes]},
    )

    result = ai_service.analyze_asset(AIAnalysisRequest(symbol="TEST", risk_profile="moderado"))

    assert result["indicators"]["trend"] == "alcista"
    assert result["indicators"]["sma20"] > result["indicators"]["sma50"]
    assert result["confidence"] == "análisis cuantitativo explicable"
