import csv
import io
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from backend.api import data_management as data_api
from backend.core.database import get_connection, initialize_database
from backend.main import app
from backend.services import csv_service
from backend.services.csv_service import CSV_COLUMNS


def fake_quote(symbol: str) -> dict:
    return {
        "symbol": symbol.upper(), "name": f"Activo {symbol.upper()}",
        "asset_type": "EQUITY", "currency": "USD", "exchange": "TEST",
    }


def fake_fx(source: str, target: str, occurred_at=None) -> dict:
    rates = {("USD", "ARS"): 1000.0, ("ARS", "USD"): 0.001}
    return {"rate": 1.0 if source == target else rates[(source, target)]}


@pytest.fixture(autouse=True)
def reset_phase4(monkeypatch):
    initialize_database()
    monkeypatch.setattr(data_api, "find_market_asset", fake_quote)
    monkeypatch.setattr(data_api, "get_fx_rate", fake_fx)
    with get_connection() as connection:
        connection.execute("DELETE FROM portfolio_import_batches")
        connection.execute("DELETE FROM portfolio_audit_log")
        connection.execute("DELETE FROM portfolio_fx_conversions")
        connection.execute("DELETE FROM portfolio_corporate_actions")
        connection.execute("DELETE FROM portfolio_transactions")
        connection.execute("DELETE FROM portfolio_cash_movements")
        connection.execute("DELETE FROM portfolio_assets")
        connection.execute("DELETE FROM portfolios WHERE id <> 1")
        connection.execute(
            """
            UPDATE portfolios
            SET name='Principal', base_currency='USD', initial_cash=1000,
                allow_margin=0, is_archived=0, updated_at=CURRENT_TIMESTAMP
            WHERE id=1
            """
        )


def sample_csv() -> str:
    rows = [
        {
            "record_type": "CASH_MOVEMENT", "occurred_at": "2026-07-01T10:00:00Z",
            "movement_type": "DEPOSIT", "amount": 500, "currency": "USD",
            "fx_rate_to_base": 1, "notes": "Aporte",
        },
        {
            "record_type": "TRANSACTION", "occurred_at": "2026-07-02T10:00:00Z",
            "symbol": "MANUAL-A", "transaction_type": "BUY", "quantity": 2,
            "price": 100, "fees": 1, "pricing_mode": "MANUAL",
            "asset_name": "Activo A", "asset_type": "OTHER", "asset_currency": "USD",
            "exchange": "Manual", "fx_rate_to_base": 1, "notes": "Compra",
        },
        {
            "record_type": "TRANSACTION", "occurred_at": "2026-07-02T10:00:00Z",
            "symbol": "MANUAL-A", "transaction_type": "BUY", "quantity": 2,
            "price": 100, "fees": 1, "pricing_mode": "MANUAL",
            "asset_name": "Activo A", "asset_type": "OTHER", "asset_currency": "USD",
            "exchange": "Manual", "fx_rate_to_base": 1, "notes": "Duplicada",
        },
        {
            "record_type": "TRANSACTION", "occurred_at": "2026-07-03T10:00:00Z",
            "symbol": "MANUAL-A", "transaction_type": "SELL", "quantity": 99,
            "price": 120, "fees": 0, "pricing_mode": "MANUAL",
            "asset_name": "Activo A", "asset_type": "OTHER", "asset_currency": "USD",
            "exchange": "Manual", "fx_rate_to_base": 1, "notes": "Venta inválida",
        },
    ]
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=CSV_COLUMNS)
    writer.writeheader()
    writer.writerows(rows)
    return output.getvalue()


def test_template_preview_partial_and_duplicate_detection() -> None:
    with TestClient(app) as client:
        template = client.get("/api/data/csv/template")
        preview = client.post(
            "/api/data/csv/preview?portfolio_id=1",
            json={"filename": "prueba.csv", "content": sample_csv()},
        )
    assert template.status_code == 200
    assert "record_type" in template.text
    assert preview.status_code == 200
    data = preview.json()
    assert data["accepted"] == 2
    assert data["duplicate"] == 1
    assert data["rejected"] == 1
    assert any("vender" in row["message"] for row in data["rows"] if row["status"] == "rejected")


def test_csv_commit_exports_and_second_import_is_duplicate() -> None:
    with TestClient(app) as client:
        imported = client.post(
            "/api/data/csv/import?portfolio_id=1",
            json={"filename": "prueba.csv", "content": sample_csv(), "import_valid_only": True},
        )
        overview = client.get("/api/portfolio?portfolio_id=1")
        second = client.post(
            "/api/data/csv/preview?portfolio_id=1",
            json={"filename": "prueba.csv", "content": sample_csv()},
        )
        generic = client.get("/api/data/csv/export/generic?portfolio_id=1")
        positions = client.get("/api/data/csv/export/positions?portfolio_id=1")
        history = client.get("/api/data/csv/imports?portfolio_id=1")
    assert imported.status_code == 201
    assert len(imported.json()["committed"]) == 2
    assert overview.json()["holdings"][0]["quantity"] == pytest.approx(2)
    assert second.json()["accepted"] == 0
    assert second.json()["duplicate"] == 3  # two identical buys plus the existing deposit
    assert generic.status_code == 200 and "CASH_MOVEMENT" in generic.text
    assert positions.status_code == 200 and "MANUAL-A" in positions.text
    assert history.json()[0]["accepted_rows"] == 2


def test_backup_validate_restore_roundtrip() -> None:
    with TestClient(app) as client:
        client.post(
            "/api/portfolio/cash-movements?portfolio_id=1",
            json={
                "movement_type": "DEPOSIT", "amount": 100, "currency": "USD",
                "occurred_at": "2026-07-01T10:00:00Z", "fx_rate_to_base": 1,
            },
        )
        created = client.post("/api/data/backups", json={"note": "Prueba integral"})
        assert created.status_code == 201
        filename = created.json()["filename"]
        raw = client.get(f"/api/data/backups/{filename}").content
        validation = client.post(
            f"/api/data/backups/validate?filename={filename}", content=raw,
            headers={"content-type": "application/octet-stream"},
        )
        client.post(
            "/api/portfolio/cash-movements?portfolio_id=1",
            json={
                "movement_type": "DEPOSIT", "amount": 200, "currency": "USD",
                "occurred_at": "2026-07-02T10:00:00Z", "fx_rate_to_base": 1,
            },
        )
        before = client.get("/api/portfolio?portfolio_id=1").json()["summary"]["cash_balance"]
        restored = client.post(
            f"/api/data/backups/restore?filename={filename}&confirmation=RESTAURAR",
            content=raw, headers={"content-type": "application/octet-stream"},
        )
        after = client.get("/api/portfolio?portfolio_id=1").json()["summary"]["cash_balance"]
        backups = client.get("/api/data/backups")
    assert validation.status_code == 200
    assert validation.json()["valid"] is True
    assert before == pytest.approx(1300)
    assert restored.status_code == 200
    assert after == pytest.approx(1100)
    assert any(item["filename"] == filename for item in backups.json())


def test_backup_rejects_invalid_and_wrong_confirmation() -> None:
    with TestClient(app) as client:
        invalid = client.post(
            "/api/data/backups/validate?filename=falso.qlbackup", content=b"not-a-zip",
            headers={"content-type": "application/octet-stream"},
        )
        created = client.post("/api/data/backups", json={}).json()
        raw = client.get(created["download_url"]).content
        blocked = client.post(
            f"/api/data/backups/restore?filename={created['filename']}&confirmation=NO",
            content=raw, headers={"content-type": "application/octet-stream"},
        )
    assert invalid.status_code == 422
    assert blocked.status_code == 422
    assert "RESTAURAR" in blocked.json()["detail"]


def test_csv_all_or_nothing_blocks_partial_commit() -> None:
    with TestClient(app) as client:
        response = client.post(
            "/api/data/csv/import?portfolio_id=1",
            json={
                "filename": "estricto.csv", "content": sample_csv(),
                "import_valid_only": False, "skip_duplicates": True,
            },
        )
        transactions = client.get("/api/portfolio/transactions?portfolio_id=1").json()
        movements = client.get("/api/portfolio/cash-movements?portfolio_id=1").json()
    assert response.status_code == 422
    assert transactions == []
    assert movements == []



def test_strict_import_rolls_back_unexpected_commit_failure(monkeypatch) -> None:
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=CSV_COLUMNS)
    writer.writeheader()
    writer.writerows([
        {
            "record_type": "CASH_MOVEMENT", "occurred_at": "2026-07-01T10:00:00Z",
            "movement_type": "DEPOSIT", "amount": 10, "currency": "USD",
            "fx_rate_to_base": 1,
        },
        {
            "record_type": "CASH_MOVEMENT", "occurred_at": "2026-07-02T10:00:00Z",
            "movement_type": "DEPOSIT", "amount": 20, "currency": "USD",
            "fx_rate_to_base": 1,
        },
    ])
    original = csv_service.create_cash_movement
    calls = {"count": 0}

    def flaky_create(*args, **kwargs):
        calls["count"] += 1
        if calls["count"] == 2:
            raise RuntimeError("Falla simulada durante commit")
        return original(*args, **kwargs)

    monkeypatch.setattr(csv_service, "create_cash_movement", flaky_create)
    with TestClient(app) as client:
        response = client.post(
            "/api/data/csv/import?portfolio_id=1",
            json={
                "filename": "atomico.csv", "content": output.getvalue(),
                "import_valid_only": False, "skip_duplicates": True,
            },
        )
        movements = client.get("/api/portfolio/cash-movements?portfolio_id=1").json()
        batches = client.get("/api/data/csv/imports?portfolio_id=1").json()
    assert response.status_code == 422
    assert "revertidos" in response.json()["detail"]
    assert movements == []
    assert batches == []

def test_corrupted_backup_checksum_is_rejected() -> None:
    import io
    import json
    import zipfile

    with TestClient(app) as client:
        created = client.post("/api/data/backups", json={}).json()
        raw = client.get(created["download_url"]).content
        source = zipfile.ZipFile(io.BytesIO(raw))
        manifest = json.loads(source.read("manifest.json"))
        database_bytes = source.read("quantlab.db")
        manifest["database_sha256"] = "0" * 64
        output = io.BytesIO()
        with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            archive.writestr("manifest.json", json.dumps(manifest))
            archive.writestr("quantlab.db", database_bytes)
        response = client.post(
            "/api/data/backups/validate?filename=alterado.qlbackup",
            content=output.getvalue(), headers={"content-type": "application/octet-stream"},
        )
    assert response.status_code == 422
    assert "checksum" in response.json()["detail"].lower()


def test_phase3_schema_migrates_to_phase4_with_backup(tmp_path: Path, monkeypatch) -> None:
    import shutil
    import sqlite3
    from backend.core import database

    initialize_database()
    data_dir = tmp_path / "data"
    data_dir.mkdir()
    db_path = data_dir / "quantlab.db"
    shutil.copy2(database.DATABASE_PATH, db_path)
    with sqlite3.connect(db_path) as connection:
        connection.execute("DELETE FROM schema_migrations WHERE version = 7")
        connection.execute("DROP TABLE IF EXISTS portfolio_import_batches")
        connection.execute("DROP TABLE IF EXISTS backup_history")
        connection.commit()
    monkeypatch.setattr(database, "DATA_DIR", data_dir)
    monkeypatch.setattr(database, "DATABASE_PATH", db_path)
    database.initialize_database()
    with sqlite3.connect(db_path) as connection:
        version = connection.execute(
            "SELECT 1 FROM schema_migrations WHERE version = 7"
        ).fetchone()
        tables = {
            row[0] for row in connection.execute(
                "SELECT name FROM sqlite_master WHERE type='table'"
            ).fetchall()
        }
    assert version is not None
    assert {"portfolio_import_batches", "backup_history"}.issubset(tables)
    assert list((data_dir / "backups").glob("quantlab_pre_alpha14_phase4_*.db"))
