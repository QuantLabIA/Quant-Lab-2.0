from __future__ import annotations

import sqlite3

import pytest
from fastapi.testclient import TestClient

from backend.agents import service as agent_service
from backend.agents.planner import plan_query
from backend.core import database
from backend.core.database import initialize_database
from backend.main import app
from backend.models import AIAgentQuery
from backend.services.fundamental_service import analyze_fundamentals, compare_fundamentals


def raw_fundamental(symbol: str) -> dict:
    variants = {
        "AAA": {"revenue_growth_percent": 15, "earnings_growth_percent": 20, "profit_margin_percent": 18, "return_on_equity_percent": 24, "return_on_assets_percent": 12, "debt_to_equity": 45, "current_ratio": 1.8, "free_cash_flow": 250, "operating_cash_flow": 300, "trailing_pe": 20, "price_to_book": 4, "price_to_sales": 5, "revenue": 1000, "net_income": 180},
        "BBB": {"revenue_growth_percent": -4, "earnings_growth_percent": -12, "profit_margin_percent": 2, "return_on_equity_percent": 4, "return_on_assets_percent": 1, "debt_to_equity": 240, "current_ratio": 0.8, "free_cash_flow": -20, "operating_cash_flow": 10, "trailing_pe": 55, "price_to_book": 10, "price_to_sales": 12, "revenue": 900, "net_income": 18},
    }
    metrics = variants[symbol]
    return {
        "symbol": symbol,
        "name": f"Empresa {symbol}",
        "currency": "USD",
        "sector": "Technology",
        "industry": "Software",
        "metrics": metrics,
        "coverage": {"available_fields": len(metrics), "total_fields": len(metrics)},
        "source": "TEST FUNDAMENTALS",
        "last_updated": "2026-07-31T21:00:00Z",
        "is_partial": False,
    }


def setup_temp_database(tmp_path, monkeypatch) -> None:
    data_dir = tmp_path / "data"
    data_dir.mkdir()
    monkeypatch.setattr(database, "DATA_DIR", data_dir)
    monkeypatch.setattr(database, "DATABASE_PATH", data_dir / "quantlab.db")
    initialize_database()


def test_fundamental_analysis_scores_and_separates_thesis_risk() -> None:
    result = analyze_fundamentals("AAA", raw_fundamental)
    assert result["scores"]["overall"] > 60
    assert result["assessment"]["favorable"]
    assert result["assessment"]["risks"] == []
    assert result["coverage"]["status"] == "complete"


def test_fundamental_comparison_identifies_leader() -> None:
    result = compare_fundamentals(["AAA", "BBB"], raw_fundamental)
    assert result["leaders"]["overall_score"]["symbol"] == "AAA"
    assert result["leaders"]["lower_debt_to_equity"]["symbol"] == "AAA"
    assert len(result["assets"]) == 2


def test_planner_adds_fundamental_tools() -> None:
    single = plan_query(AIAgentQuery(message="Analizá los fundamentales de AAPL", symbols=["AAPL"]))
    comparison = plan_query(AIAgentQuery(message="Compará los fundamentales", symbols=["AAPL", "MSFT"]))
    assert single["intent"] == "fundamental"
    assert [tool["name"] for tool in single["tools"]] == ["market_quote", "fundamental_analysis"]
    assert comparison["intent"] == "fundamental_compare"
    assert [tool["name"] for tool in comparison["tools"]] == ["asset_comparison", "fundamental_comparison"]


def test_follow_up_reuses_previous_symbol(tmp_path, monkeypatch) -> None:
    setup_temp_database(tmp_path, monkeypatch)

    def controlled_tool(name: str, arguments: dict) -> dict:
        if name == "market_quote":
            result = {"symbol": arguments["symbol"], "price": 100, "currency": "USD", "change_percent": 1, "source": "TEST"}
        else:
            result = analyze_fundamentals(arguments["symbol"], raw_fundamental)
        return {"name": name, "arguments": arguments, "status": "success", "duration_ms": 1, "result": result, "error": None}

    monkeypatch.setattr(agent_service, "execute_tool", controlled_tool)
    first = agent_service.run_agent_query(AIAgentQuery(message="Analizá los fundamentales de AAA", symbols=["AAA"], scope="fundamental", use_language_model=False))
    second = agent_service.run_agent_query(AIAgentQuery(message="¿Y qué riesgos tiene?", session_id=first["session_id"], use_language_model=False))
    assert second["intent"] == "fundamental"
    assert second["conversation_context"]["symbols"] == ["AAA"]
    assert any(tool["name"] == "fundamental_analysis" for tool in second["tools_used"])


def test_optional_llm_failure_uses_deterministic_fallback(tmp_path, monkeypatch) -> None:
    setup_temp_database(tmp_path, monkeypatch)

    class FailingProvider:
        def is_available(self):
            return True
        def rewrite(self, **kwargs):
            from backend.llm.base import LanguageModelError
            raise LanguageModelError("fallo controlado")

    monkeypatch.setattr(agent_service, "get_language_model_provider", lambda: FailingProvider())
    monkeypatch.setattr(agent_service, "language_model_status", lambda: {"provider": "test", "configured": True, "model": "test"})
    monkeypatch.setattr(agent_service, "execute_tool", lambda name, arguments: {
        "name": name, "arguments": arguments, "status": "success", "duration_ms": 1,
        "result": {"symbol": "AAA", "price": 100, "currency": "USD", "change_percent": 0, "source": "TEST"} if name == "market_quote" else analyze_fundamentals("AAA", raw_fundamental),
        "error": None,
    })
    response = agent_service.run_agent_query(AIAgentQuery(message="Fundamentales de AAA", symbols=["AAA"], scope="fundamental", use_language_model=True))
    assert response["language_model"]["fallback"] is True
    assert response["answer"] == response["deterministic_answer"]
    assert response["safety"]["llm_cannot_add_evidence"] is True


def test_alpha16_phase2_migration_adds_settings_and_backup(tmp_path, monkeypatch) -> None:
    setup_temp_database(tmp_path, monkeypatch)
    db_path = database.DATABASE_PATH
    with sqlite3.connect(db_path) as connection:
        connection.execute("DELETE FROM schema_migrations WHERE version = 14")
        connection.execute("DROP TABLE IF EXISTS ai_agent_settings")
        connection.commit()
    initialize_database()
    with sqlite3.connect(db_path) as connection:
        version = connection.execute("SELECT 1 FROM schema_migrations WHERE version = 14").fetchone()
        columns = {row[1] for row in connection.execute("PRAGMA table_info(ai_analysis_sessions)")}
        setting = connection.execute("SELECT use_language_model, response_style FROM ai_agent_settings WHERE portfolio_id = 1").fetchone()
    assert version is not None
    assert {"last_intent", "context_symbols_json"}.issubset(columns)
    assert setting == (1, "claro")
    assert list((database.DATA_DIR / "backups").glob("quantlab_pre_alpha16_phase2_*.db"))


def test_phase2_api_exposes_fundamental_and_agent_settings(monkeypatch) -> None:
    from backend.api import ai as ai_api

    monkeypatch.setattr(ai_api, "get_fundamental_data", raw_fundamental)
    with TestClient(app) as client:
        fundamental = client.get("/api/v1/ai/fundamentals/AAA")
        settings = client.get("/api/v1/ai/agent/settings?portfolio_id=1")
        updated = client.put("/api/v1/ai/agent/settings?portfolio_id=1", json={"use_language_model": False, "response_style": "breve"})
        capabilities = client.get("/api/v1/ai/agent/capabilities")
    assert fundamental.status_code == 200
    assert fundamental.json()["scores"]["overall"] is not None
    assert settings.status_code == 200
    assert updated.json()["response_style"] == "breve"
    assert len(capabilities.json()["tools"]) == 8
