@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul
cd /d "%~dp0"
title QuantLab AI 5.0 Beta - Iniciador

set "APP_URL=http://127.0.0.1:8000"
set "HEALTH_URL=http://127.0.0.1:8000/api/v1/health"
set "APP_HOST=127.0.0.1"
set "APP_PORT=8000"
set "VENV_DIR=.venv"
set "VENV_PY=%VENV_DIR%\Scripts\python.exe"
set "HASH_FILE=%VENV_DIR%\.quantlab_requirements.sha256"

echo.
echo ============================================================
echo             QUANTLAB AI 5.0 BETA - COMPLETA
echo ============================================================
echo.
echo Este paquete ya contiene todas las fases integradas.
echo No necesitas copiar ni ensamblar otras versiones.
echo.

if not exist "requirements.txt" (
    echo [ERROR] No se encontro requirements.txt.
    echo Ejecuta este archivo desde la carpeta principal de QuantLab AI.
    goto :error
)

rem Si QuantLab ya esta ejecutandose, solo abrir la web.
powershell -NoProfile -Command "try { $r=Invoke-RestMethod -Uri '%HEALTH_URL%' -TimeoutSec 2; if ($r.status -eq 'ok') { exit 0 } else { exit 1 } } catch { exit 1 }" >nul 2>&1
if not errorlevel 1 (
    echo QuantLab AI ya esta ejecutandose. Abriendo navegador...
    start "" "%APP_URL%"
    goto :end
)

rem Buscar Python: primero el lanzador py, luego python.
where py >nul 2>&1
if not errorlevel 1 (
    set "PY_CMD=py -3"
) else (
    where python >nul 2>&1
    if errorlevel 1 (
        echo [ERROR] Python no esta instalado o no esta agregado al PATH.
        echo Instala Python 3.11 o superior desde python.org.
        echo Durante la instalacion, marca "Add Python to PATH".
        goto :error
    )
    set "PY_CMD=python"
)

%PY_CMD% -c "import sys; raise SystemExit(0 if sys.version_info >= (3, 11) else 1)" >nul 2>&1
if errorlevel 1 (
    echo [ERROR] QuantLab AI requiere Python 3.11 o superior.
    %PY_CMD% --version
    goto :error
)

if not exist "%VENV_PY%" (
    echo [1/4] Creando entorno virtual...
    %PY_CMD% -m venv "%VENV_DIR%"
    if errorlevel 1 (
        echo [ERROR] No se pudo crear el entorno virtual.
        goto :error
    )
    set "NEW_VENV=1"
) else (
    echo [1/4] Entorno virtual encontrado.
)

rem Calcular hash de requirements.txt para instalar solo cuando cambie.
set "REQ_HASH="
for /f "tokens=*" %%H in ('certutil -hashfile requirements.txt SHA256 ^| findstr /r /v /c:"^[ ]*$" /c:"CertUtil" /c:"hash" /c:"Hash"') do (
    if not defined REQ_HASH set "REQ_HASH=%%H"
)
if defined REQ_HASH set "REQ_HASH=!REQ_HASH: =!"

set "OLD_HASH="
if exist "%HASH_FILE%" set /p OLD_HASH=<"%HASH_FILE%"

set "INSTALL_DEPS=0"
if defined NEW_VENV set "INSTALL_DEPS=1"
if not defined REQ_HASH set "INSTALL_DEPS=1"
if /i not "!REQ_HASH!"=="!OLD_HASH!" set "INSTALL_DEPS=1"

"%VENV_PY%" -c "import fastapi, uvicorn, pydantic, httpx, yfinance, pandas, numpy" >nul 2>&1
if errorlevel 1 set "INSTALL_DEPS=1"

if "!INSTALL_DEPS!"=="1" (
    echo [2/4] Instalando o actualizando dependencias...
    "%VENV_PY%" -m pip install --upgrade pip
    if errorlevel 1 goto :dependency_error

    "%VENV_PY%" -m pip install -r requirements.txt
    if errorlevel 1 goto :dependency_error

    "%VENV_PY%" -m pip check
    if errorlevel 1 goto :dependency_error

    if defined REQ_HASH >"%HASH_FILE%" echo !REQ_HASH!
) else (
    echo [2/4] Dependencias actualizadas. No es necesario reinstalar.
)

if not exist "data" mkdir "data"
if not exist "data\backups" mkdir "data\backups"
if not exist "data\logs" mkdir "data\logs"

echo [3/4] Preparando apertura del navegador...
start "" powershell -NoProfile -WindowStyle Hidden -Command "$u='%APP_URL%'; $h='%HEALTH_URL%'; for($i=0;$i -lt 60;$i++){try{$r=Invoke-RestMethod -Uri $h -TimeoutSec 2;if($r.status -eq 'ok'){Start-Process $u;exit}}catch{};Start-Sleep -Seconds 1};Start-Process $u"

echo [4/4] Iniciando servidor en %APP_URL%
echo.
echo Para cerrar QuantLab AI, presiona CTRL+C en esta ventana.
echo No cierres esta ventana mientras uses la aplicacion.
echo.

set "QUANTLAB_ENV=desktop"
"%VENV_PY%" -m uvicorn backend.main:app --host %APP_HOST% --port %APP_PORT%

if errorlevel 1 (
    echo.
    echo [ERROR] El servidor se cerro por un problema.
    echo Podes ejecutar verificar_windows.bat para obtener un diagnostico.
    goto :error
)

goto :end

:dependency_error
echo.
echo [ERROR] No se pudieron instalar o validar las dependencias.
echo Revisa tu conexion a Internet y vuelve a ejecutar iniciar_windows.bat.
goto :error

:error
echo.
pause
exit /b 1

:end
endlocal
