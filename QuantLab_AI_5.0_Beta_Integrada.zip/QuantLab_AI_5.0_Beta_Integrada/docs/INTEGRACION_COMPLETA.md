# Integración completa — QuantLab AI 5.0 Beta

## Objetivo

Esta entrega reemplaza el sistema anterior de descargas por fases. El código de Alpha 1.4, Alpha 1.5 y Alpha 1.6 está acumulado en un único proyecto ejecutable.

## Alcance verificado

| Área | Implementación principal | Pruebas asociadas |
|---|---|---|
| Mercado | `backend/providers`, `market_service.py` | API, datos y plataforma |
| Portafolios | `portfolio_service.py`, API portfolio | portafolio, multiactivo y múltiples carteras |
| Edición y auditoría | ledger y `portfolio_audit_log` | safe editing |
| Multimoneda | conversiones FX y cajas por moneda | multicurrency cash |
| Portabilidad | CSV y `.qlbackup` | data portability |
| Analytics | `analytics_service.py` | Alpha 1.5 Fase 1 |
| Dividendos | `dividends_service.py` | Alpha 1.5 Fase 2 |
| Eventos corporativos | `corporate_actions_service.py` | Alpha 1.5 Fase 3 |
| Riesgo avanzado | `advanced_analytics_service.py` | Alpha 1.5 Fase 4 |
| Agente verificable | `backend/agents` | Alpha 1.6 Fase 1 |
| Fundamentales | `fundamental_service.py` | Alpha 1.6 Fase 2 |
| Alertas y memoria | `alerts.py`, `memory.py` | Alpha 1.6 Fase 3 |

## Base de datos

- Esquema actual: 15.
- Las migraciones se ejecutan en orden y son idempotentes.
- Una instalación nueva crea automáticamente las tablas necesarias.
- Una base anterior se respalda antes de aplicar migraciones.

## Criterio de integración

La versión se considera integrada cuando:

- todos los módulos anteriores están presentes en el mismo árbol de código;
- la suite completa pasa sin copiar dependencias entre fases;
- el frontend referencia una única API;
- el iniciador parte desde la raíz del proyecto;
- el paquete no incluye una base ni logs de prueba;
- la documentación indica que no se deben mezclar releases.

## Validación realizada

- 114 pruebas automatizadas aprobadas.
- Backend compilado correctamente.
- JavaScript validado con Node.
- 332 identificadores HTML sin duplicados.
- API v1 comprobada por la suite.
- Datos de ejecución y pruebas eliminados antes del empaquetado.

## Material de cursos

La integración incluye únicamente documentación y código ya adaptado al proyecto. Los ZIP/RAR originales de los cursos no se redistribuyen dentro del release.

La auditoría está en `docs/AUDITORIA_CURSOS_ORIGINALES.md` y el inventario de adaptación en `docs/REUTILIZACION_CURSOS.md`.
