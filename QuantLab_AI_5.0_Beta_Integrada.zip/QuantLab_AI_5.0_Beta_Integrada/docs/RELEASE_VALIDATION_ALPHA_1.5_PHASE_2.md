# Validación del release — Alpha 1.5, fase 2

- Esquema esperado: 10.
- Backup previo desde fase 1: `quantlab_pre_alpha15_phase2_*.db`.
- Dividendos brutos, retenciones y netos verificados.
- Reinversión vinculada a una compra verificada.
- Importación y duplicados verificados.
- Calendario histórico y estimado verificado con datos controlados.
- Atribución de precio y FX para posiciones abiertas verificada.
- API `/api/v1` y alias heredado comprobados por el conjunto de pruebas.
- Frontend validado con JavaScript sintácticamente correcto.
- Uso educativo y proyecciones no confirmadas documentados.

- Eliminación y restauración sincronizada de reinversiones verificada.
- Borrado aislado de compras vinculadas correctamente rechazado.
- Editor genérico bloqueado para dividendos avanzados.
- 71 pruebas automatizadas aprobadas.
