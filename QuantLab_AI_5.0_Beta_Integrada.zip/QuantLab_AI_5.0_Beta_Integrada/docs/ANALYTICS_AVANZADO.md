# Analytics avanzado — Alpha 1.5 fase 4

## Objetivo

Completar Alpha 1.5 con métricas de riesgo multiactivo, comparación contra benchmark, análisis de diversificación y una salida estructurada para el futuro agente AI.

## Métricas incorporadas

- Sortino y desviación bajista anualizada.
- VaR histórico diario al 95% y 99%.
- CVaR / Expected Shortfall al 95% y 99%.
- Calmar y Omega educativos.
- Beta, correlación, alpha estimado, tracking error e information ratio.
- Captura alcista y bajista contra benchmark.
- Matriz de correlación y covarianza anualizada.
- Contribución marginal y porcentual de cada posición al riesgo.
- Concentración por sector e industria con cobertura explícita.
- Comparador de dos a seis activos en moneda base.
- Atribución por posición entre precio abierto, FX abierto, dividendos y P&L realizado combinado.

## Metodología

Los históricos de cada activo se convierten a la moneda base antes de calcular retornos. Las series se alinean por fecha y se completan hacia adelante únicamente después de que existe un dato válido. Los activos manuales o sin histórico se excluyen de la matriz y generan un estado parcial visible.

El VaR es histórico: utiliza percentiles de los retornos observados y no supone una distribución normal. El CVaR es la pérdida promedio de los retornos iguales o peores que el umbral VaR.

La contribución al riesgo usa la matriz de covarianza anualizada y pesos de mercado actuales:

```text
contribución = peso × riesgo marginal / volatilidad del portafolio
```

Puede haber contribuciones negativas cuando un activo reduce el riesgo agregado por su covarianza.

## Sector e industria

Yahoo Finance se usa como fuente de metadatos cuando los ofrece. Los activos sin clasificación aparecen como `Sin clasificar`; QuantLab informa el porcentaje de cobertura para evitar presentar una distribución incompleta como si fuera total.

## Comparador

El comparador admite hasta seis símbolos. Convierte las monedas, normaliza los precios a base 100 y calcula rendimiento, volatilidad, drawdown, Sortino y VaR 95.

## Reportes

`GET /api/v1/analytics/export.csv` produce un CSV UTF-8 con métricas, contribución al riesgo, atribución por posición y alertas estructuradas.

## Alcances y límites

- Todas las métricas son educativas.
- El P&L realizado histórico continúa agrupando precio, FX y comisiones porque las operaciones existentes usan costo promedio y no lotes fiscales individuales.
- La clasificación sectorial depende de la disponibilidad del proveedor.
- VaR y CVaR describen el pasado y no establecen una pérdida máxima futura.
