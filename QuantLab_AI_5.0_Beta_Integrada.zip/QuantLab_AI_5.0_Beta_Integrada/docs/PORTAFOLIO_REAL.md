# Portafolio real: diseño técnico

## Flujo

```text
Formulario HTML
  └─ JavaScript / Fetch
       └─ FastAPI: backend/api/portfolio.py
            └─ Reglas: backend/services/portfolio_service.py
                 ├─ SQLite: operaciones y configuración
                 └─ market_service.py: cotizaciones e históricos
```

## Tablas SQLite

### `portfolio_settings`

Guarda el nombre, la moneda base y el capital inicial. Existe una sola fila con `id = 1` en esta etapa.

### `portfolio_transactions`

Guarda:

- símbolo;
- tipo `BUY` o `SELL`;
- cantidad;
- precio ejecutado;
- comisiones;
- fecha y hora;
- notas.

Las posiciones no se guardan como una tabla separada: se reconstruyen desde el historial de operaciones. Esto evita que una posición quede desincronizada respecto de sus compras y ventas.

## Ledger

Las operaciones se ordenan por fecha e identificador.

### Compra

```text
costo = cantidad × precio + comisiones
nuevo efectivo = efectivo anterior − costo
nuevo costo acumulado = costo anterior + costo
```

### Precio promedio

```text
precio promedio = costo acumulado / cantidad actual
```

### Venta

```text
ganancia realizada = cantidad vendida × (precio venta − precio promedio) − comisión
```

La venta reduce el costo acumulado usando el precio promedio vigente antes de esa venta.

## Valuación

Para cada posición abierta, el backend consulta `yfinance`:

```text
valor de mercado = cantidad × precio actual
ganancia no realizada = valor de mercado − costo acumulado
patrimonio = efectivo + valor de mercado
resultado total = patrimonio − capital inicial
```

Si una cotización falla, la aplicación conserva la posición y usa temporalmente su costo acumulado para no perder el ledger. La respuesta marca la valuación como parcial.

## Curva patrimonial

El endpoint reconstruye el portafolio día por día:

1. descarga cierres históricos de los símbolos operados;
2. aplica las compras y ventas que corresponden a cada fecha;
3. actualiza el efectivo;
4. valúa las cantidades abiertas con el último cierre conocido;
5. devuelve puntos de patrimonio, efectivo y valor de mercado.

## Endpoints

```http
GET /api/portfolio
GET /api/portfolio/settings
PUT /api/portfolio/settings
GET /api/portfolio/transactions
POST /api/portfolio/transactions
POST /api/portfolio/transactions/{id}/preview
PUT /api/portfolio/transactions/{id}
DELETE /api/portfolio/transactions/{id}   # borrado lógico
POST /api/portfolio/transactions/{id}/restore
GET /api/portfolio/equity-curve?period=3mo
```

## Reglas de seguridad de datos

- No se puede comprar con efectivo insuficiente.
- No se puede vender más cantidad que la disponible en la fecha elegida.
- No se puede eliminar lógicamente una compra si deja una venta posterior sin respaldo.
- Toda corrección se valida mediante reconstrucción completa del ledger.
- Los registros eliminados pueden restaurarse y conservan auditoría.
- No se puede cambiar la moneda base con operaciones existentes.
- No se pueden mezclar cotizaciones de otra moneda sin conversión FX.
- No se permiten operaciones fechadas en el futuro.
