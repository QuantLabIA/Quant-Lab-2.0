# Validación del release — Alpha 1.5 Fase 1

**Fecha:** 31 de julio de 2026  
**Versión:** `4.1.0-alpha.1.5.1`  
**Esquema SQLite:** 9

## Comprobaciones completadas

- 63 pruebas automatizadas aprobadas.
- Backend Python compilado sin errores.
- JavaScript validado con `node --check`.
- 246 identificadores HTML únicos, sin duplicados.
- Navegación y controles de Analytics presentes.
- API principal, `/api/v1/health`, documentación y OpenAPI responden correctamente.
- Endpoints Analytics visibles en OpenAPI.
- Migración desde esquema 8 simulada y comprobada.
- Backup previo `quantlab_pre_alpha15_phase1_*` comprobado.
- Configuración de benchmark aislada por portafolio.
- TWR, volatilidad, Sharpe y drawdown validados con casos deterministas.
- Benchmark, concentración y rendimiento por posición validados con proveedores falsos controlados.

## Dependencia externa no ejecutada en este entorno

El entorno de empaquetado no tiene instalado `yfinance`, por lo que no se ejecutó una descarga real durante la validación final. La dependencia está declarada en `requirements.txt` y `iniciar_windows.bat` la instala y comprueba antes de iniciar la aplicación.

Las pruebas automatizadas aíslan Internet deliberadamente para que el release no dependa de disponibilidad externa.

## Resultado

La Fase 1 se considera apta para instalación local y para continuar con Alpha 1.5 Fase 2. Las métricas siguen marcadas como educativas y los eventos corporativos/dividendos avanzados permanecen pendientes según `ROADMAP.md`.
