# Validación del release — Alpha 1.5, fase 3

**Fecha:** 31 de julio de 2026  
**Esquema esperado:** 11  
**Pruebas automatizadas:** 83

## Cobertura

- Split y reverse split.
- Dividendo en acciones.
- Cambio de ticker y alias.
- Fusión por acciones.
- Spin-off y asignación de costo.
- Devolución de capital y exceso sobre base.
- Vista previa, corrección, borrado lógico y restauración.
- API v1.
- Migración desde esquema 10 y backup previo.
- Compatibilidad con las 71 pruebas de fases anteriores.

## Comandos

```powershell
pytest -q
python -m compileall backend
node --check frontend/assets/js/app.js
```

## Resultado

El release no genera una base de datos de demostración dentro del ZIP. La instalación crea `data/quantlab.db` en el primer inicio.
