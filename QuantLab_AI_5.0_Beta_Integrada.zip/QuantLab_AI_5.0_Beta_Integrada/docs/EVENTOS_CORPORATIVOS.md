# Eventos corporativos — Alpha 1.5, fase 3

## Objetivo

Mantener cantidades, costo y patrimonio correctos cuando una empresa modifica sus acciones o estructura societaria. Los eventos se procesan dentro del mismo replay cronológico que compras, ventas, efectivo y conversiones FX.

## Reglas contables implementadas

### Split y reverse split

```text
cantidad nueva = cantidad anterior × ratio
costo total nuevo = costo total anterior
```

El precio promedio cambia de forma inversa al ratio.

### Cambio de ticker

La posición completa se mueve al nuevo símbolo. Se conservan cantidad, costo y P&L realizado acumulado. También se registra un alias de mercado.

### Fusión por acciones

```text
cantidad destino = cantidad origen × ratio de intercambio
costo destino = costo origen
```

La fase 3 cubre fusiones por intercambio de acciones. Las fusiones complejas con efectivo y tratamientos fiscales jurisdiccionales deberán modelarse con eventos separados y revisión profesional.

### Spin-off

```text
cantidad hija = cantidad matriz × ratio
costo hija = costo matriz × porcentaje asignado
costo matriz nuevo = costo matriz anterior − costo hija
```

La suma del costo de ambas posiciones permanece igual.

### Dividendo en acciones

```text
acciones adicionales = acciones existentes × ratio
```

No se acredita efectivo ni se registra ingreso. El costo total se mantiene.

### Devolución de capital

El efectivo se acredita en su moneda y reduce la base de costo. Si el importe supera la base disponible, el exceso se reconoce como resultado realizado dentro del motor educativo.

## Seguridad

- Vista previa con replay completo.
- Rechazo de eventos anteriores a la tenencia.
- Corrección con revisión incremental.
- Eliminación lógica.
- Restauración validada.
- Auditoría antes/después.
- Backup previo a la migración.

## Limitaciones

- No se calcula tratamiento impositivo específico por país.
- Las fusiones mixtas complejas deben separarse en eventos verificables.
- Los ratios y porcentajes deben confirmarse con documentación oficial del emisor o broker.
- La importación automática de eventos desde un proveedor queda para una integración posterior; en esta fase el registro es manual y auditable.

## Integración con dividendos y CSV

- La cantidad histórica usada al registrar o importar dividendos se reconstruye con el ledger completo, incluyendo eventos corporativos previos.
- Los eventos pueden importarse en el CSV unificado con `record_type=CORPORATE_ACTION`.
- La vista previa valida cronológicamente el evento antes de confirmar y evita duplicados por fingerprint.
- Existe una exportación específica de eventos corporativos.
