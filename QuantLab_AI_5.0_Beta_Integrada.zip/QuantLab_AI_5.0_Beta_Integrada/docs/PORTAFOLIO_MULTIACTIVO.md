# Portafolio multiactivo y multimoneda

## Arquitectura

```text
Frontend HTML/CSS/JS
        ↓ Fetch JSON
FastAPI
        ↓
Portfolio Service ── Market Service
        ↓                  ↓
SQLite              yfinance / Yahoo Finance
```

## Libro contable

Desde Alpha 1.4 fase 3, cada operación impacta primero el saldo real de la moneda del activo. La moneda base se utiliza para valuar y comparar, no como una caja universal. El sistema conserva:

- precio y comisión en moneda local;
- saldo de efectivo independiente por moneda;
- costo histórico de cada caja en moneda base;
- moneda del activo;
- tasa FX a moneda base;
- costo histórico en moneda base;
- cantidad y precio promedio;
- ganancia realizada.

## Flujos externos

Los depósitos y retiros modifican el patrimonio, pero no son rentabilidad. Por eso la ganancia de inversión se calcula como:

```text
Ganancia de inversión = patrimonio actual - capital inicial - depósitos + retiros
```

Los dividendos e intereses sí son rendimiento. Los impuestos y gastos lo reducen.

## XIRR

XIRR utiliza las fechas reales del capital inicial, depósitos, retiros y patrimonio final. Se resuelve numéricamente mediante búsqueda por bisección sobre el valor presente neto irregular.

## TWR

La curva calcula subperíodos diarios. En los días con depósitos o retiros, elimina el efecto del flujo externo antes de encadenar el rendimiento:

```text
Retorno del subperíodo = (patrimonio final - flujo externo) / patrimonio anterior - 1
```

## Cobertura de activos

### Automáticos

La búsqueda acepta el universo publicado por Yahoo Finance, incluyendo normalmente:

- acciones y ADR;
- ETF;
- fondos;
- índices;
- criptomonedas;
- pares de divisas;
- futuros y commodities;
- algunos bonos y opciones, según disponibilidad del proveedor.

### Manuales

Permiten incluir activos sin símbolo público:

- inmuebles;
- bonos privados;
- participaciones en negocios;
- objetos de inversión;
- activos alternativos.

## Seguridad de datos

La migración desde Alpha 1.2 es no destructiva. Las tablas nuevas se crean con `CREATE TABLE IF NOT EXISTS` y las columnas se agregan sólo si faltan.
