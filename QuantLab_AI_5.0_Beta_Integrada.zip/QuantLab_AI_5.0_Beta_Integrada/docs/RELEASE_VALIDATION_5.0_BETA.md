# Validación de release — QuantLab AI 5.0 Beta Integrada

**Versión:** `5.0.0-beta.1-integrated`  
**Fecha:** 1 de agosto de 2026  
**Esquema SQLite:** 15

## Resultado

- 114 pruebas automatizadas aprobadas.
- Backend y pruebas compilados con `compileall`.
- JavaScript validado con `node --check`.
- 332 identificadores HTML y ninguno duplicado.
- `GET /api/v1/health` respondió 200 con la versión integrada.
- La página principal respondió 200.
- La documentación `/docs` respondió 200.
- El paquete contiene un único árbol de código con todas las fases acumuladas.

## Cobertura funcional incluida

- mercado y proveedores;
- watchlist;
- portafolios múltiples;
- ledger, edición y auditoría;
- efectivo y FX multimoneda;
- CSV, backups y restauración;
- Analytics y riesgo avanzado;
- dividendos y eventos corporativos;
- agente verificable y fundamentales;
- alertas y memoria de cambios.

## Limpieza del paquete

Antes del empaquetado se eliminaron:

- `data/quantlab.db`;
- logs de ejecución;
- backups generados por las pruebas;
- cachés de Python y pytest;
- archivos temporales.

Se conservaron únicamente archivos `.gitkeep` en las carpetas de datos.

## Limitación de la validación

Las pruebas de mercado utilizan datos controlados y no requieren Internet. No se efectuó una consulta en vivo a Yahoo Finance durante esta validación porque `yfinance` no está instalado en el entorno de construcción. El paquete lo declara en `requirements.txt` y `iniciar_windows.bat` lo instala en el equipo del usuario.
