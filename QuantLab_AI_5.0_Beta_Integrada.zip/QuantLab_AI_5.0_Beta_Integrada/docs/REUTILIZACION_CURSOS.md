# Inventario de reutilización de cursos — QuantLab AI

**Versión:** Alpha 1.5, fase 4  
**Objetivo:** registrar qué conocimientos y código de los cursos pueden reciclarse, qué ya se incorporó y qué material todavía falta localizar.

## 1. Código y estructuras ya disponibles

### Python financiero

El proyecto anterior y los materiales asociados ya trabajaban con:

- `pandas` para series temporales, limpieza, alineación y cálculos vectorizados;
- `numpy` para estadística y operaciones numéricas;
- `yfinance` para cotizaciones, históricos y eventos de mercado;
- Plotly como antecedente de gráficos interactivos;
- separación en carpetas `services`, `models`, `database` y `ui`.

**Reciclado en Alpha 1.5:**

- motor vectorizado de retornos TWR;
- volatilidad anualizada;
- ratio de Sharpe educativo;
- drawdown y curva de drawdown;
- benchmark normalizado en base 100;
- alineación de fechas y monedas;
- concentración por activo, moneda y categoría;
- replay cronológico de tenencias para dividendos;
- cálculo bruto/retención/neto;
- calendario estimado mediante intervalos históricos;
- atribución del P&L abierto entre precio y FX.

No se copió código de Flet ni Streamlit porque la interfaz oficial del proyecto es HTML, CSS y JavaScript. Se conserva únicamente la lógica financiera que puede desacoplarse de la interfaz.

### Desarrollo web

De la ruta de enseñanza web y del trabajo realizado en las fases anteriores se reutiliza:

- HTML semántico para formularios, tablas y navegación;
- CSS Grid/Flexbox y diseño responsive;
- JavaScript para DOM, eventos, filtros, gráficos SVG y almacenamiento local;
- `fetch()` para consumir la API;
- FastAPI para rutas versionadas y validación;
- SQLite y migraciones para persistencia local;
- pruebas automatizadas antes de cada release.

## 2. Conceptos del curso de trader incorporados

El curso de trader profesional enfatiza disciplina, proceso, control emocional, límites de pérdida y evaluación sistemática. En QuantLab esos conceptos se traducen en herramientas objetivas:

- drawdown máximo y actual;
- volatilidad;
- concentración;
- comparación contra benchmark;
- rendimiento por período y posición;
- advertencias educativas;
- separación entre aportes y ganancias;
- análisis del proceso antes de interpretar resultados.

No se transforman esas ideas en señales automáticas de compra o venta. El objetivo es mostrar información verificable para apoyar una revisión responsable.

## 3. Archivos originales auditados

Durante Alpha 1.5 se recibieron y revisaron los paquetes originales:

- `trading cuantitativo completo`: se recuperaron 51 programas Python y notebooks sobre métricas, optimización, indicadores, backtesting y brokers; el notebook final de redes neuronales está dañado.
- `enseñanza profesor chileno`: contiene indicadores, momentum, GARCH, volatilidad, modelos gaussianos, Kelly, portafolios y VaR.
- `estrategias profesor chileno`: contiene pares, cointegración, ADF, Hurst, Johansen, PCA, clustering y modelos experimentales.
- `por las dudas`: contiene plantillas de estrategias, backtesting, optimización e históricos multitemporales.
- `Desarrollo web.rar`: se inventariaron HTML, CSS, Grid, Flexbox, JavaScript, DOM, Fetch, Async/Await, SASS, Node, PHP y MVC. El entorno no pudo extraer RAR5 línea por línea; se espera una copia ZIP completa.
- `Python_Curso_Rapido.ipynb`: disponible como referencia básica de Python.

Antes de reutilizar un módulo se comprueba dependencia, ausencia de credenciales, compatibilidad y resultados con pruebas. Los ejemplos de brokers se mantienen aislados y no se conectan a ejecución real.

**Pendiente:** nueva copia íntegra de redes neuronales y ZIP completo de Desarrollo Web.

## 4. Matriz de reutilización

| Tema | Fuente disponible | Estado | Destino en QuantLab |
|---|---|---:|---|
| pandas y NumPy | Proyecto financiero previo | Incorporado | Motor de analytics |
| yfinance | Proyecto previo y arquitectura actual | Incorporado | Mercado, benchmark, FX y eventos históricos de dividendos |
| Plotly | Dependencia del proyecto previo | Evaluado | Posible fase visual posterior; Alpha 1.5 usa SVG sin Node |
| Dividendos históricos | API yfinance ya integrada | Incorporado | Importación, control de duplicados y calendario |
| Estadística de intervalos | Conceptos de pandas/Python | Incorporado | Frecuencia estimada y promedio de pagos |
| Indicadores técnicos | Motor AI actual | Incorporado parcialmente | Alpha 1.6 reutilizará RSI, SMA y volatilidad |
| Psicotrading y disciplina | Curso de trader | Incorporado como criterio | Panel de riesgo y métricas educativas |
| Backtesting | Trading cuantitativo y paquete “por las dudas” | Auditado | Laboratorio futuro, después del agente AI básico |
| Bot de Telegram | Archivos fuente no localizados | Pendiente | Alertas futuras, no Alpha 1.5 |
| Compra de criptomonedas | Archivos fuente no localizados | Pendiente | No se conectará ejecución real en esta etapa |
| HTML/CSS/JavaScript | Curso y proyectos web inventariados | Incorporado parcialmente | Frontend oficial; auditoría completa al recibir ZIP |
| FastAPI/SQLite | Arquitectura actual | Incorporado | Backend y persistencia |

## 5. Regla para próximas fases

Cada release deberá actualizar esta matriz indicando:

- archivo de origen;
- módulo reutilizado;
- cambios realizados;
- pruebas agregadas;
- código descartado y motivo.

De esta manera QuantLab crece aprovechando los cursos sin perder trazabilidad ni mezclar código incompatible.


## 6. Reutilización específica de Alpha 1.5 fase 2

### Código reutilizado y adaptado

- `MarketDataProvider.get_dividends()` y el proveedor Yahoo existente.
- Replay de operaciones del `PortfolioService` para conocer la tenencia histórica.
- Motor de FX histórico y actual para consolidar dividendos en moneda base.
- Auditoría, migraciones, API v1 y formularios web de las fases anteriores.
- Estadística estándar de Python para inferir intervalos y promedios del calendario.

### Implementado desde cero

- modelo bruto/retención/neto;
- compra vinculada por reinversión;
- preferencias de dividendos por portafolio;
- yield sobre costo y valor de mercado;
- atribución precio/FX de posiciones abiertas;
- calendario estimado con nivel de confianza.

### Material pendiente

Los archivos originales de trading ya fueron recibidos posteriormente. Esta fase no se reatribuyó retroactivamente: su implementación permanece propia y auditada.


## 7. Reutilización específica de Alpha 1.5 fase 3

### Código reutilizado y adaptado

- Replay cronológico del `PortfolioService`, ampliado para procesar eventos con prioridad temporal.
- Modelos Pydantic, validación previa y manejo uniforme de errores.
- Auditoría, revisiones, eliminación lógica y restauración de Alpha 1.4.
- Catálogo multiactivo y alias de símbolos de la capa de mercado.
- Curva patrimonial y Analytics de Alpha 1.5 fase 1.
- Frontend HTML/CSS/JavaScript con `fetch()` y vistas previas.

### Conceptos de cursos aplicados

- Separar datos de mercado, reglas del negocio y presentación.
- Reproducir los eventos en orden temporal antes de calcular resultados.
- Validar el impacto completo antes de persistir cambios.
- Mantener trazabilidad para poder revisar el proceso, no sólo el resultado final.

### Implementado desde cero

- tabla `portfolio_corporate_actions`;
- motor de split, reverse split, ticker, fusión, spin-off, dividendo en acciones y devolución de capital;
- asignación de costo entre activo matriz y activo escindido;
- reducción de base de costo y reconocimiento del exceso en devoluciones de capital;
- integración de eventos en la curva patrimonial;
- API, interfaz y pruebas específicas.

### Material pendiente

No se encontró un módulo completo de eventos corporativos en los archivos auditados. Esta implementación continúa siendo propia de QuantLab.


## 8. Reutilización específica de Alpha 1.5 fase 4

### Fuentes auditadas utilizadas

- `07 - Métricas de Rendimiento/03 - Coeficiente de Sortino.py`: concepto de penalizar sólo volatilidad negativa.
- `07 - Métricas de Rendimiento/02 - Coeficiente de Sharpe.py` y `04 - Máximo Retroceso.py`: contraste y validación metodológica.
- `08 - Optimización de Portafolios/01 y 02`: retornos, volatilidad, pesos, covarianza y diversificación.
- `5_VaR+and+LVAR.ipynb`: referencia para percentiles históricos de pérdida.
- Curso del profesor chileno: gestión de riesgo, covarianzas y análisis de cartera.
- Material web inventariado: Grid/Flexbox, DOM, Fetch y diseño responsive ya presentes en el frontend.

### Adaptación realizada

El código educativo original estaba orientado a scripts y notebooks aislados. QuantLab no lo copió literalmente: se reescribió como servicios puros, API FastAPI, respuestas JSON, estados parciales y pruebas automatizadas. Se corrigieron además supuestos como acceso posicional ambiguo en pandas, ausencia de manejo de datos faltantes y dependencia directa de descargas online.

### Implementado en esta fase

- Sortino y desviación bajista.
- VaR/CVaR histórico 95/99.
- Beta, alpha, tracking error, information ratio y captura.
- Correlación, covarianza y contribución al riesgo.
- Comparador multiactivo.
- Sector/industria y cobertura de metadatos.
- Exportación y resumen estructurado para AI.

### No incorporado todavía

- Redes neuronales: se espera una copia íntegra.
- GARCH y optimización avanzada: quedan para un laboratorio posterior, no para el agente AI inicial.
- Ejecución con OANDA, FXCM o Interactive Brokers: excluida por seguridad.
- Curso web completo: se ampliará la auditoría cuando llegue en ZIP.

## 9. Reutilización específica de Alpha 1.6 fase 1

### Código y arquitectura reutilizados

- `AIService` técnico de Alpha 1.1 para SMA, RSI y volatilidad.
- `PortfolioService` como fuente única del ledger y patrimonio.
- `AnalyticsService` y `AdvancedAnalyticsService` para riesgo, benchmark y concentración.
- `MarketDataProvider` para desacoplar la fuente de mercado.
- FastAPI, Pydantic, SQLite, migraciones, backups y API v1.
- HTML/CSS/JavaScript, Fetch, estados de carga y diseño responsive.

### Conceptos de los cursos aplicados

- separar adquisición de datos, cálculo e interpretación;
- medir riesgo junto con rendimiento;
- registrar el proceso y no sólo el resultado;
- mostrar límites de datos antes de emitir una conclusión;
- evitar mezclar ejecución de órdenes con análisis.

### Implementado desde cero

- planificador de intención del agente;
- registro de herramientas y fuentes;
- respuesta por secciones verificables;
- historial de conversaciones por portafolio;
- barreras que impiden cualquier modificación financiera;
- interfaz de consultas sugeridas e historial.

### Material pendiente

- redes neuronales: no se integran hasta recibir una copia íntegra y auditarla;
- curso web completo en ZIP: se revisará para mejorar la interfaz en fases posteriores;
- modelos generativos externos: se evaluarán sólo después de validar la trazabilidad determinística.


## Alpha 1.6 Fase 2

Se reutilizaron la arquitectura por servicios, normalización de datos, métricas financieras y patrones de comparación presentes en los materiales auditados. El motor específico de fundamentales y la integración segura del LLM fueron desarrollados para QuantLab porque no se encontró un módulo completo y compatible que cubriera estas funciones. No se incorporaron credenciales, órdenes de broker ni notebooks sin validar.

## Alpha 1.6 Fase 3

Se reutilizaron las métricas de riesgo ya adaptadas de los cursos —drawdown, volatilidad y concentración— como entradas verificables para reglas educativas. La arquitectura de cola prepara una futura integración con el material del bot de Telegram, pero no se copió ni ejecutó código de mensajería porque ese paquete todavía no fue auditado de forma completa.

Implementado desde cero para QuantLab:

- motor de reglas y eventos;
- estados atendido, descartado y resuelto;
- snapshots estructurados con fingerprint;
- comparación de cambios materiales;
- outbox sin entrega externa;
- interfaz web de alertas y memoria.
