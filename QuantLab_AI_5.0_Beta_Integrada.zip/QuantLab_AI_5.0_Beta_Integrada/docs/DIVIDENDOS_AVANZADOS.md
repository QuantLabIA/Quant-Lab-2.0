# Dividendos avanzados — Alpha 1.5, fase 2

## Objetivo

Registrar dividendos sin confundir el importe anunciado con el efectivo efectivamente recibido. QuantLab conserva por separado:

- dividendo bruto;
- retención impositiva;
- dividendo neto;
- moneda y tasa FX histórica;
- cantidad de acciones en la fecha;
- importe por acción;
- fuente manual o Yahoo Finance;
- reinversión y operación de compra vinculada.

## Modelo contable

El ledger acredita únicamente el **dividendo neto** en la caja real de la moneda correspondiente.

```text
Dividendo neto = dividendo bruto − retención
```

El bruto y la retención permanecen como metadatos auditables. No se crea un movimiento de impuesto separado para la retención, evitando descontarla dos veces.

Cuando se activa la reinversión:

```text
Cantidad reinvertida = (dividendo neto − comisión) / precio de reinversión
```

QuantLab crea una compra vinculada en la misma fecha. El dividendo acredita efectivo antes de que la compra lo utilice.

La compra vinculada no puede eliminarse de forma independiente. Al eliminar o restaurar el dividendo, QuantLab aplica la misma acción a la reinversión dentro de una sola validación del ledger y registra ambos cambios en la auditoría. Para conservar bruto, retención y vínculo, los dividendos no se editan desde el editor genérico de movimientos: se eliminan y vuelven a registrar desde el módulo Dividendos.

## Importación desde Yahoo Finance

La importación:

1. consulta el historial de dividendos;
2. reconstruye la cantidad de acciones que existía en cada fecha;
3. calcula el importe bruto;
4. aplica la retención configurada;
5. evita duplicados con el marcador `AUTO_DIVIDEND:símbolo:fecha`;
6. opcionalmente usa el cierre histórico más cercano para reinvertir.

Las fechas e importes importados son históricos. Las proyecciones futuras del calendario son estimaciones estadísticas y se muestran diferenciadas de los pagos registrados.

## Calendario estimado

La frecuencia se infiere con la mediana de los intervalos históricos recientes. El importe se aproxima con el promedio de los últimos eventos registrados.

Limitaciones:

- no confirma anuncios corporativos;
- no contempla automáticamente cambios futuros en la política de dividendos;
- una empresa puede suspender, reducir o modificar pagos;
- con poco historial la confianza se marca como baja.

## Atribución precio/FX

Para posiciones abiertas se reconstruyen dos componentes:

- **efecto precio:** variación del valor local medida con el FX promedio de adquisición;
- **efecto FX:** cambio de la moneda del activo respecto de la moneda base.

La suma se reconcilia contra el P&L no realizado del ledger. El P&L realizado histórico continúa combinado porque una venta puede mezclar precio, tipo de cambio y comisiones.

## API

```text
GET  /api/v1/portfolio/dividends
POST /api/v1/portfolio/dividends
GET  /api/v1/portfolio/dividends/settings
PUT  /api/v1/portfolio/dividends/settings
GET  /api/v1/portfolio/dividends/summary
POST /api/v1/portfolio/dividends/import/{symbol}
```

## Persistencia

El esquema 10 agrega columnas a `portfolio_cash_movements` y crea `portfolio_dividend_settings`.

Antes de migrar se genera:

```text
data/backups/quantlab_pre_alpha15_phase2_FECHA.db
```
