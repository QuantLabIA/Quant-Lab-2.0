# Alertas educativas y memoria de cambios — Alpha 1.6 Fase 3

## Principio de seguridad

Las alertas son observaciones educativas. No tienen permisos para:

- comprar o vender;
- modificar operaciones;
- cambiar límites del portafolio;
- enviar órdenes a brokers;
- generar notificaciones externas en segundo plano.

## Tipos de regla

| Tipo | Valor observado | Se activa cuando |
|---|---|---|
| `CONCENTRATION` | peso de la mayor posición | supera el umbral |
| `DRAWDOWN` | drawdown actual absoluto | supera el umbral |
| `VOLATILITY` | volatilidad anualizada | supera el umbral |
| `PRICE_ABOVE` | última referencia del símbolo | alcanza o supera el precio |
| `PRICE_BELOW` | última referencia del símbolo | alcanza o baja del precio |

## Ciclo de un evento

```text
ACTIVE → ACKNOWLEDGED
ACTIVE → DISMISSED
ACKNOWLEDGED/DISMISSED → ACTIVE
cualquier estado abierto → RESOLVED cuando desaparece la condición
```

Los eventos resueltos se conservan para trazabilidad.

## Memoria

La memoria no guarda “opiniones” como fuente. Guarda JSON estructurado con valores seleccionados y un hash SHA-256.

La comparación usa tolerancias para evitar ruido:

- precios y patrimonio: cambio relativo mínimo aproximado de 0,5%;
- porcentajes y ratios: cambio absoluto mínimo aproximado de 0,5 puntos;
- cantidad de posiciones: al menos una unidad;
- estados textuales: cambio exacto.

## Preparación de notificaciones

Cada alerta nueva crea una entrada `PENDING` en `ai_notification_outbox` con canal `IN_APP`. La tabla permite agregar después adaptadores para email, push o Telegram sin modificar el motor de reglas.

En esta fase ningún worker procesa la cola y no existe ejecución en segundo plano.
