# Analytics y riesgo — Alpha 1.5 Fase 1

## Objetivo

Agregar una capa de medición educativa sobre el ledger real de cada portafolio. Los cálculos se realizan en el backend con `pandas` y `numpy`; el frontend solamente presenta resultados normalizados.

## Retorno TWR

El retorno diario neutraliza depósitos y retiros:

```text
retorno diario = (patrimonio final - flujo externo) / patrimonio anterior - 1
```

Los retornos se enlazan geométricamente. Dividendos, intereses, impuestos, gastos y operaciones permanecen dentro del rendimiento porque forman parte del resultado de inversión; depósitos y retiros se consideran flujos externos.

## Períodos

La API admite:

```text
1mo, 3mo, 6mo, 1y, 2y, 5y, max
```

La pantalla muestra:

- último día;
- mes actual;
- año actual;
- período seleccionado;
- desde el inicio;
- retorno acumulado normalizado.

## Benchmark

Cada portafolio guarda su propia configuración:

- SPY — S&P 500;
- QQQ — Nasdaq 100;
- `^MERV` — S&P Merval;
- BTC-USD — Bitcoin;
- símbolo personalizado;
- sin benchmark.

El benchmark y el portafolio se alinean por fecha, se completan únicamente valores anteriores conocidos y se normalizan a base 100. Si la moneda es distinta, el benchmark se convierte a la moneda base con histórico FX.

## Riesgo

### Volatilidad anualizada

Desvío estándar muestral de los retornos diarios multiplicado por la raíz de 252.

### Sharpe educativo

Exceso de retorno diario sobre una tasa libre de riesgo configurable, dividido por la volatilidad diaria y anualizado con raíz de 252.

No se interpreta como garantía ni recomendación de inversión.

### Drawdown

Caída porcentual de la curva TWR respecto de su máximo acumulado. Se informa drawdown actual, máximo, mejor día y peor día.

## Concentración

Se calcula por:

- activo, incluyendo efectivo por moneda;
- moneda;
- tipo de activo.

También se informa HHI y un puntaje educativo de diversificación. El análisis por sector queda pendiente porque depende de metadatos de mercado consistentes.

## Rendimiento por posición

Para cada activo se muestra:

- costo base;
- valor de mercado;
- P&L realizado;
- P&L no realizado;
- dividendos;
- resultado total;
- retorno total sobre costo.

## Descomposición del resultado

Alpha 1.5 Fase 1 separa:

- precio y operaciones;
- dividendos;
- intereses;
- efectivo y P&L FX;
- impuestos y comisiones.

La separación fina entre movimiento del precio del activo y efecto cambiario propio de un activo multimoneda queda pendiente para una fase posterior.

## API

```text
GET /api/v1/analytics/settings
PUT /api/v1/analytics/settings
GET /api/v1/analytics/overview?period=1y
```

Todos los endpoints aceptan `portfolio_id` y respetan el portafolio activo.

## Límites conocidos

- Los resultados dependen de la calidad y disponibilidad de Yahoo Finance.
- Los activos manuales se valúan con el último precio manual; no generan una serie histórica automática.
- Calendarios distintos pueden reducir la cantidad de fechas comparables.
- No se calculan todavía beta, VaR, correlaciones ni análisis sectorial.
- Los eventos corporativos avanzados siguen pendientes.
