# Efectivo multimoneda y conversiones FX — Alpha 1.4, fase 3

## Objetivo

Distinguir el efectivo realmente disponible en cada moneda de su valor convertido a la moneda base del portafolio.

## Principio contable

La moneda base es una unidad de presentación. No es una caja universal.

```text
Caja USD ── 900 USD
Caja ARS ── 100.000 ARS
Caja EUR ── 250 EUR
                 ↓ tasas actuales
       Valuación consolidada en moneda base
```

Una compra consume la moneda del activo. Si no hay saldo suficiente, la operación se rechaza, salvo que el portafolio tenga margen habilitado expresamente.

## Libro de efectivo

El ledger reconstruye cronológicamente:

1. capital inicial en la moneda base;
2. depósitos, retiros, dividendos, intereses, impuestos y gastos;
3. compras y ventas en la moneda del activo;
4. conversiones entre monedas;
5. comisiones asociadas.

Cada cuenta conserva:

- `balance`: unidades reales de la moneda;
- `cost_basis_base`: costo histórico en moneda base;
- `last_fx_rate_to_base`: última tasa histórica conocida;
- valor actual convertido;
- P&L FX no realizado.

## Conversión FX

La tabla `portfolio_fx_conversions` registra:

```text
portfolio_id
from_currency
to_currency
from_amount
to_amount
exchange_rate
pricing_mode
fee_amount
fee_currency
from_fx_rate_to_base
to_fx_rate_to_base
realized_fx_pnl_base
occurred_at
revision / borrado lógico
```

La conversión reduce la caja de origen y aumenta la de destino. Nunca genera un depósito externo.

## Resultado cambiario

El resultado FX realizado compara el valor bruto recibido con el costo histórico del efectivo entregado. Las comisiones se muestran en una métrica separada para evitar doble descuento.

El P&L FX no realizado surge de comparar la valuación actual de una caja extranjera con su costo histórico en moneda base.

## Margen

`allow_margin` pertenece a cada portafolio y comienza en `false`.

- Desactivado: ninguna compra, retiro, gasto o conversión puede dejar una caja negativa.
- Activado: se permiten saldos negativos y se informa `margin_used` convertido a moneda base.

## Edición y auditoría

Las conversiones usan el mismo estándar de seguridad de operaciones y movimientos:

- vista previa antes de guardar;
- validación de todos los eventos posteriores;
- motivo obligatorio al editar;
- borrado lógico;
- restauración;
- auditoría con antes y después.

## Migración

La migración de esquema 6:

1. crea un backup `quantlab_pre_alpha14_phase3_*.db`;
2. agrega `allow_margin` con valor `0`;
3. crea `portfolio_fx_conversions` e índices;
4. conserva íntegramente los datos previos.
