# Conexión de datos reales

## Flujo completo

```text
Navegador
  └─ fetch('/api/market/AAPL')
       └─ FastAPI: backend/api/market.py
            └─ Servicio: backend/services/market_service.py
                 └─ yfinance
                      └─ Yahoo Finance
```

El navegador nunca se conecta directamente con el proveedor financiero. La clave de esta arquitectura es que Python concentra:

- validación de símbolos;
- descarga de cotizaciones;
- normalización de respuestas;
- caché temporal;
- cálculo de variaciones;
- manejo de errores;
- indicadores del análisis cuantitativo.

## Endpoints

### Activos destacados

```http
GET /api/market
```

### Cotización individual

```http
GET /api/market/AAPL
```

También acepta, según disponibilidad del proveedor:

- `MELI`
- `GGAL`
- `BTC-USD`
- `EURUSD=X`
- `^GSPC`

### Histórico OHLCV

```http
GET /api/market/AAPL/history?period=3mo&interval=1d
```

La respuesta incluye fecha, apertura, máximo, mínimo, cierre y volumen.

### Estado del proveedor

```http
GET /api/market/provider/status
```

### Análisis cuantitativo

```http
POST /api/ai/analyze
Content-Type: application/json

{
  "symbol": "NVDA",
  "risk_profile": "moderado"
}
```

El análisis usa seis meses de cierres reales y calcula:

- media móvil de 20 ruedas;
- media móvil de 50 ruedas;
- RSI de 14 ruedas;
- volatilidad anualizada;
- tendencia;
- nivel de riesgo orientativo.

## Caché

Los activos destacados se guardan 60 segundos, las cotizaciones individuales 45 segundos y los históricos 180 segundos. Esto reduce consultas repetidas y hace que la web responda más rápido.

## Alcance y límites

`yfinance` usa APIs públicas de Yahoo Finance y está pensado para investigación y educación. Los datos pueden llegar con demora, cambiar de disponibilidad o tener restricciones de uso. Para una versión comercial se debe migrar el mismo servicio a un proveedor con licencia y API key, como Twelve Data u otro feed contratado.
