# Fundamentales y conversación — Alpha 1.6 Fase 2

## Flujo verificable

```text
Pregunta
  → planificador
  → herramienta fundamental / técnica / portafolio
  → datos normalizados
  → cálculo determinístico
  → secciones con fuentes
  → redacción opcional
  → fallback determinístico
```

## Datos fundamentales

QuantLab consulta, cuando están disponibles:

- ingresos, beneficio neto y EBITDA;
- crecimiento de ingresos y beneficios;
- margen bruto, operativo y neto;
- ROE y ROA;
- flujo operativo y flujo de caja libre;
- efectivo, deuda, liquidez corriente y rápida;
- P/E histórico y futuro, P/B, P/S y EV/EBITDA;
- dividendo, payout y precio objetivo medio del proveedor;
- sector, industria, moneda y mercado.

La cobertura se informa como completa, parcial o no disponible. Los campos ausentes no se rellenan con estimaciones silenciosas.

## Puntaje educativo

El puntaje agrega cuatro bloques normalizados:

1. calidad;
2. crecimiento;
3. fortaleza financiera;
4. valuación.

Es una herramienta de comparación y aprendizaje, no una valuación intrínseca.

## Conversación

Cada sesión conserva:

- último alcance;
- símbolos relevantes;
- mensajes del usuario y del agente;
- herramientas ejecutadas;
- fuentes y fechas.

Esto permite preguntas de seguimiento sin repetir el ticker. El contexto se limita al portafolio activo.

## LLM opcional

La interfaz `LanguageModelProvider` permite reemplazar el proveedor. La implementación inicial utiliza OpenAI Responses API mediante HTTP desde el servidor.

Guardrails:

- la clave sólo se lee de variables de entorno o `.env` local;
- el navegador nunca recibe la clave;
- el modelo sólo recibe evidencia sintetizada;
- no puede ejecutar herramientas ni modificar datos;
- no puede agregar cifras o fuentes;
- cualquier error activa fallback determinístico.

## Fuentes técnicas

- yfinance `Ticker`, `get_info`, estados financieros y datos de análisis.
- OpenAI Responses API para redacción opcional del lado servidor.
