# Alpha 1.4 Fase 5 — Platform Hardening & UX

## Objetivo

Cerrar Alpha 1.4 con una plataforma estable antes de incorporar analytics avanzados.

## API versionada

La ruta oficial es `/api/v1`. El alias `/api` se mantiene temporalmente y puede desactivarse con `QUANTLAB_LEGACY_API_ENABLED=false`.

## Proveedores de mercado

El contrato se encuentra en `backend/providers/base.py`. La implementación actual está en `backend/providers/yahoo_finance.py` y el registro en `backend/providers/registry.py`.

Para conectar un proveedor en tiempo real se debe implementar el mismo contrato y registrarlo sin modificar el servicio de portafolio.

## Calidad del dato

Las cotizaciones incluyen `price_kind`, `data_status`, `market_state`, `last_updated`, `data_age_seconds`, `status_label` y `warnings`.

Los precios manuales se guardan en `market_manual_prices`. Los cambios de ticker se registran en `market_symbol_aliases`.

## Errores y diagnóstico

Todas las respuestas de error mantienen `detail` por compatibilidad y agregan:

```json
{
  "error": {
    "code": "validation_error",
    "request_id": "identificador"
  }
}
```

El mismo identificador se devuelve en la cabecera `X-Request-ID` y aparece en los logs.

## Logs

Los logs se almacenan en `data/logs/quantlab.log`, con formato JSON y rotación automática. No se envían a servicios externos.

## Migraciones

`backend/core/migrations.py` define migraciones idempotentes ordenadas. El esquema actual es `8`. Antes de migrar desde Fase 4 se crea un backup automático.

## Experiencia de usuario

La interfaz incorpora indicador de carga, filtros de registros, ordenamiento de tablas, tema claro/oscuro, foco visible, navegación por teclado y mejoras responsive.
