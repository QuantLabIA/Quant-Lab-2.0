# Alpha 1.4 Fase 4 — Portabilidad de datos

Esta fase permite mover, revisar y recuperar los datos financieros sin editar SQLite manualmente.

## CSV genérico

La plantilla usa el esquema `quantlab-generic-csv-v1` y admite tres tipos de registro:

- `TRANSACTION`: compras y ventas.
- `CASH_MOVEMENT`: depósitos, retiros, dividendos, intereses, impuestos y gastos.
- `FX_CONVERSION`: conversiones de divisas.

El archivo puede utilizar coma, punto y coma o tabulación como separador. Las fechas aceptan ISO 8601 y formatos comunes como `dd/mm/aaaa`.

### Proceso seguro

1. El navegador lee el archivo local.
2. FastAPI valida tamaño, encabezados y tipos.
3. Pydantic normaliza cada fila.
4. Se calculan tasas FX y metadatos de activos cuando corresponde.
5. Se detectan duplicados mediante SHA-256 de los campos financieros normalizados.
6. El ledger se reconstruye cronológicamente sin escribir en SQLite.
7. La interfaz muestra filas aceptadas, rechazadas y duplicadas.
8. La confirmación vuelve a validar y guarda sólo las filas permitidas.

Las importaciones parciales son opcionales. En modo estricto, una sola fila rechazada cancela todo el lote.

## Exportaciones

Se pueden descargar:

- todos los registros en el formato genérico;
- operaciones;
- movimientos;
- conversiones FX;
- posiciones actuales;
- resumen del portafolio.

Cada exportación respeta el `portfolio_id` activo.

## Historial de importaciones

La tabla `portfolio_import_batches` registra:

- nombre y checksum del archivo;
- adaptador utilizado;
- estado del lote;
- filas aceptadas, rechazadas y duplicadas;
- reporte completo;
- fecha de creación y confirmación.

Las tablas financieras incorporan `import_fingerprint`, `import_batch_id` e `import_row_number` para mantener trazabilidad.

## Backup `.qlbackup`

Un backup es un ZIP con extensión `.qlbackup` que contiene:

```text
manifest.json
quantlab.db
```

El manifiesto informa:

- versión de QuantLab;
- versión del esquema;
- fecha de creación;
- tamaño de SQLite;
- SHA-256 de la base;
- cantidad de portafolios, operaciones y movimientos;
- nota opcional.

La copia de SQLite se genera mediante la API de backup de SQLite, por lo que es consistente incluso si la aplicación utiliza WAL.

## Restauración

Antes de reemplazar la base, QuantLab verifica:

- límite de tamaño;
- formato ZIP;
- rutas internas seguras;
- manifiesto reconocido;
- checksum SHA-256;
- `PRAGMA quick_check`;
- tablas mínimas requeridas;
- compatibilidad de la versión del esquema.

Después crea un backup automático `pre_restore`, reemplaza SQLite de forma atómica, ejecuta las migraciones pendientes y vuelve a ejecutar `PRAGMA quick_check`.

La confirmación textual obligatoria es `RESTAURAR`.

## Límites configurables

```env
QUANTLAB_MAX_CSV_BYTES=5242880
QUANTLAB_MAX_CSV_ROWS=10000
QUANTLAB_MAX_BACKUP_BYTES=104857600
```

Los valores predeterminados son 5 MB, 10.000 filas y 100 MB.

## Endpoints

```text
GET  /api/data/csv/template
POST /api/data/csv/preview
POST /api/data/csv/import
GET  /api/data/csv/imports
GET  /api/data/csv/export/{dataset}

GET  /api/data/backups
POST /api/data/backups
GET  /api/data/backups/{filename}
POST /api/data/backups/validate
POST /api/data/backups/restore
```
