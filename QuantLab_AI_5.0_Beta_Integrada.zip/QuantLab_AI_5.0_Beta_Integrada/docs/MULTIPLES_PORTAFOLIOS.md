# Múltiples portafolios — Alpha 1.4, fase 1

## Objetivo

Separar completamente configuraciones, operaciones, movimientos, activos y métricas antes de incorporar usuarios.

## Modelo

```text
portfolios
  id
  user_id          # preparado, todavía NULL
  name
  base_currency
  initial_cash
  is_archived

portfolio_transactions
  portfolio_id → portfolios.id

portfolio_cash_movements
  portfolio_id → portfolios.id

portfolio_assets
  portfolio_id → portfolios.id
  UNIQUE(portfolio_id, symbol)
```

El mismo ticker puede existir en distintos portafolios sin compartir precio manual ni metadatos locales.

## Selección activa

El backend no mantiene una selección global. El frontend guarda `quantlab.activePortfolioId` en `localStorage` y envía `portfolio_id` en cada consulta financiera. Esto evita mezclar sesiones o depender de estado mutable en el servidor.

## Archivado

`DELETE /api/portfolios/{id}` no elimina registros: establece `is_archived=1`. Las operaciones y movimientos continúan en SQLite. Debe quedar al menos un portafolio activo.

## Migración

Antes de modificar una base Alpha 1.3, QuantLab crea un backup. La configuración única se copia a `portfolios.id=1`; luego se asigna ese identificador a operaciones y movimientos. La antigua tabla de activos se reconstruye con clave compuesta por portafolio y símbolo.

## Preparación para usuarios

La tabla `portfolios` incluye `user_id` nullable. No se aplican todavía cuentas ni permisos. En la versión 2.0 se agregará la relación real con usuarios y cada consulta deberá validar propiedad.
