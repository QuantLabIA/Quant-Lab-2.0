# Instalación y actualización

## Instalación limpia

No se necesita ninguna versión anterior.

1. Descomprimir el ZIP.
2. Ejecutar `iniciar_windows.bat`.
3. Esperar a que se cree `.venv` y se instalen dependencias.
4. Usar la web desde `http://127.0.0.1:8000`.

## Actualización con datos existentes

Método recomendado:

1. Abrir la versión anterior.
2. Generar un backup `.qlbackup`.
3. Abrir QuantLab AI 5.0 Beta.
4. Restaurar el backup desde la interfaz.

Método manual:

1. Cerrar ambas versiones.
2. Copiar `data/quantlab.db` de la versión anterior.
3. Pegar el archivo en `data/quantlab.db` de esta versión.
4. Ejecutar `iniciar_windows.bat`.

El proyecto crea backups previos cuando una migración cambia el esquema.

## Actualizaciones futuras

No se deben reemplazar archivos individuales. Cada nuevo release será completo. Para actualizar, se conservarán datos mediante `.qlbackup` o copia de `quantlab.db`.
