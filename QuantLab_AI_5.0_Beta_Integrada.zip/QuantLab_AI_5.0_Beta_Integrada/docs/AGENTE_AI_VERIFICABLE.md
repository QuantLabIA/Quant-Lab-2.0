# Agente AI verificable — Alpha 1.6 Fase 1

## Objetivo

La primera fase del agente conecta la pantalla de Inteligencia AI con herramientas financieras reales de QuantLab. No depende de una API generativa externa y no improvisa cifras: el planificador selecciona herramientas, ejecuta cálculos existentes y construye una respuesta estructurada.

## Herramientas disponibles

1. `market_quote`: cotización, moneda, mercado, calidad y fecha.
2. `technical_analysis`: SMA 20/50, RSI 14, tendencia y volatilidad.
3. `portfolio_snapshot`: patrimonio, efectivo, posiciones y P&L.
4. `portfolio_analytics`: rendimiento, benchmark, drawdown, VaR/CVaR, correlación y concentración.
5. `portfolio_activity`: operaciones, movimientos, FX y eventos corporativos.
6. `asset_comparison`: comparación de dos a seis activos en moneda base.

## Flujo

```text
Consulta
  ↓
Planificador de intención
  ↓
Herramientas internas
  ↓
Fuentes + tiempos + estado de datos
  ↓
Hechos / cálculos / interpretación / riesgos / límites
  ↓
Historial SQLite por portafolio
```

## Modos de consulta

- automático;
- un activo;
- comparación;
- portafolio;
- riesgo;
- rendimiento.

## Trazabilidad

Cada respuesta registra:

- herramienta ejecutada;
- argumentos;
- éxito o error;
- duración;
- fuente;
- fecha observada;
- calidad completa, parcial o no disponible;
- mensaje del usuario y respuesta estructurada.

Las tablas nuevas son:

- `ai_analysis_sessions`;
- `ai_analysis_messages`;
- `ai_tool_runs`.

## Seguridad

- El agente no puede comprar, vender ni modificar el portafolio.
- No inventa precios cuando el proveedor falla.
- Las fallas quedan visibles en límites y fuentes.
- Separa hechos, cálculos e interpretación.
- Evita órdenes directas de compra o venta.
- Toda respuesta incluye una advertencia educativa.

## Límite de esta fase

La redacción es determinística y basada en plantillas verificables. Todavía no incorpora:

- análisis fundamental completo;
- noticias;
- un modelo de lenguaje externo;
- alertas automáticas;
- memoria semántica avanzada.

Esta decisión permite validar primero herramientas, datos, historial y barreras de seguridad.
