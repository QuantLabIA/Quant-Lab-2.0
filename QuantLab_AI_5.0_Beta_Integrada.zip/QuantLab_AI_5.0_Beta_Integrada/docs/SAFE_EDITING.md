# Edición segura y auditoría — Alpha 1.4, fase 2

## Objetivo

Permitir corregir errores de carga sin perder el registro original ni romper el libro contable.

## Principio central

Las posiciones no se editan directamente. QuantLab modifica un evento del historial y luego reconstruye todo el ledger en orden cronológico.

```text
Operación original
       ↓
Cambios propuestos
       ↓
Recalcular compras, ventas y movimientos posteriores
       ↓
Validar efectivo y tenencias
       ↓
Vista previa
       ↓
Guardar + auditoría
```

## Campos editables

### Operaciones

- símbolo;
- compra o venta;
- cantidad;
- precio;
- comisión;
- fecha y hora;
- notas;
- origen automático o manual;
- nombre, tipo, moneda y mercado del activo;
- tasa FX a moneda base.

### Movimientos

- depósito, retiro, dividendo, interés, impuesto o gasto;
- importe;
- moneda;
- activo relacionado;
- fecha y hora;
- notas;
- tasa FX.

## Vista previa

Los endpoints `/preview` no escriben en SQLite. Construyen una versión temporal del historial y comparan:

- efectivo anterior y posterior;
- diferencia de efectivo;
- P&L realizado;
- cantidad anterior y posterior del activo;
- costo acumulado anterior y posterior.

Si el historial propuesto es inválido, se devuelve un error 422 antes de guardar.

## Borrado lógico

Las tablas `portfolio_transactions` y `portfolio_cash_movements` incorporan:

```text
is_deleted
deleted_at
deleted_reason
updated_at
revision
```

Un registro eliminado:

- sigue almacenado;
- no participa en el ledger;
- puede consultarse con `include_deleted=true`;
- puede restaurarse si el historial vuelve a ser válido.

## Auditoría

La tabla `portfolio_audit_log` guarda:

- portafolio;
- tipo e identificador del elemento;
- acción `CREATE`, `UPDATE`, `DELETE` o `RESTORE`;
- JSON del estado anterior;
- JSON del estado posterior;
- motivo;
- fecha.

Esto permite saber qué cambió sin depender únicamente del valor actual de la fila.

## Seguridad de la restauración

Restaurar no significa activar la fila sin controles. Antes de hacerlo, QuantLab agrega temporalmente el registro al historial activo y recalcula el ledger. La restauración se rechaza si produciría:

- venta de unidades inexistentes;
- efectivo negativo;
- retiro, impuesto o gasto sin saldo;
- secuencia cronológica inconsistente.

## Migración

Una base Alpha 1.4 fase 1 recibe un backup automático antes de agregar las nuevas columnas y la tabla de auditoría. Los registros existentes quedan con:

```text
is_deleted = 0
revision = 1
updated_at = created_at
```

La migración se registra como versión `5` en `schema_migrations`.
