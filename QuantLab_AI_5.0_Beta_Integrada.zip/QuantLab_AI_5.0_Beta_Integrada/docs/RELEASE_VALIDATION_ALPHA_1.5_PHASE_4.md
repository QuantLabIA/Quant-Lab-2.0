# Validación de release — Alpha 1.5 fase 4

- 92 pruebas automatizadas aprobadas.
- Backend completo compilado con `py_compile`.
- JavaScript validado con `node --check`.
- API v1 de overview, comparador y exportación comprobada.
- Migración de esquema 11 a 12 y backup previo comprobados.
- Sortino, VaR, CVaR, beta, tracking error y contribuciones validados con series controladas.
- Matriz de correlación y comparador probados sin conexión externa.
- Frontend revisado para identificadores únicos y controles conectados.
- Paquete final sin bases, logs, entornos virtuales ni datos de prueba.
