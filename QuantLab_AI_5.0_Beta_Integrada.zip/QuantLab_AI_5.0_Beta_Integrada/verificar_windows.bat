@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
title QuantLab AI 5.0 Beta - Verificacion

echo.
echo ============================================================
echo             VERIFICACION DE QUANTLAB AI 5.0
echo ============================================================
echo.

if not exist ".venv\Scripts\python.exe" (
    echo [ERROR] Primero ejecuta iniciar_windows.bat para crear el entorno.
    goto :error
)

set "PY=.venv\Scripts\python.exe"

echo [1/5] Version del proyecto:
type VERSION

echo.
echo [2/5] Comprobando dependencias...
"%PY%" -m pip check
if errorlevel 1 goto :error

echo.
echo [3/5] Compilando backend...
"%PY%" -m compileall -q backend
if errorlevel 1 goto :error

echo.
echo [4/5] Ejecutando pruebas automatizadas...
"%PY%" -m pytest -q
if errorlevel 1 goto :error

echo.
echo [5/5] Verificacion terminada correctamente.
echo El proyecto esta listo para iniciar con iniciar_windows.bat.
echo.
pause
exit /b 0

:error
echo.
echo [ERROR] La verificacion detecto un problema.
echo Copia el texto de esta ventana para poder revisarlo.
echo.
pause
exit /b 1
